#ifndef _FLOAT_H
#define _FLOAT_H

#ifdef __FLT_EVAL_METHOD__
#define FLT_EVAL_METHOD __FLT_EVAL_METHOD__
#else
#define FLT_EVAL_METHOD 0
#endif

#include <arch/float.h>

#endif
