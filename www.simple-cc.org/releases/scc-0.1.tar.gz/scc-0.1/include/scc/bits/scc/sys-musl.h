#define LDBIN "ld"
#define ASBIN "as"

/* configure below your system linker command line */
#define GCCLIBPATH "/usr/lib/gcc/x86_64-unknown-linux-gnu/10.2/"

/* configure below your standard sys include paths */
char *sysincludes[] = {
	LIBPREFIX "/include",
	"%p/include/",
	NULL
};

char *ldcmd[] = {
	"-static",
	"-z","nodefaultlib",
        %NOPIE%
	"-o","%o",
	"-L","%p/lib/",
	"-L",GCCLIBPATH,
	"-L",LIBPREFIX "/lib",
	LIBPREFIX "/lib/Scrt1.o",
	LIBPREFIX "/lib/crti.o",
	GCCLIBPATH "/crtbeginS.o",
	"%c",
	GCCLIBPATH "/crtendS.o",
	LIBPREFIX "/lib/crtn.o",
	"-lc",
	"-lgcc",
	"-lgcc_eh",
	NULL
};

/* configure below your system assembler command line */
char *ascmd[] = {
        "-o", "%o",
        NULL
};
