#include <scc/mach.h>
#include <scc/scc.h>

#include "../as.h"

unsigned long long maxaddr = 0xFFFFFFFFFFFFFFFF;
int endian = LITTLE_ENDIAN;

void
iarch(void)
{
}
