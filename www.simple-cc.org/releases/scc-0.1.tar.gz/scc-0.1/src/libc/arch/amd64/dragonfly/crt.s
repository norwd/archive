	.include	"../crt-posix.s"
