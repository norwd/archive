
/* error.c */
void error(const char *msg, ...);

/* usocket.c */
int serve_socket();
void remove_socket(int ls);
int accept_connection(int ls);
int connect_socket();

/* signals.c */
int install_signal_forwarders();
