/*
    stdin mix - a mixer/multiplexer for stdin to processes
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided COPYING file.
*/
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <errno.h>

#include "main.h"

void error(const char *msg, ...)
{
    va_list v;

    va_start(v, msg);
    vfprintf(stderr, msg, v);
    putc('\n', stderr);
    fprintf(stderr, " errno %i: %s\n", errno, strerror(errno));
    exit(-1);
}

