/*
    stdin mix - a mixer/multiplexer for stdin to processes
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided COPYING file.
*/
#include <signal.h>

#include "main.h"

static int child;

static void forward_signals_to_child_handler(int val)
{
    kill(child, val);
}

int install_signal_forwarders(int _child)
{
  struct sigaction act;

  child = _child;

  act.sa_handler = forward_signals_to_child_handler;
  /* Reset the mask */
  memset(&act.sa_mask,0,sizeof(act.sa_mask));
  act.sa_flags = 0;

  sigaction(SIGTERM, &act, 0);
  sigaction(SIGINT, &act, 0);
}
