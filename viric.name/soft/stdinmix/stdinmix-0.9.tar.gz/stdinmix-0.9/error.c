/*
    stdin mix - a mixer/multiplexer for stdin to processes
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided COPYING file.
*/
#include <stdio.h>
#include <stdlib.h>

#include "main.h"

void error(const char *msg)
{
    perror(msg);
    exit(-1);
}

