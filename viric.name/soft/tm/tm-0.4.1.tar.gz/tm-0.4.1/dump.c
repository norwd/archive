/*
    Terminal Mixer - multi-point multi-user access to terminal applications
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided COPYING file.
*/
#include <stdio.h>
#include <sys/select.h>
#include <stdarg.h>

#include "main.h"

int should_dump = 0;

void dump_line(const char *msg, ...)
{
    va_list v;
    FILE *f;

    if (!should_dump) return;

    va_start(v, msg);
    f = fopen("/tmp/dump.txt", "a");
    if (f == 0) return;

    vfprintf(f, msg, v);
    fclose(f);
}

void hex_dump(const char *head, const unsigned char *data, int len)
{
    int i;
    FILE *f;

    if (!should_dump) return;

    f = fopen("/tmp/dump.txt", "a");
    if (f == 0) return;

    fprintf(f, "%s (%i): \"", head, len);
    for(i=0;i<len; ++i)
    {
        int c;
        c = data[i];
        if (c >= 32 && c <= 127)
            fprintf(f, "%c", c);
        else if (c == 0x0a)
            fprintf(f, "\\n");
        else
            fprintf(f, "\\x%02x", c);
    }
    fprintf(f, "\"\n");
    fclose(f);
}

void fdset_dump(fd_set *set, int maxfd)
{
  int i;

  fprintf(stderr, "fdset:");
  for (i=0; i <= maxfd; ++i)
    if (FD_ISSET(i, set))
      fprintf(stderr, " %i", i);
  fprintf(stderr, "\n");
}
