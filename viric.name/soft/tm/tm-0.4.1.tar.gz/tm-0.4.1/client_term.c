/*
    Terminal Mixer - multi-point multi-user access to terminal applications
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided COPYING file.
*/
#include <unistd.h>

void send_to_client_stdout(const char *buf, int len)
{
    write(1, buf, len);
}
