enum Transport
{
    UNIX,
    TCP,
    ETHERNET
};

struct Command_line {
    int is_server;
    char *unix_path; /* path or 0 if not to be used */
    int tcp_port;
    char *eth_device;
    int eth_port;
    struct {
        int serve_tcp; /* yes/no */
        int serve_unix; /* yes/no */
        int serve_eth; /* yes/no */
        int max_served; /* how many */
        char run_in_subterminal; /* use opentty */
        char echo_in_local_terminal;
        char use_blocking_sockets;
        char send_xterm_resize;
        char client_may_close_app_stdin;
        char client_can_write;
        char nohup; /* detach from terminal as nohup */
        char **command; /* ordono por exec */
    } s_param;
    struct {
        enum Transport transport;
        unsigned int wait_until_char; /* -1, don't wait. */
        char raw_mode; /* bool. else cooked */
        char * server_address;
    } c_param;
    int buffer_size;
};


/* error.c */
void not_implemented(const char *msg, ...);
void error(const char *msg, ...);
void warning(const char *msg, ...);
void debugmsg(const char *msg, ...);
void finish(int ret);

/* signals.c */
void install_signal_forwarders();
void program_timeout(int secs);
void unprogram_timeout();
int did_timeout_happen();
void ignore_sighup();

/* main.c */
extern int app_stdin;
extern int app_stdout;
extern int app_stderr;
extern struct Command_line command_line;
int max(int a, int b);
int min(int a, int b);

/* gen_sockets.c */
extern char *stream_buffer;
extern int stream_buffer_size;
extern char *ostream_buffer;
extern int ostream_buffer_size;
extern char *ostream_buffer2;
extern int ostream_buffer2_size;
void init_stream_buffers();
void welcome_new_client_socket(int s);

/* server.c */
int server();

/* client.c */ 
int client();

/* app_term.c */
int fork_app(char * const command[]);
void pass_winsize_to_slave();

/* server_term.c */
void prepare_user_terminal();
void restore_user_terminal();

/* xterm.c */
char * get_xterm_resize_string();

/* dump.c */
extern int should_dump;
void hex_dump(const char *head, const unsigned char *data, int len);
void dump_line(const char *msg, ...);

/* eth_proto.c */
enum Eth_type
{
    ETH_SERVER,
    ETH_CLIENT
};
void eth_proto_init();
int eth_proto_open(enum Eth_type type);
int eth_proto_recv(char *data, int size);
int eth_proto_send(const char *data, int size);
int eth_proto_allow_sending();
int eth_proto_max_send();
int eth_proto_process_timeouts();
