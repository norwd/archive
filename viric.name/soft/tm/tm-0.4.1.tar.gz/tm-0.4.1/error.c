/*
    Terminal Mixer - multi-point multi-user access to terminal applications
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided COPYING file.
*/
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <errno.h>

#include "main.h"

void error(const char *msg, ...)
{
    va_list v;

    va_start(v, msg);
    vfprintf(stderr, msg, v);
    putc('\n', stderr);
    fprintf(stderr, " errno %i: %s\n", errno, strerror(errno));
    finish(-1);
}

void warning(const char *msg, ...)
{
    va_list v;

    va_start(v, msg);
    vfprintf(stderr, msg, v);
    putc('\n', stderr);
}

void debugmsg(const char *msg, ...)
{
    va_list v;

    va_start(v, msg);
    if (0)
    {
        vfprintf(stderr, msg, v);
        putc('\n', stderr);
    }
}

void not_implemented(const char *msg, ...)
{
    va_list v;

    va_start(v, msg);
    fprintf(stderr, "Not implemented: ");
    vfprintf(stderr, msg, v);
    putc('\n', stderr);
    fprintf(stderr, " errno %i: %s\n", errno, strerror(errno));
    finish(-1);
}
