int eth_open(char *eth, enum Eth_type type);
int eth_recv(char *buf, int len, char *partner_mac);
int eth_send(char *dev, char *mac, void *p, int len);
