typedef void (*Net_c_prepare_read_fdset)(fd_set *read_set, int *maxfd);
/* Send -1 on eof */
typedef int (*Net_c_process_read_fdset)(fd_set *read_set);
typedef void (*Net_c_send)(const char *buf, size_t len);

/* unix_server.c */
void s_unix_update_served(int new);
void s_unix_shutdown();
void s_unix_prepare_read_fdset(fd_set *read_set, int *maxfd);
void s_unix_process_read_fdset(fd_set *read_set);
void get_unix_path();
void s_unix_send_to_connected(const char *buffer, size_t size);

/* app_control.c */
void app_control_start();
void app_control_shutdown();
void app_control_prepare_read_fdset(fd_set *read_set, int *maxfd);
int  app_control_process_read_fdset(fd_set *read_set);
void app_control_remote_send_to_stdin(const char *buffer, size_t size);
void app_control_local_send_to_stdin(const char *buffer, size_t size);

/* unix_client.c */
void c_unix_connect_socket();
/* Send -1 on eof */
void c_unix_prepare_read_fdset(fd_set *read_set, int *maxfd);
int c_unix_process_read_fdset(fd_set *read_set);
void c_unix_send(const char *buf, size_t len);

/* client_term.c */
void send_to_client_stdout(const char *buf, int len);

/* tcp_server.c */
void s_tcp_update_served(int new);
void s_tcp_shutdown();
void s_tcp_prepare_read_fdset(fd_set *read_set, int *maxfd);
void s_tcp_process_read_fdset(fd_set *read_set);
void s_tcp_send_to_connected(const char *buffer, size_t size);

/* eth_server.c */
void s_eth_init();
void s_eth_shutdown();
void s_eth_prepare_read_fdset(fd_set *read_set, int *maxfd);
void s_eth_process_read_fdset(fd_set *read_set);
void s_eth_send_to_connected(const char *buffer, size_t size);

/* eth_server.c */
void c_eth_init();
void c_eth_shutdown();
void c_eth_prepare_read_fdset(fd_set *read_set, int *maxfd);
int  c_eth_process_read_fdset(fd_set *read_set);
void c_eth_send_to_connected(const char *buffer, size_t size);

/* flow.c */
void avoid_sending(fd_set *read_set);
