/*
    stdin mix - a mixer/multiplexer for stdin to processes
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided COPYING file.
*/
#include <unistd.h>
#include <sys/types.h>
#include <sys/select.h>
#include "main.h"
#include "handlers.h"
#include "filter.h"

static int myfd = -1;

extern struct FilterRules *client_recv_fr;

void c_eth_init()
{
    eth_proto_init();
    myfd = eth_proto_open(ETH_CLIENT);
    if (myfd < 0)
        error("Cannot eth_proto_open");
}

void c_eth_shutdown()
{
    if (myfd >= 0)
        close(myfd);
}

void c_eth_prepare_read_fdset(fd_set *read_set, int *maxfd)
{
    FD_SET(myfd, read_set);
    *maxfd = max(*maxfd, myfd);
    if (!eth_proto_allow_sending())
        avoid_sending(read_set);
}

/* Send -1 on eof */
int c_eth_process_read_fdset(fd_set *read_set)
{
    if (FD_ISSET(myfd, read_set))
    {
        int res;
        int olen;
        res = eth_proto_recv(stream_buffer, stream_buffer_size);
        if (res < 0)
            return 1; /* ignore it */
        if (res == 0) /* EOF */
        {
            filter_flush(client_recv_fr, ostream_buffer, &olen);
            if (olen > 0)
                send_to_client_stdout(ostream_buffer, olen);
            return -1;
        }
        hex_dump("recv_unix_client",stream_buffer, res);

        filter_stream(client_recv_fr, ostream_buffer, &olen, stream_buffer,
                res);
        if (olen > 0)
            send_to_client_stdout(ostream_buffer, olen);
    }

    return 0;
}

void c_eth_send_to_connected(const char *buffer, size_t size)
{
    eth_proto_send(buffer, size);
}
