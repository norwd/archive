/*
    Terminal Mixer - multi-point multi-user access to terminal applications
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided COPYING file.
*/
#include <sys/ioctl.h>
#include <termios.h>
#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include "main.h"

static char xterm_resize_string[100];

char * get_xterm_resize_string()
{
    int rows, cols;
    extern struct winsize app_winsize; /* from app_term.c */

    if (isatty(0))
    {
      int res;
      /* Get rows and cols from our connection to the terminal: fd 0 */
      res = ioctl(0, TIOCGWINSZ, &app_winsize);
      if (res == -1)
          error("ioctl TIOCGWINSZ");
    }
    rows = app_winsize.ws_row;
    cols = app_winsize.ws_col;

    /* Prepare the xterm resize string */
    snprintf(xterm_resize_string, sizeof xterm_resize_string,
            "\033[8;%i;%it", rows, cols);

    return xterm_resize_string;
}
