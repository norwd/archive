/*
    Terminal Mixer - multi-point multi-user access to terminal applications
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided COPYING file.
*/
#include <unistd.h>
#include <sys/types.h>
#include <sys/select.h>
#include "main.h"
#include "handlers.h"

static int myfd = -1;

void s_eth_init()
{
    eth_proto_init();
    myfd = eth_proto_open(ETH_SERVER);
    if (myfd < 0)
        error("Cannot eth_proto_open");
}

void s_eth_shutdown()
{
    eth_proto_send(0, 0);
    if (myfd >= 0)
        close(myfd);
}

void s_eth_prepare_read_fdset(fd_set *read_set, int *maxfd)
{
    FD_SET(myfd, read_set);
    *maxfd = max(*maxfd, myfd);

    if (!eth_proto_allow_sending())
        avoid_sending(read_set);
}

void s_eth_process_read_fdset(fd_set *read_set)
{
    if (FD_ISSET(myfd, read_set))
    {
        int res;

        res = eth_proto_recv(stream_buffer, stream_buffer_size);

        if (res >= 0)
            app_control_remote_send_to_stdin(stream_buffer, res);
    }
}

void s_eth_send_to_connected(const char *buffer, size_t size)
{
    eth_proto_send(buffer, size);
}
