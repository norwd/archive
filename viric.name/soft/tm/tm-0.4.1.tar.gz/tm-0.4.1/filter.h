struct FilterRules;
struct FFilter;

typedef void (*Fcallback)(struct FilterRules *fr, const struct FFilter *ff,
        char *obuf, int *olen, const char *ibuf, int pos);

/* TRUE if match */
typedef int (*Ffunction)(struct FFilter *ff, unsigned char c);

typedef void (*Freset)(struct FFilter *ff);

struct FFilter {
    /* Static */
    Ffunction function;
    Freset reset;
    Fcallback callback;

    int matched;
};

struct FilterRules {
    int nfilters;
    struct FFilter **filters;
    unsigned char *fbuffer;
    int fbuffer_len;
    int fbuffer_allocated;
};

void add_ffilter(struct FilterRules *fr, struct FFilter *ff);
struct FilterRules * new_filter_rules();
void filter_stream(struct FilterRules *fr, char *obuf, int *olen, const char *buffer, int len);
void filter_flush(struct FilterRules *fr, char *obuf, int *olen);

/* filter_string.c */
struct FFilter *new_fstring(char *p);
struct FFilter *new_fstring_len(char *p, int len);

/* filter_telnet.c */
struct FFilter *new_ftelnet();

/* filter_tildes.c */
struct FFilter *new_ftildes();
