/*
    Terminal Mixer - multi-point multi-user access to terminal applications
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided COPYING file.
*/
#include <stdlib.h>
#include <string.h>
#include "filter.h"
#include "main.h"

struct FTildes
{
    struct FFilter base;
};

static void ftildes_reset(struct FFilter *ff)
{
    ff->matched = 0;
}

static int ftildes_function(struct FFilter *ff, unsigned char c)
{
    struct FTildes *fs = (struct FTildes *) ff;

    dump_line("ftildes: base.matched: %i\n", fs->base.matched);
    switch(fs->base.matched)
    {
        case 0:
            if (c == '~')
                fs->base.matched++;
            else
                fs->base.matched = 0;
            break;
        case 1:
            if (c == '~')
                fs->base.matched++;
            else
                fs->base.matched = 0;
            break;
        case 2:
            if (c == '.')
            {
                fs->base.matched++;
                return 1;
            }
            else if (c == '~')
            {
                fs->base.matched++;
                return 1;
            } else
                fs->base.matched = 0;
            break;
        default:
            fs->base.matched = 0;
    }
    return 0;
}

struct FFilter *new_ftildes(char *p)
{
    struct FTildes *fs;
    fs = (struct FTildes *) malloc(sizeof(*fs));

    fs->base.matched = 0;
    fs->base.function = ftildes_function;
    fs->base.reset = ftildes_reset;
    fs->base.callback = 0;

    return (struct FFilter *) fs;
}

struct FFilter *new_ftildes_len(char *p, int len)
{
    struct FTildes *fs;
    fs = (struct FTildes *) malloc(sizeof(*fs));

    fs->base.matched = 0;
    fs->base.function = ftildes_function;
    fs->base.reset = ftildes_reset;
    fs->base.callback = 0;

    return (struct FFilter *) fs;
}
