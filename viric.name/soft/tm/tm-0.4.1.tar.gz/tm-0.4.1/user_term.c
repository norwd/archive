/*
    Terminal Mixer - multi-point multi-user access to terminal applications
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided COPYING file.
*/
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <termios.h>

#include "main.h"

static int is_tios_saved = 0;
static struct termios saved_tios;

void prepare_user_terminal()
{
    int res;
    struct termios tios;

    res = tcgetattr(1, &tios);
    if (res == -1)
    {
        debugmsg("tcgetattr(1) failed - not a terminal");
        return;
    }

    memcpy(&saved_tios, &tios, sizeof(struct termios));
    is_tios_saved = 1;

    cfmakeraw(&tios);
    tios.c_lflag &= ~ECHO;

    res = tcsetattr(1, TCSANOW, &tios);
    if (res == -1)
        debugmsg("tcsetattr(1) failed - not a terminal");
}

void restore_user_terminal()
{
    int res;
    res = tcsetattr(1, TCSANOW, &saved_tios);
    if (res == -1)
        debugmsg("tcsetatttr failed: %s", strerror(errno));
}

void finish(int ret)
{
    if (is_tios_saved)
        restore_user_terminal();
    exit(ret);
}
