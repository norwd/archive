/*
    Terminal Mixer - multi-point multi-user access to terminal applications
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided COPYING file.
*/
#include <unistd.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <sys/socket.h>
#include "main.h"

char *stream_buffer = 0;
char *ostream_buffer = 0;
char *ostream_buffer2 = 0;
int stream_buffer_size;
int ostream_buffer_size;
int ostream_buffer2_size;

void init_stream_buffers()
{
    if (stream_buffer == 0)
    {
        int eth_buf;
        assert(command_line.buffer_size > 0);

        stream_buffer_size = command_line.buffer_size;
#ifdef linux
        if ((command_line.is_server && command_line.s_param.serve_eth)
                || (!command_line.is_server && command_line.c_param.transport == ETHERNET))
        {
            eth_buf = eth_proto_max_send();
            stream_buffer_size = min(command_line.buffer_size, eth_buf);
        }
#endif
        stream_buffer = (char *) malloc(stream_buffer_size);

        ostream_buffer_size = stream_buffer_size;
        ostream_buffer = (char *) malloc(ostream_buffer_size);
        ostream_buffer2_size = stream_buffer_size;
        ostream_buffer2 = (char *) malloc(ostream_buffer_size);
    }
}

static void send_xterm_resize_string_to_socket(int s)
{
    char *term;
    term = getenv("TERM");
    /* I prefer it to send the xterm string always. */
    if (1 || term == 0 || strcmp(term, "xterm") == 0)
    {
        char *xterm_str;
        xterm_str = get_xterm_resize_string();
          hex_dump("xterm_resize", xterm_str, strlen(xterm_str));
        send(s, xterm_str, strlen(xterm_str), 0);
        hex_dump("xterm string sent", xterm_str, strlen(xterm_str));
    }
}

static void telnet_send_noecho(int s)
{
  char seq[] = { 255 /*IAC*/, 251 /*WILL*/, 1 /*ECHO*/ };
  hex_dump("telnet_send_noecho", seq, sizeof seq);
  send(s, seq, sizeof seq, 0);
}

static void telnet_send_suppress_go_ahead(int s)
{
  char seq[] = { 255 /*IAC*/, 251 /*WILL*/, 3 /*ECHO*/ };
  hex_dump("telnet_send_suppress_go_ahead", seq, sizeof seq);
  send(s, seq, sizeof seq, 0);
}

void welcome_new_client_socket(int s)
{
    if (command_line.s_param.run_in_subterminal)
    {
        telnet_send_noecho(s);
        telnet_send_suppress_go_ahead(s);
    }
    if (command_line.s_param.send_xterm_resize)
        send_xterm_resize_string_to_socket(s);
}
