/*
    Terminal Mixer - multi-point multi-user access to terminal applications
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided COPYING file.
*/
#include <stdlib.h>
#include <unistd.h>
#include <sys/select.h>

#include "main.h"
#include "handlers.h"

void avoid_sending(fd_set *read_set)
{
    dump_line("Avoid sending\n");
    if (command_line.is_server)
    {
        if (app_stdout >= 0)
            FD_CLR(app_stdout, read_set);
        if (app_stderr >= 0)
            FD_CLR(app_stderr, read_set);
    }
    else
    {
            FD_CLR(0, read_set); /* client terminal stdin */
    }
}
