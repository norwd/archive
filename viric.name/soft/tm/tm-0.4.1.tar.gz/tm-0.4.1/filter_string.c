/*
    Terminal Mixer - multi-point multi-user access to terminal applications
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided COPYING file.
*/
#include <stdlib.h>
#include <string.h>
#include "filter.h"

struct FString
{
    struct FFilter base;
    unsigned char *p;
    int len;
};

static void fstring_reset(struct FFilter *ff)
{
    ff->matched = 0;
}

static int fstring_function(struct FFilter *ff, unsigned char c)
{
    struct FString *fs = (struct FString *) ff;

    if (fs->p[fs->base.matched] == c)
        fs->base.matched++;
    else
    {
        /* A SAC */
        if (fs->p[0] == c)
            fs->base.matched = 1;
        else
            fs->base.matched = 0;
    }

    if (fs->base.matched == fs->len)
        return 1;
    return 0;
}

struct FFilter *new_fstring(char *p)
{
    struct FString *fs;
    fs = (struct FString *) malloc(sizeof(*fs));

    fs->p = strdup(p);
    fs->len = strlen(p);
    fs->base.matched = 0;
    fs->base.function = fstring_function;
    fs->base.reset = fstring_reset;
    fs->base.callback = 0;

    return (struct FFilter *) fs;
}

struct FFilter *new_fstring_len(char *p, int len)
{
    struct FString *fs;
    fs = (struct FString *) malloc(sizeof(*fs));

    fs->p = strdup(p);
    fs->len = len;
    fs->base.matched = 0;
    fs->base.function = fstring_function;
    fs->base.reset = fstring_reset;
    fs->base.callback = 0;

    return (struct FFilter *) fs;
}
