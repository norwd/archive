/*
    Terminal Mixer - multi-point multi-user access to terminal applications
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided COPYING file.
*/
#include <stdio.h>
#include <string.h>

#include "filter.h"

char base[] = "El val dilluns vaig provar el tatami d'en valeri\n";

int main()
{
    int i;
    char obuf[sizeof base];
    struct FilterRules *fr;
    struct FFilter *ff;
    fr = new_filter_rules();

    ff = new_fstring("val");
    add_ffilter(fr, ff);
    ff = new_fstring("tatami");
    add_ffilter(fr, ff);

    for(i=1; i < sizeof(base)-1; ++i)
    {
        int olen;
        printf("test %i:\n", i);
        if (i == 17)
            olen=0;
        filter_stream(fr, obuf, &olen, base, i);
        filter_stream(fr, obuf + olen, &olen, base + i, sizeof(base) - i);
        filter_flush(fr, obuf + olen, &olen);
        printf("%s", obuf);
    }

    {
        int olen = 0;
        printf("test po litere:\n");
        for(i=0; i < sizeof(base); ++i)
        {
            int tlen;
            filter_stream(fr, obuf + olen, &tlen, base + i, 1);
            olen += tlen;
        }
        filter_flush(fr, obuf + olen, &olen);
        printf("%s", obuf);
    }

    return 0;
}
