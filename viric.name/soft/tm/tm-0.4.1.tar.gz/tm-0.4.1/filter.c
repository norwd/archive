/*
    Terminal Mixer - multi-point multi-user access to terminal applications
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided COPYING file.
*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "main.h"

#include "filter.h"

void add_ffilter(struct FilterRules *fr, struct FFilter *ff)
{
    fr->nfilters += 1;
    fr->filters = (struct FFilter **) realloc(fr->filters,
            sizeof(*fr->filters) * fr->nfilters);
    if (fr->filters == 0) error("realloc failed.");

    fr->filters[fr->nfilters-1] = ff;
    ff->matched = 0;
}

struct FilterRules * new_filter_rules()
{
    struct FilterRules *fr;
    fr = (struct FilterRules *) malloc(sizeof(*fr));
    if (fr == 0) error("malloc failed.");

    fr->nfilters = 0;
    fr->filters = 0; /* null for realloc */
    fr->fbuffer = 0;
    fr->fbuffer_len = 0;
    fr->fbuffer_allocated = 0;

    return fr;
}

/* We want to access index even before the 'buffer' limits.
 * Those are at fr->fbuffer, and referred as -X indexes. */
static int get_char(struct FilterRules *fr, const unsigned char *buffer, int pos)
{
    if (pos >= 0)
        return buffer[pos];
    else
    {
        if (-pos > fr->fbuffer_len)
            return -1;
        /* pos is negative */
        return fr->fbuffer[fr->fbuffer_len + pos];
    }
}

static int set_char(struct FilterRules *fr, unsigned char *buffer, int pos, int c)
{
    if (pos >= 0)
    {
        buffer[pos] = c;
        return buffer[pos];
    }
    else
    {
        if (-pos > fr->fbuffer_len)
            return -1;
        fr->fbuffer[fr->fbuffer_len - pos] = c;
        return fr->fbuffer[fr->fbuffer_len - pos];
    }
}

/* Return 1 if matches */
static int apply_ffilter(struct FilterRules *fr, struct FFilter *ff,
        char *obuf, int *olen, const unsigned char *buffer, int pos)
{
    int res;

    res = ff->function(ff, buffer[pos]);
    if (res)
    {
        /* String matches */
        if (ff->callback)
        {
            int shift;
            shift = pos - ff->matched;
            /* Call callback */
            ff->callback(fr, ff, obuf, olen, buffer, shift);
        }
        return 1;
    }
    return 0;
}

static void reset_matched(struct FilterRules *fr)
{
    int i;
    for (i=0; i < fr->nfilters; ++i)
    {
            struct FFilter *ff;
            ff = fr->filters[i];
            ff->matched = 0;
            if (ff->reset)
                ff->reset(ff);
    }
}

void filter_stream(struct FilterRules *fr, char *obuf, int *olen, const char *buffer, int len)
{
    int i;

    int ipos;
    int max_matched;

    *olen = 0;
    ipos = - fr->fbuffer_len;
    max_matched = fr->fbuffer_len;
    for(i=0; i< len; ++i)
    { /* each char */
        int j;
        int old_max_matched = max_matched;
        int found = 0;
        max_matched = 0;
        /*printf("Try '%c'...\n", buffer[i]);*/
        for (j=0; j < fr->nfilters; ++j)
        {
            struct FFilter *ff;
            ff = fr->filters[j];
            found = apply_ffilter(fr, ff, obuf, olen, buffer, i);
            max_matched = max(max_matched, ff->matched);
            if (found)
                break;
        }
        /* Some chars may not be needed for the filters
         * already. */
        /*printf("ipos: %i\n", ipos);*/
        if (found)
        {
            /*printf("[match!]\n");*/
            reset_matched(fr);
            /* The longest string will be matched, sure. Right?*/
            ipos += max_matched;
            max_matched = 0;
        }
        else
        {
            int freed = old_max_matched + 1 /* new char */ - max_matched;
            for(j=0; j < freed; ++j)
            {
                obuf[(*olen)++] = get_char(fr, buffer, ipos++);
            }
        }
    }
    if (max_matched > fr->fbuffer_allocated)
    {
        fr->fbuffer = realloc(fr->fbuffer, max_matched);
        if (fr->fbuffer == 0) error("Cannot allocate fbuffer");
    }
    /* Copy only new data from buffer */
    {
        int start_new_data;
        int size_cpy;
        int offset;
        size_cpy = max_matched;
        start_new_data = len - max_matched;
        offset = 0;
        if (start_new_data < 0)
        {
            offset += (-start_new_data);
            size_cpy -= (-start_new_data);
            start_new_data = 0;
        }
        memcpy(fr->fbuffer + offset, buffer + start_new_data, size_cpy);
        fr->fbuffer_len = max_matched;
    }
}

void filter_flush(struct FilterRules *fr, char *obuf, int *olen)
{
    memcpy(obuf, fr->fbuffer, fr->fbuffer_len);
    *olen = fr->fbuffer_len;
    fr->fbuffer_len = 0;
}
