/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class Scaler;
class CoefsImage;
class FloatImage;
class ActionCreator;

class Trianta : public ImproveRawPlane
{
protected:
    float threshold;
    int WSMM_winsize;
    int WSMM_halfsize;
    float WSMM_tau;
    int hf_kernel_size;
    int hf_kernel_size_half;
    float att_constant_mu;
    float hf_sigma_kernel;
    float lf_sigma_kernel;
    int lf_kernel_size;
    int lf_kernel_size_half;
    bool give_thresholding;

private:
    /*! The initial floatplane, which will be projected */
    FloatPlane reference;
    /*! Where the result will be stored */
    FloatPlane *result;

    float *hf_kernel;
    float *lf_kernel;

    unsigned int width;
    unsigned int height;

    Qtable qtable;

    CoefsPlane coefs;

    void set_DCT_constraint();
    void start_restoration();
    void decompress_normal();
    float get_gradient_x(int x, int y);
    float get_gradient_y(int x, int y);
    float get_gaussian_wb(int x, int y);
    void get_WSMM(int x, int y, float *A, float *B, float *C);
    void get_VxVy(int x, int y, float A, float B, float *Vx, float *Vy);
    void hf_filter(int x, int y, float A, float B, float C);
    void lf_filter(int x, int y);
    float get_gaussian_lf(int x, int y);
    void prepare_lf_kernel();
    void apply_per_pixel();
    void prepare_parameters();

public:
    Trianta();
    ~Trianta();

	void prepare(const CoefsPlane *coefs,
            const FloatPlane *initial);
	FloatPlane * apply();
};

class TriantaCreator : public ActionCreator
{
    TriantaCreator();

public:
    static void init();

    ImproveRawPlane * createImproveRawPlane() const;
	bool isapplicable(const JPEGParameters &p);
};
