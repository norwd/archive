/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class CoefsPlane;
class FloatPlane;

class Nosratinia : public ImproveRawPlane
{
protected:
    unsigned int shifts;
private:
    int min_shift;
    int max_shift;

    CoefsPlane DCTmin;
    CoefsPlane DCTmax;
    CoefsPlane DCTimage;

    /*! Temporary bitmap, which will have the final image. */
    FloatPlane bitmap;
    /*! The initial floatplane, from which apply Nosratinia */
    FloatPlane reference;
    /*! We use this image for adding other images, and then averagin */
    FloatPlane sums;
    /*! Counts how many additions we made to sums */
    unsigned int nsums;

    /*! Width in blocks * 8 */
    unsigned int width;
    /*! Height in blocks * 8 */
    unsigned int height;

    Qtable qtable;

    CoefsPlane coefs;

    void start_restoration();
    void average_bitmap();
    void loopshifts();
    void quantize();
    void set_DCT_constraint();
    void calculate_shifts();
    void add2sums(FloatPlane &from);
    void project(FloatPlane &out);

public:
    Nosratinia();
    virtual ~Nosratinia() {};

	void prepare(const CoefsPlane *coefs,
            const FloatPlane *initial);
	FloatPlane * apply();
    bool getConfiguredEnv();
};

class NosratiniaCreator : public ActionCreator
{
    NosratiniaCreator();

public:
    static void init();

    ImproveRawPlane * createImproveRawPlane() const;
	bool isapplicable(const JPEGParameters &p);
};
