/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <ActionType.h>
#include <MeasureResult.h>
#include <Actions.h>
#include <ActionCreator.h>
#include <ActionManager.h>
#include <GrayImage.h>
#include <ARGBImage.h>

#include <ColorMapFuncs.h>
#include <Stat.h>
#include "LumStat.h" // includes cmath

inline static float square(float a)
{
    return a*a;
}

LumStat::LumStat()
{
    name = "LumStat";
}

void LumStat::prepare(const ARGBImage *img)
{
    argb = img;
    type = ARGB;
}

void LumStat::prepare(const GrayImage *img)
{
    gray = img;
    type = Gray;
}

LLStat LumStat::gray_stat()
{
    LLStat s;
    unsigned char *c;
    int i;
    int max = gray->getWidth() * gray->getHeight();

    c = gray->data();
    for (i = 0; i < max; ++i, ++c)
    {
        s.addData(*c);
    }

    return s;
}

LLStat4 LumStat::argb_stat()
{
    LLStat4 s;
    int i;
    unsigned int *c;
    int max = argb->getWidth() * argb->getHeight();

    c = argb->data();
    for (i = 0; i < max; ++i, ++c)
    {
        s.red.addData(ARGBImage::getR(*c));
        s.green.addData(ARGBImage::getG(*c));
        s.blue.addData(ARGBImage::getB(*c));
        s.lum.addData(ColorMapFuncs::RGB2Y(
                    ARGBImage::getR(*c),
                    ARGBImage::getG(*c),
                    ARGBImage::getB(*c))
                );
    }

    return s;
}

MeasureResult * LumStat::apply()
{
    MeasureResult *res = new MeasureResult();
    switch(type)
    {
        case Gray:
            {
                LLStat s = gray_stat();
                res->text += QString("Gray:\n");
                res->text += QString("  Mean: \%1\n").arg(s.getMean());
                res->text += QString("  StdDev: \%1\n").arg(s.getStdDev());
            }
            break;
        case ARGB:
            {
                LLStat4 s = argb_stat();
                res->text += QString("Red:\n");
                res->text += QString("  Mean: \%1\n").arg(s.red.getMean());
                res->text += QString("  StdDev: \%1\n").arg(s.red.getStdDev());
                res->text += QString("Green:\n");
                res->text += QString("  Mean: \%1\n").arg(s.green.getMean());
                res->text += QString("  StdDev: \%1\n").arg(s.green.getStdDev());
                res->text += QString("Blue:\n");
                res->text += QString("  Mean: \%1\n").arg(s.blue.getMean());
                res->text += QString("  StdDev: \%1\n").arg(s.blue.getStdDev());
                res->text += QString("Luminance:\n");
                res->text += QString("  Mean: \%1\n").arg(s.lum.getMean());
                res->text += QString("  StdDev: \%1\n").arg(s.lum.getStdDev());
            }
            break;
    }
    return res;
}


LumStatCreator::LumStatCreator()
{
    type = e_Measure;
}

bool LumStatCreator::isapplicable(const JPEGParameters &p)
{
    return true;
}


void LumStatCreator::init()
{
    ActionCreator *a = new LumStatCreator();
    ActionManager::sreg("LumStat", a);
}

Measure * LumStatCreator::createMeasure() const
{
    return new LumStat();
}
