/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class Scaler;
class CoefsImage;
class FloatImage;
class ActionCreator;

class Froment : public ImproveRawPlane
{
protected:
    float wTV[8]; /* Weights */
    float step_size;
    int steps;
    bool constant_step;

private:
    CoefsPlane DCTmin;
    CoefsPlane DCTmax;
    CoefsPlane DCTimage;

    /*! Temporary bitmap, which will have the final image. */
    FloatPlane bitmap;

    FloatPlane reference;

    /*! Width in blocks * 8 */
    unsigned int width;
    /*! Height in blocks * 8 */
    unsigned int height;

    Qtable qtable;

    CoefsPlane coefs;

    void start_restoration();
    void quantize();
    void set_DCT_constraint();
    void project(FloatPlane &out);

    float TV(FloatPlane &ug, FloatPlane &dE);
    void min_TV();

public:
    Froment();
    virtual ~Froment() {};

	void prepare(const CoefsPlane *coefs,
            const FloatPlane *initial);
	FloatPlane * apply();
    bool getConfiguredEnv();
};

class FromentCreator : public ActionCreator
{
    FromentCreator();

public:
    static void init();

    ImproveRawPlane * createImproveRawPlane() const;
	bool isapplicable(const JPEGParameters &p);
};
