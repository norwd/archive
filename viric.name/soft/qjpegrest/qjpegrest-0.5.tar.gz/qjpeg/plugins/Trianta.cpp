/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include "ActionType.h"
#include <FloatPlane.h>
#include <JPEGData.h>
#include <CoefsPlane.h>
#include <ActionCreator.h>
#include <Actions.h>
#include <ActionManager.h>
#include "Trianta.h"
#include <cstdlib> // getenv
#include <cstdio> // debug
#include <cmath> // fabs
extern "C" {
#include <cdct.h>
}


/* Implementation of the method developed by: G.A. Triantafyllidis, M. Varnuska,
 *   D. Sampson, D. Tzovaras, M.G. Strintzis:
     "An efficient algorithm for the enhancement of JPEG-coded images"
   from Computer & Graphics 27 (2003) 529-534

   Notes:
   - We don't apply the hf_filter and the lf_filter based on the input
     plane. First we apply the lf_filter based on the input plane, and then
     we apply the hf_filter, so it can see the lf_filtered points.
*/

void Trianta::prepare(const CoefsPlane *coefs,
            const FloatPlane *initial)
{
    reference = *initial;
    Trianta::coefs = *coefs;

    maxProgress = 1;
    setProgress(0);
}

FloatPlane * Trianta::apply()
{
    ComponentData p = coefs.getParameters();
    for(unsigned int i=0; i < DCTSize2; ++i)
        qtable[i] = p.qtable[i];

    result = new FloatPlane();

    prepare_parameters();

    start_restoration();

    return result;
}

TriantaCreator::TriantaCreator()
{
    type = e_ImproveRawPlane;
}

bool TriantaCreator::isapplicable(const JPEGParameters &p)
{
    return true;
}


void TriantaCreator::init()
{
    ActionCreator *a = new TriantaCreator();
    ActionManager::sreg("Trianta (alter)", a);
}

ImproveRawPlane * TriantaCreator::createImproveRawPlane() const
{
    return new Trianta();
}

Trianta::Trianta()
{
    name = "Trianta (alter)";

    hf_kernel = 0;
    lf_kernel = 0;

    give_thresholding = false;
    threshold = 500;
    WSMM_tau = 1;
    WSMM_winsize = 7;
    WSMM_halfsize = 3;

    hf_kernel_size = 7;
    hf_kernel_size_half = 3;
    att_constant_mu = 1;
    hf_sigma_kernel = 2;
    lf_kernel_size = 7;
    lf_kernel_size_half = 3;
    lf_sigma_kernel = 2;
}


void
Trianta::start_restoration ()
{
    /* Prepare dimensions */
    width = coefs.getWidthInBlocks() * DCTSize;
    height = coefs.getHeightInBlocks() * DCTSize;

    result->allocate(width, height);

    if (hf_kernel)
        delete[] hf_kernel;
    hf_kernel = new float[hf_kernel_size*hf_kernel_size];


    prepare_lf_kernel();

    apply_per_pixel();

    setProgress(maxProgress);
}

void Trianta::prepare_parameters()
{
    lf_kernel_size_half =  (int) lf_sigma_kernel + 1;
    WSMM_halfsize = (int) WSMM_tau + 1;
    hf_kernel_size_half = (int) hf_sigma_kernel + 1;;

    WSMM_winsize = WSMM_halfsize*2 +1;
    hf_kernel_size = hf_kernel_size_half*2 +1;
    lf_kernel_size = lf_kernel_size_half*2 +1;
}

/* eq. 4 */
float Trianta::get_gradient_x(int x, int y)
{
    float res;
    if (x < 1 || x >= width-1 || y < 0 || y >= height)
        return 0;
    res = (reference.get(x+1, y) - reference.get(x-1, y)) / 2.;
    return res;
}

/* eq. 4 */
float Trianta::get_gradient_y(int x, int y)
{
    float res;
    if (x < 0 || x >= width || y < 1 || y >= height-1)
        return 0;
    res = (reference.get(x, y+1) - reference.get(x, y-1)) / 2.;
    return res;
}

float Trianta::get_gaussian_wb(int x, int y)
{
    return expf(-((float)(x*x+y*y))/(2*WSMM_tau*WSMM_tau));
}

void Trianta::prepare_lf_kernel()
{
    int i,j;
    float norm;

    if (lf_kernel)
        delete[] lf_kernel;
    lf_kernel = new float[lf_kernel_size*lf_kernel_size];

    norm = 0;
    for (j = -lf_kernel_size_half; j <= lf_kernel_size_half; ++j)
        for (i = -lf_kernel_size_half; i <= lf_kernel_size_half; ++i)
        {
            int ptr;
            float tmp;
            ptr = (j + lf_kernel_size_half)*lf_kernel_size
                + i + lf_kernel_size_half;
            tmp = get_gaussian_lf(i,j);
            norm += tmp;
            lf_kernel[ptr] = tmp;
        }

    for (j = -lf_kernel_size_half; j <= lf_kernel_size_half; ++j)
        for (i = -lf_kernel_size_half; i <= lf_kernel_size_half; ++i)
        {
            int ptr;
            float tmp;
            ptr = (j + lf_kernel_size_half)*lf_kernel_size
                + i + lf_kernel_size_half;
            lf_kernel[ptr] /= norm;
        }
}

float Trianta::get_gaussian_lf(int x, int y)
{
    return expf(-((float)(x*x+y*y))/(2*lf_sigma_kernel*lf_sigma_kernel));
}

void Trianta::lf_filter(int x, int y)
{
    int i,j;
    float newval = 0;

    for (j = -lf_kernel_size_half; j <= lf_kernel_size_half; ++j)
        for (i = -lf_kernel_size_half; i <= lf_kernel_size_half; ++i)
        {
            int px, py;
            int ptr;
            px = x+i;
            py = y+j;
            if (px < 0 || px >= width || py < 0 || py >= height)
                continue;
            ptr = (j + lf_kernel_size_half)*lf_kernel_size
                + i + lf_kernel_size_half;
            newval += lf_kernel[ptr] * reference.get(px, py);
            /*
            newval +=  result->get(px, py) /
                (float) (lf_kernel_size*lf_kernel_size);
            */
        }

    result->set(x,y, newval);
}

/* eq. 5 */
void Trianta::get_WSMM(int x, int y, float *A, float *B, float *C)
{
    int i,j;

    *A = 0;
    *B = 0;
    *C = 0;

    for (j = -WSMM_halfsize; j <= WSMM_halfsize; ++j)
        for (i = -WSMM_halfsize; i <= WSMM_halfsize; ++i)
        {
            float wb, gx, gy;
            wb = get_gaussian_wb(i,j);
            gx = get_gradient_x(x+i, y+j);
            gy = get_gradient_y(x+i, y+j);
            *A += wb*gx*gx;
            *B += wb*gy*gy;
            *C += wb*gx*gy;
        }
}

/* eq. 9 */
void Trianta::get_VxVy(int x, int y, float A, float B, float *Vx, float *Vy)
{
    int i,j;

    *Vx = 0;
    *Vy = 0;
    for (j = -WSMM_halfsize; j <= WSMM_halfsize; ++j)
        for (i = -WSMM_halfsize; i <= WSMM_halfsize; ++i)
        {
            float wb, gx, gy;
            wb = get_gaussian_wb(i,j);
            gx = get_gradient_x(x+i, y+j);
            gy = get_gradient_y(x+i, y+j);

            *Vx += wb * (gx * gx * (float)i + gx * gy * (float)j);
            *Vy += wb * (gy * gy * (float)j + gx * gy * (float)i);
        }

    *Vx /= (A + B);
    *Vy /= (A + B);
}

void Trianta::hf_filter(int x, int y, float A, float B, float C)
{
    float Vx, Vy, Dx, Dy;
    float S;
    float AChap, BChap, CChap;
    float tmp;
    float newval;
    int i,j;

    /* eq. 9 */
    get_VxVy(x, y, A, B, &Vx, &Vy);

    /* eq.  8 */
    tmp = (float) hf_kernel_size / 2. 
        / sqrtf(att_constant_mu*att_constant_mu + Vx*Vx + Vy*Vy);
    Dx = tmp * Vx;
    Dy = tmp * Vy;

    AChap = A / (A+B);
    BChap = B / (A+B);
    CChap = C / (A+B);

    /* Get S - eq. 7 */
    S = 0;
    for (j = -hf_kernel_size_half; j <= hf_kernel_size_half; ++j)
        for (i = -hf_kernel_size_half; i <= hf_kernel_size_half; ++i)
        {
            int Kptr;

            tmp = expf(-(AChap * ((float)i + Dx)*((float)i + Dx) +
                2. * CChap * ((float)i + Dx)*((float)j + Dy) +
                BChap * ((float)j + Dy) * ((float)j + Dy))
                / 2 * hf_sigma_kernel * hf_sigma_kernel);
            Kptr = hf_kernel_size*(j + hf_kernel_size_half)
                + i + hf_kernel_size_half;
            hf_kernel[Kptr] = tmp;
            S += tmp;
        }


    newval = 0;
    /* The hf_kernel values still aren't divided by S */
    for (j = -hf_kernel_size_half; j <= hf_kernel_size_half; ++j)
        for (i = -hf_kernel_size_half; i <= hf_kernel_size_half; ++i)
        {
            int Kptr;
            float in;
            int px, py;
            px = x+i;
            py = y+j;
            if (px < 0 || px >= width || py < 0 || py >= height)
                continue;
            in = result->get(px,py);
            Kptr = hf_kernel_size*(j + hf_kernel_size_half)
                + i + hf_kernel_size_half;
            newval += in * hf_kernel[Kptr];
        }

    result->set(x,y, newval / S);
}

void Trianta::apply_per_pixel()
{
    int i, j;

    /* The margins get copied from reference, when
     * result = reference. newcopy() before */
    for (unsigned int j=0;j<height;++j)
        for (unsigned int i=0;i<width;++i)
        {
            float A, B, C;
            get_WSMM(i,j, &A, &B, &C);

            /*std::printf("A: %f  B: %f\n", A, B);*/
            if (give_thresholding)
            {
                if(A > threshold || B > threshold)
                {
                    /* High detail */
                    result->set(i,j, 250);
                }
                else
                {
                    /* Low detail */
                    result->set(i,j, 0);
                }
            } else
            { /* Normal filter */
                if(A > threshold || B > threshold)
                {
                    /* High detail */
                    result->set(i,j,reference.get(i,j));
                }
                else
                {
                    /* Low detail */
                    lf_filter(i,j);
                }
            }
        }

    /* Although not according to the paper, we pass the hf_filter later.
     * The filter is applied overy the picture which already has the 
     * lf_filter applied. */

    if (!give_thresholding)
        for (unsigned int j=0;j<height;++j)
            for (unsigned int i=0;i<width;++i)
            {
                float A, B, C;
                get_WSMM(i,j, &A, &B, &C);
                if(A > threshold || B > threshold)
                    hf_filter(i,j, A, B, C);
            }
}

Trianta::~Trianta()
{
    if (hf_kernel)
        delete[] hf_kernel;
    if (lf_kernel)
        delete[] lf_kernel;
}
