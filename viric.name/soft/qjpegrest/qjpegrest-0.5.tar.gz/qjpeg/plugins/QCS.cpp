/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include "ActionType.h"
#include <FloatPlane.h>
#include <JPEGData.h>
#include <CoefsPlane.h>
#include <ActionCreator.h>
#include <Actions.h>
#include <ActionManager.h>
#include "QCS.h"
#include <cstdlib> // getenv
#include <cstdio> // sscanf
#include <cmath> // floor
extern "C" {
#include <cdct.h>
}

/* Projection on the constraint - algorithm code by Froment*/

void QCS::prepare(const CoefsPlane *coefs,
            const FloatPlane *initial)
{
    reference = *initial;
    QCS::coefs = *coefs;

    maxProgress = 2;
    setProgress(0);
}

FloatPlane * QCS::apply()
{
    ComponentData p = coefs.getParameters();
    for(unsigned int i=0; i < DCTSize2; ++i)
        qtable[i] = p.qtable[i];

    result = new FloatPlane();

    start_restoration();

    DCTmax.free();
    DCTmin.free();
    DCTimage.free();

    return result;
}

QCSCreator::QCSCreator()
{
    type = e_ImproveRawPlane;
}

bool QCSCreator::isapplicable(const JPEGParameters &p)
{
    return true;
}


void QCSCreator::init()
{
    ActionCreator *a = new QCSCreator();
    ActionManager::sreg("QCS Projection", a);
}

ImproveRawPlane * QCSCreator::createImproveRawPlane() const
{
    return new QCS();
}

QCS::QCS()
{
    name = "QCS Projection";
}


void
QCS::start_restoration ()
{
  /* Prepare dimensions */
  width = coefs.getWidthInBlocks() * DCTSize;
  height = coefs.getHeightInBlocks() * DCTSize;

  /* Load the coefficients, and prepare the DCT ranges */
  set_DCT_constraint();

  /* Overwrite of previous uninitialized *result */
  *result = reference.newcopy();

  setProgress(1);

  project(*result);

  setProgress(maxProgress);
}


void QCS::set_DCT_constraint()
{
    DCTimage = coefs.newcopy();
    
    DCTmin.allocate(coefs.getWidthInBlocks(), coefs.getHeightInBlocks());
    DCTmax.allocate(coefs.getWidthInBlocks(), coefs.getHeightInBlocks());

    float * cptr = coefs.getPtr();

    for (unsigned int j=0;j<coefs.getHeightInBlocks();++j)
        for (unsigned int i=0;i<coefs.getWidthInBlocks();++i)
        {
            unsigned int base = (j * coefs.getWidthInBlocks() + i) * DCTSize2;
            for (unsigned int k=0;k<DCTSize2;k++)
            {
              DCTmin.getPtr()[base+k]=cptr[base+k] - (0.5*qtable[k]);
              DCTmax.getPtr()[base+k]=cptr[base+k] + (0.5*qtable[k]);
            }
        }
}

/* Projection on the constraint - by Froment*/
/*! Projects the DCTimage into out, according to DCTmin and DCTmax */
void QCS::project(FloatPlane &out)
{
  fdct_image(DCTimage.getPtr(), out.getPtr(), width, height);
    
  unsigned int length = width * height;
  for (unsigned int j=0;j<length;j++)
  {
    if (0)
    {
        /* I use this code for dumping DCT coefficients for 
         * some blocks. */
        if (j == (coefs.getHeightInBlocks()*18+16)*DCTSize2)
        {
            FILE *f;
            f = std::fopen("block16x18.txt", "a");
            std::fprintf(f, "# New block\n");
            for(int i=0; i < DCTSize2; ++i)
            {
                int zig = CoefsPlane::jpeg_natural_order[i];
                std::fprintf(f, "%i %f %f %f\n", i,
                        DCTimage.getPtr()[j+zig],
                        DCTmin.getPtr()[j+zig],
                        DCTmax.getPtr()[j+zig]);
            }
            std::fclose(f);
        }
    }

    if (1) /* normal flow */
    {
        if (DCTimage.getPtr()[j] > DCTmax.getPtr()[j])
          DCTimage.getPtr()[j] = DCTmax.getPtr()[j];
        else if (DCTimage.getPtr()[j] < DCTmin.getPtr()[j])
          DCTimage.getPtr()[j] = DCTmin.getPtr()[j];
    } else if (0) /* Minimum coefs */
    {
        float &min = DCTmin.getPtr()[j];
        float &max = DCTmax.getPtr()[j];
        float &final = DCTimage.getPtr()[j];

        if (min > 0 && max > 0)
            final = min;
        else if (min < 0 && max > 0)
            final = 0;
        else
            final = max;
    } else if (0) /* Maximum coefs */
    {
        float &min = DCTmin.getPtr()[j];
        float &max = DCTmax.getPtr()[j];
        float &final = DCTimage.getPtr()[j];

        if (min > 0 && max > 0)
            final = max;
        else if (min < 0 && max > 0)
            final = max;
        else
            final = min;
    }
  }

  fdct_inverse_image(DCTimage.getPtr(), out.getPtr(), width, height);
}
