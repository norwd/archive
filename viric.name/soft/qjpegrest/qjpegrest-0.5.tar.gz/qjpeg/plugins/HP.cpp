/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QMap>

#include "ActionType.h"
#include <FloatPlane.h>
#include <JPEGData.h>
#include <CoefsPlane.h>
#include <ActionCreator.h>
#include <Actions.h>
#include <ActionManager.h>
#include "HP.h"
#include <cstdlib> // getenv
#include <cstdio> // sscanf
#include <cmath> // floor
extern "C" {
#include <cdct.h>
}

/* Implementation of the method developed by Ramin Samadani, Arvind
 * Sundararajan and Amir Said:
 *   Deringing and deblocking DCT compression artifacts with efficient
 *   shifted transforms.
 * from the online version published at HP's site.
 *
 * Notes:
 * - We implement the version which uses DCTs/iDCTs. Basically a variance
 *   over Nosratinia's method, locally choosing the shifts to average for
 *   obtaining the final point.
 * - This methods takes _a lot of memory_, around 65 times each image pixel,
 *   with a float for every pixel.
 */

enum {
    MAXSHIFTS = 64
};

/* Prototypes */
static void fdct_inverse_image_shift(float * coefdct, float * out,
    const int w, int const h, const int shift_x, const int shift_y);
static void fdct_image_shift (float * coefdct, float * in,
    const int w, int const h, const int shift_x, const int shift_y);

void HP::prepare(const CoefsPlane *coefs,
            const FloatPlane *initial)
{
    reference = *initial;
    HP::coefs = *coefs;

    maxProgress = shifts+1;
    setProgress(0);
}

FloatPlane * HP::apply()
{
    ComponentData p = coefs.getParameters();
    for(unsigned int i=0; i < DCTSize2; ++i)
        qtable[i] = p.qtable[i];

    start_restoration();

    FloatPlane *result = new FloatPlane();
    *result = final;

    /* Deallocate the bitmaps */
    /* One bitmap (in the middle of shifts) will not
     * be deallocated, because the null-displacement
     * bitmap is not used, therefore, not allocated */
    for(int i=1; i < MAXSHIFTS; ++i)
        bitmap[i].free();
    delete[] bitmap;
    alpha.free();
    sums.free();
    DCTmax.free();
    DCTmin.free();
    DCTimage.free();

    return result;
}

HPCreator::HPCreator()
{
    type = e_ImproveRawPlane;
}

bool HPCreator::isapplicable(const JPEGParameters &p)
{
    return true;
}


void HPCreator::init()
{
    ActionCreator *a = new HPCreator();
    ActionManager::sreg("HP (alter)", a);
}

ImproveRawPlane * HPCreator::createImproveRawPlane() const
{
    return new HP();
}

HP::HP()
{
    name = "HP (alter)";
    /* Default configuration */
    shifts = MAXSHIFTS;
    percent_var = 30.;
    calculate_shifts();
}

bool HP::getConfiguredEnv()
{
    char *env_var;

    env_var = std::getenv("JPEG_HP_SHIFTS");
    if (env_var != NULL)
        std::sscanf(env_var, "%u", &shifts);

    env_var = std::getenv("JPEG_HP_PERCENTV");
    if (env_var != NULL)
        std::sscanf(env_var, "%f", &percent_var);

    calculate_shifts();
}


void
HP::start_restoration ()
{
  /* Prepare dimensions */
  width = coefs.getWidthInBlocks() * DCTSize;
  height = coefs.getHeightInBlocks() * DCTSize;
  nsums = 0;

  /* Load the coefficients, and prepare the DCT ranges */
  set_DCT_constraint();

  /* Allocate the bitmaps */
  bitmap = new FloatPlane[shifts+1];
  /*
  for (int i=0; i < shifts + 1; i++)
      bitmap[i].allocate(width, height);
      */

  /* Allocate the sums */
  sums.allocate(width, height);

  /* Zero sums */
  sums.setzero();

  /* Allocate the alpha */
  alpha.allocate(width, height);

  loopshifts();

  average_bitmap();

  calculate_alpha();

  /* Allocate the final */
  final.allocate(width, height);

  calculate_final();

  /* We don't project. This alters the JPEG */

  setProgress(maxProgress);
}

void
HP::calculate_final()
{
  int row, col;
  int pixels_low_variance;

  /* Select the lowest 30% */
  pixels_low_variance = (int) (shifts * percent_var) / 100;

  for(row=0; row < height; row++) 
    for (col=0; col < width; col++)
    {
      final.set(col, row, calculate_final_pixel(row, col, pixels_low_variance));
    }
}

float HP::pixel_spatial_variance(const int row, const int col,
        const int nbitmap)
{
  int wrow, wcol;
  int bound_up, bound_down, bound_left, bound_right;
  enum { WINDOW = 3 }; /* Size of the window. Must be odd */
  float mean, sigma2, diff;

  int border;

  border = (WINDOW - 1)/2;

  /* Calculate spatial variance for the pixel */
  bound_up = (row >= border) ? row - border: 0;
  bound_down = (row < height - border) ? row + border: height - 1;
  bound_left = (col >= border) ? col - border: 0;
  bound_right = (col < width - border) ? col + border: width - 1;

  /* Mean */
  mean = 0.;
  for (wrow = bound_up; wrow <= bound_down; wrow++)
    for (wcol = bound_left; wcol <= bound_right; wcol++)
    {
      mean += bitmap[nbitmap].get(wcol, wrow);
    }
  mean /= (bound_down - bound_up + 1) * (bound_right - bound_left + 1);

  /* Variance */
  sigma2 = 0.;
  for (wrow = bound_up; wrow <= bound_down; wrow++)
    for (wcol = bound_left; wcol <= bound_right; wcol++)
    {
      diff = bitmap[nbitmap].get(wcol, wrow) - mean;
      sigma2 += diff*diff;
    }
  sigma2 /= (bound_down - bound_up + 1) * (bound_right - bound_left + 1) - 1.;

  return sigma2;
}

float HP::calculate_final_pixel(const int row, const int col,
        int n_significative_variances)
{
  int i;
  QMultiMap<float, int> variances;
  int valid_shifts;

  float low_variance_mean;

  /* Get the spatial variance of each shift */
  valid_shifts=0;
  for (i=0; i <= shifts; i++)
  {
    if (bitmap[i].getPtr() != 0 && bitmap[i].get(col,row) != 0)
    {
        float variance;
        variance = pixel_spatial_variance(row, col, i);
        variances.insert(variance, i);
        valid_shifts++;
    }
  }

  /* Upper bound */
  if (valid_shifts < n_significative_variances)
    n_significative_variances = valid_shifts;

  low_variance_mean = 0.;
  QMultiMap<float,int>::const_iterator iter = variances.begin();
  for (i=0; i < n_significative_variances; ++iter)
  {
    low_variance_mean += bitmap[iter.value()].get(col,row);
    ++i;
  }
  low_variance_mean /= n_significative_variances;

  /* Main formula from the article */
  return (1. - alpha.get(col,row)) * sums.get(col,row)
    + alpha.get(col,row) * low_variance_mean;
}

void
HP::calculate_alpha()
{
  int row, col, wrow, wcol;
  int bound_up, bound_down, bound_left, bound_right;
  float max, min;
  float contrast_local, contrast_block;
  float val;
  int border_local, border_block;
  enum { WINDOW_LOCAL = 3,
    WINDOW_BLOCK = 15 };
  float z;

  border_local = (WINDOW_LOCAL-1)/2;
  border_block = (WINDOW_BLOCK-1)/2;

  for(row=0; row < height; row++) 
      for (col=0; col < width; col++)
      {
          /* 3x3 window for getting the pixel range */
          bound_up = (row >= border_local) ? row - border_local: 0;
          bound_down = (row < height - border_local) ? row + border_local
              : height - 1;
          bound_left = (col >= border_local) ? col - border_local: 0;
          bound_right = (col < width - border_local) ? col + border_local
              : width - 1;
          max = 0.;
          min = 256.;
          for (wrow = bound_up; wrow <= bound_down; wrow++)
              for (wcol = bound_left; wcol <= bound_right; wcol++)
              {
                  val = sums.get(wcol, wrow);
                  if (val > max)
                      max = val;
                  else if (val < min)
                      min = val;
              }
          contrast_local = max - min;

          /* 15x15 window */
          bound_up = (row >= border_block) ? row - border_block : 0;
          bound_down = (row < height - border_block) ? row + border_block
              : height - 1;
          bound_left = (col >= border_block) ? col - border_block : 0;
          bound_right = (col < width - border_block) ? col + border_block
              : width - 1;
          max = 0.;
          min = 256.;
          for (wrow = bound_up; wrow <= bound_down; wrow++)
              for (wcol = bound_left; wcol <= bound_right; wcol++)
              {
                  val = sums.get(wcol, wrow);
                  if (val > max)
                      max = val;
                  else if (val < min)
                      min = val;
              }
          contrast_block = max - min;

          z = contrast_block - contrast_local;
          /* The sigmoidal function.
           * alpha = 1 / (1 + exp( -(z-85)/8.5)) */
          alpha.set(col, row, 1.0 / (1.0 + expf(-(z-85.0)/8.5))); 
      }
}

void
HP::average_bitmap()
{
  unsigned int row, col;

  for(row=0; row < height; row++) 
    for (col=0; col < width; col++)
    {
      sums.set(col, row, sums.get(col, row) / (float) nsums);
    }
}

void HP::loopshifts()
{
  int shift;

  int shift_y, shift_x;

  shift_y = min_shift;
  shift_x = min_shift;

  shift = 0;

  /* add into the sums */
  add2sums(reference);
  bitmap[0] = reference; /* Same data. Share pointer */
#if 0
  bitmap[0].operator=(reference); /* Same data. Share pointer */
  bitmap[0] = reference.newcopy(); /* Same data. Share pointer */
#endif
  shift++;
  
  for (; shift <= shifts; shift++)
  {
    setProgress(shift);
    /* Forget the central image */
    if (shift_x == 0 && shift_y == 0)
    {
      shift_x++;
      continue;
    }

    /* Reget the 'reference' over the 'bitmap'.*/
    bitmap[shift] = reference.newcopy();

    /* DCT the image shifted */
    fdct_image_shift(DCTimage.getPtr(), bitmap[shift].getPtr(), width, height,
            shift_x, shift_y);

    /* Quantize the new coef with the component qtable */
    quantize();

    /* iDCT the shifted image and unshift */
    fdct_inverse_image_shift(DCTimage.getPtr(), bitmap[shift].getPtr(),
            width, height, shift_x, shift_y);

    /* The method doesn't describe this, but here could be a QCS projection
     * of bitmap[shift]. */

    /* add into the sums */
    add2sums(bitmap[shift]);

    /* Calculate shift offsets */
    shift_x++;
    if (shift_x > max_shift)
    {
      shift_y++;
      shift_x = min_shift;
    }
  }
}

/* IDCT on the whole image, with shifts */

static void
fdct_inverse_image_shift(float * coefdct, float * out,
    const int w, int const h, const int shift_x, const int shift_y)
{
  int i,j,x,y;
  RSAMP * ptr;
  RSAMP out_gray[DCTSize2]; 
  int index_y, index_x;

  for (i=0; i<h; i+=DCTSize)
    for (j=0; j<w;j+=DCTSize) 
      {
	fidct_buffer(coefdct, out_gray);
	coefdct+=DCTSize2;
	ptr=out_gray;
	for (y=0;y<DCTSize;y++)
	  for (x=0;x<DCTSize;x++)
	  {
	    index_y = i + y + shift_y;
	    if (index_y < 0)
	      index_y = 0;
	    else if (index_y >= h)
	      index_y = h - 1;

	    index_x = j + x + shift_x;
	    if (index_x < 0)
	      index_x = 0;
	    else if (index_x >= w)
	      index_x = w - 1;
	    out[index_y*w + index_x]=*(ptr++);
	  }
      }
}

/* DCT on the whole image, with shifts */

static void
fdct_image_shift (float * coefdct, float * in,
    const int w, int const h, const int shift_x, const int shift_y)
{
  int i,j,x,y;
  float in_gray[DCTSize2];
  RSAMP * ptr;
  int index_y, index_x;

  for (i=0; i<h; i+=DCTSize)
    for (j=0; j<w;j+=DCTSize) 
    {
      ptr=in_gray;
      for (y=0;y<DCTSize;y++)
	for (x=0;x<DCTSize;x++)
	{
	  index_y = i + y + shift_y;
	  if (index_y < 0)
	    index_y = 0;
	  else if (index_y >= h)
	    index_y = h - 1;

	  index_x = j + x + shift_x;
	  if (index_x < 0)
	    index_x = 0;
	  else if (index_x >= w)
	    index_x = w - 1;

	  *(ptr++)=in[index_y*w + index_x];
	}
      fdct_buffer(in_gray, coefdct);
      coefdct+=DCTSize2;
    }
}


void HP::quantize()
{
  float * coef = DCTimage.getPtr();


  /* The next is equivalent to width_in_blocks*height_in_blocks*DCTSize2 */
  unsigned int length = width*height;
  int num_coef = 0;
  for (unsigned int i=0; i<length; ++i)
  {
    *coef = *coef / qtable[num_coef];
    *coef += 0.5;
    *coef = std::floor(*coef) * qtable[num_coef];
    coef++;
    /* num_coef should loop from 0 to 63 */
    if(num_coef == 63)
        num_coef = 0;
    else
        ++num_coef;
  }
}

void HP::set_DCT_constraint()
{
    DCTimage.allocate(coefs.getWidthInBlocks(), coefs.getHeightInBlocks());
    DCTmin.allocate(coefs.getWidthInBlocks(), coefs.getHeightInBlocks());
    DCTmax.allocate(coefs.getWidthInBlocks(), coefs.getHeightInBlocks());

    float * cptr = coefs.getPtr();

    for (unsigned int j=0;j<coefs.getHeightInBlocks();++j)
        for (unsigned int i=0;i<coefs.getWidthInBlocks();++i)
        {
            unsigned int base = (j * coefs.getWidthInBlocks() + i) * DCTSize2;
            for (unsigned int k=0;k<DCTSize2;k++)
            {
              DCTmin.getPtr()[base+k]=cptr[base+k] - (0.5*qtable[k]);
              DCTmax.getPtr()[base+k]=cptr[base+k] + (0.5*qtable[k]);
            }
        }
}

/*! Calculate the number and ranges of shifts */
void HP::calculate_shifts()
{
  if (shifts < 1)
    shifts = 1;
  else if (shifts > MAXSHIFTS)
    shifts = MAXSHIFTS;

  if (shifts == 1)
  {
    min_shift = 0;
    max_shift = 0;
  }
  else if (shifts <= 3*3)
  {
    min_shift = -1;
    max_shift = 1;
  }
  else if (shifts <= 5*5)
  {
    min_shift = -2;
    max_shift = 2;
  }
  else if (shifts <= 7*7)
  {
    min_shift = -3;
    max_shift = 3;
  }
  else if (shifts <= 8*8)
  {
    min_shift = -3;
    max_shift = 4;
  }
}

void HP::add2sums(const FloatPlane &from)
{
  sums.add(from);
  ++nsums;
}


/* Projection on the constraint - by Froment*/
/*! Projects the DCTimage into out, according to DCTmin and DCTmax */
void HP::project(FloatPlane &out)
{
  fdct_image(DCTimage.getPtr(), out.getPtr(), width, height);
    
  unsigned int length = width * height;
  for (unsigned int j=0;j<length;j++)
    if (DCTimage.getPtr()[j] > DCTmax.getPtr()[j])
      DCTimage.getPtr()[j] = DCTmax.getPtr()[j];
    else if (DCTimage.getPtr()[j] < DCTmin.getPtr()[j])
      DCTimage.getPtr()[j] = DCTmin.getPtr()[j];

  fdct_inverse_image(DCTimage.getPtr(), out.getPtr(), width, height);
}
