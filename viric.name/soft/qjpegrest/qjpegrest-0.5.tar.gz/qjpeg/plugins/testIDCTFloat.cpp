/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <ActionType.h>
#include <ActionManager.h>
#include <Actions.h>
#include <ActionCreator.h>
#include <JPEGData.h>
#include <JPEGFile.h>
#include <CoefsPlane.h>
#include <CoefsImage.h>
#include <FloatPlane.h>
#include "IDCTFloat.h"

void initialize()
{
    new ActionManager();
    IDCTFloatCreator::init();
}

int main()
{
    IDCTPlane *fidct;

    initialize();
    /* Get the IDCTFloat */
    fidct = ActionManager::sfind("IDCTFloat")->createIDCTPlane();

    /* Open a jpeg */
    JPEGFile jfile("a.jpg");

    /* Get the coefficients */
    CoefsImage * coefs = jfile.getCoefs();

    /* Unpack the first plane */
    fidct->prepare(&coefs->plane[0]);
    FloatPlane * fplane = fidct->apply();

    fplane->writePGM("prova.pgm");

    coefs->free();
    fplane->free();
    delete coefs;
    delete fplane;
    delete fidct;
    ActionManager::destroy();
}
