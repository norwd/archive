/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <ActionType.h>
#include <MeasureResult.h>
#include <Actions.h>
#include <ActionCreator.h>
#include <ActionManager.h>
#include <GrayImage.h>
#include <ARGBImage.h>
#include <cmath>
#include "GBIM.h"

using std::log;
using std::sqrt;

/* Based on paper 1070-9908/97 (c) 1997 IEEE
   H. R. Wu and M. Yuen
   A Generalized Block-Edge Impairment Metric for Video Coding

   All the error_h functions are related to vertical edge artifacts, so
   they calculate for horizontal block boundaries. Analogous for error_v.
*/

/* lambda = ln(1 + sqrt(255 - zeta)) / ( ln( 1 + sqrt(zeta) ) ) */
/* zeta is the "selected average luminance value for which the highest
weight should be given to the distortion". */
static float
get_lambda(float zeta)
{
	return log(1 + sqrt(255 - zeta)) / ( log( 1 + sqrt(zeta) ) );
}

inline static float square(float a)
{
    return a*a;
}

void
GBIM::argb_error_h_mu_sigma(float h_mu[], float h_sigma[],
		const int rows, const int block_columns)
{
	float sum_h, mu_l, mu_r, sigma_l, sigma_r = 0;
	/* The zero value above are for eviting the compiler warning for
	 * use of uninitialized values. They're right used in the code. */
	int row;
	int i;            /* It will go through the block columns */
	int n;            /* It will go through the columns IN a block */
	int last_columns; /* The number of columns of the last block */
	int columns_in_block; /* For each block processed, the number of
				 columns */
	int is_left_block_calculated;

	last_columns = argb->getWidth() % 8;
	if (last_columns == 0) last_columns = 8;

	/* The arrays h_* have 'rows' rows, and (block_columns-1) columns
	 * Thus, the accessing method is, for instance with h_mu:
	 *  h_mu[row * (block_columns-1) + column] */

	for(row = 0; row < rows; row++)
	{
		columns_in_block = 8;
		is_left_block_calculated = 0; /* false at first block column */

		/* The last block
		 * will be processed specially because it may be a
		 * non full block. */
		for(i=0; i < block_columns - 1; i++)
		{
			if (is_left_block_calculated)
			{
				mu_l = mu_r;
				sigma_l = sigma_r;
			}
			else /* The left block is not calculated */
			{
				/* Left block. Mu. We start with element 0 */
				sum_h = argb->getPixel(i*8+0, row);
				for(n=1; n < 8; n++)
				{
					sum_h = sum_h + argb->getPixel(i*8+n, row);
				}
				mu_l = sum_h / 8;

				/* Left block. Sigma. */
				sum_h = argb->getPixel(i*8+0, row);
				for(n=1; n < 8; n++)
				{
					/* sum+h + (f_(i,n) - mu_l)^2 */
					sum_h = sum_h + square(argb->getPixel(i*8+n, row) - mu_l);
				}
				sigma_l = sqrt(sum_h / 8);
			}

			/* Account for columns in the last block*/
			if (i == block_columns - 2)
				columns_in_block = last_columns;
			/* else - it shouldn't be mentioned, we initialize
			 * columns_in_block to 8 */

			/* Right block. We start with element 0 */
			sum_h = argb->getPixel((i+1)*8+0, row);
			for(n=1; n < columns_in_block; n++)
			{
				sum_h = sum_h + argb->getPixel((i+1)*8+n, row);
			}
			mu_r = sum_h / columns_in_block;

			/* Right block. Sigma. */
			sum_h = argb->getPixel((i+1)*8+0, row);
			for(n=1; n < columns_in_block; n++)
			{
				/* sum+h + (f_(i+1,n) - mu_l)^2 */
				sum_h = sum_h + square(argb->getPixel((i+1)*8+n, row) - mu_r);
			}
			sigma_r = sqrt(sum_h / columns_in_block);

			is_left_block_calculated = 1; /* true */

			/* Write the calculations */
			h_mu[row * (block_columns - 1) + i] = (mu_l + mu_r) / 2;
			h_sigma[row * (block_columns - 1) + i] =
				(sigma_l + sigma_r) / 2;
		}
	}
}

void
GBIM::argb_error_v_mu_sigma(float v_mu[], float v_sigma[],
		const int columns, const int block_rows)
{
	float sum_v, mu_u, mu_l, sigma_u, sigma_l = 0;
	/* The zero value above are for eviting the compiler warning for
	 * use of uninitialized values. They're right used in the code. */
	int column;
	int i;            /* It will go through the block rows */
	int n;            /* It will go through the rows IN a block */
	int last_rows;    /* The number of rows of the last block */
	int rows_in_block; /* For each block processed, the number of
				 rows */
	int is_upper_block_calculated;

	last_rows = argb->getHeight() % 8;
	if (last_rows == 0) last_rows = 8;

	/* The arrays h_* have 'rows' rows, and (block_columns-1) columns
	 * Thus, the accessing method is, for instance with h_mu:
	 *  h_mu[row * (block_columns-1) + column] */

	for(column = 0; column < columns; column++)
	{
		rows_in_block = 8;
		is_upper_block_calculated = 0; /* false at first block row */

		/* The last block
		 * will be processed specially because it may be a
		 * non full block. */
		for(i=0; i < block_rows - 1; i++)
		{
			if (is_upper_block_calculated)
			{
				mu_u = mu_l;
				sigma_u = sigma_l;
			}
			else /* The upper block is not calculated */
			{
				/* Upper block. Mu. We start with element 0 */
				sum_v = argb->getPixel(column, (i*8+0));
				for(n=1; n < 8; n++)
				{
					sum_v = sum_v + argb->getPixel(column, (i*8+n));
				}
				mu_u = sum_v / 8;

				/* Upper block. Sigma. */
				sum_v = argb->getPixel(column, (i*8+0));
				for(n=1; n < 8; n++)
				{
					/* sum+h + (f_(i,n) - mu_u)^2 */
					sum_v = sum_v + square(argb->getPixel(column, (i*8+n)) - mu_u);
				}
				sigma_u = sqrt(sum_v / 8);
			}

			/* Account for rows in the last block*/
			if (i == block_rows - 2)
				rows_in_block = last_rows;
			/* else - it shouldn't be mentioned, we initialize
			 * rows_in_block to 8 */

			/* Lower block. We start with element 0 */
			sum_v = argb->getPixel(column, ((i+1)*8+0));
			for(n=1; n < rows_in_block; n++)
			{
				sum_v = sum_v + argb->getPixel(column, ((i+1)*8+n));
			}
			mu_l = sum_v / rows_in_block;

			/* Lower block. Sigma. */
			sum_v = argb->getPixel(column, ((i+1)*8+0));
			for(n=1; n < rows_in_block; n++)
			{
				/* sum+h + (f_(i+1,n) - mu_u)^2 */
				sum_v = sum_v + square(argb->getPixel(column, ((i+1)*8+n)) - mu_l);
			}
			sigma_l = sqrt(sum_v / rows_in_block);

			is_upper_block_calculated = 1; /* true */

			/* Write the calculations */
			v_mu[i * columns + column] = (mu_u + mu_l) / 2;
			v_sigma[i * columns + column] =
				(sigma_u + sigma_l) / 2;
		}
	}
}


void
GBIM::argb_error_h_w(float h_w[], const float h_mu[], const float h_sigma[],
		const int rows, const int block_columns,
		const float zeta)
{
	int offset;
	float lambda;
	int row;
	int i;

	lambda = get_lambda(zeta);

	/* The arrays h_* have 'rows' rows, and (block_columns-1) columns
	 * Thus, the accessing method is, for instance with h_mu:
	 *  h_mu[row * (block_columns-1) + column] */
	for(row = 0; row < rows; row++)
		for(i=0; i < block_columns - 1; i++)
		{
			offset = row * (block_columns-1) + i;

			if (h_mu[offset] <= zeta)
				h_w[offset] = lambda
					* log(1+( sqrt(h_mu[offset])
						/ (1+h_sigma[offset])));
			else
				h_w[offset] = log(1+(sqrt(255 - h_mu[offset])
						/ (1+h_sigma[offset])));
		}
}

void
GBIM::argb_error_v_w(float v_w[], const float v_mu[], const float v_sigma[],
		const int columns, const int block_rows,
		const float zeta)
{
	int offset;
	float lambda;
	int column;
	int i;

	lambda = get_lambda(zeta);

	/* The arrays h_* have 'rows' rows, and (block_columns-1) columns
	 * Thus, the accessing method is, for instance with h_mu:
	 *  h_mu[row * (block_columns-1) + column] */
	for(column = 0; column < columns; column++)
		for(i=0; i < block_rows - 1; i++)
		{
			offset = i * columns + column;

			if (v_mu[offset] <= zeta)
				v_w[offset] = lambda
					* log(1+( sqrt(v_mu[offset])
						/ (1+v_sigma[offset])));
			else
				v_w[offset] = log(1+(sqrt(255 - v_mu[offset])
						/ (1+v_sigma[offset])));
		}
}


/* It gives the squared weighted differences between columns at
 *    offset and offset+1, being 0 the beginning of a block.
 *    for edge differences, offset = 7 (calculing Mh)
 *    for other differences, offset = [0,7) (calculing E)
 */
void
GBIM::argb_error_h_sqdiff(float h_weighted_sqdiff[], const float h_w[],
		const int rows, const int block_columns, const int offset)
{
	int k;
	int row;
	float sum_v; /* Sum of the row squared weighted differences */
	float difference;

	for(k=0; k < block_columns-1; k++)
	{
		sum_v = 0;
		for(row = 0; row < rows; row++)
		{
			difference = argb->getPixel(k*8+offset, row) - argb->getPixel(k*8+offset+1, row);

			sum_v = sum_v +
				(h_w[row * (block_columns-1) + k] * difference)*
				(h_w[row * (block_columns-1) + k] * difference);
		}
		h_weighted_sqdiff[k] = sum_v;
	}
}

/* It gives the squared weighted differences between rows at
 *    offset and offset+1, being 0 the beginning of a block.
 *    for edge differences, offset = 7 (calculing Mv)
 *    for other differences, offset = [0,7) (calculing E)
 */
void
GBIM::argb_error_v_sqdiff(float v_weighted_sqdiff[], const float v_w[],
		const int columns, const int block_rows, const int offset)
{
	int k;
	int column;
	float sum_h; /* Sum of the row squared weighted differences */
	float difference;

	for(k=0; k < block_rows-1; k++)
	{
		sum_h = 0;
		for(column = 0; column < columns; ++column)
		{
			difference = argb->getPixel(column, k*8+offset) - argb->getPixel(column, k*8+offset+1);

			sum_h = sum_h +
				(v_w[k * columns + column] * difference)*
				(v_w[k * columns + column] * difference);
		}
		v_weighted_sqdiff[k] = sum_h;
	}
}

float
GBIM::argb_error_mhgbim(const float zeta)
{
	float *h_mu, *h_sigma, *h_w, *h_weighted_sqdiff;
	int block_columns;
	int k,n;
	float h_S, E;
	float sum_v; /* Sum of the block column squared weighted differences */

	block_columns = (argb->getWidth() / 8 + ((argb->getWidth() % 8)?1:0));

	h_mu = new float[argb->getHeight() * (block_columns - 1 )];
	h_sigma = new float[argb->getHeight() * (block_columns - 1 )];
	h_w = new float[argb->getHeight() * (block_columns - 1 )];
	h_weighted_sqdiff = new float[block_columns - 1];
	
	/* Get mu, sigma */
	argb_error_h_mu_sigma(h_mu, h_sigma, argb->getHeight(), block_columns);
	/* Get weights w */
	argb_error_h_w(h_w, h_mu, h_sigma, argb->getHeight(), block_columns, zeta);
	/* Get squared weighted column differences for the edges (offset=7)*/
	argb_error_h_sqdiff(h_weighted_sqdiff, h_w, argb->getHeight(), block_columns, 7);

	/* now we have the weighted diferences for each block column*/
	sum_v = 0;
	for(k = 0; k < block_columns - 1; k++)
	{
		sum_v = sum_v + h_weighted_sqdiff[k];
	}
	h_S = sqrt(sum_v);

	/* Let's calculate for each E element offset (from 0 to 6).
	 * It's a variant over the original paper. Originally, it's
	 * between the second and the last block - arbitrally.
	 * We do that because the last block _may_ not be complete. */
	E = 0;
	for (n=0; n < 7; n++)
	{
		argb_error_h_sqdiff(h_weighted_sqdiff, h_w, argb->getHeight(),
				block_columns, n);
		sum_v = 0;
		for(k = 0; k < block_columns - 1; k++)
		{
			sum_v = sum_v + h_weighted_sqdiff[k];
		}
		E = E + sqrt(sum_v);
	}
	E = E / 7;

	delete[] h_mu;
	delete[] h_sigma;
	delete[] h_w;
	delete[] h_weighted_sqdiff;

	return h_S/E;
}


float
GBIM::argb_error_mvgbim(const float zeta)
{
	float *v_mu, *v_sigma, *v_w, *v_weighted_sqdiff;
	int block_rows;
	int k,n;
	float v_S, E;
	float sum_h; /* Sum of the block column squared weighted differences */

	block_rows = (argb->getHeight() / 8 + ((argb->getHeight() % 8)?1:0));

	v_mu = new float[argb->getWidth() * (block_rows - 1 )];
	v_sigma = new float[argb->getWidth() * (block_rows - 1 )];
	v_w = new float[argb->getWidth() * (block_rows - 1 )];
	v_weighted_sqdiff = new float[block_rows - 1];
	
	/* Get mu, sigma */
	argb_error_v_mu_sigma(v_mu, v_sigma, argb->getWidth(), block_rows);
	/* Get weights w */
	argb_error_v_w(v_w, v_mu, v_sigma, argb->getWidth(), block_rows, zeta);
	/* Get squared weighted column differences for the edges (offset=-1)*/
	argb_error_v_sqdiff(v_weighted_sqdiff, v_w, argb->getWidth(), block_rows, 7);

	/* now we have the weighted diferences for each block column*/
	sum_h = 0;
	for(k = 0; k < block_rows - 1; k++)
	{
		sum_h = sum_h + v_weighted_sqdiff[k];
	}
	v_S = sqrt(sum_h);

	/* Let's calculate for each E element offset (from 0 to 6).
	 * It's a variant over the original paper. Originally, it's
	 * between the second and the last block - arbitrally.
	 * We do that because the last block _may_ not be complete. */
	E = 0;
	for (n=0; n < 7; n++)
	{
		argb_error_v_sqdiff(v_weighted_sqdiff, v_w, argb->getWidth(),
				block_rows, n);
		sum_h = 0;
		for(k = 0; k < block_rows - 1; k++)
		{
			sum_h = sum_h + v_weighted_sqdiff[k];
		}
		E = E + sqrt(sum_h);
	}
	E = E / 7;

	delete[] v_mu;
	delete[] v_sigma;
	delete[] v_w;
	delete[] v_weighted_sqdiff;

	return v_S/E;
}

float
GBIM::argb_error_mgbim_zeta(const float zeta)
{
	const float alpha=0.5, beta=0.5;
	return (alpha * argb_error_mhgbim(zeta) + beta * argb_error_mvgbim(zeta));
}

/* MGBIM measure using zeta = 81, as in the paper. */
float
GBIM::argb_error_mgbim()
{
	return argb_error_mgbim_zeta(81);
}

void
GBIM::gray_error_h_mu_sigma(float h_mu[], float h_sigma[],
		const int rows, const int block_columns)
{
	float sum_h, mu_l, mu_r, sigma_l, sigma_r = 0;
	/* The zero value above are for eviting the compiler warning for
	 * use of uninitialized values. They're right used in the code. */
	int row;
	int i;            /* It will go through the block columns */
	int n;            /* It will go through the columns IN a block */
	int last_columns; /* The number of columns of the last block */
	int columns_in_block; /* For each block processed, the number of
				 columns */
	int is_left_block_calculated;

	last_columns = gray->getWidth() % 8;
	if (last_columns == 0) last_columns = 8;

	/* The arrays h_* have 'rows' rows, and (block_columns-1) columns
	 * Thus, the accessing method is, for instance with h_mu:
	 *  h_mu[row * (block_columns-1) + column] */

	for(row = 0; row < rows; row++)
	{
		columns_in_block = 8;
		is_left_block_calculated = 0; /* false at first block column */

		/* The last block
		 * will be processed specially because it may be a
		 * non full block. */
		for(i=0; i < block_columns - 1; i++)
		{
			if (is_left_block_calculated)
			{
				mu_l = mu_r;
				sigma_l = sigma_r;
			}
			else /* The left block is not calculated */
			{
				/* Left block. Mu. We start with element 0 */
				sum_h = gray->getPixel(i*8+0, row);
				for(n=1; n < 8; n++)
				{
					sum_h = sum_h + gray->getPixel(i*8+n, row);
				}
				mu_l = sum_h / 8;

				/* Left block. Sigma. */
				sum_h = gray->getPixel(i*8+0, row);
				for(n=1; n < 8; n++)
				{
					/* sum+h + (f_(i,n) - mu_l)^2 */
					sum_h = sum_h + square(gray->getPixel(i*8+n, row) - mu_l);
				}
				sigma_l = sqrt(sum_h / 8);
			}

			/* Account for columns in the last block*/
			if (i == block_columns - 2)
				columns_in_block = last_columns;
			/* else - it shouldn't be mentioned, we initialize
			 * columns_in_block to 8 */

			/* Right block. We start with element 0 */
			sum_h = gray->getPixel((i+1)*8+0, row);
			for(n=1; n < columns_in_block; n++)
			{
				sum_h = sum_h + gray->getPixel((i+1)*8+n, row);
			}
			mu_r = sum_h / columns_in_block;

			/* Right block. Sigma. */
			sum_h = gray->getPixel((i+1)*8+0, row);
			for(n=1; n < columns_in_block; n++)
			{
				/* sum+h + (f_(i+1,n) - mu_l)^2 */
				sum_h = sum_h + square(gray->getPixel((i+1)*8+n, row) - mu_r);
			}
			sigma_r = sqrt(sum_h / columns_in_block);

			is_left_block_calculated = 1; /* true */

			/* Write the calculations */
			h_mu[row * (block_columns - 1) + i] = (mu_l + mu_r) / 2;
			h_sigma[row * (block_columns - 1) + i] =
				(sigma_l + sigma_r) / 2;
		}
	}
}

void
GBIM::gray_error_v_mu_sigma(float v_mu[], float v_sigma[],
		const int columns, const int block_rows)
{
	float sum_v, mu_u, mu_l, sigma_u, sigma_l = 0;
	/* The zero value above are for eviting the compiler warning for
	 * use of uninitialized values. They're right used in the code. */
	int column;
	int i;            /* It will go through the block rows */
	int n;            /* It will go through the rows IN a block */
	int last_rows;    /* The number of rows of the last block */
	int rows_in_block; /* For each block processed, the number of
				 rows */
	int is_upper_block_calculated;

	last_rows = gray->getHeight() % 8;
	if (last_rows == 0) last_rows = 8;

	/* The arrays h_* have 'rows' rows, and (block_columns-1) columns
	 * Thus, the accessing method is, for instance with h_mu:
	 *  h_mu[row * (block_columns-1) + column] */

	for(column = 0; column < columns; column++)
	{
		rows_in_block = 8;
		is_upper_block_calculated = 0; /* false at first block row */

		/* The last block
		 * will be processed specially because it may be a
		 * non full block. */
		for(i=0; i < block_rows - 1; i++)
		{
			if (is_upper_block_calculated)
			{
				mu_u = mu_l;
				sigma_u = sigma_l;
			}
			else /* The upper block is not calculated */
			{
				/* Upper block. Mu. We start with element 0 */
				sum_v = gray->getPixel(column, (i*8+0));
				for(n=1; n < 8; n++)
				{
					sum_v = sum_v + gray->getPixel(column, (i*8+n));
				}
				mu_u = sum_v / 8;

				/* Upper block. Sigma. */
				sum_v = gray->getPixel(column, (i*8+0));
				for(n=1; n < 8; n++)
				{
					/* sum+h + (f_(i,n) - mu_u)^2 */
					sum_v = sum_v + square(gray->getPixel(column, (i*8+n)) - mu_u);
				}
				sigma_u = sqrt(sum_v / 8);
			}

			/* Account for rows in the last block*/
			if (i == block_rows - 2)
				rows_in_block = last_rows;
			/* else - it shouldn't be mentioned, we initialize
			 * rows_in_block to 8 */

			/* Lower block. We start with element 0 */
			sum_v = gray->getPixel(column, ((i+1)*8+0));
			for(n=1; n < rows_in_block; n++)
			{
				sum_v = sum_v + gray->getPixel(column, ((i+1)*8+n));
			}
			mu_l = sum_v / rows_in_block;

			/* Lower block. Sigma. */
			sum_v = gray->getPixel(column, ((i+1)*8+0));
			for(n=1; n < rows_in_block; n++)
			{
				/* sum+h + (f_(i+1,n) - mu_u)^2 */
				sum_v = sum_v + square(gray->getPixel(column, ((i+1)*8+n)) - mu_l);
			}
			sigma_l = sqrt(sum_v / rows_in_block);

			is_upper_block_calculated = 1; /* true */

			/* Write the calculations */
			v_mu[i * columns + column] = (mu_u + mu_l) / 2;
			v_sigma[i * columns + column] =
				(sigma_u + sigma_l) / 2;
		}
	}
}


void
GBIM::gray_error_h_w(float h_w[], const float h_mu[], const float h_sigma[],
		const int rows, const int block_columns,
		const float zeta)
{
	int offset;
	float lambda;
	int row;
	int i;

	lambda = get_lambda(zeta);

	/* The arrays h_* have 'rows' rows, and (block_columns-1) columns
	 * Thus, the accessing method is, for instance with h_mu:
	 *  h_mu[row * (block_columns-1) + column] */
	for(row = 0; row < rows; row++)
		for(i=0; i < block_columns - 1; i++)
		{
			offset = row * (block_columns-1) + i;

			if (h_mu[offset] <= zeta)
				h_w[offset] = lambda
					* log(1+( sqrt(h_mu[offset])
						/ (1+h_sigma[offset])));
			else
				h_w[offset] = log(1+(sqrt(255 - h_mu[offset])
						/ (1+h_sigma[offset])));
		}
}

void
GBIM::gray_error_v_w(float v_w[], const float v_mu[], const float v_sigma[],
		const int columns, const int block_rows,
		const float zeta)
{
	int offset;
	float lambda;
	int column;
	int i;

	lambda = get_lambda(zeta);

	/* The arrays h_* have 'rows' rows, and (block_columns-1) columns
	 * Thus, the accessing method is, for instance with h_mu:
	 *  h_mu[row * (block_columns-1) + column] */
	for(column = 0; column < columns; column++)
		for(i=0; i < block_rows - 1; i++)
		{
			offset = i * columns + column;

			if (v_mu[offset] <= zeta)
				v_w[offset] = lambda
					* log(1+( sqrt(v_mu[offset])
						/ (1+v_sigma[offset])));
			else
				v_w[offset] = log(1+(sqrt(255 - v_mu[offset])
						/ (1+v_sigma[offset])));
		}
}


/* It gives the squared weighted differences between columns at
 *    offset and offset+1, being 0 the beginning of a block.
 *    for edge differences, offset = 7 (calculing Mh)
 *    for other differences, offset = [0,7) (calculing E)
 */
void
GBIM::gray_error_h_sqdiff(float h_weighted_sqdiff[], const float h_w[],
		const int rows, const int block_columns, const int offset)
{
	int k;
	int row;
	float sum_v; /* Sum of the row squared weighted differences */
	float difference;

	for(k=0; k < block_columns-1; k++)
	{
		sum_v = 0;
		for(row = 0; row < rows; row++)
		{
			difference = gray->getPixel(k*8+offset, row) - gray->getPixel(k*8+offset+1, row);

			sum_v = sum_v +
				(h_w[row * (block_columns-1) + k] * difference)*
				(h_w[row * (block_columns-1) + k] * difference);
		}
		h_weighted_sqdiff[k] = sum_v;
	}
}

/* It gives the squared weighted differences between rows at
 *    offset and offset+1, being 0 the beginning of a block.
 *    for edge differences, offset = 7 (calculing Mv)
 *    for other differences, offset = [0,7) (calculing E)
 */
void
GBIM::gray_error_v_sqdiff(float v_weighted_sqdiff[], const float v_w[],
		const int columns, const int block_rows, const int offset)
{
	int k;
	int column;
	float sum_h; /* Sum of the row squared weighted differences */
	float difference;

	for(k=0; k < block_rows-1; k++)
	{
		sum_h = 0;
		for(column = 0; column < columns; ++column)
		{
			difference = gray->getPixel(column, k*8+offset) - gray->getPixel(column, k*8+offset+1);

			sum_h = sum_h +
				(v_w[k * columns + column] * difference)*
				(v_w[k * columns + column] * difference);
		}
		v_weighted_sqdiff[k] = sum_h;
	}
}

float
GBIM::gray_error_mhgbim(const float zeta)
{
	float *h_mu, *h_sigma, *h_w, *h_weighted_sqdiff;
	int block_columns;
	int k,n;
	float h_S, E;
	float sum_v; /* Sum of the block column squared weighted differences */

	block_columns = (gray->getWidth() / 8 + ((gray->getWidth() % 8)?1:0));

	h_mu = new float[gray->getHeight() * (block_columns - 1 )];
	h_sigma = new float[gray->getHeight() * (block_columns - 1 )];
	h_w = new float[gray->getHeight() * (block_columns - 1 )];
	h_weighted_sqdiff = new float[block_columns - 1];
	
	/* Get mu, sigma */
	gray_error_h_mu_sigma(h_mu, h_sigma, gray->getHeight(), block_columns);
	/* Get weights w */
	gray_error_h_w(h_w, h_mu, h_sigma, gray->getHeight(), block_columns, zeta);
	/* Get squared weighted column differences for the edges (offset=7)*/
	gray_error_h_sqdiff(h_weighted_sqdiff, h_w, gray->getHeight(), block_columns, 7);

	/* now we have the weighted diferences for each block column*/
	sum_v = 0;
	for(k = 0; k < block_columns - 1; k++)
	{
		sum_v = sum_v + h_weighted_sqdiff[k];
	}
	h_S = sqrt(sum_v);

	/* Let's calculate for each E element offset (from 0 to 6).
	 * It's a variant over the original paper. Originally, it's
	 * between the second and the last block - arbitrally.
	 * We do that because the last block _may_ not be complete. */
	E = 0;
	for (n=0; n < 7; n++)
	{
		gray_error_h_sqdiff(h_weighted_sqdiff, h_w, gray->getHeight(),
				block_columns, n);
		sum_v = 0;
		for(k = 0; k < block_columns - 1; k++)
		{
			sum_v = sum_v + h_weighted_sqdiff[k];
		}
		E = E + sqrt(sum_v);
	}
	E = E / 7;

	delete[] h_mu;
	delete[] h_sigma;
	delete[] h_w;
	delete[] h_weighted_sqdiff;

	return h_S/E;
}


float
GBIM::gray_error_mvgbim(const float zeta)
{
	float *v_mu, *v_sigma, *v_w, *v_weighted_sqdiff;
	int block_rows;
	int k,n;
	float v_S, E;
	float sum_h; /* Sum of the block column squared weighted differences */

	block_rows = (gray->getHeight() / 8 + ((gray->getHeight() % 8)?1:0));

	v_mu = new float[gray->getWidth() * (block_rows - 1 )];
	v_sigma = new float[gray->getWidth() * (block_rows - 1 )];
	v_w = new float[gray->getWidth() * (block_rows - 1 )];
	v_weighted_sqdiff = new float[block_rows - 1];
	
	/* Get mu, sigma */
	gray_error_v_mu_sigma(v_mu, v_sigma, gray->getWidth(), block_rows);
	/* Get weights w */
	gray_error_v_w(v_w, v_mu, v_sigma, gray->getWidth(), block_rows, zeta);
	/* Get squared weighted column differences for the edges (offset=-1)*/
	gray_error_v_sqdiff(v_weighted_sqdiff, v_w, gray->getWidth(), block_rows, 7);

	/* now we have the weighted diferences for each block column*/
	sum_h = 0;
	for(k = 0; k < block_rows - 1; k++)
	{
		sum_h = sum_h + v_weighted_sqdiff[k];
	}
	v_S = sqrt(sum_h);

	/* Let's calculate for each E element offset (from 0 to 6).
	 * It's a variant over the original paper. Originally, it's
	 * between the second and the last block - arbitrally.
	 * We do that because the last block _may_ not be complete. */
	E = 0;
	for (n=0; n < 7; n++)
	{
		gray_error_v_sqdiff(v_weighted_sqdiff, v_w, gray->getWidth(),
				block_rows, n);
		sum_h = 0;
		for(k = 0; k < block_rows - 1; k++)
		{
			sum_h = sum_h + v_weighted_sqdiff[k];
		}
		E = E + sqrt(sum_h);
	}
	E = E / 7;

	delete[] v_mu;
	delete[] v_sigma;
	delete[] v_w;
	delete[] v_weighted_sqdiff;

	return v_S/E;
}

float
GBIM::gray_error_mgbim_zeta(const float zeta)
{
	const float alpha=0.5, beta=0.5;
	return (alpha * gray_error_mhgbim(zeta) + beta * gray_error_mvgbim(zeta));
}

/* MGBIM measure using zeta = 81, as in the paper. */
float
GBIM::gray_error_mgbim()
{
	return gray_error_mgbim_zeta(81);
}

GBIM::GBIM()
{
    name = "GBIM";
}

void GBIM::prepare(const ARGBImage *img)
{
    argb = img;
    type = ARGB;
}

void GBIM::prepare(const GrayImage *img)
{
    gray = img;
    type = Gray;
}

MeasureResult * GBIM::apply()
{
    MeasureResult *res = new MeasureResult();
    switch(type)
    {
        case Gray:
            res->text += QString("Gray: \%1\n").arg(gray_error_mgbim());
            break;
        case ARGB:
            argb->setPlane(0);
            res->text += QString("Red: \%1\n").arg(argb_error_mgbim());
            argb->setPlane(1);
            res->text += QString("Green: \%1\n").arg(argb_error_mgbim());
            argb->setPlane(2);
            res->text += QString("Blue: \%1\n").arg(argb_error_mgbim());
            break;
    }
    return res;
}


GBIMCreator::GBIMCreator()
{
    type = e_Measure;
}

bool GBIMCreator::isapplicable(const JPEGParameters &p)
{
    return true;
}


void GBIMCreator::init()
{
    ActionCreator *a = new GBIMCreator();
    ActionManager::sreg("GBIM", a);
}

Measure * GBIMCreator::createMeasure() const
{
    return new GBIM();
}
