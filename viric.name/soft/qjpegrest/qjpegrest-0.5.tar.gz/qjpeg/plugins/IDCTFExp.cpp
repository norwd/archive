/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include "ActionType.h"
#include <FloatPlane.h>
#include <JPEGData.h>
#include <CoefsPlane.h>
#include <ActionCreator.h>
#include <Actions.h>
#include <ActionManager.h>
#include "IDCTFExp.h"
#include <cstdlib> // getenv
#include <cstdio> // sscanf
#include <cmath> // floor
extern "C" {
#include <cdct.h>
}

/* Taken the proposal from:
 *  "An efficient algorithm for the enhancement of JPEG-coded images"
 *  G.A. Triantafyllidis, M. Varnuska, D. Sampson, D. Tzovaras, M.G. Strintzis
 *  April 2003
 *
 *  Basically, using an exponential random variable for the probability
 *  of the dequantization of AC coefficients.
 *
 *  Parameters:
 *     mu - paramter of the exp random variable.
 */

const float IDCTFExp::zeromargin = 1e-5f;

void IDCTFExp::prepare(const CoefsPlane *in)
{
    IDCTFExp::coefs = *in;

    maxProgress = 2;
    setProgress(0);
}

FloatPlane * IDCTFExp::apply()
{
    unsigned int width, height;

    ComponentData p = coefs.getParameters();
    for(unsigned int i=0; i < DCTSize2; ++i)
        qtable[i] = p.qtable[i];

    /* Prepare dimensions */
    width = coefs.getWidthInBlocks() * DCTSize;
    height = coefs.getHeightInBlocks() * DCTSize;

    result = new FloatPlane();
    result->allocate(width, height);

    /* Dequantize according to an exponential with mean mu.
     * Eq. 3. */
    dequantize_coefs();

    setProgress(1); /* half */

    /* IDCT the dequantized coefs. */
    fdct_inverse_image(DCTimage.getPtr(), result->getPtr(), width, height);

    DCTimage.free();

    setProgress(maxProgress);

    return result;
}

IDCTFExpCreator::IDCTFExpCreator()
{
    type = e_IDCTPlane;
}

bool IDCTFExpCreator::isapplicable(const JPEGParameters &p)
{
    return true;
}


void IDCTFExpCreator::init()
{
    ActionCreator *a = new IDCTFExpCreator();
    ActionManager::sreg("IDCTFExp", a);
}

IDCTPlane * IDCTFExpCreator::createIDCTPlane() const
{
    return new IDCTFExp();
}

IDCTFExp::IDCTFExp()
{
    name = "IDCTFExp";
    mu = 0.5;
}

float IDCTFExp::despcoef(float coefmean)
{
    float res;
    float e;

    if (coefmean > -zeromargin && coefmean < zeromargin) /* == 0 */
    {
        res = 0;
    } else if (coefmean > 0)
    {
        e = expf(-1./mu);
        res = (-0.5 + mu - e / (1 - e));
    } else if (coefmean < 0)
    {
        e = expf(-1./mu);
        res = (0.5 - mu + e / (1 - e));
    }
    return res;
}

void IDCTFExp::dequantize_coefs()
{
    DCTimage = coefs.newcopy();
    
    float * cptr = coefs.getPtr();

    for (unsigned int j=0;j<coefs.getHeightInBlocks();++j)
        for (unsigned int i=0;i<coefs.getWidthInBlocks();++i)
        {
            unsigned int base = (j * coefs.getWidthInBlocks() + i) * DCTSize2;
            for (unsigned int k=0;k<DCTSize2;k++)
            {
                float mean;
                float val;
                mean = cptr[base+k];
                val = mean;

                if (k != 0) /* Only for AC coefficients */
                    val += despcoef(mean)*qtable[k];

                if (val > mean + (0.5*qtable[k]))
                    val = mean + (0.5*qtable[k]);
                else if (val < mean - (0.5 * qtable[k]))
                    val = mean - (0.5*qtable[k]);

                DCTimage.getPtr()[base+k] = val;
            }
        }
}
