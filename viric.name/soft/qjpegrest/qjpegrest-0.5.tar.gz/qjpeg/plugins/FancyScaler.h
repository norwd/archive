/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class Scaler;
class CoefsImage;
class FloatImage;
class ActionCreator;

class FancyScaler : public Scaler
{
    const FloatImage *infimage;
    /*! Although we don't use the coefs, we take from there the
     * jpegdata */
    const CoefsImage *incimage;
public:
    FancyScaler();
	void prepare(const CoefsImage *coefs,
            const FloatImage *initial);
	FloatImage * apply();
};

class FancyScalerCreator : public ActionCreator
{
    FancyScalerCreator();

public:
    static void init();

    Scaler * createScaler() const;
	bool isapplicable(const JPEGParameters &p);
};
