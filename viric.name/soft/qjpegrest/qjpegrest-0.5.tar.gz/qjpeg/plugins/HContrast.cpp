/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include "ActionType.h"
#include <FloatPlane.h>
#include <JPEGData.h>
#include <CoefsPlane.h>
#include <ActionCreator.h>
#include <Actions.h>
#include <ActionManager.h>
#include "HContrast.h"
#include <cstdlib> // getenv
#include <cstdio> // debug
#include <cmath> // fabs
extern "C" {
#include <cdct.h>
}


void HContrast::prepare(const CoefsPlane *coefs,
            const FloatPlane *initial)
{
    reference = *initial;
    HContrast::coefs = *coefs;

    maxProgress = 2;
    setProgress(0);
}

FloatPlane * HContrast::apply()
{
    ComponentData p = coefs.getParameters();
    for(unsigned int i=0; i < DCTSize2; ++i)
        qtable[i] = p.qtable[i];

    result = new FloatPlane();

    start_restoration();

    DCTmax.free();
    DCTmin.free();
    DCTimage.free();
    normal.free();

    return result;
}

HContrastCreator::HContrastCreator()
{
    type = e_ImproveRawPlane;
}

bool HContrastCreator::isapplicable(const JPEGParameters &p)
{
    return true;
}


void HContrastCreator::init()
{
    ActionCreator *a = new HContrastCreator();
    ActionManager::sreg("HContrast (alter)", a);
}

ImproveRawPlane * HContrastCreator::createImproveRawPlane() const
{
    return new HContrast();
}

HContrast::HContrast()
{
    name = "HContrast (alter)";
    thlevel = 0.1;
    winsize = 7;
}


void
HContrast::start_restoration ()
{
  /* Prepare dimensions */
  width_in_blocks = coefs.getWidthInBlocks();
  height_in_blocks = coefs.getHeightInBlocks();

  /* Load the coefficients, and prepare the DCT ranges */
  set_DCT_constraint();

  /* Overwrite of previous uninitialized *result */
  *result = reference.newcopy();

  setProgress(1);

  decompress_normal();

  mix();

  setProgress(maxProgress);
}

void HContrast::decompress_normal()
{
    /* set_DCT_constraint prepares DCTimage */
    normal.allocate(width_in_blocks*8, height_in_blocks*8);
    fdct_inverse_image(DCTimage.getPtr(), normal.getPtr(), width_in_blocks*8,
            height_in_blocks*8);
}

void HContrast::set_DCT_constraint()
{
    DCTimage = coefs.newcopy();
    
    DCTmin.allocate(width_in_blocks,height_in_blocks);
    DCTmax.allocate(width_in_blocks,height_in_blocks);

    float * cptr = coefs.getPtr();

    for (unsigned int j=0;j<height_in_blocks;++j)
        for (unsigned int i=0;i<width_in_blocks;++i)
        {
            unsigned int base = (j * width_in_blocks + i) * DCTSize2;
            for (unsigned int k=0;k<DCTSize2;k++)
            {
              DCTimage.getPtr()[base+k]=cptr[base+k];
              DCTmin.getPtr()[base+k]=cptr[base+k] - (0.5*qtable[k]);
              DCTmax.getPtr()[base+k]=cptr[base+k] + (0.5*qtable[k]);
            }
        }
}

#if 0
float HContrast::getContrast(const FloatPlane *p, int x, int y) const
{
    float mean, var;
    int border = (winsize - 1) / 2;

    mean = var = 0.;
    for(int j = y-border; j < y+border; ++j)
    {
        for(int i = x-border; j < y+border; ++j)
        {
            float val = p->get(i, j);
            mean += val;
            var += val*val;
        }
    }
    mean /= (float) winsize * (float) winsize;
    var = (var - (float) winsize*mean*mean) / 48.;
    return var;
}
#endif

float HContrast::getContrast(const FloatPlane *p, int x, int y) const
{
    float max, min;
    int border = (winsize - 1) / 2;

    max = -1000; min = 1000;
    for(int j = y-border; j < y+border; ++j)
    {
        for(int i = x-border; j < y+border; ++j)
        {
            if (p->get(i,j) > max)
                max = p->get(i,j);
            if (p->get(i,j) < min)
                min = p->get(i,j);
        }
    }

    /* Michelson formula */
    return (max - min) / (max + min);
}

void HContrast::mix()
{
    int i, j, k;
    unsigned int width, height;
    int border = (winsize - 1) / 2;
    width = width_in_blocks*8;
    height = height_in_blocks*8;

    /* The margins get copied from reference, when
     * result = reference. newcopy() before */
    for (unsigned int j=border;j<height-border;++j)
        for (unsigned int i=border;i<width-border;++i)
        {
            float diffcontrast;

            diffcontrast = getContrast(&normal, i, j)
                - getContrast(&reference, i, j);

            if (diffcontrast > thlevel)
                result->set(i,j, normal.get(i,j));
            else
                result->set(i,j, reference.get(i,j));
        }
}
