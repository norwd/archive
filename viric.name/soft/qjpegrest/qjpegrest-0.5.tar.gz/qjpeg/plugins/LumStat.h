/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class ARGBImage;
class GrayImage;
class MeasureResult;
class Measure;
class ActionCreator;

template<class DataType> class Stat;

class LLStat : public Stat<long long int> {};

class LLStat4
{
    public:
        LLStat red, green, blue;
        Stat<double> lum;
};

class LumStat : public Measure
{
    enum {
        ARGB,
        Gray
    } type;
    const ARGBImage *argb;
    const GrayImage *gray;

	LLStat4 argb_stat();
	LLStat gray_stat();
public:
    LumStat();
	void prepare(const ARGBImage *img);
	void prepare(const GrayImage *img);
	MeasureResult * apply();
};

class LumStatCreator : public ActionCreator
{
    LumStatCreator();

public:
    static void init();

    Measure * createMeasure() const;
	bool isapplicable(const JPEGParameters &p);
};
