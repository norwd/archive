/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class CoefsPlane;
class FloatPlane;

class Robertson : public ImproveRawPlane
{
protected:
    int steps;
    float T_Huber;
    float step_size;
    float lambda;
    static const float MINIMUM_STEP_SIZE;

private:
    CoefsPlane DCTmin;
    CoefsPlane DCTmax;
    CoefsPlane DCTimage;

    /*! Width in blocks * 8 */
    unsigned int width;
    /*! Height in blocks * 8 */
    unsigned int height;

    /*! The initial floatplane, from which apply Nosratinia */
    FloatPlane reference;
    /*! Article's z. Final image for each step */
    FloatPlane bitmap;
    /*! Estimated new picture after each descent step */
    FloatPlane estimate;
    /*! Gradient for the descent algorithm */
    FloatPlane gradient;

    Qtable qtable;
    Qtable inv_k_ey; /* DCT-domain error autocovariance */
    CoefsPlane coefs;

    void start_restoration();
    void set_DCT_constraint();
    void min_map();
    float calc_objective(const FloatPlane &plane);
    void calc_gradient_hubber();
    void get_new_estimate(float ssize);
    float f_huber(float u);
    void project(const FloatPlane &in, FloatPlane &out);
    float diff_huber(float u);
    void calc_inv_k_ey();
    void add_noise_to_gradient();

public:
    Robertson();
    virtual ~Robertson() {};

	void prepare(const CoefsPlane *coefs,
            const FloatPlane *initial);
	FloatPlane * apply();
    bool getConfiguredEnv();
};

class RobertsonCreator : public ActionCreator
{
    RobertsonCreator();

public:
    static void init();

    ImproveRawPlane * createImproveRawPlane() const;
	bool isapplicable(const JPEGParameters &p);
};
