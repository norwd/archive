/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <JPEGData.h>
#include <FloatPlane.h>
#include <FloatImage.h>
#include <cstdio>
#include <cstdlib>

extern "C" {
#include <pam.h>
}

using namespace std;

void rgb2ycc(float r, float g, float b, float &y, float &cb, float &cr)
{
    y = 0.29900 * r + 0.58700 * g + 0.11400 * b;
    cb = -0.16874 * r - 0.33126 * g + 0.5000 * b + 128.;
    cr = 0.5 * r - 0.41869 * g - 0.08131 * b + 128.;
}

void convert(FloatImage *img)
{
    int i;
    int len;

    len = img->getWidth() * img->getHeight();

    for (i=0; i < len; ++i){
        float r, g, b, y, cb, cr;
        r = img->plane[0].getPtr()[i];
        g = img->plane[1].getPtr()[i];
        b = img->plane[2].getPtr()[i];
        rgb2ycc(r,g,b,y,cb,cr);
        img->plane[0].getPtr()[i] = y;
        img->plane[1].getPtr()[i] = cb;
        img->plane[2].getPtr()[i] = cr;
    }
}

FloatImage * readPPM(char *fname)
{
    FILE * f;
    struct pam inpam;
    tuple **tuples;
    FloatPlane planes[3];
    FloatImage *img;
    int row, column, plane;

    f = fopen(fname, "r");

    tuples = pnm_readpam(f, &inpam, PAM_STRUCT_SIZE(tuple_type));
    if (inpam.depth != 3)
    {
        printf("Error: %i planes instead of 3.\n", inpam.depth);
        exit(-1);
    }

    for (int i=0; i < 3; ++i)
        /*
        planes[i] = new FloatPlane(inpam.width, inpam.height);
        */
        planes[i].allocate(inpam.width, inpam.height);


    for (row = 0; row < inpam.height; row++) {
        for (column = 0; column < inpam.width; ++column) {
            for (plane = 0; plane < 3; plane++)
                planes[plane].getPtr()[row *
                    inpam.width + column] = tuples[row][column][plane];
        }
    }

    pnm_freepamarray(tuples, &inpam);
    fclose(f);

    img = new FloatImage(planes, 3);

    return img;
}

int main(int argc, char **argv)
{
    FloatImage *img;

    if (argc < 3)
    {
        printf("usage: %s image_in.pnm image_out.pnm\n");
        exit(-1);
    }

    pnm_init(&argc, argv);

    img = readPPM(argv[1]);
    convert(img);
    img->writePPM(argv[2]);
}
