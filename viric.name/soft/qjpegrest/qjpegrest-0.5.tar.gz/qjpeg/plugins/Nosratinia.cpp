/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <ActionType.h>
#include <FloatPlane.h>
#include <JPEGData.h>
#include <CoefsPlane.h>
#include <ActionCreator.h>
#include <Actions.h>
#include <ActionManager.h>
#include "Nosratinia.h"
#include <cstdlib> // getenv
#include <cstdio> // sscanf
#include <cmath> // floor
extern "C" {
#include <cdct.h>
}

/* Implementation of the method developed by Aria Nosratinia:
     Enhancement of JPEG-Compressed Images by Re-application of JPEG
   (c) 2002 Kluwer Academic Publishers.

   Notes:
   - The implementation from Nikhil Hegde has been a reference for writting
     this one.
*/

enum {
    MAXSHIFTS = 64
};

/* Prototypes */
static void fdct_inverse_image_shift(float * coefdct, float * out,
    const int w, int const h, const int shift_x, const int shift_y);
static void fdct_image_shift (float * coefdct, float * in,
    const int w, int const h, const int shift_x, const int shift_y);

void Nosratinia::prepare(const CoefsPlane *coefs,
            const FloatPlane *initial)
{
    reference = *initial;
    Nosratinia::coefs = *coefs;

    maxProgress = shifts+1;
    setProgress(0);
}

FloatPlane * Nosratinia::apply()
{
    ComponentData p = coefs.getParameters();
    for(unsigned int i=0; i < DCTSize2; ++i)
        qtable[i] = p.qtable[i];

    start_restoration();

    FloatPlane *result = new FloatPlane();
    *result = bitmap;
    sums.free();
    DCTmax.free();
    DCTmin.free();
    DCTimage.free();

    return result;
}

NosratiniaCreator::NosratiniaCreator()
{
    type = e_ImproveRawPlane;
}

bool NosratiniaCreator::isapplicable(const JPEGParameters &p)
{
    return true;
}


void NosratiniaCreator::init()
{
    ActionCreator *a = new NosratiniaCreator();
    ActionManager::sreg("Nosratinia (alter)", a);
}

ImproveRawPlane * NosratiniaCreator::createImproveRawPlane() const
{
    return new Nosratinia();
}

Nosratinia::Nosratinia()
{
    name = "Nosratinia (alter)";
    /* Default configuration */
    shifts = MAXSHIFTS;
    calculate_shifts();
}

bool Nosratinia::getConfiguredEnv()
{
  char *env_var;

  env_var = std::getenv("JPEG_NOSRATINIA_SHIFTS");
  if (env_var != NULL)
    std::sscanf(env_var, "%u", &shifts);
  else
      return false;

  calculate_shifts();
  return true;
}


void
Nosratinia::start_restoration ()
{
  /* Prepare dimensions */
  width = coefs.getWidthInBlocks() * DCTSize;
  height = coefs.getHeightInBlocks() * DCTSize;
  nsums = 0;

  /* Load the coefficients, and prepare the DCT ranges */
  set_DCT_constraint();

  /* Allocate the bitmap */
  bitmap.allocate(width, height);

  /* Allocate the sums */
  sums.allocate(width, height);

  /* Zero sums */
  sums.setzero();

  loopshifts();

  average_bitmap();

  /* We don't project. This alters the JPEG */

  setProgress(maxProgress);
}

void
Nosratinia::average_bitmap()
{
  unsigned int index, row, col;

  for(row=0; row < height; row++) 
    for (col=0; col < width; col++)
    {
      index = row * width + col; 
      bitmap.getPtr()[index] = sums.getPtr()[index] / (float) nsums;
    }
}

void Nosratinia::loopshifts()
{
  int shift;

  int shift_y, shift_x;

  shift_y = min_shift;
  shift_x = min_shift;

  shift = 0;

  /* add into the sums */
  add2sums(reference);
  shift++;
  
  for (; shift <= shifts; shift++)
  {
    setProgress(shift);
    /* Forget the central image */
    if (shift_x == 0 && shift_y == 0)
    {
      shift_x++;
      continue;
    }

    /* Reget the 'reference' over the 'bitmap'.*/
    bitmap.free();
    bitmap = reference.newcopy();

    /* Decompress the image */
    fdct_image_shift(DCTimage.getPtr(), bitmap.getPtr(), width, height,
            shift_x, shift_y);

    /* Quantize the new coef with the component qtable */
    quantize();

    /* Decompress the image */
    fdct_inverse_image_shift(DCTimage.getPtr(), bitmap.getPtr(), width, height,
            shift_x, shift_y);

    /* add into the sums */
    add2sums(bitmap);

    /* Calculate shift offsets */
    shift_x++;
    if (shift_x > max_shift)
    {
      shift_y++;
      shift_x = min_shift;
    }
  }
}

/* IDCT on the whole image, with shifts */

static void
fdct_inverse_image_shift(float * coefdct, float * out,
    const int w, int const h, const int shift_x, const int shift_y)
{
  int i,j,x,y;
  RSAMP * ptr;
  RSAMP out_gray[DCTSize2]; 
  int index_y, index_x;

  for (i=0; i<h; i+=DCTSize)
    for (j=0; j<w;j+=DCTSize) 
      {
	fidct_buffer(coefdct, out_gray);
	coefdct+=DCTSize2;
	ptr=out_gray;
	for (y=0;y<DCTSize;y++)
	  for (x=0;x<DCTSize;x++)
	  {
	    index_y = i + y + shift_y;
	    if (index_y < 0)
	      index_y = 0;
	    else if (index_y >= h)
	      index_y = h - 1;

	    index_x = j + x + shift_x;
	    if (index_x < 0)
	      index_x = 0;
	    else if (index_x >= w)
	      index_x = w - 1;
	    out[index_y*w + index_x]=*(ptr++);
	  }
      }
}

/* DCT on the whole image, with shifts */

static void
fdct_image_shift (float * coefdct, float * in,
    const int w, int const h, const int shift_x, const int shift_y)
{
  int i,j,x,y;
  float in_gray[DCTSize2];
  RSAMP * ptr;
  int index_y, index_x;

  for (i=0; i<h; i+=DCTSize)
    for (j=0; j<w;j+=DCTSize) 
    {
      ptr=in_gray;
      for (y=0;y<DCTSize;y++)
	for (x=0;x<DCTSize;x++)
	{
	  index_y = i + y + shift_y;
	  if (index_y < 0)
	    index_y = 0;
	  else if (index_y >= h)
	    index_y = h - 1;

	  index_x = j + x + shift_x;
	  if (index_x < 0)
	    index_x = 0;
	  else if (index_x >= w)
	    index_x = w - 1;

	  *(ptr++)=in[index_y*w + index_x];
	}
      fdct_buffer(in_gray, coefdct);
      coefdct+=DCTSize2;
    }
}


void Nosratinia::quantize()
{
  float * coef = DCTimage.getPtr();


  /* The next is equivalent to width_in_blocks*height_in_blocks*DCTSize2 */
  unsigned int length = width*height;
  int num_coef = 0;
  for (unsigned int i=0; i<length; ++i)
  {
    *coef = *coef / qtable[num_coef];
    *coef += 0.5;
    *coef = std::floor(*coef) * qtable[num_coef];
    coef++;
    /* num_coef should loop from 0 to 63 */
    if(num_coef == 63)
        num_coef = 0;
    else
        ++num_coef;
  }
}

void Nosratinia::set_DCT_constraint()
{
    DCTimage = coefs.newcopy();
    
    DCTmin.allocate(coefs.getWidthInBlocks(), coefs.getHeightInBlocks());
    DCTmax.allocate(coefs.getWidthInBlocks(), coefs.getHeightInBlocks());

    float * cptr = coefs.getPtr();

    for (unsigned int j=0;j<coefs.getHeightInBlocks();++j)
        for (unsigned int i=0;i<coefs.getWidthInBlocks();++i)
        {
            unsigned int base = (j * coefs.getWidthInBlocks() + i) * DCTSize2;
            for (unsigned int k=0;k<DCTSize2;k++)
            {
              DCTmin.getPtr()[base+k]=cptr[base+k] - (0.5*qtable[k]);
              DCTmax.getPtr()[base+k]=cptr[base+k] + (0.5*qtable[k]);
            }
        }
}

/*! Calculate the number and ranges of shifts */
void Nosratinia::calculate_shifts()
{
  if (shifts < 1)
    shifts = 1;
  else if (shifts > MAXSHIFTS)
    shifts = MAXSHIFTS;

  if (shifts == 1)
  {
    min_shift = 0;
    max_shift = 0;
  }
  else if (shifts <= 3*3)
  {
    min_shift = -1;
    max_shift = 1;
  }
  else if (shifts <= 5*5)
  {
    min_shift = -2;
    max_shift = 2;
  }
  else if (shifts <= 7*7)
  {
    min_shift = -3;
    max_shift = 3;
  }
  else if (shifts <= 8*8)
  {
    min_shift = -3;
    max_shift = 4;
  }
}

void Nosratinia::add2sums(FloatPlane &from)
{
  sums.add(from);
  ++nsums;
}


/* Projection on the constraint - by Froment*/
/*! Projects the DCTimage into out, according to DCTmin and DCTmax */
void Nosratinia::project(FloatPlane &out)
{
  fdct_image(DCTimage.getPtr(), out.getPtr(), width, height);
    
  unsigned int length = width * height;
  for (unsigned int j=0;j<length;j++)
    if (DCTimage.getPtr()[j] > DCTmax.getPtr()[j])
      DCTimage.getPtr()[j] = DCTmax.getPtr()[j];
    else if (DCTimage.getPtr()[j] < DCTmin.getPtr()[j])
      DCTimage.getPtr()[j] = DCTmin.getPtr()[j];

  fdct_inverse_image(DCTimage.getPtr(), out.getPtr(), width, height);
}
