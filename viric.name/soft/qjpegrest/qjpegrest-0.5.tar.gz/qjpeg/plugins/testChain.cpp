/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <ActionType.h>
#include <ActionManager.h>
#include <Actions.h>
#include <ActionCreator.h>
#include <JPEGData.h>
#include <JPEGFile.h>
#include <CoefsPlane.h>
#include <CoefsImage.h>
#include <FloatPlane.h>
#include <FloatImage.h>
#include <Chain.h>
#include "IDCTFloat.h"
#include "IntScaler.h"
#include "YCC2RGB.h"
#include "Nosratinia.h"

static void initialize()
{
    new ActionManager();
    IDCTFloatCreator::init();
    IntScalerCreator::init();
    YCC2RGBCreator::init();
    NosratiniaCreator::init();
}

int main()
{
    initialize();

    /* Open a jpeg */
    JPEGFile jfile("a.jpg");

    /* Get the coefficients */
    CoefsImage * coefs = jfile.getCoefs();

    Chain c(coefs);

    for (unsigned int i = 0; i<coefs->getComponents(); ++i)
        c.setIDCTPlane(i,"IDCTFloat");

    /*
    for (unsigned int i = 0; i<coefs->getComponents(); ++i)
        c.addImproveRawPlane(i,"Nosratinia");
        */

    c.setScaler("IntScaler");
    c.addColorMap("YCC2RGB");

    FloatImage * fimage = c.apply();

    fimage->writePPM("prova.ppm");

    fimage->free();
    delete fimage;
    coefs->free();
    delete coefs;
    ActionManager::destroy();
}
