/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class ARGBImage;
class GrayImage;
class MeasureResult;
class Compare;
class ActionCreator;

class PSNR : public Compare
{
    enum {
        ARGB,
        Gray
    } type;
    const ARGBImage *rgbimg1, *rgbimg2;
    const GrayImage *gray1, *gray2;

    float fromGray();
    void fromARGB(float psnrs[3]);

public:
    PSNR();
	void prepare(const ARGBImage *img1, const ARGBImage *img2);
	void prepare(const GrayImage *img1, const GrayImage *img2);
	MeasureResult * apply();
};

class PSNRCreator : public ActionCreator
{
    PSNRCreator();

public:
    static void init();

    Compare * createCompare() const;
	bool isapplicable(const JPEGParameters &p);
};
