/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class Scaler;
class CoefsImage;
class FloatImage;
class ActionCreator;

class HP : public ImproveRawPlane
{
protected:
    unsigned int shifts;
    /* Percent of the lowest pixel spatial variations */
    float percent_var;
private:
    int min_shift;
    int max_shift;

    CoefsPlane DCTmin;
    CoefsPlane DCTmax;
    CoefsPlane DCTimage;

    /*! Array of bitmaps, where all shifted images will be stored. */
    FloatPlane *bitmap;
    /*! The initial floatplane, from which apply HP */
    FloatPlane reference;
    /*! We use this image for adding other images, and then averagin */
    FloatPlane sums;
    /*! I don't remember what it is */
    FloatPlane alpha;
    /*! Final image */
    FloatPlane final;
    /*! Counts how many additions we made to sums */
    unsigned int nsums;

    /*! Width in blocks * 8 */
    unsigned int width;
    /*! Height in blocks * 8 */
    unsigned int height;

    Qtable qtable;

    CoefsPlane coefs;

    void start_restoration();
    void average_bitmap();
    void loopshifts();
    void quantize();
    void set_DCT_constraint();
    void calculate_shifts();
    void calculate_alpha();
    void calculate_final();
    float calculate_final_pixel(const int row, const int col,
            int n_significative_variances);
    float pixel_spatial_variance(const int row, const int col,
            const int nbitmap);
    void add2sums(const FloatPlane &from);
    void project(FloatPlane &out);

public:
    HP();

	void prepare(const CoefsPlane *coefs,
            const FloatPlane *initial);
	FloatPlane * apply();
    bool getConfiguredEnv();
};

class HPCreator : public ActionCreator
{
    HPCreator();

public:
    static void init();

    ImproveRawPlane * createImproveRawPlane() const;
	bool isapplicable(const JPEGParameters &p);
};
