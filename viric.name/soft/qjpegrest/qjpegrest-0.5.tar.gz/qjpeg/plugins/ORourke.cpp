/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <ActionType.h>
#include <FloatPlane.h>
#include <JPEGData.h>
#include <CoefsPlane.h>
#include <ActionCreator.h>
#include <Actions.h>
#include <ActionManager.h>
#include "ORourke.h"
#include <cstdlib> // getenv
#include <cstdio> // debug
extern "C" {
#include <cdct.h>
}

/* Implementation of the method developed by Thomas P. O'Rourke and
 * Robert L. Stevenson:
 *   Improved Image Decompression for Reduced Transform Coding Artifacts
 * from IEEE Transactions on Circuits and Systems for Video Technology,
 * vol. 5, No. 6, December 1995.
 *
 * There are a few changes over the original:
 * - The gradient is calculated as (eq 17):
 *   g^(k) = sum(c in C, rho_T' (d_c^t * z^(k)) * d_c)
 *   instead of
 *   g^(k) = sum(c in C, rho_T' (d_c^t * z^(k)) * d_c^t)
 * - The step size isn't calculated. It's tried from 1, and halving
 *   as much as needed for minimizing the objective function
 *      sum(c in C, rho_T(z_{m,n} - z_{k,l}))
 * - The step size tried has a minimum on halving (MINIMUM_STEP_SIZE). Having
 *   reached the minimum, no more steps are done, as they wouldn't improve
 *   the bitmap according to the method constraints.
 */

const float ORourke::MINIMUM_STEP_SIZE=0.0000001;

void ORourke::prepare(const CoefsPlane *coefs,
            const FloatPlane *initial)
{
    reference = *initial;
    ORourke::coefs = *coefs;

    maxProgress = steps+1;
    setProgress(0);
}

bool ORourke::getConfiguredEnv()
{
    char *env_var;
    bool res;

    res = true;

    env_var = getenv("JPEG_OROURKE_STEPS");
    if (env_var != NULL)
    {
        res = true;
        sscanf(env_var, "%i", &steps);
    }

    env_var = getenv("JPEG_OROURKE_STEPSIZE");
    if (env_var != NULL)
    {
        res = true;
        sscanf(env_var, "%f", &step_size);
    }

    env_var = getenv("JPEG_OROURKE_THUBER");
    if (env_var != NULL)
    {
        res = true;
        sscanf(env_var, "%f", &T_Huber);
    }

    return false;
}

ORourke::ORourke()
{
    name = "O'Rourke";
    steps = 10;
    T_Huber = 0.1f;
    step_size = 1.f;
}

FloatPlane * ORourke::apply()
{
    ComponentData p = coefs.getParameters();
    for(unsigned int i=0; i < DCTSize2; ++i)
        qtable[i] = p.qtable[i];

    start_restoration();

    FloatPlane *result = new FloatPlane();
    *result = bitmap;
    DCTmax.free();
    DCTmin.free();
    DCTimage.free();

    return result;
}

void ORourke::start_restoration()
{
    width = coefs.getWidthInBlocks() * DCTSize;
    height = coefs.getHeightInBlocks() * DCTSize;

    set_DCT_constraint();

    bitmap = reference.newcopy();
    gradient.allocate(width, height);
    estimate.allocate(width, height);

    min_map();
    setProgress(maxProgress);
}

void ORourke::min_map()
{
    int step;
    float obj, last_obj;
    float ssize /* alpha in the article*/;

    last_obj = calc_objective(bitmap);

    for (step=0; step< steps; step++)
    {
        calc_gradient();

        /* First step size to try. The article calculates that using the
         * gradient and the image, but the algorithm proposed is heavy.
         * We get it as a parameter. */
        ssize = step_size;

        /* Get a new estimate (w), searching a proper step size. */
        do
        {
            get_new_estimate(ssize);
            obj = calc_objective(estimate);

            /* For the possible next loop */
            ssize = ssize / 2.;
            if (ssize < MINIMUM_STEP_SIZE)
                break;
        } while (obj >= last_obj);
        /* If that's true, the image cannot be improved anymore.
         * So exit, because bitmap is good enough. */
        if (ssize < MINIMUM_STEP_SIZE)
            break;

        /*
        std::fprintf(stderr, "w: last_obj: %f, obj = %f, stepsize = %f\n", 
          last_obj, obj, ssize);
          */

        last_obj = obj;
        project(estimate, bitmap);
    }
}

void ORourke::set_DCT_constraint()
{
    DCTimage = coefs.newcopy();
    
    DCTmin.allocate(coefs.getWidthInBlocks(), coefs.getHeightInBlocks());
    DCTmax.allocate(coefs.getWidthInBlocks(), coefs.getHeightInBlocks());

    float * cptr = coefs.getPtr();

    for (unsigned int j=0;j<coefs.getHeightInBlocks();++j)
        for (unsigned int i=0;i<coefs.getWidthInBlocks();++i)
        {
            unsigned int base = (j * coefs.getWidthInBlocks() + i) * DCTSize2;
            for (unsigned int k=0;k<DCTSize2;k++)
            {
              DCTmin.getPtr()[base+k]=cptr[base+k] - (0.5*qtable[k]);
              DCTmax.getPtr()[base+k]=cptr[base+k] + (0.5*qtable[k]);
            }
        }
}

/* Projection on the constraint - by Froment*/
/*! Projects the DCTimage [idct(in)] into out, according to DCTmin and DCTmax */
void ORourke::project(const FloatPlane &in, FloatPlane &out)
{
  fdct_image(DCTimage.getPtr(), in.getPtr(), width, height);
    
  unsigned int length = width * height;
  for (unsigned int j=0;j<length;j++)
    if (DCTimage.getPtr()[j] > DCTmax.getPtr()[j])
      DCTimage.getPtr()[j] = DCTmax.getPtr()[j];
    else if (DCTimage.getPtr()[j] < DCTmin.getPtr()[j])
      DCTimage.getPtr()[j] = DCTmin.getPtr()[j];

  fdct_inverse_image(DCTimage.getPtr(), out.getPtr(), width, height);
}

void ORourke::get_new_estimate(float ssize)
{
  int i;
  float *e_ptr;
  const float *b_ptr, *g_ptr;

  e_ptr = estimate.getPtr();
  b_ptr = bitmap.getPtr();
  g_ptr = gradient.getPtr();

  /* Equation 19 */
  for (i = 0; i < width*height; i++)
      /* TODO: The '+' sign may be -, as in Robertson. This explains
       * the change of sign in the calculation of gradient */
    e_ptr[i] = b_ptr[i] + ssize * g_ptr[i];
}

float ORourke::calc_objective(const FloatPlane &plane)
{
    int index_mn, index_kl;
    int bound_up, bound_down, bound_left, bound_right;
    int border_local;
    int row, col, wrow, wcol;
    float obj;
    enum { WINDOW_LOCAL = 3 };

    const float * p = plane.getPtr();

    border_local = (WINDOW_LOCAL-1)/2;

    obj = 0.;

    for(row=0; row < height; row++) 
        for (col=0; col < width; col++)
        {
            /* This scope is N_{m,n} as in the article */

            bound_up = (row >= border_local) ? row - border_local: 0;
            bound_down = (row < height - border_local) ? row + border_local
                : height - 1;
            bound_left = (col >= border_local) ? col - border_local: 0;
            bound_right = (col < width - border_local) ? col + border_local
                : width - 1;

            index_mn = row * width + col;

            for (wrow = bound_up; wrow <= bound_down; wrow++)
                for (wcol = bound_left; wcol <= bound_right; wcol++)
                {
                    if (wrow == row && wcol == col)
                        continue;

                    /* This scope is a "c in C", as explained in the article. */

                    index_kl = wrow * width + wcol;

                    /* Calculate for the gradient */
                    /* sum(c in C, rho_T(d_c^t * z) */
                    obj += f_huber(p[index_mn] - p[index_kl]);
                }
        }

    return obj;
}

float ORourke::f_huber(float u)
{
    float T;
    float ret;

    T = T_Huber;

    if (u > 0.)
    {
        if (u > T)
            ret = T*T + 2. * T * (u - T);
        else
            ret = u*u;
    }
    else
    {
        if (u < -T)
            ret = T*T + 2. * T * (-u - T);
        else
            ret = u*u;
    }

    return ret;
}

float ORourke::diff_huber(float u)
{
  float T;
  float ret;

  T = T_Huber;
  
  if (u > 0.)
  {
    if (u > T)
      ret = 2. * T;
    else
      ret = 2. * u;
  }
  else
  {
    if (u < -T)
      ret = -2. * T;
    else
      ret = 2. * u;
  }

  return ret;
}

void ORourke::calc_gradient()
{
    int index_mn, index_kl;
    int bound_up, bound_down, bound_left, bound_right;
    int border_local;
    int row, col, wrow, wcol;
    float huber;
    float *b_ptr, *g_ptr;
    enum { WINDOW_LOCAL = 3 };

    b_ptr = bitmap.getPtr();
    g_ptr = gradient.getPtr();

    gradient.setzero();

    border_local = (WINDOW_LOCAL-1)/2;

    for(row=0; row < height; row++) 
        for (col=0; col < width; col++)
        {
            /* This scope is N_{m,n} as in the article */

            bound_up = (row >= border_local) ? row - border_local: 0;
            bound_down = (row < height - border_local) ? row + border_local
                : height - 1;
            bound_left = (col >= border_local) ? col - border_local: 0;
            bound_right = (col < width - border_local) ? col + border_local
                : width - 1;

            index_mn = row * width + col;

            for (wrow = bound_up; wrow <= bound_down; wrow++)
                for (wcol = bound_left; wcol <= bound_right; wcol++)
                {
                    if (wrow == row && wcol == col)
                        continue;

                    /* This scope is a "c in C", as explained in the article. */

                    index_kl = wrow * width + wcol;

                    /* Calculate for the gradient (eq 17) */
                    /* We change the calculation of the gradient. The article
                     * says:
                     *   g^(k) = sum(c in C, rho_T' (d_c^t * z^(k)) * d_c^t)
                     * but we do the next: 
                     *   g^(k) = sum(c in C, rho_T' (d_c^t * z^(k)) * d_c) */
                    huber = diff_huber(b_ptr[index_mn]
                            - b_ptr[index_kl]);
                    g_ptr[index_mn] -= huber;
                    g_ptr[index_kl] += huber;
                }
        }
}

ORourkeCreator::ORourkeCreator()
{
    type = e_ImproveRawPlane;
}

bool ORourkeCreator::isapplicable(const JPEGParameters &p)
{
    return true;
}


void ORourkeCreator::init()
{
    ActionCreator *a = new ORourkeCreator();
    ActionManager::sreg("O'Rourke", a);
}

ImproveRawPlane * ORourkeCreator::createImproveRawPlane() const
{
    return new ORourke();
}
