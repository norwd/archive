/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class ColorMap;
class ActionCreator;

class YCC2RGB : public ColorMap
{
    FloatImage *inimage;

public:
    YCC2RGB();
    void prepare(FloatImage *initial);
    void apply();
};

class YCC2RGBCreator : public ActionCreator
{
    YCC2RGBCreator();

public:
    static void init();

    ColorMap * createColorMap() const;
	bool isapplicable(const JPEGParameters &p);
};
