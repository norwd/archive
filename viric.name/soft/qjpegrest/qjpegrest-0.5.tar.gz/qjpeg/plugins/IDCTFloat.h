/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class IDCTPlane;
class ActionCreator;
class FloatPlane;
class FloatImage;
class CoefsPlane;
class CoefsImage;

class IDCTFloat : public IDCTPlane
{
    const CoefsPlane *inplane;
    const CoefsImage *inimage;

    FloatPlane * applyPlane();

public:
    IDCTFloat();
    void prepare(const CoefsPlane *in);
    FloatPlane * apply();
};

class IDCTFloatCreator : public ActionCreator
{
    IDCTFloatCreator();

public:
    static void init();

    IDCTPlane * createIDCTPlane() const;
	bool isapplicable(const JPEGParameters &p);
};
