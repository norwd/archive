/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include "ActionType.h"
#include <FloatPlane.h>
#include <JPEGData.h>
#include <CoefsPlane.h>
#include <FloatImage.h>
#include <CoefsImage.h>
#include <ActionCreator.h>
#include <Actions.h>
#include <ActionManager.h>
#include "IDCTFloat.h"
extern "C" {
#include <cdct.h>
}

void IDCTFloat::prepare(const CoefsPlane *in)
{
    inplane = in;
    progress = 0;
    maxProgress = 1;
}

FloatPlane * IDCTFloat::apply()
{
    FloatPlane *tmp;
    setProgress(0);
    tmp = applyPlane();
    setProgress(maxProgress);
    return tmp;
}

FloatPlane * IDCTFloat::applyPlane()
{
    unsigned int width = inplane->getWidthInBlocks() * 8;
    unsigned int height = inplane->getHeightInBlocks() * 8;
    FloatPlane *p = new FloatPlane();
    p->allocate(width,height);

    fdct_inverse_image(inplane->getPtr(), p->getPtr(), width, height);

    return p;
}

IDCTFloatCreator::IDCTFloatCreator()
{
    type = e_IDCTPlane;
}

bool IDCTFloatCreator::isapplicable(const JPEGParameters &p)
{
    return true;
}


void IDCTFloatCreator::init()
{
    ActionCreator *a = new IDCTFloatCreator();
    ActionManager::sreg("IDCTFloat", a);
}

IDCTPlane * IDCTFloatCreator::createIDCTPlane() const
{
    return new IDCTFloat();
}

IDCTFloat::IDCTFloat()
{
    name = "IDCTFloat";
}
