/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <cstring> // memcpy
#include "ActionType.h"
#include <FloatPlane.h>
#include <JPEGData.h>
#include <FloatImage.h>
#include <CoefsPlane.h>
#include <CoefsImage.h>
#include <ActionCreator.h>
#include <Actions.h>
#include <ActionManager.h>
#include "FancyScaler.h"

static void
int_upsample_row(const FloatPlane &in, FloatPlane &out,
        const unsigned int inrow, const unsigned int outrow,
        const unsigned int hexpand)
{
    unsigned int incol = 0;
    unsigned int outcol = 0;
    /* This can be optimized */
    while (outcol < out.getWidth())
    {
        unsigned int outcolrepeat = 0;
        while (outcolrepeat < hexpand && outcol < out.getWidth())
        {
            out.set(outcol, outrow, in.get(incol,inrow));
            ++outcolrepeat;
            ++outcol;
        }
        ++incol;
    }
}

static void
int_upsample(const FloatPlane &in, FloatPlane &out,
        const unsigned int hexpand, const unsigned int vexpand)
{
    unsigned int inrow = 0;
    unsigned int outrow = 0;
    
    while (outrow < out.getHeight())
    {
        unsigned int outrowrepeat = 0;
        while (outrowrepeat < vexpand && outrow < out.getHeight())
        {
            int_upsample_row(in, out, inrow, outrow, hexpand);
            ++outrowrepeat;
            ++outrow;
        }
        ++inrow;
    }
}

static void
h2v2_fancy_upsample(const FloatPlane &in, FloatPlane &out)
{
    int inrow;
    int outrow;
    float thiscolsum, lastcolsum, nextcolsum;
    const float *inptr0, *inptr1;
    float *outptr;

    inrow = 0;
    for(outrow = 0; outrow < out.getHeight();)
    {
        int v;
        for(v = 0; v < 2; ++v)
        {
            unsigned ocol;
            unsigned int colctr;

            if (outrow >= out.getHeight())
                break;

            /* inptr0 points to nearest input row, inptr1 points to next
             * nearest*/
            inptr0 = in.getrow(inrow);
            if (v == 0)
            { 
                if (inrow != 0)
                    inptr1 = in.getrow(inrow-1);
                else
                    /* We mirror: row 1, row 0, row 1, row 2, row 3, ... */
                    inptr1 = in.getrow(1);
            }
            else
            {
                if(inrow < in.getHeight() - 1)
                    inptr1 = in.getrow(inrow+1);
                else
                    /* We also mirror here */
                    inptr1 = in.getrow(in.getHeight() - 2);
            }

            outptr = out.getrow(outrow++);
            ocol = 0;

            /* First column */
            thiscolsum = (*inptr0++) * 3. + (*inptr1++);
            nextcolsum = (*inptr0++) * 3. + (*inptr1++);
            *outptr++ = thiscolsum * 4. / 16.;
            ++ocol;
            if (ocol >= out.getWidth())
                continue;
            *outptr++ = (thiscolsum * 3. + nextcolsum) / 16.;
            ++ocol;
            if (ocol >= out.getWidth())
                continue;
            lastcolsum = thiscolsum; thiscolsum = nextcolsum;

            for (colctr = 1; colctr < in.getWidth() - 1; ++colctr)
            {
                /* General case: 3/4 * nearer pixel + 1/4 * further pixel in each
                 * dimension, thus 9/16, 3/16, 3/16, 1/16 overall */
                nextcolsum = (*inptr0++) * 3. + (*inptr1++);
                *outptr++ = (thiscolsum * 3. + lastcolsum) / 16.;
                ++ocol;
                if (ocol >= out.getWidth())
                    break;
                *outptr++ = (thiscolsum * 3. + nextcolsum) / 16.;
                ++ocol;
                if (ocol >= out.getWidth())
                    break;
                lastcolsum = thiscolsum; thiscolsum = nextcolsum;
            }
             
            if (ocol >= out.getWidth())
                continue;
            /* Special case for last column */
            *outptr++ = (thiscolsum * 3. + lastcolsum) / 16.;
            ++ocol;
            if (ocol >= out.getWidth())
                continue;
            *outptr++ = (thiscolsum * 4.) / 16.;
        }
        ++inrow;
    }
}

static void
h2v1_fancy_upsample(const FloatPlane &in, FloatPlane &out)
{
    unsigned int inrow = 0;
    unsigned int outrow = 0;

    for(inrow = 0; inrow < in.getHeight(); ++inrow)
    {
        float invalue;
        unsigned ocol;
        unsigned int colctr;

        if (outrow >= in.getHeight())
            break;
        invalue = in.get(0, inrow);
        /* First column */
        out.set(0, outrow, invalue);
        if (1 >= out.getWidth())
            continue;
        out.set(1, outrow, (invalue * 3 + in.get(1, inrow)) / 4);

        for (colctr = 1; colctr < in.getWidth() - 1; ++colctr)
        {
            invalue = in.get(colctr, inrow) * 3;
            if (colctr*2 >= out.getWidth())
                break;
            out.set(colctr*2, outrow,
                    (invalue + in.get(colctr-1, inrow)) / 4);
            if (colctr*2+1 >= out.getWidth())
                break;
            out.set(colctr*2+1, outrow,
                    (invalue + in.get(colctr+1, inrow)) / 4);
        }
        if (colctr*2 >= out.getWidth())
            continue;
        /* Last column */
        invalue = in.get(colctr, inrow);
        out.set(colctr*2, outrow,
                (invalue * 3 + in.get(colctr-1, inrow)) / 4);
        if (colctr*2+1 >= out.getWidth())
            continue;
        out.set(colctr*2+1, outrow, invalue);

        ++outrow;
    }
}

void FancyScaler::prepare(const CoefsImage *coefs,
            const FloatImage *initial)
{
    infimage = initial;
    /* We only use the jpegdata from the coefs */
    incimage = coefs;
    maxProgress = incimage->getComponents();
    setProgress(0);
}

FloatImage * FancyScaler::apply()
{
    unsigned int newwidth = incimage->jpegparameters.width;
    unsigned int newheight = incimage->jpegparameters.height;

    unsigned int components = incimage->jpegparameters.num_components;


    FloatImage *outimage = new FloatImage();
    outimage->setComponents(components);

    /* Call the scaler for each component */
    for (unsigned int c = 0; c < components; ++c)
    {
        setProgress(c);
        ComponentData comp = incimage->jpegparameters.components[c];
        unsigned int vexpand = incimage->jpegparameters.max_v_samp_factor /
            comp.v_samp_factor;
        unsigned int hexpand = incimage->jpegparameters.max_h_samp_factor /
            comp.h_samp_factor;

        outimage->plane[c].allocate(newwidth, newheight);
        if (hexpand == 2 && vexpand == 1)
            h2v1_fancy_upsample(infimage->plane[c], outimage->plane[c]);
        else if (hexpand == 2 && vexpand == 2)
            h2v2_fancy_upsample(infimage->plane[c], outimage->plane[c]);
        else
            int_upsample(infimage->plane[c], outimage->plane[c], hexpand, vexpand);
    }
    setProgress(maxProgress);

    return outimage;
}

bool FancyScalerCreator::isapplicable(const JPEGParameters &p)
{
    /* Given that we unpack the JPEG to its real image_size (and not smaller),
     * we can use this scaler for sure */
    return true;
}

FancyScalerCreator::FancyScalerCreator()
{
    type = e_Scaler;
}

void FancyScalerCreator::init()
{
    ActionCreator *a = new FancyScalerCreator();
    ActionManager::sreg("FancyScaler", a);
}

Scaler * FancyScalerCreator::createScaler() const
{
    return new FancyScaler();
}

FancyScaler::FancyScaler()
{
    name = "FancyScaler";
}
