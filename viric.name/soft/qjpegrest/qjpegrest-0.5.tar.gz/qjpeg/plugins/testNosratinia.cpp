/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <ActionType.h>
#include <ActionManager.h>
#include <Actions.h>
#include <ActionCreator.h>
#include <JPEGData.h>
#include <JPEGFile.h>
#include <CoefsPlane.h>
#include <CoefsImage.h>
#include <FloatPlane.h>
#include <FloatImage.h>
#include "IDCTFloat.h"
#include "IntScaler.h"
#include "YCC2RGB.h"
#include "Nosratinia.h"

static void initialize()
{
    new ActionManager();
    IDCTFloatCreator::init();
    IntScalerCreator::init();
    YCC2RGBCreator::init();
    NosratiniaCreator::init();
}

int main()
{
    IDCTPlane *fidct;

    initialize();
    /* Get the IDCTFloat */
    fidct = ActionManager::sfind("IDCTFloat")->createIDCTPlane();

    /* Open a jpeg */
    JPEGFile jfile("a.jpg");

    /* Get the coefficients */
    CoefsImage * coefs = jfile.getCoefs();

    /* Unpack the Image plane */
    fidct->prepareImage(coefs);
    FloatImage * fimageraw = fidct->applyImage();

    /* Get Nosratinia */
    ImproveRawPlane * nosratinia;
    nosratinia = ActionManager::sfind("Nosratinia")->createImproveRawPlane();

    /* Apply it to the first plane */
    nosratinia->prepare(&coefs->plane[0], &fimageraw->plane[0]);
    FloatPlane * improvedplane = nosratinia->apply();

    fimageraw->plane[0].free();
    fimageraw->plane[0] = *improvedplane;
    improvedplane->writePGM("prova.pgm");

    /* Get the rescaler */
    Scaler *scaler;
    scaler = ActionManager::sfind("IntScaler")->createScaler();

    /* Rescale the image */
    scaler->prepare(coefs, fimageraw);
    FloatImage * fimage = scaler->apply();

    /* Get the Colormapper */
    ColorMap *colormap;
    colormap = ActionManager::sfind("YCC2RGB")->createColorMap();

    /* Apply the colormap */
    colormap->prepare(fimage);
    colormap->apply();

    fimage->writePPM("prova.ppm");

    coefs->free();
    fimage->free();
    fimageraw->free();
    delete coefs;
    delete fimage;
    delete fimageraw;
    delete improvedplane;
    delete nosratinia;
    delete fidct;
    delete scaler;
    delete colormap;
    ActionManager::destroy();
}
