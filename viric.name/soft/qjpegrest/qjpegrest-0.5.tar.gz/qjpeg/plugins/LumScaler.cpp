/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <cstring> // memcpy
#include "ActionType.h"
#include <FloatPlane.h>
#include <JPEGData.h>
#include <FloatImage.h>
#include <CoefsPlane.h>
#include <CoefsImage.h>
#include <ActionCreator.h>
#include <Actions.h>
#include <ActionManager.h>
#include <cmath>
#include "LumScaler.h"

/* Implementation of the method developed by Hiroshi Sugita and Akira Taguchi:
 *   Chrominance Signal Interpolation of YUV 4:2:0 Format Color Images
 * from the
 * Electronics and Communications in Japan, Part 3, Vol. 89, No. 9, 2006
 *
 * Notes:
 * - We adapted the algorithm to JPEG's 4:2:2 and 4:2:0, according to the
 *   intersited color planes (instead of the article's cosited planes)
 */

static void
int_upsample_row(const FloatPlane &in, FloatPlane &out,
        const unsigned int inrow, const unsigned int outrow,
        const unsigned int hexpand)
{
    unsigned int incol = 0;
    unsigned int outcol = 0;
    /* This can be optimized */
    while (outcol < out.getWidth())
    {
        unsigned int outcolrepeat = 0;
        while (outcolrepeat < hexpand && outcol < out.getWidth())
        {
            out.set(outcol, outrow, in.get(incol,inrow));
            ++outcolrepeat;
            ++outcol;
        }
        ++incol;
    }
}

static void
int_upsample(const FloatPlane &in, FloatPlane &out,
        const unsigned int hexpand, const unsigned int vexpand)
{
    unsigned int inrow = 0;
    unsigned int outrow = 0;
    
    while (outrow < out.getHeight())
    {
        unsigned int outrowrepeat = 0;
        while (outrowrepeat < vexpand && outrow < out.getHeight())
        {
            int_upsample_row(in, out, inrow, outrow, hexpand);
            ++outrowrepeat;
            ++outrow;
        }
        ++inrow;
    }
}

void LumScaler::h2v2_lum_upsample(const FloatPlane &lum, const FloatPlane &in,
        FloatPlane &out)
{
    /*
     *  + Points of the output plane or luminance
     *  * Approximations related to the nearer two + points
     *  X Points from the input plane
     *
     *  Calculation in order for each target: 1, 2, 3
     *  Therefore we apply two horizontal weights, and one vertical.
     *
     *   YFar3 Ytop  YFar2
     *     +     *     +     *     +     *     +     orow;
     *
     *   Yleft Cnear Yright           Cfar1
     *     *     X     *1          *     X     *       Crow
     *
     *               Target
     *     +     *     +3    *     +     *     +     orow_far;
     *  YFar1 Ybottom Ypoint
     *
     *     *           *           *           *
     *
     *
     *     +     *     +     *     +     *     +
     *
     *         Cfar2                   Cfar3
     *     *     X     *2          *     X     *       Crow_far
     *
     *
     *     +     *     +     *     +     *     +
     * */
    float Cnear; /* The in pixel nearer to our target */
    float CFar1, CFar2, CFar3, Cm_near, Cm_far;
    float Ypoint;
    float YNear;
    float YFar1, YFar2, YFar3;
    float Ym_Cm_near, Ym_Cm_far;
    float Ym_near, Ym_far;
    const float *Yrow, *Yrow_near, *Yrow_far1, *Yrow_far2, *Crow, *Crow_far;
    float *outptr, *orow_far;
    unsigned int colctr;
    int inrow, outrow;

    inrow = 0;
    for(outrow = 0; outrow < out.getHeight();)
    {
        int v;
        for(v = 0; v < 2; ++v, ++outrow)
        {
            unsigned int colctr;
            unsigned int outcol;
            /* Crow points to nearest input row, Crow_far points to next
             * nearest*/
            if (outrow >= out.getHeight())
                break;
            Crow = in.getrow(inrow);
            if (v == 0)
            { 
                if (inrow != 0)
                    Crow_far = in.getrow(inrow-1);
                else
                {
                    /* We mirror */
                    Crow_far = in.getrow(1);
                }
            }
            else
            {
                if(inrow < in.getHeight() - 1)
                    Crow_far = in.getrow(inrow+1);
                else
                    /* We mirror. */
                    Crow_far = in.getrow(in.getHeight() - 2);
            }

            outptr = out.getrow(outrow); /* orow */
            Yrow = lum.getrow(outrow);
            if (v == 0)
            {
                /* Over the CRow */
                Yrow_near = lum.getrow(outrow+1);
                if (outrow >= 1)
                    Yrow_far1 = lum.getrow(outrow-1);
                else
                    /* We mirror. */
                    Yrow_far1 = lum.getrow(1);
                if (outrow >= 2)
                    Yrow_far2 = lum.getrow(outrow-2);
                else
                    /* We mirror.
                     * outrow == 1 => would like -1 => give 1
                     * outrow == 0 => would like -2 => give 2 */
                    Yrow_far2 = lum.getrow(outrow+1);
            }
            else
            {
                /* Below the CRow */
                Yrow_near = lum.getrow(outrow-1);
                if (outrow <= out.getHeight() - 1 - 1)
                    Yrow_far1 = lum.getrow(outrow+1);
                else
                    /* We mirror. */
                    Yrow_far1 = lum.getrow(out.getHeight()-2);
                if (outrow <= out.getHeight() - 1 - 2)
                    Yrow_far2 = lum.getrow(outrow+2);
                else
                {
                    /* We mirror.
                     * outrow == last-1 => would like last+1 => give last-1
                     * outrow == last => would like last+2 => give last-2 */
                    if (outrow == out.getHeight()-1 - 1) /* last - 1 */
                        Yrow_far2 = lum.getrow(out.getHeight()-1 - 1);
                    else if (outrow == out.getHeight()-1) /* last */
                        Yrow_far2 = lum.getrow(out.getHeight()-1 - 2);
                }
            }

            /* First column */
            outcol = 0;
            outptr[outcol] = (Crow[0] * 3 + Crow_far[0]) / 4.;
            outcol = 1;
            if (outcol >= out.getWidth())
                continue;
            Cnear = Crow[0];
            CFar1 = Crow[1];
            CFar2 = Crow_far[0];
            CFar3 = Crow_far[1];
            Ypoint = Yrow[outcol];
            YNear = (Yrow[outcol-1] + Yrow[outcol] + Yrow_near[outcol-1]
                    + Yrow_near[outcol]) / 4.;
            YFar1 = (Yrow[outcol+2] + Yrow[outcol+1] + Yrow_near[outcol+2]
                    + Yrow_near[outcol+1]) / 4.;
            YFar2 = (Yrow_far1[outcol-1] + Yrow_far1[outcol] + Yrow_far2[outcol-1]
                    + Yrow_far2[outcol]) / 4.;
            YFar3 = (Yrow_far1[outcol+2] + Yrow_far1[outcol+1] + Yrow_far2[outcol+2]
                    + Yrow_far2[outcol+1]) / 4.;
            Ym_Cm_near = (Yrow[outcol] + Yrow_near[outcol]) / 2.;
            Ym_Cm_far = (Yrow_far1[outcol] + Yrow_far2[outcol]) / 2.;

            Cm_near = Cnear + (CFar1 - Cnear) * h_weight(Ym_Cm_near, YNear, YFar1);
            Cm_far = CFar2 + (CFar3 - CFar2) * h_weight(Ym_Cm_far, YFar2, YFar3);
            outptr[outcol] = Cm_near + (Cm_far - Cm_near) *
                v_weight(Ypoint, Ym_Cm_near, Ym_Cm_far);

            for (colctr = 1; colctr < in.getWidth() - 1; ++colctr)
            {
                /* First */
                outcol = colctr*2;
                if (outcol >= out.getWidth())
                    break;
                Cnear = Crow[colctr];
                CFar1 = Crow[colctr-1];
                CFar2 = Crow_far[colctr];
                CFar3 = Crow_far[colctr-1];
                Ypoint = Yrow[outcol];
                YNear = (Yrow[outcol+1] + Yrow[outcol] + Yrow_near[outcol+1]
                        + Yrow_near[outcol]) / 4.;
                YFar1 = (Yrow[outcol-1] + Yrow[outcol-2] + Yrow_near[outcol-1]
                        + Yrow_near[outcol-2]) / 4.;
                YFar2 = (Yrow_far1[outcol+1] + Yrow_far1[outcol] + Yrow_far2[outcol+1]
                        + Yrow_far2[outcol]) / 4.;
                YFar3 = (Yrow_far1[outcol-1] + Yrow_far1[outcol-2] + Yrow_far2[outcol-1]
                        + Yrow_far2[outcol-2]) / 4.;
                Ym_Cm_near = (Yrow[outcol] + Yrow_near[outcol]) / 2.;
                Ym_Cm_far = (Yrow_far1[outcol] + Yrow_far2[outcol]) / 2.;

                Cm_near = Cnear + (CFar1 - Cnear) * h_weight(Ym_Cm_near, YNear, YFar1);
                Cm_far = CFar2 + (CFar3 - CFar2) * h_weight(Ym_Cm_far, YFar2, YFar3);
                outptr[outcol] = Cm_near + (Cm_far - Cm_near) *
                    v_weight(Ypoint, Ym_Cm_near, Ym_Cm_far);

                /* Next */
                outcol = colctr*2+1;
                if (outcol >= out.getWidth())
                    break;
                Cnear = Crow[colctr];
                CFar1 = Crow[colctr+1];
                CFar2 = Crow_far[colctr];
                CFar3 = Crow_far[colctr+1];
                Ypoint = Yrow[outcol];
                YNear = (Yrow[outcol-1] + Yrow[outcol] + Yrow_near[outcol-1]
                        + Yrow_near[outcol]) / 4.;
                YFar1 = (Yrow[outcol+2] + Yrow[outcol+1] + Yrow_near[outcol+2]
                        + Yrow_near[outcol+1]) / 4.;
                YFar2 = (Yrow_far1[outcol-1] + Yrow_far1[outcol] + Yrow_far2[outcol-1]
                        + Yrow_far2[outcol]) / 4.;
                YFar3 = (Yrow_far1[outcol+2] + Yrow_far1[outcol+1] + Yrow_far2[outcol+2]
                        + Yrow_far2[outcol+1]) / 4.;
                Ym_Cm_near = (Yrow[outcol] + Yrow_near[outcol]) / 2.;
                Ym_Cm_far = (Yrow_far1[outcol] + Yrow_far2[outcol]) / 2.;

                Cm_near = Cnear + (CFar1 - Cnear) * h_weight(Ym_Cm_near, YNear, YFar1);
                Cm_far = CFar2 + (CFar3 - CFar2) * h_weight(Ym_Cm_far, YFar2, YFar3);
                outptr[outcol] = Cm_near + (Cm_far - Cm_near) *
                    v_weight(Ypoint, Ym_Cm_near, Ym_Cm_far);
            }
             
            /* Special case for last two output columns */
            outcol = colctr*2;
            if (outcol >= out.getWidth())
                continue;
            Cnear = Crow[colctr];
            CFar1 = Crow[colctr-1];
            CFar2 = Crow_far[colctr];
            CFar3 = Crow_far[colctr-1];
            Ypoint = Yrow[outcol];
            YNear = (Yrow[outcol+1] + Yrow[outcol] + Yrow_near[outcol+1]
                    + Yrow_near[outcol]) / 4.;
            YFar1 = (Yrow[outcol-1] + Yrow[outcol-2] + Yrow_near[outcol-1]
                    + Yrow_near[outcol-2]) / 4.;
            YFar2 = (Yrow_far1[outcol+1] + Yrow_far1[outcol] + Yrow_far2[outcol+1]
                    + Yrow_far2[outcol]) / 4.;
            YFar3 = (Yrow_far1[outcol-1] + Yrow_far1[outcol-2] + Yrow_far2[outcol-1]
                    + Yrow_far2[outcol-2]) / 4.;
            Ym_Cm_near = (Yrow[outcol] + Yrow_near[outcol]) / 2.;
            Ym_Cm_far = (Yrow_far1[outcol] + Yrow_far2[outcol]) / 2.;

            Cm_near = Cnear + (CFar1 - Cnear) * h_weight(Ym_Cm_near, YNear, YFar1);
            Cm_far = CFar2 + (CFar3 - CFar2) * h_weight(Ym_Cm_far, YFar2, YFar3);
            outptr[outcol] = Cm_near + (Cm_far - Cm_near) *
                v_weight(Ypoint, Ym_Cm_near, Ym_Cm_far);

            /* Last */
            outcol = colctr*2+1;
            if (outcol >= out.getWidth())
                continue;
            outptr[outcol] = (Crow[colctr] * 3 + Crow_far[colctr]) / 4.;

        }
        ++inrow;
    }
}

float LumScaler::h_weight(float Ypoint, float Ynear, float Yfar)
{
    float w;

    /* In the usual fancy upsampling, the Cnear point is at a 1/4 distance of
     * the target, and the Cfar is at 3/4. Units: C pixels
     * As we will weight the far against the near, we set up a 0.25 mean weight. */
    if ((Yfar - Ynear) != 0)
        w = fabsf((Ypoint - Ynear) / (Yfar - Ynear));
    else
        w = 0.25;

    if (w > 0.25 + epsilon_h)
        w = 0.25 + epsilon_h;
    else if (w < 0.25 - epsilon_h)
        w = 0.25 - epsilon_h;

    return w;
}

float LumScaler::v_weight(float Ypoint, float Ynear, float Yfar)
{
    float w;

    /* In the usual fancy upsampling, the Cnear point is at a 1/4 distance of
     * the target, and the Cfar is at 3/4. Units: C pixels
     * As we will weight the far against the near, we set up a 0.25 mean weight. */
    if ((Yfar - Ynear) != 0)
        w = fabsf((Ypoint - Ynear) / (Yfar - Ynear));
    else
        w = 0.25;

    if (w > 0.25 + epsilon_v)
        w = 0.25 + epsilon_v;
    else if (w < 0.25 - epsilon_v)
        w = 0.25 - epsilon_v;

    return w;
}

void
LumScaler::h2v1_lum_upsample(const FloatPlane &lum, const FloatPlane &in,
        FloatPlane &out)
{
    unsigned int inrow = 0; /* analog to outrow */

    for(inrow = 0; inrow < in.getHeight(); ++inrow)
    {
        float Cnear; /* The in pixel nearer to our target */
        float Cfar; /* The in pixel next nearer to our target */
        float Ypoint; /* The luminance pixel at the same position as our target */
        float Ynear; /* The luminance of a supposed pixel at the position of Cnear */
        float Yfar; /* The luminance of a supposed pixel at the position of Cfar */
        const float *Yrow, *Crow;
        float *Orow;
        unsigned int colctr;

        Yrow = lum.getrow(inrow);
        Crow = in.getrow(inrow);
        Orow = out.getrow(inrow);

        /* First column */
        Cnear = Crow[0];
        Orow[0] = Cnear;
        if (1 >= out.getWidth())
            continue;
        Ynear = (Yrow[0] + Yrow[1]) / 2.;
        Yfar = (Yrow[2] + Yrow[3]) / 2.;
        Ypoint = Yrow[1];
        Cfar = Crow[1];
        Orow[1] = Cnear + (Cfar - Cnear) * h_weight(Ypoint, Ynear, Yfar);

        for (colctr = 1; colctr < in.getWidth() - 1; ++colctr)
        {
            int outcol;
            Cnear = Crow[colctr];

            Cfar = Crow[colctr-1];
            outcol = colctr*2;
            if (outcol >= out.getWidth())
                break;
            Ypoint = Yrow[outcol];
            Ynear = (Yrow[outcol] + Yrow[outcol+1]) / 2.;
            Yfar = (Yrow[(colctr-1)*2] + Yrow[(colctr-1)*2+1]) / 2.;
            Orow[outcol] = Cnear + (Cfar - Cnear) * h_weight(Ypoint, Ynear, Yfar);

            outcol = colctr*2+1;
            if (outcol >= out.getWidth())
                break;
            Cfar = Crow[colctr+1];
            Ypoint = Yrow[outcol];
            Yfar = (Yrow[(colctr+1)*2] + Yrow[(colctr+1)*2+1]) / 2.;
            Orow[outcol] = Cnear + (Cfar - Cnear) * h_weight(Ypoint, Ynear, Yfar);
        }
        /* Last column */
        if (colctr*2 >= out.getWidth())
            continue;
        Cnear = Crow[colctr];
        Cfar = Crow[colctr - 1];
        Ypoint = Yrow[colctr*2];
        Ynear = (Yrow[colctr*2] + Yrow[colctr*2+1]) / 2.;
        Yfar = (Yrow[(colctr-1)*2] + Yrow[(colctr-1)*2+1]) / 2.;
        Orow[colctr*2] = Cnear + (Cfar - Cnear) * h_weight(Ypoint, Ynear, Yfar);

        if (colctr*2+1 >= out.getWidth())
            continue;
        Orow[colctr*2+1] = Cnear;
    }
}

void LumScaler::prepare(const CoefsImage *coefs,
            const FloatImage *initial)
{
    infimage = initial;
    /* We only use the jpegdata from the coefs */
    incimage = coefs;
    maxProgress = incimage->getComponents();
    setProgress(0);
}

FloatImage * LumScaler::apply()
{
    unsigned int newwidth = incimage->jpegparameters.width;
    unsigned int newheight = incimage->jpegparameters.height;

    unsigned int components = incimage->jpegparameters.num_components;


    FloatImage *outimage = new FloatImage();
    outimage->setComponents(components);

    /* Call the scaler for each component */
    for (unsigned int c = 0; c < components; ++c)
    {
        setProgress(c);
        ComponentData comp = incimage->jpegparameters.components[c];
        unsigned int vexpand = incimage->jpegparameters.max_v_samp_factor /
            comp.v_samp_factor;
        unsigned int hexpand = incimage->jpegparameters.max_h_samp_factor /
            comp.h_samp_factor;

        outimage->plane[c].allocate(newwidth, newheight);
        if (hexpand == 2 && vexpand == 1)
            h2v1_lum_upsample(infimage->plane[0],
                    infimage->plane[c], outimage->plane[c]);
        else if (hexpand == 2 && vexpand == 2)
            h2v2_lum_upsample(infimage->plane[0],
                    infimage->plane[c], outimage->plane[c]);
        else
            int_upsample(infimage->plane[c], outimage->plane[c], hexpand, vexpand);
    }
    setProgress(maxProgress);

    return outimage;
}

bool LumScalerCreator::isapplicable(const JPEGParameters &p)
{
    /* Given that we unpack the JPEG to its real image_size (and not smaller),
     * we can use this scaler for sure */
    return true;
}

LumScalerCreator::LumScalerCreator()
{
    type = e_Scaler;
}

void LumScalerCreator::init()
{
    ActionCreator *a = new LumScalerCreator();
    ActionManager::sreg("LumScaler", a);
}

Scaler * LumScalerCreator::createScaler() const
{
    return new LumScaler();
}

LumScaler::LumScaler()
{
    name = "LumScaler";
    epsilon_h = 0.25f;
    epsilon_v = 0.25f;
}
