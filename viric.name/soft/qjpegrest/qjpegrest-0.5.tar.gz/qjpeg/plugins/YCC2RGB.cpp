/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include "ActionType.h"
#include <FloatPlane.h>
#include <JPEGData.h>
#include <FloatImage.h>
#include <ActionCreator.h>
#include <Actions.h>
#include <ActionManager.h>
#include "YCC2RGB.h"

#define SCALEBITS 16  /* speediest right-shift on some machines */
#define ONE_HALF  ((INT32) 1 << (SCALEBITS-1))
#define FIX(x)    ((INT32) ((x) * (1L<<SCALEBITS) + 0.5))

/* The incoming values for Cr and Cb are CENTERJSAMPLE=128 moved */

enum{
    CENTERJSAMPLE = 128
};

/*! Assuming that cb and cr are CENTERJSAMPLE displaced, perform a conversion
 * of the three given components to RGB (returned in the same vars) */
static inline void colorconvert(float &y, float &cb, float &cr)
{
    float r = y + 1.40200 * (cr - CENTERJSAMPLE);
    float g = y - 0.34414 * (cb-CENTERJSAMPLE) - 0.71414 * (cr-CENTERJSAMPLE);
    float b = y + 1.77200 * (cb - CENTERJSAMPLE);

    /* Return the values in the parameters */
    y =  r;
    cb = g;
    cr = b;
}

void YCC2RGB::prepare(FloatImage *initial)
{
    inimage = initial;
    maxProgress = 1;
    setProgress(0);
}

void YCC2RGB::apply()
{
    unsigned int adr;

    if (inimage->getComponents() != 3)
        return;

    if (!inimage->sameDimensions())
        return;

    float *y, *cb, *cr; /* one for component */
    y = inimage->plane[0].ptr;
    cb = inimage->plane[1].ptr;
    cr = inimage->plane[2].ptr;

    unsigned int width = inimage->plane[0].getWidth();
    unsigned int height = inimage->plane[0].getHeight();

    for(unsigned int row = 0; row < height; ++row)
        for(unsigned int col = 0; col < width; ++col)
        {
            adr = row*width + col;
            colorconvert(y[adr], cb[adr], cr[adr]);
        }
    setProgress(maxProgress);
}

YCC2RGBCreator::YCC2RGBCreator()
{
    type = e_ColorMap;
}

bool YCC2RGBCreator::isapplicable(const JPEGParameters &p)
{
    /* Error if components != 3 */
    if (p.colorspace != Colorspace(YCbCr))
        return false;

    if (p.num_components != 3)
        return false;

    return true;
}

void YCC2RGBCreator::init()
{
    ActionCreator *a = new YCC2RGBCreator();
    ActionManager::sreg("YCC2RGB", a);
}

ColorMap * YCC2RGBCreator::createColorMap() const
{
    return new YCC2RGB();
}

YCC2RGB::YCC2RGB()
{
    name = "YCC2RGB";
}
