/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class ARGBImage;
class GrayImage;
class MeasureResult;
class Measure;
class ActionCreator;

class GBIM : public Measure
{
    enum {
        ARGB,
        Gray
    } type;
    const ARGBImage *argb;
    const GrayImage *gray;
    void gray_error_h_mu_sigma(float h_mu[], float h_sigma[],
		const int rows, const int block_columns);
    void gray_error_v_mu_sigma(float v_mu[], float v_sigma[],
		const int columns, const int block_rows);
    void gray_error_h_w(float h_w[], const float h_mu[], const float h_sigma[],
		const int rows, const int block_columns, const float zeta);
    void gray_error_v_w(float v_w[], const float v_mu[], const float v_sigma[],
		const int columns, const int block_rows, const float zeta);
    void gray_error_h_sqdiff(float h_weighted_sqdiff[], const float h_w[],
		const int rows, const int block_columns, const int offset);
    void gray_error_v_sqdiff(float v_weighted_sqdiff[], const float v_w[],
		const int columns, const int block_rows, const int offset);
    float gray_error_mhgbim(const float zeta);
    float gray_error_mvgbim(const float zeta);
    float gray_error_mgbim_zeta(const float zeta);
    float gray_error_mgbim();
    void argb_error_h_mu_sigma(float h_mu[], float h_sigma[],
		const int rows, const int block_columns);
    void argb_error_v_mu_sigma(float v_mu[], float v_sigma[],
		const int columns, const int block_rows);
    void argb_error_h_w(float h_w[], const float h_mu[], const float h_sigma[],
		const int rows, const int block_columns, const float zeta);
    void argb_error_v_w(float v_w[], const float v_mu[], const float v_sigma[],
		const int columns, const int block_rows, const float zeta);
    void argb_error_h_sqdiff(float h_weighted_sqdiff[], const float h_w[],
		const int rows, const int block_columns, const int offset);
    void argb_error_v_sqdiff(float v_weighted_sqdiff[], const float v_w[],
		const int columns, const int block_rows, const int offset);
    float argb_error_mhgbim(const float zeta);
    float argb_error_mvgbim(const float zeta);
    float argb_error_mgbim_zeta(const float zeta);
    float argb_error_mgbim();

public:
    GBIM();
	void prepare(const ARGBImage *img);
	void prepare(const GrayImage *img);
	MeasureResult * apply();
};

class GBIMCreator : public ActionCreator
{
    GBIMCreator();

public:
    static void init();

    Measure * createMeasure() const;
	bool isapplicable(const JPEGParameters &p);
};
