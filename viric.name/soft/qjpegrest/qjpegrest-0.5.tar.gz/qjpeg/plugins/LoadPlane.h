/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class Scaler;
class CoefsImage;
class FloatImage;
class ActionCreator;

class LoadPlane : public ImproveRawPlane
{
protected:
    FloatPlane *loaded_image;
    CoefsPlane coefs;

private:
    /*! Where the result will be stored */
    FloatPlane *result;

public:
    LoadPlane();

	void prepare(const CoefsPlane *coefs,
            const FloatPlane *initial);
	FloatPlane * apply();
};

class LoadPlaneCreator : public ActionCreator
{
    LoadPlaneCreator();

public:
    static void init();

    ImproveRawPlane * createImproveRawPlane() const;
	bool isapplicable(const JPEGParameters &p);
};
