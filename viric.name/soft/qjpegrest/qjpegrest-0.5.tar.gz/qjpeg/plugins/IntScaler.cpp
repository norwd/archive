/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <cstring> // memcpy
#include "ActionType.h"
#include <FloatPlane.h>
#include <JPEGData.h>
#include <FloatImage.h>
#include <CoefsPlane.h>
#include <CoefsImage.h>
#include <ActionCreator.h>
#include <Actions.h>
#include <ActionManager.h>
#include "IntScaler.h"

static void
int_upsample_row(const FloatPlane &in, FloatPlane &out,
        const unsigned int inrow, const unsigned int outrow,
        const unsigned int hexpand)
{
    unsigned int incol = 0;
    unsigned int outcol = 0;
    /* This can be optimized */
    while (outcol < out.getWidth())
    {
        unsigned int outcolrepeat = 0;
        while (outcolrepeat < hexpand && outcol < out.getWidth())
        {
            out.set(outcol, outrow, in.get(incol,inrow));
            ++outcolrepeat;
            ++outcol;
        }
        ++incol;
    }
}

static void
int_upsample(const FloatPlane &in, FloatPlane &out,
        const unsigned int hexpand, const unsigned int vexpand)
{
    unsigned int inrow = 0;
    unsigned int outrow = 0;
    
    while (outrow < out.getHeight())
    {
        unsigned int outrowrepeat = 0;
        while (outrowrepeat < vexpand && outrow < out.getHeight())
        {
            int_upsample_row(in, out, inrow, outrow, hexpand);
            ++outrowrepeat;
            ++outrow;
        }
        ++inrow;
    }
}

static void
fullsize_upsample(const FloatPlane &in, FloatPlane &out,
        const unsigned int hexpand, const unsigned int vexpand)
{
    for(unsigned int row=0; row < in.getHeight(); ++row)
        std::memcpy(out.getrow(row), in.getrow(row),
                out.getWidth()*sizeof(float));
}

void IntScaler::prepare(const CoefsImage *coefs,
            const FloatImage *initial)
{
    infimage = initial;
    /* We only use the jpegdata from the coefs */
    incimage = coefs;
    maxProgress = incimage->getComponents();
    setProgress(0);
}

FloatImage * IntScaler::apply()
{
    unsigned int newwidth = incimage->jpegparameters.width;
    unsigned int newheight = incimage->jpegparameters.height;

    unsigned int components = incimage->jpegparameters.num_components;


    FloatImage *outimage = new FloatImage();
    outimage->setComponents(components);

    /* Call the scaler for each component */
    for (unsigned int c = 0; c < components; ++c)
    {
        setProgress(c);
        ComponentData comp = incimage->jpegparameters.components[c];
        unsigned int vexpand = incimage->jpegparameters.max_v_samp_factor /
            comp.v_samp_factor;
        unsigned int hexpand = incimage->jpegparameters.max_h_samp_factor /
            comp.h_samp_factor;

        outimage->plane[c].allocate(newwidth, newheight);
        int_upsample(infimage->plane[c], outimage->plane[c], hexpand, vexpand);
    }
    setProgress(maxProgress);

    return outimage;
}

bool IntScalerCreator::isapplicable(const JPEGParameters &p)
{
    /* Given that we unpack the JPEG to its real image_size (and not smaller),
     * we can use this scaler for sure */
    return true;
}

IntScalerCreator::IntScalerCreator()
{
    type = e_Scaler;
}

void IntScalerCreator::init()
{
    ActionCreator *a = new IntScalerCreator();
    ActionManager::sreg("IntScaler", a);
}

Scaler * IntScalerCreator::createScaler() const
{
    return new IntScaler();
}

IntScaler::IntScaler()
{
    name = "IntScaler";
}
