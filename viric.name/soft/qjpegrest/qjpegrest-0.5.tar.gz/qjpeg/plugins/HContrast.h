/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class Scaler;
class CoefsImage;
class FloatImage;
class ActionCreator;

class HContrast : public ImproveRawPlane
{
protected:
    float thlevel;
    unsigned int winsize;

private:
    /*! The initial floatplane, which will be projected */
    FloatPlane reference;
    /*! Where the result will be stored */
    FloatPlane *result;
    /*! Normal JPEG decompression */
    FloatPlane normal;

    CoefsPlane DCTmin;
    CoefsPlane DCTmax;
    CoefsPlane DCTimage;

    unsigned int width_in_blocks;
    unsigned int height_in_blocks;

    Qtable qtable;

    CoefsPlane coefs;

    void set_DCT_constraint();
    void start_restoration();
    void decompress_normal();
    void mix();

    float getContrast(const FloatPlane *p, int x, int y) const;

public:
    HContrast();

	void prepare(const CoefsPlane *coefs,
            const FloatPlane *initial);
	FloatPlane * apply();
};

class HContrastCreator : public ActionCreator
{
    HContrastCreator();

public:
    static void init();

    ImproveRawPlane * createImproveRawPlane() const;
	bool isapplicable(const JPEGParameters &p);
};
