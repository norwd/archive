/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class Scaler;
class CoefsImage;
class FloatImage;
class ActionCreator;

class QCS : public ImproveRawPlane
{
    /*! The initial floatplane, which will be projected */
    FloatPlane reference;
    /*! Where the result will be stored */
    FloatPlane *result;

    CoefsPlane DCTmin;
    CoefsPlane DCTmax;
    CoefsPlane DCTimage;

    /*! Width in blocks * 8 */
    unsigned int width;
    /*! Height in blocks * 8 */
    unsigned int height;

    Qtable qtable;

    CoefsPlane coefs;

    void set_DCT_constraint();
    void start_restoration();
    void project(FloatPlane &out);

public:
    QCS();

	void prepare(const CoefsPlane *coefs,
            const FloatPlane *initial);
	FloatPlane * apply();
};

class QCSCreator : public ActionCreator
{
    QCSCreator();

public:
    static void init();

    ImproveRawPlane * createImproveRawPlane() const;
	bool isapplicable(const JPEGParameters &p);
};
