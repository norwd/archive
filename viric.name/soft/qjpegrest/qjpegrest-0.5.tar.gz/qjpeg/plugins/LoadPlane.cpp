/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include "ActionType.h"
#include <FloatPlane.h>
#include <JPEGData.h>
#include <CoefsPlane.h>
#include <ActionCreator.h>
#include <Actions.h>
#include <ActionManager.h>
#include "LoadPlane.h"
#include <cstdlib> // getenv
#include <cstdio> // sscanf and debug
#include <cmath> // floor
extern "C" {
#include <cdct.h>
}

void LoadPlane::prepare(const CoefsPlane *coefs,
            const FloatPlane *initial)
{
    LoadPlane::coefs = *coefs;

    maxProgress = 2;
    setProgress(0);
}

FloatPlane * LoadPlane::apply()
{
    ComponentData p = coefs.getParameters();

    result = new FloatPlane();

    /* A subclass (frontend) for this plugin is responsible
     * for loading the FloatPlane loaded_image.
     * At the time of this writting, there is QLoadPlane,
     * which uses QT's QtGui module for loading images. */
    if (loaded_image &&
            coefs.getWidthInBlocks() * 8 == loaded_image->getWidth() &&
            coefs.getHeightInBlocks() * 8 == loaded_image->getHeight())
        *result = loaded_image->newcopy();
    else
    {
        std::fprintf(stderr, "Loaded Plane doesn't fit.\n");
        result->allocate(coefs.getWidthInBlocks()*8,
                coefs.getHeightInBlocks()*8);
    }

    return result;
}

LoadPlaneCreator::LoadPlaneCreator()
{
    type = e_ImproveRawPlane;
}

bool LoadPlaneCreator::isapplicable(const JPEGParameters &p)
{
    return true;
}


void LoadPlaneCreator::init()
{
    ActionCreator *a = new LoadPlaneCreator();
    ActionManager::sreg("LoadPlane", a);
}

ImproveRawPlane * LoadPlaneCreator::createImproveRawPlane() const
{
    return new LoadPlane();
}

LoadPlane::LoadPlane()
{
    name = "LoadPlane";
    loaded_image = 0;
}
