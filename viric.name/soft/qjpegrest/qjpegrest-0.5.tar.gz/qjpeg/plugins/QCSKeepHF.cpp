/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include "ActionType.h"
#include <FloatPlane.h>
#include <JPEGData.h>
#include <CoefsPlane.h>
#include <ActionCreator.h>
#include <Actions.h>
#include <ActionManager.h>
#include "QCSKeepHF.h"
#include <cstdlib> // getenv
#include <cstdio> // debug
#include <cmath> // fabs
extern "C" {
#include <cdct.h>
}

/* Projection on the constraint - algorithm code by Froment*/

void QCSKeepHF::prepare(const CoefsPlane *coefs,
            const FloatPlane *initial)
{
    reference = *initial;
    QCSKeepHF::coefs = *coefs;

    maxProgress = 2;
    setProgress(0);
}

FloatPlane * QCSKeepHF::apply()
{
    ComponentData p = coefs.getParameters();
    for(unsigned int i=0; i < DCTSize2; ++i)
        qtable[i] = p.qtable[i];

    result = new FloatPlane();

    start_restoration();

    DCTmax.free();
    DCTmin.free();
    DCTimage.free();

    return result;
}

QCSKeepHFCreator::QCSKeepHFCreator()
{
    type = e_ImproveRawPlane;
}

bool QCSKeepHFCreator::isapplicable(const JPEGParameters &p)
{
    return true;
}


void QCSKeepHFCreator::init()
{
    ActionCreator *a = new QCSKeepHFCreator();
    ActionManager::sreg("QCSKeepHF", a);
}

ImproveRawPlane * QCSKeepHFCreator::createImproveRawPlane() const
{
    return new QCSKeepHF();
}

QCSKeepHF::QCSKeepHF()
{
    name = "QCSKeepHF";
    latestCoefs = 40;
    HFlevel = 2.;
}


void
QCSKeepHF::start_restoration ()
{
  /* Prepare dimensions */
  width_in_blocks = coefs.getWidthInBlocks();
  height_in_blocks = coefs.getHeightInBlocks();

  /* Load the coefficients, and prepare the DCT ranges */
  set_DCT_constraint();

  /* Overwrite of previous uninitialized *result */
  *result = reference.newcopy();

  setProgress(1);

  project(*result);

  setProgress(maxProgress);
}


void QCSKeepHF::set_DCT_constraint()
{
    DCTimage = coefs.newcopy();
    
    DCTmin.allocate(width_in_blocks,height_in_blocks);
    DCTmax.allocate(width_in_blocks,height_in_blocks);

    float * cptr = coefs.getPtr();

    for (unsigned int j=0;j<height_in_blocks;++j)
        for (unsigned int i=0;i<width_in_blocks;++i)
        {
            unsigned int base = (j * width_in_blocks + i) * DCTSize2;
            for (unsigned int k=0;k<DCTSize2;k++)
            {
              DCTmin.getPtr()[base+k]=cptr[base+k] - (0.5*qtable[k]);
              DCTmax.getPtr()[base+k]=cptr[base+k] + (0.5*qtable[k]);
            }
        }
}

float QCSKeepHF::getLevel(const float *cblockmin, const float *cblockmax) const
{
    /*   0  1  2  3  4  5  6  7
     *   8  9 10 11 12 13 14 15
     *  16 17 18 19 20 21 22 23
     *  24 25 26 27 28 29 30 31
     *  32 33 34 35 36 37 38 39
     *  40 41 42 43 44 45 46 47
     *  48 49 50 51 52 53 54 55
     *  56 57 58 59 60 61 62 63
     *  */
    /* This is not exactly the inverse of the ZigZag
     * storage of JPEG */
    const int backIndexs[64] =
    {
        63, 62, 55, 61, 54, 47, 60, 43, 46, 39,
        59, 52, 45, 38, 31,
        58, 51, 44, 37, 30, 23,
        57, 50, 43, 36, 29, 22, 15,
        56, 49, 42, 35, 28, 21, 14, 7,
        48, 41, 34, 27, 20, 13, 6,
        40, 33, 26, 19, 12, 5, 
        32, 25, 18, 11, 4,
        24, 17, 10, 3,
        16, 9, 2,
        8, 1,
        0
    };
    float sum;

    sum = 0;
    for(int i = 0; i < latestCoefs; ++i)
    {
        sum += fabsf((cblockmax[backIndexs[i]] + cblockmin[backIndexs[i]])/2.);
    }
    sum /= (float) latestCoefs;
    std::printf("%f\n", sum);
    return sum;
}

/* Projection on the constraint - by Froment*/
/*! Projects the DCTimage into out, according to DCTmin and DCTmax */
void QCSKeepHF::project(FloatPlane &out)
{
    int i, j, k;

    fdct_image(DCTimage.getPtr(), out.getPtr(), width_in_blocks*8,
            height_in_blocks*8);

    for (unsigned int j=0;j<height_in_blocks;++j)
        for (unsigned int i=0;i<width_in_blocks;++i)
        {
            unsigned int base = (j * width_in_blocks + i) * DCTSize2;
            if (getLevel( &(DCTmin.getPtr()[base]), &(DCTmax.getPtr()[base]))
                    > HFlevel)
            {
                for (unsigned int k=0;k<DCTSize2;k++)
                {
                    unsigned int ci = base + k;
                    /* Simple decompression */
                    DCTimage.getPtr()[ci] = (DCTmax.getPtr()[ci] +
                            DCTmin.getPtr()[ci]) / 2.;
                }
            }
            else
                for (unsigned int k=0;k<DCTSize2;k++)
                {
                    unsigned int ci = base + k;
                    if (DCTimage.getPtr()[ci] > DCTmax.getPtr()[ci])
                        DCTimage.getPtr()[ci] = DCTmax.getPtr()[ci];
                    else if (DCTimage.getPtr()[ci] < DCTmin.getPtr()[ci])
                        DCTimage.getPtr()[ci] = DCTmin.getPtr()[ci];
                }
        }

    fdct_inverse_image(DCTimage.getPtr(), out.getPtr(), width_in_blocks*8,
            height_in_blocks*8);
}
