/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class Scaler;
class CoefsImage;
class FloatImage;
class ActionCreator;
class QString;

class SavePlane : public ImproveRawPlane
{
protected:
    QString *filename;

private:
    /*! Where the result will be stored */
    FloatPlane reference;
    FloatPlane *result;
    CoefsPlane coefs;

public:
    SavePlane();
    ~SavePlane();

	void prepare(const CoefsPlane *coefs,
            const FloatPlane *initial);
	FloatPlane * apply();
};

class SavePlaneCreator : public ActionCreator
{
    SavePlaneCreator();

public:
    static void init();

    ImproveRawPlane * createImproveRawPlane() const;
	bool isapplicable(const JPEGParameters &p);
};
