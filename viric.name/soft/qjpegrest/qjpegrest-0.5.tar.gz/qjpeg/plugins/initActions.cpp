/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <JPEGData.h>
#include <JPEGFile.h>
#include <CoefsImage.h>
#include <Chain.h>

/* The actions */
#include <ActionType.h>
#include <ActionManager.h>
#include <ARGBImage.h>
#include <GrayImage.h>
#include <MeasureResult.h>
#include <Actions.h>
#include <ActionCreator.h>

#include <Stat.h> /* Required by lumstat */

#include "GBIM.h"
#include "PSNR.h"
#include "LumStat.h"
#include "IDCTFloat.h"
#include "IntScaler.h"
#include "CoefsPlane.h"
#include "FloatPlane.h"
#include "Nosratinia.h"
#include "HP.h"
#include "Froment.h"
#include "QCS.h"
#include "YCC2RGB.h"
#include "ORourke.h"
#include "Robertson.h"

#include "initActions.h"

void initActionManager()
{
    new ActionManager();
    GBIMCreator::init();
    PSNRCreator::init();
    LumStatCreator::init();
    IDCTFloatCreator::init();
    IntScalerCreator::init();
    NosratiniaCreator::init();
    HPCreator::init();
    FromentCreator::init();
    ORourkeCreator::init();
    RobertsonCreator::init();
    QCSCreator::init();
    YCC2RGBCreator::init();
}

