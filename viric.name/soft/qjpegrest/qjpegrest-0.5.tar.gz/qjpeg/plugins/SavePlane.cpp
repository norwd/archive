/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include "ActionType.h"
#include <FloatPlane.h>
#include <JPEGData.h>
#include <CoefsPlane.h>
#include <ActionCreator.h>
#include <Actions.h>
#include <ActionManager.h>

#include <QString>

#include "SavePlane.h"
#include <cstdlib> // getenv
#include <cstdio> // sscanf and debug
#include <cmath> // floor
extern "C" {
#include <cdct.h>
}

void SavePlane::prepare(const CoefsPlane *coefs,
            const FloatPlane *initial)
{
    SavePlane::coefs = *coefs;
    reference = *initial;

    maxProgress = 2;
    setProgress(0);
}

FloatPlane * SavePlane::apply()
{
    ComponentData p = coefs.getParameters();

    result = new FloatPlane();

    *result = reference.newcopy();

    /* A subclass (frontend) for this plugin is responsible
     * for loading the filename QString. */
    if (!filename->isEmpty())
    {
        QByteArray text;
        text = filename->toLocal8Bit();
        reference.writePGM(text.data());
    }

    return result;
}

SavePlaneCreator::SavePlaneCreator()
{
    type = e_ImproveRawPlane;
}

bool SavePlaneCreator::isapplicable(const JPEGParameters &p)
{
    return true;
}


void SavePlaneCreator::init()
{
    ActionCreator *a = new SavePlaneCreator();
    ActionManager::sreg("SavePlane", a);
}

ImproveRawPlane * SavePlaneCreator::createImproveRawPlane() const
{
    return new SavePlane();
}

SavePlane::SavePlane()
{
    name = "SavePlane";
    filename = new QString();
}

SavePlane::~SavePlane()
{
    if (filename)
        delete filename;
}
