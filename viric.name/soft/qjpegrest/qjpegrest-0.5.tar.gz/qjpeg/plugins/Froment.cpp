/*
    MegaWave 2 - Copyright according to COPYRIGHT-Megawave2 file.
    Taken from the MegaWave 2 module jpeg_tv,
        Version: 1.01
        Authors: François Alter, Jacques Froment

    Please find the license in the provided LICENSE-Megawave2 file.
*/
#include "ActionType.h"
#include <FloatPlane.h>
#include <JPEGData.h>
#include <CoefsPlane.h>
#include <ActionCreator.h>
#include <Actions.h>
#include <ActionManager.h>
#include "Froment.h"
#include <cstdlib> // getenv
#include <cstdio> // sscanf
#include <cmath> // floor && sqrt
extern "C" { 
#include <cdct.h>
}

/* Implementation of the method developed by: François Alter, Sylvain Durand and
   Jacques Froment:
     Adapted Total Variation for Artifact Free Decompression of JPEG Images
   from Journal of Mathematical Imaging and Vision 23: 199-211, 2005

   Notes:
   - Big part of the implementation has been freely given by Jacques Froment.
   - This method (or implementation) noticeable decreases the image contrast.
*/

/* Plain TV */
static const float plain_wTV[8]={1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0};

static const float default_wTV[8]={5.0,2.0,1.0,1.0,1.0,2.0,5.0,10.0};



void Froment::prepare(const CoefsPlane *coefs,
            const FloatPlane *initial)
{
    reference = *initial;
    Froment::coefs = *coefs;

    maxProgress = 100;
    setProgress(0);
}

FloatPlane * Froment::apply()
{
    ComponentData p = coefs.getParameters();
    for(unsigned int i=0; i < DCTSize2; ++i)
        qtable[i] = p.qtable[i];

    /*
    std::printf("steps: %i ssize: %f const: %i\n",
            steps, step_size, (int) constant_step);
            */
    start_restoration();

    FloatPlane *result = new FloatPlane();
    *result = bitmap;
    DCTmax.free();
    DCTmin.free();
    DCTimage.free();

    return result;
}

FromentCreator::FromentCreator()
{
    type = e_ImproveRawPlane;
}

bool FromentCreator::isapplicable(const JPEGParameters &p)
{
    return true;
}


void FromentCreator::init()
{
    ActionCreator *a = new FromentCreator();
    ActionManager::sreg("Froment", a);
}

ImproveRawPlane * FromentCreator::createImproveRawPlane() const
{
    return new Froment();
}

Froment::Froment()
{
    name = "Froment";
    /* Default configuration */
    steps = 10;
    step_size = 1.;
    constant_step = false;
    for (int i=0; i<8; i++)
        wTV[i] = default_wTV[i];
}

bool Froment::getConfiguredEnv()
{
    char *env_var;
    env_var = getenv("JPEG_FROMENT_STEPS");
    if (env_var != NULL)
        sscanf(env_var, "%i", &steps);

    env_var = getenv("JPEG_FROMENT_STEP_SIZE");
    if (env_var != NULL)
        sscanf(env_var, "%g", &step_size);

    env_var = getenv("JPEG_FROMENT_WEIGHTS");
    if (env_var != NULL)
        sscanf(env_var, "%g%g%g%g%g%g%g%g", &wTV[0], &wTV[1],
                &wTV[2], &wTV[3], &wTV[4], &wTV[5], &wTV[6], &wTV[7]);
}


void
Froment::start_restoration ()
{
  /* Prepare dimensions */
  width = coefs.getWidthInBlocks() * DCTSize;
  height = coefs.getHeightInBlocks() * DCTSize;

  /* Load the coefficients, and prepare the DCT ranges */
  set_DCT_constraint();

  /* Get the bitmap from the reference */
  bitmap = reference.newcopy();

  min_TV();

  setProgress(maxProgress);
}

void
Froment::min_TV()
{
    int i,j;
    double tv;
    double t;

    FloatPlane dE;
    float *p_out, *p_dE;

    dE.allocate(width, height);

    for (i=0; i < steps; ++i)
    {
        /* Compute TV and its gradient */
        tv = TV(bitmap, dE) / (double) (width * height);

        /* stepsize */
        if (constant_step)
            t=step_size; /* constant step size, to speed-up the algorithm */
        else
            t = step_size/((double) i+1.0); /* step size that ensures the convergence */
        project(bitmap);

        /* Gradient descent */
        for (p_out=bitmap.getPtr(), p_dE=dE.getPtr(), j=0;
                j<width*height;
                j++,p_out++,p_dE++)
            *p_out -= (float) (t * *p_dE);
    }
}


float Froment::TV(FloatPlane &ug, FloatPlane &dE)
{
    int x,y,center,left,right,down,up;
    double e,v,vleft,vright,vdown,vup,d1,d2,d3,d4;
    float *p_dE, *p_ug;

    /* Set all dE points to 0 */
    for (x=0,p_dE=dE.getPtr(); x<width*height; x++)
        *(p_dE++)=0.0;

    p_dE = dE.getPtr();
    p_ug = ug.getPtr();

    e = 0.;

    for(y=1;y<height-1;y++) 
        for (x=1;x<width-1;x++)
        {
            center = y*width+x;
            right=center+1;
            down=center+width;
            left=center-1;
            up=center-width;

            vup=p_ug[up];
            vleft=p_ug[left];
            vdown=p_ug[down];
            vright=p_ug[right];
            v=p_ug[center];

            d1 = wTV[x%8]*(vright-v);
            d2 = wTV[y%8]*(vdown-v);
            d3 = wTV[(x-1)%8]*(v-vleft);
            d4 = wTV[(y-1)%8]*(v-vup);

            v = std::sqrt( (d1*d1+d2*d2+d3*d3+d4*d4) );
            e += v;
            if (v==0.) v=1.;
            p_dE[center]   += (d3+d4-d1-d2)/v;
            p_dE[right] += d1/v;
            p_dE[down] += d2/v;
            p_dE[up] -= d4/v;
            p_dE[left] -= d3/v;

        }
    return(e);
}

void Froment::quantize()
{
  float * coef = DCTimage.getPtr();


  /* The next is equivalent to width_in_blocks*height_in_blocks*DCTSize2 */
  unsigned int length = width*height;
  int num_coef = 0;
  for (unsigned int i=0; i<length; ++i)
  {
    *coef = *coef / qtable[num_coef];
    *coef += 0.5;
    *coef = std::floor(*coef) * qtable[num_coef];
    coef++;
    /* num_coef should loop from 0 to 63 */
    if(num_coef == 63)
        num_coef = 0;
    else
        ++num_coef;
  }
}

void Froment::set_DCT_constraint()
{
    DCTimage = coefs.newcopy();
    
    DCTmin.allocate(coefs.getWidthInBlocks(), coefs.getHeightInBlocks());
    DCTmax.allocate(coefs.getWidthInBlocks(), coefs.getHeightInBlocks());

    float * cptr = coefs.getPtr();

    for (unsigned int j=0;j<coefs.getHeightInBlocks();++j)
        for (unsigned int i=0;i<coefs.getWidthInBlocks();++i)
        {
            unsigned int base = (j * coefs.getWidthInBlocks() + i) * DCTSize2;
            for (unsigned int k=0;k<DCTSize2;k++)
            {
              DCTmin.getPtr()[base+k]=cptr[base+k] - (0.5*qtable[k]);
              DCTmax.getPtr()[base+k]=cptr[base+k] + (0.5*qtable[k]);
            }
        }
}


/* Projection on the constraint - by Froment*/
/*! Projects the DCTimage into out, according to DCTmin and DCTmax */
void Froment::project(FloatPlane &out)
{
  fdct_image(DCTimage.getPtr(), out.getPtr(), width, height);
    
  unsigned int length = width * height;
  for (unsigned int j=0;j<length;j++)
    if (DCTimage.getPtr()[j] > DCTmax.getPtr()[j])
      DCTimage.getPtr()[j] = DCTmax.getPtr()[j];
    else if (DCTimage.getPtr()[j] < DCTmin.getPtr()[j])
      DCTimage.getPtr()[j] = DCTmin.getPtr()[j];

  fdct_inverse_image(DCTimage.getPtr(), out.getPtr(), width, height);
}
