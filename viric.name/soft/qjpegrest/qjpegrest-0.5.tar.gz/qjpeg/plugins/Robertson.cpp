/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <ActionType.h>
#include <FloatPlane.h>
#include <JPEGData.h>
#include <CoefsPlane.h>
#include <ActionCreator.h>
#include <Actions.h>
#include <ActionManager.h>
#include "Robertson.h"
#include <cstdlib> // getenv
#include <cstdio> // debug
extern "C" {
#include <cdct.h>
}

/* Implementation of the method developed by Mark A. Robertson and
 * Robert L. Stevenson:
 *   DCT Quantization Noise in Compressed Images
 * draft published online, dated of February 23rd, 2004.
 *
 * Notes:
 * - The article doesn't mention how to find a good \alpha^{(w)}.
 *   We start from an alpha equal to the proposed step size, and then
 *   halving until a good candidate is found (decreasing the term that we have
 *   to minimize). At MINIMUM_STEP_SIZE, we stop trying to minimize, and exit
 *   the minimizing loop.
 */

const float Robertson::MINIMUM_STEP_SIZE=0.0000001;

void Robertson::prepare(const CoefsPlane *coefs,
            const FloatPlane *initial)
{
    reference = *initial;
    Robertson::coefs = *coefs;

    maxProgress = steps+1;
    setProgress(0);
}

bool Robertson::getConfiguredEnv()
{
    char *env_var;
    bool res;

    res = true;

    env_var = getenv("JPEG_ROBERTSON_STEPS");
    if (env_var != NULL)
    {
        res = true;
        sscanf(env_var, "%i", &steps);
    }

    env_var = getenv("JPEG_ROBERTSON_STEPSIZE");
    if (env_var != NULL)
    {
        res = true;
        sscanf(env_var, "%f", &step_size);
    }

    env_var = getenv("JPEG_ROBERTSON_THUBER");
    if (env_var != NULL)
    {
        res = true;
        sscanf(env_var, "%f", &T_Huber);
    }

    env_var = getenv("JPEG_ROBERTSON_LAMBDA");
    if (env_var != NULL)
    {
        res = true;
        sscanf(env_var, "%f", &lambda);
    }

    return false;
}

Robertson::Robertson()
{
    name = "Robertson";
    steps = 10;
    T_Huber = 0.1f;
    step_size = 1.f;
    lambda = 0.00075f;
}

FloatPlane * Robertson::apply()
{
    ComponentData p = coefs.getParameters();
    for(unsigned int i=0; i < DCTSize2; ++i)
        qtable[i] = p.qtable[i];

    start_restoration();

    FloatPlane *result = new FloatPlane();
    *result = bitmap;
    DCTmax.free();
    DCTmin.free();
    DCTimage.free();

    return result;
}

void Robertson::start_restoration()
{
    width = coefs.getWidthInBlocks() * DCTSize;
    height = coefs.getHeightInBlocks() * DCTSize;

    set_DCT_constraint();

    gradient.allocate(width, height);
    estimate.allocate(width, height);

    min_map();
    setProgress(maxProgress);
}

void Robertson::min_map()
{
    int step;
    float obj, last_obj;
    float ssize;
    
    
    /* Save a copy of the first bitmap. z_q in the article. */
    bitmap = reference.newcopy();

    last_obj = calc_objective(bitmap);

    /* Calculate the error autovariance using the qtable */
    calc_inv_k_ey();

    for (step=0; step< steps; step++)
    {
        calc_gradient_hubber();
        add_noise_to_gradient();

        /* First step size to try. The article calculates that using the
         * gradient and the image, but the algorithm proposed is heavy.
         * We get it as a parameter. */
        ssize = step_size;

        /* Get a new estimate (w), searching a proper step size. */
        do
        {
            get_new_estimate(ssize);
            obj = calc_objective(estimate);

            /* For the possible next loop */
            ssize = ssize / 2.;
            if (ssize < MINIMUM_STEP_SIZE)
                break;

            /*
            std::fprintf(stderr, "w: last_obj: %f, obj = %f, stepsize = %f\n", 
              last_obj, obj, ssize);
              */
        } while (obj >= last_obj);

        /* If that's true, the image cannot be improved anymore.
         * So exit, because bitmap is good enough. */
        if (ssize < MINIMUM_STEP_SIZE)
            break;

        last_obj = obj;
        project(estimate, bitmap);
    }
}

void Robertson::add_noise_to_gradient()
{
    int i,j,x,y,adr;
    int h,w;
    float bbitmap[DCTSize2];
    float coefdct[DCTSize2];
    float *ptr;
    float *g_ptr;
    const float *b_ptr;
    const float *r_ptr;

    h = height;
    w = width;

    r_ptr = reference.getPtr();
    b_ptr = bitmap.getPtr();
    g_ptr = gradient.getPtr();

    for (i=0; i<h; i+=DCTSize)
        for (j=0; j<w;j+=DCTSize) 
        {
            adr=(i*w+j);    
            ptr = bbitmap;
            /* Put (z - z_q) in the bbitmap buffer */
            for (y=0;y<DCTSize;y++)
                for (x=0;x<DCTSize;x++)
                    *(ptr++)=b_ptr[adr+x+y*w] - r_ptr[adr+x+y*w]
                        + 128.; /* RAWCENTER for dct */

            /* Get D * (z - z_q) */
            fdct_buffer(bbitmap, coefdct);

            /* Get K_ey^-1 * D * (z - z_q) */
            for (y=0;y<DCTSize2;y++)
            {
                /*
                std::fprintf(stderr,"coefdct: %f inv_key: %f z-zq = %f\n",
                        coefdct[y], inv_k_ey[y], bbitmap[y]);
                        */
                coefdct[y] *= inv_k_ey[y];
            }

            /* Get D^t * K_ey^-1 * D * (z - z_q) */
            fidct_buffer(coefdct, bbitmap);

            /* Put the result into gradient, taking into account that
             * there is Nabla r(z) */
            ptr = bbitmap;
            for (y=0;y<DCTSize;y++)
                for (x=0;x<DCTSize;x++)
                {
                    /* 128 is rawcenter for the DCT operations */
                    /*
                       fprintf(stderr, "contribution (%f/%f): %f\n",
                       lambda * gradient[adr+x+y*w],
                       (*ptr - 128), lambda* gradient[adr+x+y*w] / *ptr);
                       */
                    g_ptr[adr+x+y*w] += lambda
                        * g_ptr[adr+x+y*w] + *(ptr++) - 128.;
                }
        }
}

void Robertson::calc_inv_k_ey()
{
    int i;

    for (i = 0; i < DCTSize2; i++)
    {
        /* each element is the inverse of the variance of the coefficient.
         * Uniform distribution: sigma_e = (q_{i+1} - q_{i})^2 / 12 */
        inv_k_ey[i] = 12. / (qtable[i] * qtable[i]);
    }
}

void Robertson::set_DCT_constraint()
{
    DCTimage = coefs.newcopy();
    
    DCTmin.allocate(coefs.getWidthInBlocks(), coefs.getHeightInBlocks());
    DCTmax.allocate(coefs.getWidthInBlocks(), coefs.getHeightInBlocks());

    float * cptr = coefs.getPtr();

    for (unsigned int j=0;j<coefs.getHeightInBlocks();++j)
        for (unsigned int i=0;i<coefs.getWidthInBlocks();++i)
        {
            unsigned int base = (j * coefs.getWidthInBlocks() + i) * DCTSize2;
            for (unsigned int k=0;k<DCTSize2;k++)
            {
              DCTmin.getPtr()[base+k]=cptr[base+k] - (0.5*qtable[k]);
              DCTmax.getPtr()[base+k]=cptr[base+k] + (0.5*qtable[k]);
            }
        }
}

/* Projection on the constraint - by Froment*/
/*! Projects the DCTimage [idct(in)] into out, according to DCTmin and DCTmax */
void Robertson::project(const FloatPlane &in, FloatPlane &out)
{
  fdct_image(DCTimage.getPtr(), in.getPtr(), width, height);
    
  unsigned int length = width * height;
  for (unsigned int j=0;j<length;j++)
    if (DCTimage.getPtr()[j] > DCTmax.getPtr()[j])
      DCTimage.getPtr()[j] = DCTmax.getPtr()[j];
    else if (DCTimage.getPtr()[j] < DCTmin.getPtr()[j])
      DCTimage.getPtr()[j] = DCTmin.getPtr()[j];

  fdct_inverse_image(DCTimage.getPtr(), out.getPtr(), width, height);
}

void Robertson::get_new_estimate(float ssize)
{
  int i;
  float *e_ptr;
  const float *b_ptr, *g_ptr;

  e_ptr = estimate.getPtr();
  b_ptr = bitmap.getPtr();
  g_ptr = gradient.getPtr();

  /* Equation 32 */
  for (i = 0; i < width*height; i++)
    e_ptr[i] = b_ptr[i] - ssize * g_ptr[i];
}

float Robertson::calc_objective(const FloatPlane &plane)
{
    int index_mn, index_kl;
    int bound_up, bound_down, bound_left, bound_right;
    int border_local;
    int row, col, wrow, wcol;
    float obj;
    enum { WINDOW_LOCAL = 3 };

    const float * p = plane.getPtr();

    border_local = (WINDOW_LOCAL-1)/2;

    obj = 0.;

    for(row=0; row < height; row++) 
        for (col=0; col < width; col++)
        {
            /* This scope is N_{m,n} as in the article */

            bound_up = (row >= border_local) ? row - border_local: 0;
            bound_down = (row < height - border_local) ? row + border_local
                : height - 1;
            bound_left = (col >= border_local) ? col - border_local: 0;
            bound_right = (col < width - border_local) ? col + border_local
                : width - 1;

            index_mn = row * width + col;

            for (wrow = bound_up; wrow <= bound_down; wrow++)
                for (wcol = bound_left; wcol <= bound_right; wcol++)
                {
                    if (wrow == row && wcol == col)
                        continue;

                    /* This scope is a "c in C", as explained in the article. */

                    index_kl = wrow * width + wcol;

                    /* Calculate for the gradient */
                    /* sum(c in C, rho_T(d_c^t * z) */
                    obj += f_huber(p[index_mn] - p[index_kl]);
                }
        }

    return obj;
}

float Robertson::f_huber(float u)
{
    float T;
    float ret;

    T = T_Huber;

    if (u > 0.)
    {
        if (u > T)
            ret = T*T + 2. * T * (u - T);
        else
            ret = u*u;
    }
    else
    {
        if (u < -T)
            ret = T*T + 2. * T * (-u - T);
        else
            ret = u*u;
    }

    return ret;
}

float Robertson::diff_huber(float u)
{
  float T;
  float ret;

  T = T_Huber;
  
  if (u > 0.)
  {
    if (u > T)
      ret = 2. * T;
    else
      ret = 2. * u;
  }
  else
  {
    if (u < -T)
      ret = -2. * T;
    else
      ret = 2. * u;
  }

  return ret;
}

void Robertson::calc_gradient_hubber()
{
    int index_mn, index_kl;
    int bound_up, bound_down, bound_left, bound_right;
    int border_local;
    int row, col, wrow, wcol;
    float huber;
    float *b_ptr, *g_ptr;
    enum { WINDOW_LOCAL = 3 };

    b_ptr = bitmap.getPtr();
    g_ptr = gradient.getPtr();

    gradient.setzero();

    border_local = (WINDOW_LOCAL-1)/2;

    for(row=0; row < height; row++) 
        for (col=0; col < width; col++)
        {
            /* This scope is N_{m,n} as in the article */

            bound_up = (row >= border_local) ? row - border_local: 0;
            bound_down = (row < height - border_local) ? row + border_local
                : height - 1;
            bound_left = (col >= border_local) ? col - border_local: 0;
            bound_right = (col < width - border_local) ? col + border_local
                : width - 1;

            index_mn = row * width + col;

            for (wrow = bound_up; wrow <= bound_down; wrow++)
                for (wcol = bound_left; wcol <= bound_right; wcol++)
                {
                    if (wrow == row && wcol == col)
                        continue;

                    /* This scope is a "c in C", as explained in the article. */

                    index_kl = wrow * width + wcol;

                    /* Calculate for the gradient 
                     *   g^(k) = sum(c in C, d_c * rho_T' (d_c^t * z^(k)) ) */
                    huber = diff_huber(b_ptr[index_mn]
                            - b_ptr[index_kl]);
                    g_ptr[index_mn] += huber;
                    g_ptr[index_kl] -= huber;
                }
        }
}

RobertsonCreator::RobertsonCreator()
{
    type = e_ImproveRawPlane;
}

bool RobertsonCreator::isapplicable(const JPEGParameters &p)
{
    return true;
}


void RobertsonCreator::init()
{
    ActionCreator *a = new RobertsonCreator();
    ActionManager::sreg("Robertson", a);
}

ImproveRawPlane * RobertsonCreator::createImproveRawPlane() const
{
    return new Robertson();
}
