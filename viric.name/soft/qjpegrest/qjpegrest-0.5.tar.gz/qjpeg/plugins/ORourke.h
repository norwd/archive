/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class CoefsPlane;
class FloatPlane;

class ORourke : public ImproveRawPlane
{
protected:
    int steps;
    float T_Huber;
    float step_size;
    static const float MINIMUM_STEP_SIZE;

private:
    CoefsPlane DCTmin;
    CoefsPlane DCTmax;
    CoefsPlane DCTimage;

    /*! Width in blocks * 8 */
    unsigned int width;
    /*! Height in blocks * 8 */
    unsigned int height;

    /*! Temporary bitmap, which will have the final image. */
    FloatPlane bitmap;
    /*! The initial floatplane, from which apply Nosratinia */
    FloatPlane reference;
    FloatPlane gradient;
    FloatPlane estimate;

    Qtable qtable;
    CoefsPlane coefs;

    void start_restoration();
    void set_DCT_constraint();
    void min_map();
    float calc_objective(const FloatPlane &plane);
    void calc_gradient();
    void get_new_estimate(float ssize);
    float f_huber(float u);
    void project(const FloatPlane &in, FloatPlane &out);
    float diff_huber(float u);

public:
    ORourke();
    virtual ~ORourke() {};

	void prepare(const CoefsPlane *coefs,
            const FloatPlane *initial);
	FloatPlane * apply();
    bool getConfiguredEnv();
};

class ORourkeCreator : public ActionCreator
{
    ORourkeCreator();

public:
    static void init();

    ImproveRawPlane * createImproveRawPlane() const;
	bool isapplicable(const JPEGParameters &p);
};
