/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class IDCTPlane;
class Scaler;
class CoefsImage;
class FloatImage;
class ActionCreator;

class IDCTFExp : public IDCTPlane
{
protected:
    float mu;
private:
    const static float zeromargin;

    /*! Where the result will be stored */
    FloatPlane *result;

    CoefsPlane DCTimage;

    Qtable qtable;

    CoefsPlane coefs;

    void dequantize_coefs();
    float despcoef(float coefmean);

public:
    IDCTFExp();

    void prepare(const CoefsPlane *in);
    FloatPlane * apply();
};

class IDCTFExpCreator : public ActionCreator
{
    IDCTFExpCreator();

public:
    static void init();

    IDCTPlane * createIDCTPlane() const;
	bool isapplicable(const JPEGParameters &p);
};
