/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class Scaler;
class CoefsImage;
class FloatImage;
class FloatPlane;
class ActionCreator;

class LumScaler : public Scaler
{
protected:
    float epsilon_h;
    float epsilon_v;
private:
    const FloatImage *infimage;
    /*! Although we don't use the coefs, we take from there the
     * jpegdata */
    const CoefsImage *incimage;

    float h_weight(float Ypoint, float Ynear, float Yfar);
    float v_weight(float Ypoint, float Ynear, float Yfar);
    void h2v1_lum_upsample(const FloatPlane &lum, const FloatPlane &in,
        FloatPlane &out);
    void h2v2_lum_upsample(const FloatPlane &lum, const FloatPlane &in,
        FloatPlane &out);
public:
    LumScaler();
	void prepare(const CoefsImage *coefs,
            const FloatImage *initial);
	FloatImage * apply();
};

class LumScalerCreator : public ActionCreator
{
    LumScalerCreator();

public:
    static void init();

    Scaler * createScaler() const;
	bool isapplicable(const JPEGParameters &p);
};
