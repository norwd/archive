/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QWidget>

class MdiChildBase : public QWidget
{
    Q_OBJECT

protected:
    QString title;

public:
    MdiChildBase(QWidget *parent = 0) : QWidget(parent) { };
    virtual bool isImage() const;
    QString getTitle() const;
};
