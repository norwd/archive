/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include "MainWindow.h"
#include "Chain.h"
#include "QChain.h"
#include "JPEGData.h"
#include "JPEGFile.h"

void MainWindow::setMainJPEG(const char *filename)
{
    if (mainjpeg)
        delete mainjpeg;
    mainjpeg = new JPEGFile(filename);

    CoefsImage *coefs = mainjpeg->getCoefs();
    if (coefs != 0)
        mainchain->setInitial(coefs);
}
