/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QTreeWidgetItem>
/* Requires <ActionType.h> */

enum QTreeItemType {
    ActionGroup = 1000,
    Action
};

class QTreeActionItem : public QTreeWidgetItem
{
public:
    QTreeActionItem(QTreeWidget * parent, int type = QTreeItemType(Action),
            enum ActionType atype = e_Undefined);
    QTreeActionItem(QTreeWidgetItem * parent, int type = QTreeItemType(Action),
            enum ActionType atype = e_Undefined);
    enum ActionType type;
};
