/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QObject>

class QDialog;
class QSpinBox;
class QDoubleSpinBox;
class QPushButton;
class QCheckBox;

class QFroment : public QObject, public Froment, public QTConfigurable
{
    Q_OBJECT

    QDialog *dialog;
    QDoubleSpinBox *spinWeights[8];
    QSpinBox *spinSteps;
    QDoubleSpinBox *spinStepSize;
    QPushButton *butPlainWeights;
    QPushButton *butFromentWeights;
    QCheckBox *cConstantStep;

public slots:
    void setConfiguration();
    void setPlainWeights();
    void setFromentWeights();
    void resetConfiguration();

public:
    QFroment();
    virtual ~QFroment();
    void startQtConfiguration();
};

class QFromentCreator : public ActionCreator
{
    QFromentCreator();

public:
    static void init();

    ImproveRawPlane * createImproveRawPlane() const;
	bool isapplicable(const JPEGParameters &p);
};
