/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QMouseEvent>
#include <ActionType.h>
#include "QTreeActionItem.h"
#include "QTreeActions.moc"

#include <QDebug>

QTreeActions::QTreeActions(QWidget *parent)
    : QTreeWidget(parent)
{
    setDragEnabled(true);
}

void QTreeActions::mousePressEvent(QMouseEvent *event)
{
    QTreeActionItem *myitem = static_cast<QTreeActionItem *>(itemAt(event->pos()));

    if (myitem == 0)
        return;

    if (event->button() == Qt::LeftButton && myitem->type != e_Undefined) {
        QDrag *drag = new QDrag(this);
        QMimeData *mimeData = new QMimeData;

        QString content;
        content = actionType2String(myitem->type) + "\n" + myitem->text(0);
        mimeData->setText(content);
        drag->setMimeData(mimeData);

        Qt::DropAction dropAction = drag->start();
    }
}
