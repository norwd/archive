/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <Actions.h>
#include <ActionType.h>
#include <ActionCreator.h>
#include <ActionManager.h>

#include <FloatPlane.h>
#include <JPEGData.h>
#include <CoefsPlane.h>

#include <Froment.h>

#include <QDialog>
#include <QSpinBox>
#include <QDoubleSpinBox>
#include <QLabel>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QGroupBox>
#include <QCheckBox>

#include "QTConfigurable.h"
#include "QFroment.moc"

QFroment::QFroment()
{
    GUIconfigurable = true;
    dialog = 0;
}

QFroment::~QFroment()
{
    /* This will free all the elements of the dialog */
    if (dialog)
        delete dialog;
}

static QDoubleSpinBox * newDoubleBox(double val, QWidget *parent)
{
    QDoubleSpinBox *sb = new QDoubleSpinBox(parent);
    sb->setSingleStep(1.f);
    sb->setDecimals(2);
    sb->setValue(val);
    return sb;
}

void QFroment::startQtConfiguration()
{
    if (!dialog)
    {
        dialog = new QDialog();
        dialog->setWindowTitle(trUtf8("Configurant") + QString(" Froment"));
        QVBoxLayout *v = new QVBoxLayout(dialog);
        QGroupBox *grouptop = new QGroupBox(trUtf8("Pesos"));
        QVBoxLayout *vtop = new QVBoxLayout(grouptop);
        QHBoxLayout *hweights = new QHBoxLayout();
        QHBoxLayout *hpresets = new QHBoxLayout();

        for(int i = 0; i < 8; ++i)
        {
            spinWeights[i] = newDoubleBox(1.0, grouptop);
            hweights->addWidget(spinWeights[i]);
        }
        butPlainWeights = new QPushButton(trUtf8("Plans"), grouptop);
        butFromentWeights = new QPushButton(trUtf8("De Froment"), grouptop);
        connect(butPlainWeights, SIGNAL(released()), this,
                SLOT(setPlainWeights()));
        connect(butFromentWeights, SIGNAL(released()), this,
                SLOT(setFromentWeights()));

        /* Top : Weights */
        hpresets->addWidget(butPlainWeights);
        hpresets->addStretch();
        hpresets->addWidget(butFromentWeights);
        vtop->addLayout(hweights);
        vtop->addLayout(hpresets);
        /* grouptop->setLayout(vtop); already */
        v->addWidget(grouptop);

        QHBoxLayout *hbottom = new QHBoxLayout();
        /* bottom left */
        QVBoxLayout *vbottomleft = new QVBoxLayout();
        QHBoxLayout *hsteps = new QHBoxLayout();
        QHBoxLayout *hstepsize = new QHBoxLayout();
        vbottomleft->addLayout(hsteps);
        vbottomleft->addLayout(hstepsize);
        QLabel *lsteps = new QLabel(trUtf8("Passos"), dialog);
        QLabel *lstepsize = new QLabel(trUtf8("Mida del pas"), dialog);
        /* class member */
        spinSteps = new QSpinBox(dialog);
        spinSteps->setMinimum(0);
        spinSteps->setMaximum(10000);
        spinSteps->setValue(10);
        /* class member */
        spinStepSize = newDoubleBox(1, dialog);
        spinStepSize->setSingleStep(0.5f);
        hsteps->addWidget(lsteps);
        hsteps->addWidget(spinSteps);
        hstepsize->addWidget(lstepsize);
        hstepsize->addWidget(spinStepSize);

        cConstantStep = new QCheckBox(trUtf8("Pas constant"), dialog);

        hstepsize->addWidget(cConstantStep);
        hbottom->addLayout(vbottomleft);

        hbottom->addStretch();

        /* bottom right */
        QVBoxLayout *vbuttons = new QVBoxLayout();
        QPushButton *applyButton = new QPushButton(trUtf8("Aplicar"), dialog);
        QPushButton *resetButton = new QPushButton(trUtf8("Restablir"), dialog);

        vbuttons->addWidget(applyButton);
        vbuttons->addWidget(resetButton);
        hbottom->addLayout(vbuttons);
        v->addLayout(hbottom);

        connect(applyButton, SIGNAL(released()), this,
                SLOT(setConfiguration()));
        connect(resetButton, SIGNAL(released()), this,
                SLOT(resetConfiguration()));
        resetConfiguration();
    }
    dialog->show();
}

void QFroment::setConfiguration()
{
    steps = spinSteps->value();
    step_size = spinStepSize->value();
    for(int i = 0; i < 8; ++i)
        wTV[i] = spinWeights[i]->value();
    constant_step = cConstantStep->isChecked();
}

void QFroment::setPlainWeights()
{
    for(int i = 0; i < 8; ++i)
        spinWeights[i]->setValue(1.0f);
}

void QFroment::setFromentWeights()
{
    const float default_wTV[8] =
        { 5.0f, 2.0f, 1.0f, 1.0f, 1.0f, 2.0f, 5.0f, 10.0f };
    for(int i = 0; i < 8; ++i)
        spinWeights[i]->setValue(default_wTV[i]);
}

void QFroment::resetConfiguration()
{
    for(int i = 0; i < 8; ++i)
        spinWeights[i]->setValue(wTV[i]);
    spinSteps->setValue(steps);
    spinStepSize->setValue(step_size);
    cConstantStep->setChecked(constant_step);
}

QFromentCreator::QFromentCreator()
{
    type = e_ImproveRawPlane;
}

void QFromentCreator::init()
{
    ActionCreator *a = new QFromentCreator();
    ActionManager::sreg("Froment", a);
}

ImproveRawPlane * QFromentCreator::createImproveRawPlane() const
{
    return new QFroment();
}

bool QFromentCreator::isapplicable(const JPEGParameters &p)
{
    return true;
}
