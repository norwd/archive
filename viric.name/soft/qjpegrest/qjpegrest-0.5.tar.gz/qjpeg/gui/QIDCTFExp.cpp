/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <Actions.h>
#include <ActionType.h>
#include <ActionCreator.h>
#include <ActionManager.h>

#include <FloatPlane.h>
#include <JPEGData.h>
#include <CoefsPlane.h>

#include <IDCTFExp.h>

#include <QDialog>
#include <QSpinBox>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLabel>

#include "QTConfigurable.h"
#include "QIDCTFExp.moc"

QIDCTFExp::QIDCTFExp()
{
    GUIconfigurable = true;
    dialog = 0;
}

QIDCTFExp::~QIDCTFExp()
{
    /* This will free all the elements of the dialog */
    if (dialog)
        delete dialog;
}

void QIDCTFExp::startQtConfiguration()
{
    if (!dialog)
    {
        dialog = new QDialog();
        dialog->setWindowTitle(trUtf8("Configurant") + QString(" IDCTFExp"));
        QHBoxLayout *h = new QHBoxLayout(dialog);

        QVBoxLayout *vlabels = new QVBoxLayout();
        QLabel *lvar = new QLabel(trUtf8("Nivell:"), dialog);
        lvar->setAlignment(Qt::AlignRight);
        vlabels->addWidget(lvar, 0, Qt::AlignVCenter);
        h->addLayout(vlabels);

        QVBoxLayout *vspins = new QVBoxLayout();
        spinMu = new QDoubleSpinBox(dialog);
        spinMu->setMaximum(100000);
        spinMu->setMinimum(-10000);
        spinMu->setDecimals(2);
        spinMu->setSingleStep(1);
        vspins->addWidget(spinMu, 0, Qt::AlignVCenter);
        h->addLayout(vspins);

        QVBoxLayout *vbuttons = new QVBoxLayout();
        QPushButton *applyButton = new QPushButton(trUtf8("Aplicar"), dialog);
        QPushButton *resetButton = new QPushButton(trUtf8("Restablir"), dialog);

        vbuttons->addWidget(applyButton);
        vbuttons->addWidget(resetButton);
        h->addLayout(vbuttons);

        connect(applyButton, SIGNAL(released()), this, SLOT(setConfig()));
        connect(resetButton, SIGNAL(released()), this, SLOT(resetConfig()));
        resetConfig();
    }
    dialog->show();
}

void QIDCTFExp::setConfig()
{
    mu = spinMu->value();
}

void QIDCTFExp::resetConfig()
{
    spinMu->setValue(mu);
}

QIDCTFExpCreator::QIDCTFExpCreator()
{
    type = e_IDCTPlane;
}

void QIDCTFExpCreator::init()
{
    ActionCreator *a = new QIDCTFExpCreator();
    ActionManager::sreg("IDCTFExp", a);
}

IDCTPlane * QIDCTFExpCreator::createIDCTPlane() const
{
    QIDCTFExp *ptr;
    ptr = new QIDCTFExp();
    return ptr;
}

bool QIDCTFExpCreator::isapplicable(const JPEGParameters &p)
{
    return true;
}
