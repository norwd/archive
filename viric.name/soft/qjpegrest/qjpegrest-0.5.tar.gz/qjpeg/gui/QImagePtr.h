/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QImage>

class QImagePtr : public QImage
{
public:
    QImagePtr ( uchar * data, int width, int height, int bytesperline,
            Format format )
        : QImage(data, width, height, bytesperline, format) {};
    QImagePtr ( const uchar * data, int width, int height, int bytesperline,
            Format format )
        : QImage(data, width, height, bytesperline, format) {};
    ~QImagePtr() {
        delete[] bits();
    };
};
