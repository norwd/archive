/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <Actions.h>
#include <ActionType.h>
#include <ActionCreator.h>
#include <ActionManager.h>

#include <FloatPlane.h>
#include <JPEGData.h>
#include <CoefsPlane.h>

#include <LoadPlane.h>

#include <QMessageBox>
#include <QFileDialog>

#include "QTConfigurable.h"
#include "QLoadPlane.h"

QLoadPlane::QLoadPlane()
{
    GUIconfigurable = true;
}

QLoadPlane::~QLoadPlane()
{
    if (loaded_image)
    {
        loaded_image->free();
        delete loaded_image;
        loaded_image = 0;
    }
}

void QLoadPlane::startQtConfiguration()
{
    QString fileName = QFileDialog::getOpenFileName();
    if (!fileName.isEmpty()) {
        QImage img;
        bool result;
        result = img.load(fileName);
        if (!result)
        {
            QMessageBox::critical(0, QObject::trUtf8("No es pot obrir el fitxer"),
                    QObject::trUtf8("No es pot obrir el fitxer: ") + fileName,
                    QMessageBox::Ok, QMessageBox::Ok);
            return;
        }

        if (img.format() != QImage::Format_Indexed8)
        {
            QMessageBox::critical(0, QObject::trUtf8("No es pot obrir el fitxer"),
                    QObject::trUtf8("Format de fitxer incorrecte. Cal un sol pla "
                        "de 8 bits."),
                    QMessageBox::Ok, QMessageBox::Ok);
            return;
        }

        /*
        if (img.width() != coefs.getWidthInBlocks() * 8 ||
            img.height() != coefs.getHeightInBlocks() * 8)

        {
            QMessageBox::critical(0, QObject::trUtf8("No es pot obrir el fitxer"),
                    QObject::trUtf8("Les mides del fitxer (%1x%2) no són les que"
                        " calen (%3x%4)").arg(img.width()).arg(img.height())
                    .arg(coefs.getWidthInBlocks()*8)
                    .arg(coefs.getHeightInBlocks()*8),
                    QMessageBox::Ok, QMessageBox::Ok);
            return;
        }
        */

        if (loaded_image)
            loaded_image->free();
        else
            loaded_image = new FloatPlane();

        loaded_image->allocate(img.width(), img.height());
        int length = img.width() * img.height();
        for(int i=0; i < length; ++i)
        {
            loaded_image->getPtr()[i] = ((unsigned char *) img.bits())[i];
        }
    }
}

QLoadPlaneCreator::QLoadPlaneCreator()
{
    type = e_ImproveRawPlane;
}

void QLoadPlaneCreator::init()
{
    ActionCreator *a = new QLoadPlaneCreator();
    ActionManager::sreg("LoadPlane", a);
}

ImproveRawPlane * QLoadPlaneCreator::createImproveRawPlane() const
{
    QLoadPlane *ptr;
    ptr = new QLoadPlane();
    return ptr;
}

bool QLoadPlaneCreator::isapplicable(const JPEGParameters &p)
{
    return true;
}
