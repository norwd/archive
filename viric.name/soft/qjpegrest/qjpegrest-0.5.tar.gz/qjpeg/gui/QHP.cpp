/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <Actions.h>
#include <ActionType.h>
#include <ActionCreator.h>
#include <ActionManager.h>

#include <FloatPlane.h>
#include <JPEGData.h>
#include <CoefsPlane.h>

#include <HP.h>

#include <QDialog>
#include <QSpinBox>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLabel>

#include "QTConfigurable.h"
#include "QHP.moc"

QHP::QHP()
{
    GUIconfigurable = true;
    dialog = 0;
}

QHP::~QHP()
{
    /* This will free all the elements of the dialog */
    if (dialog)
        delete dialog;
}

void QHP::startQtConfiguration()
{
    if (!dialog)
    {
        dialog = new QDialog();
        dialog->setWindowTitle(trUtf8("Configurant") + QString(" HP"));
        QHBoxLayout *h = new QHBoxLayout(dialog);

        QVBoxLayout *vlabels = new QVBoxLayout();
        QLabel *l = new QLabel(trUtf8("Desplaçaments:"), dialog);
        l->setAlignment(Qt::AlignRight);

        QLabel *lvar = new QLabel(trUtf8("Percentatge de transformades:"), dialog);
        lvar->setAlignment(Qt::AlignRight);
        vlabels->addWidget(l);
        vlabels->addWidget(lvar);
        h->addLayout(vlabels);

        QVBoxLayout *vspins = new QVBoxLayout();
        spinShifts = new QSpinBox(dialog);
        spinShifts->setMaximum(64);
        spinShifts->setMinimum(0);
        spinShifts->setSingleStep(1);
        spinShifts->setValue(64);
        vspins->addWidget(spinShifts);
        spinPercent = new QDoubleSpinBox(dialog);
        spinPercent->setMaximum(100);
        spinPercent->setMinimum(0);
        spinPercent->setSingleStep(1);
        spinPercent->setValue(30);
        vspins->addWidget(spinPercent);
        h->addLayout(vspins);

        QVBoxLayout *vbuttons = new QVBoxLayout();
        QPushButton *applyButton = new QPushButton(trUtf8("Aplicar"), dialog);
        QPushButton *resetButton = new QPushButton(trUtf8("Restablir"), dialog);

        vbuttons->addWidget(applyButton);
        vbuttons->addWidget(resetButton);
        h->addLayout(vbuttons);

        connect(applyButton, SIGNAL(released()), this, SLOT(setConfig()));
        connect(resetButton, SIGNAL(released()), this, SLOT(resetConfig()));
        resetConfig();
    }
    dialog->show();
}

void QHP::setConfig()
{
    shifts = spinShifts->value();
    percent_var = spinPercent->value();
}

void QHP::resetConfig()
{
    spinShifts->setValue(shifts);
    spinPercent->setValue(percent_var);
}

QHPCreator::QHPCreator()
{
    type = e_ImproveRawPlane;
}

void QHPCreator::init()
{
    ActionCreator *a = new QHPCreator();
    ActionManager::sreg("HP", a);
}

ImproveRawPlane * QHPCreator::createImproveRawPlane() const
{
    QHP *ptr;
    ptr = new QHP();
    return ptr;
}

bool QHPCreator::isapplicable(const JPEGParameters &p)
{
    return true;
}
