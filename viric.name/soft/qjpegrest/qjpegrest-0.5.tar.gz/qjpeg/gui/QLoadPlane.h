/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QObject>

class QLoadPlane : public LoadPlane, public QTConfigurable
{
public:
    QLoadPlane();
    virtual ~QLoadPlane();
    void startQtConfiguration();
};

class QLoadPlaneCreator : public ActionCreator
{
    QLoadPlaneCreator();

public:
    static void init();

    ImproveRawPlane * createImproveRawPlane() const;
	bool isapplicable(const JPEGParameters &p);
};
