/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QApplication>
#include <QWorkspace>
#include <QAction>
#include <QMenu>
#include <QMenuBar>
#include <QSignalMapper>
#include <QFileDialog>
#include <QStatusBar>
#include <QMouseEvent>

#include <QDebug>

#include "QZoomImageSettings.h"
#include "QZoomImage.h"
#include "MainWindow.moc"
#include "ImageContextMenu.h"
#include "MdiChildBase.h"
#include "MdiChildImage.h"
#include "MdiChildMResult.h"

#include "Chain.h"
#include "JPEGData.h"
#include "JPEGFile.h"
#include "QChain.h"

#include "qInitActions.h"


MainWindow * MainWindow::mainWindow;

MainWindow::MainWindow()
{
    workspace = new QWorkspace();
    setCentralWidget(workspace);
    connect(workspace, SIGNAL(windowActivated(QWidget *)),
            this, SLOT(updateMenus()));

    windowMapper = new QSignalMapper(this);
    connect(windowMapper, SIGNAL(mapped(QWidget *)),
            workspace, SLOT(setActiveWindow(QWidget *)));

    /* QChain depends on this initialized */
    qInitActions();

    /* Create the chain */
    mainchain = new QChain();

    createActions();
    createMenus();
    createStatusBar();
    updateMenus();

    setWindowTitle(trUtf8("QJpegRest") + " v0.5");

    mainWindow = this;
    mainjpeg = 0;

    /* static */
    mainWindow = this;
}

void MainWindow::openImage()
{
    QString fileName = QFileDialog::getOpenFileName(this);
    if (!fileName.isEmpty()) {
        MdiChildImage *child = createMdiChildImage();

        if (child->loadFile(fileName)) {
            bool isok = false;
            bool inheritSettings = false;
            QZoomImageSettings qzset;

            QList<MdiChildImage *> windows = allMdiChildImages();
            if (windows.size() == 0)
                isok = true;
            else
            {
                MdiChildImage *initial = windows.at(0);
                if (initial->getImageSize() == child->getImageSize())
                {
                    isok = true;
                    inheritSettings = true;
                    qzset = initial->getQZoom()->getViewSettings();
                }
            }
            /* Create the window only if the image size is the same as others */
            if (isok) {
                for(int i=0; i<windows.size(); ++i)
                {
                    bool ret;
                    MdiChildImage *win = windows.at(i);
                    ret = connect(win->getQZoom(),SIGNAL(viewSettingsChanged(QZoomImageSettings)),
                            child->getQZoom(),SLOT(setViewSettings(QZoomImageSettings)));
                    ret = connect(child->getQZoom(),SIGNAL(viewSettingsChanged(QZoomImageSettings)),
                            win->getQZoom(),SLOT(setViewSettings(QZoomImageSettings)));
                }
                statusBar()->showMessage(trUtf8("Fitxer carregat"), 2000);
                if (inheritSettings)
                    child->getQZoom()->setViewSettings(qzset);

                connect(child->getQZoom(), SIGNAL(rightClick(QMouseEvent*)),
                        this, SLOT(openImageContextMenu(QMouseEvent *)));
                child->show();
                child->updateGeometry();
            } else
            {
                statusBar()->showMessage(trUtf8("La imatge té una mida diferent"),
                        2000);
                child->close();
            }
        } else {
                statusBar()->showMessage(trUtf8("No s'ha pogut obrir la imatge"),
                        2000);
            child->close();
        }
    }
}

void MainWindow::saveImage()
{
    MdiChildBase *mdi = activeMdiChild();
    
    if (mdi->isImage())
    {
        QString fileName = QFileDialog::getSaveFileName(this);

        MdiChildImage *mdiimg = static_cast<MdiChildImage *>(mdi);

        if (mdiimg->saveFileAs(fileName))
            statusBar()->showMessage(trUtf8("Fitxer guardat"), 2000);
        else
            statusBar()->showMessage(trUtf8("No s'ha pogut guardar el fitxer"),
                    4000);
    }
}

void MainWindow::updateMenus()
{
    MdiChildBase *mdi = activeMdiChild();

    bool hasMdiChildImage = (mdi != 0);

    saveImageAction->setEnabled(hasMdiChildImage && mdi->isImage());
    closeAction->setEnabled(hasMdiChildImage);
    closeAllAction->setEnabled(hasMdiChildImage);
    tileAction->setEnabled(hasMdiChildImage);
    cascadeAction->setEnabled(hasMdiChildImage);
    arrangeAction->setEnabled(hasMdiChildImage);
}

void MainWindow::updateWindowMenu()
{
    windowMenu->clear();
    windowMenu->addAction(closeAction);
    windowMenu->addSeparator();
    windowMenu->addAction(tileAction);
    windowMenu->addAction(cascadeAction);
    windowMenu->addAction(arrangeAction);

    windowMenu->addSeparator();

    QList<QWidget *> windows = workspace->windowList();

    for (int i = 0; i < windows.size(); ++i) {
        MdiChildBase *child = static_cast<MdiChildBase *>(windows.at(i));

        QAction *action  = windowMenu->addAction(child->getTitle());
        action->setCheckable(true);
        action ->setChecked(child == activeMdiChild());
        connect(action, SIGNAL(triggered()), windowMapper, SLOT(map()));
        windowMapper->setMapping(action, child);
    }
}

void MainWindow::createMdiChildMResult(MeasureResult *mr, const QString &title)
{
    MdiChildMResult *child = new MdiChildMResult(mr);
    workspace->addWindow(child);
    child->setWindowTitle(title);
    child->show();
}

MdiChildImage *MainWindow::createMdiChildImage()
{
    MdiChildImage *child = new MdiChildImage;
    workspace->addWindow(child);

    return child;
}

void MainWindow::createActions()
{
    openImageAction = new QAction(trUtf8("Obrir una &imatge..."), this);
    openImageAction->setShortcut(trUtf8("Ctrl+O"));
    openImageAction->setStatusTip(trUtf8("Obrir una imatge guardada"));
    connect(openImageAction, SIGNAL(triggered()), this, SLOT(openImage()));

    saveImageAction = new QAction(trUtf8("Guardar la imatge com..."), this);
    saveImageAction->setStatusTip(trUtf8("Guardar la imatge amb un nou nom"));
    connect(saveImageAction, SIGNAL(triggered()), this, SLOT(saveImage()));

    exitAction = new QAction(trUtf8("&Sortir"), this);
    exitAction->setShortcut(trUtf8("Ctrl+Q"));
    exitAction->setStatusTip(trUtf8("Sortir de l'aplicació"));
    connect(exitAction, SIGNAL(triggered()), qApp, SLOT(closeAllWindows()));

    closeAction = new QAction(trUtf8("&Tancar"), this);
    closeAction->setShortcut(trUtf8("Ctrl+F4"));
    closeAction->setStatusTip(trUtf8("Tancar la finestra activa"));
    connect(closeAction, SIGNAL(triggered()),
            workspace, SLOT(closeActiveWindow()));

    closeAllAction = new QAction(trUtf8("T&ancar-ho tot"), this);
    closeAllAction->setStatusTip(trUtf8("Tancar totes les finestres"));
    connect(closeAllAction, SIGNAL(triggered()),
            workspace, SLOT(closeAllWindows()));

    tileAction = new QAction(trUtf8("&Quadrícula"), this);
    tileAction->setStatusTip(trUtf8("Posar les finestres en quadrícula"));
    connect(tileAction, SIGNAL(triggered()), workspace, SLOT(tile()));

    cascadeAction = new QAction(trUtf8("&Cascada"), this);
    cascadeAction->setStatusTip(trUtf8("Posar les finestres en cascada"));
    connect(cascadeAction, SIGNAL(triggered()), workspace, SLOT(cascade()));

    arrangeAction = new QAction(trUtf8("Recol·locar les &icones"), this);
    arrangeAction->setStatusTip(trUtf8("Recol·locar les icones"));
    connect(arrangeAction, SIGNAL(triggered()), workspace, SLOT(arrangeIcons()));

    viewChainAction = new QAction(trUtf8("Veure la &Cadena"), this);
    viewChainAction->setStatusTip(trUtf8("Veure la Cadena"));
    connect(viewChainAction, SIGNAL(triggered()), this, SLOT(viewChain()));
}

void MainWindow::viewChain()
{
    mainchain->show();
}

void MainWindow::createMenus()
{
    fileMenu = menuBar()->addMenu(trUtf8("&Fitxer"));
    fileMenu->addAction(openImageAction);
    fileMenu->addAction(saveImageAction);
    fileMenu->addSeparator();
    fileMenu->addAction(exitAction);

    windowMenu = menuBar()->addMenu(trUtf8("&Finestra"));
    connect(windowMenu, SIGNAL(aboutToShow()), this, SLOT(updateWindowMenu()));

    viewMenu = menuBar()->addMenu(trUtf8("&Veure"));
    viewMenu->addAction(viewChainAction);
}

void MainWindow::createStatusBar()
{
    statusBar()->showMessage(trUtf8("Preparat"));
}

MdiChildBase *MainWindow::activeMdiChild()
{
    return static_cast<MdiChildBase *>(workspace->activeWindow());
}

QList<MdiChildImage *> MainWindow::allMdiChildImages()
{
    QList<MdiChildImage *> l;

    QList<QWidget *> windows = workspace->windowList();

    foreach (QWidget *window, workspace->windowList()) {
        MdiChildBase *child = static_cast<MdiChildBase *>(window);
        if ( child->isImage() )
        {
            MdiChildImage *img = static_cast<MdiChildImage *>(child);
            l.append(img);
        }
    }
    
    return l;
}

QList<MdiChildImage *> MainWindow::otherMdiChildImages()
{
    QList<MdiChildImage *> l;

    QList<QWidget *> windows = workspace->windowList();

    foreach (QWidget *window, workspace->windowList()) {
        MdiChildBase *child = static_cast<MdiChildBase *>(window);
        if (child != activeMdiChild() && child->isImage() )
        {
            MdiChildImage *img = static_cast<MdiChildImage *>(child);
            l.append(img);
        }
    }
    
    return l;
}

    /*
MdiChildImage *MainWindow::findMdiChildImage(const QString &fileName)
{
       QString canonicalFilePath = QFileInfo(fileName).canonicalFilePath();

       foreach (QWidget *window, workspace->windowList()) {
       MdiChildImage *mdiChild = static_cast<MdiChildImage *>(window);
       if (mdiChild->currentFile() == canonicalFilePath)
       return mdiChild;
       }
    return 0;
}
*/

void MainWindow::openImageContextMenu(QMouseEvent *event)
{
#if 0
    MdiChildImage *mdiimg = static_cast<MdiChildImage *>(workspace->activeWindow());
    qDebug() << "Mdi: " << mdiimg->getBaseFileName();

    QMenu menu(mdiimg->getQZoom());
    menu.addAction(closeAction);
    menu.addSeparator();
    QMenu mmeasure("Mesurar", &menu);
    menu.addMenu(&mmeasure);

    /* Take the Measure-rs. */
    QList<QString> measures;
    measures = ActionManager::getListOf(ActionType(e_Measure));
    for (int i = 0; i < measures.size(); ++i) {
        QAction *action  = mmeasure.addAction(measures[i]);
        /*
        connect(action, SIGNAL(triggered()), windowMapper, SLOT(map()));
        windowMapper->setMapping(action, child);
        */
    }
#endif

    QList<MdiChildImage *> other = otherMdiChildImages();
    ImageContextMenu menu(this, static_cast<MdiChildImage *>(activeMdiChild()),
            &other, this);
    menu.exec(event->globalPos());
}

void MainWindow::newImage(QImage *img)
{
    MdiChildImage *child = mainWindow->createMdiChildImage();

    child->fromQImage(img);

    QList<MdiChildImage *> windows = mainWindow->allMdiChildImages();

    for(int i=0; i<windows.size(); ++i)
    {
        bool ret;
        MdiChildImage *win = windows.at(i);
        ret = connect(win->getQZoom(),
                SIGNAL(viewSettingsChanged(QZoomImageSettings)),
                child->getQZoom(),SLOT(setViewSettings(QZoomImageSettings)));
        ret = connect(child->getQZoom(),
                SIGNAL(viewSettingsChanged(QZoomImageSettings)),
                win->getQZoom(),SLOT(setViewSettings(QZoomImageSettings)));
    }

    mainWindow->statusBar()->showMessage(trUtf8("Cadena aplicada"), 2000);
    if (windows.size() > 0)
    {
        /* Get the used zoom settings, and apply them to the new image */
        QZoomImageSettings qzset;

        MdiChildImage *initial = windows.at(0);

        qzset = initial->getQZoom()->getViewSettings();

        initial->getQZoom()->getViewSettings();
        child->getQZoom()->setViewSettings(qzset);
    }
    connect(child->getQZoom(), SIGNAL(rightClick(QMouseEvent*)),
            mainWindow, SLOT(openImageContextMenu(QMouseEvent *)));
    child->setRestored(QString(mainWindow->mainjpeg->getFileName()));
    child->show();
    child->updateGeometry();
}
