/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QList>
#include <QSignalMapper>
#include <QMenu>
#include <QAction>

#include <ActionType.h>
#include <ActionManager.h>
#include <ARGBImage.h>
#include <GrayImage.h>
#include <MeasureResult.h>
#include <Actions.h>
#include <ActionCreator.h>
#include <GBIM.h>

#include "MainWindow.h"
#include "MdiChildBase.h"
#include "MdiChildImage.h"
#include "MeasureThread.h"

#include "MenuCompareToImage.h"
#include "ImageContextMenu.moc"

#include <QDebug>

ImageContextMenu::ImageContextMenu(MainWindow *main, MdiChildImage *from,
        QList<MdiChildImage *> *list, QWidget *parent)
    : QMenu(parent)
{
    mainwindow = main;
    myWindow = from;

    if (list != 0 && list->size() > 0)
        myWindowList = list;
    else
        myWindowList = 0;

    mapperCompare = new QSignalMapper(this);
    mapperMeasure = new QSignalMapper(this);

    /* The QObject will be MenuCompareToImage */
    if (myWindowList != 0)
        connect(mapperCompare, SIGNAL(mapped(QObject *)), this,
                SLOT(applyCompare(QObject *)));

    /* The QObject will be MdiChildImage * */
    connect(mapperMeasure, SIGNAL(mapped(QObject *)), this,
            SLOT(applyMeasure(QObject *)));

    listOptions();
}

/* List the first options in the menu */
void ImageContextMenu::listOptions()
{
    QMenu *measures = new QMenu(trUtf8("Mesurar"), this);
    addMenu(measures);
    addMeasures(measures);

    if (myWindowList != 0)
    {
        QMenu *compares = new QMenu(trUtf8("Comparar"), this);
        addCompares(compares);
        addMenu(compares);
    }

    addSeparator();
    QAction *setJPEG = addAction(trUtf8("Establir origen JPEG"));
    connect(setJPEG, SIGNAL(triggered()),
            this, SLOT(setJPEG()));

    addSeparator();
    QAction *closeWin = addAction(trUtf8("Tancar"));
    connect(closeWin, SIGNAL(triggered()),
            myWindow, SLOT(close()));
}

void ImageContextMenu::setJPEG()
{
    QByteArray utf8 = myWindow->getFileName().toUtf8();

    mainwindow->setMainJPEG(utf8.data());
}

void ImageContextMenu::addOtherImages(QMenu *menu, QString &method)
{
    foreach (MdiChildImage *img, *myWindowList) {
        QAction *action  = menu->addAction(QString(trUtf8("amb "))
                + img->getTitle());
        connect(action, SIGNAL(triggered()),mapperCompare, SLOT(map()));

        MenuCompareToImage *m = new MenuCompareToImage(menu);
        m->method = method;
        m->targetWindow = img;
        mapperCompare->setMapping(action, m);
   }
}

void ImageContextMenu::addCompares(QMenu *menu)
{
    /* Take the Compare-rs. */
    foreach(QString method, ActionManager::getListOf(ActionType(e_Compare)))
    {
        QMenu *methodmenu = new QMenu(method, menu);
        addOtherImages(methodmenu, method);
        menu->addMenu(methodmenu);
    }
}

void ImageContextMenu::addMeasures(QMenu *menu)
{
    /* Take the Measure-rs. */
    QList<QString> measures;

    measures = ActionManager::getListOf(ActionType(e_Measure));

    for (int i = 0; i < measures.size(); ++i) {
        QAction *action  = menu->addAction(measures[i]);
        connect(action, SIGNAL(triggered()), mapperMeasure, SLOT(map()));
        mapperMeasure->setMapping(action, action);
    }
}

void ImageContextMenu::applyMeasure(QObject *_method)
{
    QAction *method = qobject_cast<QAction *>(_method);
    MeasureThread *thread = new MeasureThread(method->text(), myWindow);

    connect(thread, SIGNAL(newResult(MeasureResult *, const QString &)),
            MainWindow::mainWindow, SLOT(createMdiChildMResult(MeasureResult *, const QString &)));

    thread->start();
    thread->wait();
    delete thread;
}

void ImageContextMenu::applyCompare(QObject *_params)
{
    MenuCompareToImage *params = qobject_cast<MenuCompareToImage *>(_params);

    MeasureThread *thread = new MeasureThread(params->method, myWindow, params->targetWindow);

    connect(thread, SIGNAL(newResult(MeasureResult *, const QString &)),
            MainWindow::mainWindow, SLOT(createMdiChildMResult(MeasureResult *, const QString &)));

    thread->start();
    thread->wait();
    delete thread;
}
