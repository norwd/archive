/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <Actions.h>
#include <ActionType.h>
#include <ActionCreator.h>
#include <ActionManager.h>

#include <FloatPlane.h>
#include <JPEGData.h>
#include <CoefsPlane.h>

#include <HContrast.h>

#include <QDialog>
#include <QSpinBox>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLabel>

#include "QTConfigurable.h"
#include "QHContrast.moc"

QHContrast::QHContrast()
{
    GUIconfigurable = true;
    dialog = 0;
}

QHContrast::~QHContrast()
{
    /* This will free all the elements of the dialog */
    if (dialog)
        delete dialog;
}

void QHContrast::startQtConfiguration()
{
    if (!dialog)
    {
        dialog = new QDialog();
        dialog->setWindowTitle(trUtf8("Configurant") + QString(" HContrast"));
        QHBoxLayout *h = new QHBoxLayout(dialog);

        QVBoxLayout *vlabels = new QVBoxLayout();
        QLabel *l = new QLabel(trUtf8("Mida de finestra XxX:"), dialog);
        l->setAlignment(Qt::AlignRight);
        vlabels->addWidget(l, 0, Qt::AlignVCenter);

        QLabel *lvar = new QLabel(trUtf8("Nivell:"), dialog);
        lvar->setAlignment(Qt::AlignRight);
        vlabels->addWidget(lvar, 0, Qt::AlignVCenter);
        h->addLayout(vlabels);

        QVBoxLayout *vspins = new QVBoxLayout();
        spinWinSize = new QSpinBox(dialog);
        spinWinSize->setMaximum(65);
        spinWinSize->setMinimum(3);
        spinWinSize->setSingleStep(2);
        vspins->addWidget(spinWinSize, 0, Qt::AlignVCenter);
        spinLevel = new QDoubleSpinBox(dialog);
        spinLevel->setMaximum(100000);
        spinLevel->setMinimum(-10000);
        spinLevel->setDecimals(3);
        spinLevel->setSingleStep(1);
        vspins->addWidget(spinLevel, 0, Qt::AlignVCenter);
        h->addLayout(vspins);

        QVBoxLayout *vbuttons = new QVBoxLayout();
        QPushButton *applyButton = new QPushButton(trUtf8("Aplicar"), dialog);
        QPushButton *resetButton = new QPushButton(trUtf8("Restablir"), dialog);

        vbuttons->addWidget(applyButton);
        vbuttons->addWidget(resetButton);
        h->addLayout(vbuttons);

        connect(applyButton, SIGNAL(released()), this, SLOT(setConfig()));
        connect(resetButton, SIGNAL(released()), this, SLOT(resetConfig()));
        resetConfig();
    }
    dialog->show();
}

void QHContrast::setConfig()
{
    thlevel = spinLevel->value();
    winsize = spinWinSize->value();
}

void QHContrast::resetConfig()
{
    spinLevel->setValue(thlevel);
    spinWinSize->setValue(winsize);
}

QHContrastCreator::QHContrastCreator()
{
    type = e_ImproveRawPlane;
}

void QHContrastCreator::init()
{
    ActionCreator *a = new QHContrastCreator();
    ActionManager::sreg("HContrast (alter)", a);
}

ImproveRawPlane * QHContrastCreator::createImproveRawPlane() const
{
    QHContrast *ptr;
    ptr = new QHContrast();
    return ptr;
}

bool QHContrastCreator::isapplicable(const JPEGParameters &p)
{
    return true;
}
