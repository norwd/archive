/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <Actions.h>
#include <ActionType.h>
#include <ActionCreator.h>
#include <ActionManager.h>

#include <FloatPlane.h>
#include <JPEGData.h>
#include <CoefsPlane.h>

#include <Trianta.h>

#include <QDialog>
#include <QSpinBox>
#include <QCheckBox>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLabel>

#include "QTConfigurable.h"
#include "QTrianta.moc"

QTrianta::QTrianta()
{
    GUIconfigurable = true;
    dialog = 0;
}

QTrianta::~QTrianta()
{
    /* This will free all the elements of the dialog */
    if (dialog)
        delete dialog;
}

void QTrianta::startQtConfiguration()
{
    if (!dialog)
    {
        dialog = new QDialog();
        dialog->setWindowTitle(trUtf8("Configurant") + QString(" QTrianta"));
        QHBoxLayout *h = new QHBoxLayout(dialog);

        QVBoxLayout *vlabels = new QVBoxLayout();
        QLabel *l = new QLabel(trUtf8("Variància per baixes freq.:"), dialog);
        l->setAlignment(Qt::AlignRight);
        vlabels->addWidget(l, 0, Qt::AlignVCenter);

        QLabel *l2 = new QLabel(trUtf8("Variància per altes freq.:"), dialog);
        l->setAlignment(Qt::AlignRight);
        vlabels->addWidget(l2, 0, Qt::AlignVCenter);

        QLabel *l3 = new QLabel(trUtf8("Variància per WSMM:"), dialog);
        l->setAlignment(Qt::AlignRight);
        vlabels->addWidget(l3, 0, Qt::AlignVCenter);

        QLabel *lvar = new QLabel(trUtf8("Const. d'atenuació (mu):"), dialog);
        lvar->setAlignment(Qt::AlignRight);
        vlabels->addWidget(lvar, 0, Qt::AlignVCenter);

        QLabel *lvar2 = new QLabel(trUtf8("Llindar:"), dialog);
        lvar2->setAlignment(Qt::AlignRight);
        vlabels->addWidget(lvar2, 0, Qt::AlignVCenter);

        QLabel *lvar3 = new QLabel(trUtf8("Estructures internes:"), dialog);
        lvar3->setAlignment(Qt::AlignRight);
        vlabels->addWidget(lvar3, 0, Qt::AlignVCenter);
        h->addLayout(vlabels);

        QVBoxLayout *vspins = new QVBoxLayout();
        spinRadiusLF = new QDoubleSpinBox(dialog);
        spinRadiusLF->setMaximum(10000);
        spinRadiusLF->setMinimum(0);
        spinRadiusLF->setSingleStep(2);
        vspins->addWidget(spinRadiusLF, 0, Qt::AlignVCenter);
        spinRadiusHF = new QDoubleSpinBox(dialog);
        spinRadiusHF->setMaximum(10000);
        spinRadiusHF->setMinimum(0);
        spinRadiusHF->setSingleStep(2);
        vspins->addWidget(spinRadiusHF, 0, Qt::AlignVCenter);
        spinRadiusWSMM = new QDoubleSpinBox(dialog);
        spinRadiusWSMM->setMaximum(10000);
        spinRadiusWSMM->setMinimum(0);
        spinRadiusWSMM->setSingleStep(2);
        vspins->addWidget(spinRadiusWSMM, 0, Qt::AlignVCenter);
        spinAttenMu = new QDoubleSpinBox(dialog);
        spinAttenMu->setMaximum(100000);
        spinAttenMu->setMinimum(-100000);
        spinAttenMu->setDecimals(2);
        spinAttenMu->setSingleStep(1);
        vspins->addWidget(spinAttenMu, 0, Qt::AlignVCenter);
        spinThreshold = new QDoubleSpinBox(dialog);
        spinThreshold->setMaximum(100000);
        spinThreshold->setMinimum(0);
        spinThreshold->setDecimals(2);
        spinThreshold->setSingleStep(1);
        vspins->addWidget(spinThreshold, 0, Qt::AlignVCenter);
        checkGiveThreshold = new QCheckBox(trUtf8("Donar només la segmentació"),
                dialog);
        vspins->addWidget(checkGiveThreshold, 0, Qt::AlignVCenter);
        h->addLayout(vspins);

        QVBoxLayout *vbuttons = new QVBoxLayout();
        QPushButton *applyButton = new QPushButton(trUtf8("Aplicar"), dialog);
        QPushButton *resetButton = new QPushButton(trUtf8("Restablir"), dialog);

        vbuttons->addWidget(applyButton);
        vbuttons->addWidget(resetButton);
        h->addLayout(vbuttons);

        connect(applyButton, SIGNAL(released()), this, SLOT(setConfig()));
        connect(resetButton, SIGNAL(released()), this, SLOT(resetConfig()));
        resetConfig();
    }
    dialog->show();
}

void QTrianta::setConfig()
{
    lf_sigma_kernel = spinRadiusLF->value();
    hf_sigma_kernel = spinRadiusHF->value();
    WSMM_tau = spinRadiusWSMM->value();
    att_constant_mu = spinAttenMu->value();
    threshold = spinThreshold->value();
    give_thresholding = checkGiveThreshold->isChecked();
}

void QTrianta::resetConfig()
{
    spinRadiusLF->setValue(lf_sigma_kernel);
    spinRadiusHF->setValue(hf_sigma_kernel);
    spinRadiusWSMM->setValue(WSMM_tau);
    spinAttenMu->setValue(att_constant_mu);
    spinThreshold->setValue(threshold);
    checkGiveThreshold->setChecked(give_thresholding);
}

QTriantaCreator::QTriantaCreator()
{
    type = e_ImproveRawPlane;
}

void QTriantaCreator::init()
{
    ActionCreator *a = new QTriantaCreator();
    ActionManager::sreg("Trianta (alter)", a);
}

ImproveRawPlane * QTriantaCreator::createImproveRawPlane() const
{
    QTrianta *ptr;
    ptr = new QTrianta();
    return ptr;
}

bool QTriantaCreator::isapplicable(const JPEGParameters &p)
{
    return true;
}
