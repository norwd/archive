/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QObject>

class QDialog;
class QSpinBox;
class QDoubleSpinBox;

class QRobertson : public QObject, public Robertson, public QTConfigurable
{
    Q_OBJECT

    QDialog *dialog;
    QSpinBox *spinSteps;
    QDoubleSpinBox *spinStepSize;
    QDoubleSpinBox *spinT_Huber;
    QDoubleSpinBox *spinLambda;

public slots:
    void setConfig();
    void resetConfig();

public:
    QRobertson();
    virtual ~QRobertson();
    void startQtConfiguration();
};

class QRobertsonCreator : public ActionCreator
{
    QRobertsonCreator();

public:
    static void init();

    ImproveRawPlane * createImproveRawPlane() const;
	bool isapplicable(const JPEGParameters &p);
};
