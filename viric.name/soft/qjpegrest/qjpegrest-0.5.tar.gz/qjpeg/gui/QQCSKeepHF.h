/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QObject>

class QDialog;
class QSpinBox;
class QDoubleSpinBox;

class QQCSKeepHF : public QObject, public QCSKeepHF, public QTConfigurable
{
    Q_OBJECT

    QDialog *dialog;
    QSpinBox *spinCoefs;
    QDoubleSpinBox *spinLevel;

public slots:
    void setConfig();
    void resetConfig();

public:
    QQCSKeepHF();
    virtual ~QQCSKeepHF();
    void startQtConfiguration();
};

class QQCSKeepHFCreator : public ActionCreator
{
    QQCSKeepHFCreator();

public:
    static void init();

    ImproveRawPlane * createImproveRawPlane() const;
	bool isapplicable(const JPEGParameters &p);
};
