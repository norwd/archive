/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QTreeWidget>
#include <QDialog>

class CoefsImage;
class QTreeActions;
class SceneActionsView;
class SceneBox;
class QProgressBar;

class BoxesChainStorage;

class QChain : public QDialog, public Chain
{
    Q_OBJECT


    QTreeActions *treeActions;
    QGraphicsScene *scene;
    SceneActionsView *graphicsView;

    SceneBox *imagebox;
    BoxesChainStorage *boxes;

#if 0
    SceneBox **idctboxes; /* as pointers as planes */
    QList<SceneBox *> *improveboxes; /* as pointers as planes */
    QList<SceneBox *> colormapboxes; /* 1 plane, many actions */
    SceneBox *scalerbox;
#endif

    void createSceneElements();
    void deleteSceneElements();
    void placeBoxes();
    void fillTree();
    void create();

private slots:
    void applyChain();

public:
    QChain(QWidget *parent = 0);
    QChain(CoefsImage *ini, QWidget *parent = 0);
    QGraphicsItem * newBox(qreal x, qreal y, QString title);

    QProgressBar *progressbar;

    void updateBox(SceneBox *box, const QString &text);

    void addBox(SceneBox *box, const QString &text);
    void removeBox(SceneBox *box);
    void setInitial(CoefsImage *init);

    ~QChain();
};
