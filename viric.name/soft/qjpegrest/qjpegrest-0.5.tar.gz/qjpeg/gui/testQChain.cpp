/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QtGui>
#include <JPEGData.h>
#include <JPEGFile.h>
#include <CoefsImage.h>
#include <Chain.h>

#include "QChain.h"
#include "initActions.h"


int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    /* Set that all strings for trUtf8() are in UTF-8 */
    QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF-8"));

    initActionManager();

    JPEGFile a("a.jpg");
    CoefsImage *c;
    c = a.getCoefs();

    QChain chain(c);

    chain.show();

    int ret = app.exec();

    return ret;
}
