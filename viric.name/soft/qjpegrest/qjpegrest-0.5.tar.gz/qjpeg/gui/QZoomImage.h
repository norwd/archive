/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QWidget>

class QZoomImage : public QWidget
{
    Q_OBJECT

        Q_PROPERTY(int zoomFactor READ getZoomFactor WRITE setZoomFactor);

    struct Border
    {
        int left;
        int right;
        int top;
        int bottom;
    };

    Border btarget, bsource;

    bool hasImage;
    int expand;
    QZoomImageSettings s;
    QImage *image;
    int lastmousex, lastmousey;
    /*! Clarifies if the last click was for mouse movement */
    bool ismoving;

public:
    QZoomImage(QWidget *parent = 0);
    ~QZoomImage();
    int getZoomFactor() const;
    void setViewSettings(const int zoom, const int offsetx, const int offsety);
    QZoomImageSettings getViewSettings() const;
    void forgetImage();
    void setImage(QImage *newimage);
    QSize sizeHint() const;
    QSize getImageSize() const;
    QImage *getQImage() const;

public slots:
    void setViewSettings(QZoomImageSettings x);

signals:
    void viewSettingsChanged(QZoomImageSettings set);
    void rightClick(QMouseEvent *event);

protected:
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void paintEvent(QPaintEvent *event);
    void setZoomFactor(const int z);
private:
    bool mouseOverImage(QMouseEvent *event);
    QRect pixelRect(int col, int row);
    void calcBorders();
    void showBorders();
};
