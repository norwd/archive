/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <Actions.h>
#include <ActionType.h>
#include <ActionCreator.h>
#include <ActionManager.h>

#include <FloatPlane.h>
#include <JPEGData.h>
#include <CoefsPlane.h>

#include <SavePlane.h>

#include <QMessageBox>
#include <QFileDialog>

#include "QTConfigurable.h"
#include "QSavePlane.h"

QSavePlane::QSavePlane()
{
    GUIconfigurable = true;
}

QSavePlane::~QSavePlane()
{
}

void QSavePlane::startQtConfiguration()
{
    *filename = QFileDialog::getSaveFileName(0,
            QObject::trUtf8("Guardar pla"), "", QObject::trUtf8("Pla 8 bits (*.pgm)"));
}

QSavePlaneCreator::QSavePlaneCreator()
{
    type = e_ImproveRawPlane;
}

void QSavePlaneCreator::init()
{
    ActionCreator *a = new QSavePlaneCreator();
    ActionManager::sreg("SavePlane", a);
}

ImproveRawPlane * QSavePlaneCreator::createImproveRawPlane() const
{
    QSavePlane *ptr;
    ptr = new QSavePlane();
    return ptr;
}

bool QSavePlaneCreator::isapplicable(const JPEGParameters &p)
{
    return true;
}
