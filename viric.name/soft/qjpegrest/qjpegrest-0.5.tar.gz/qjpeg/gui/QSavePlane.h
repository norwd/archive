/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QObject>

class QSavePlane : public SavePlane, public QTConfigurable
{
public:
    QSavePlane();
    virtual ~QSavePlane();
    void startQtConfiguration();
};

class QSavePlaneCreator : public ActionCreator
{
    QSavePlaneCreator();

public:
    static void init();

    ImproveRawPlane * createImproveRawPlane() const;
	bool isapplicable(const JPEGParameters &p);
};
