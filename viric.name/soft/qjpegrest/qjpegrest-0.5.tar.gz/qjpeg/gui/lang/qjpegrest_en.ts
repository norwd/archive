<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="en">
<context>
    <name>ImageContextMenu</name>
    <message>
        <location filename="../ImageContextMenu.cpp" line="61"/>
        <source>Mesurar</source>
        <translation>Measure</translation>
    </message>
    <message>
        <location filename="../ImageContextMenu.cpp" line="67"/>
        <source>Comparar</source>
        <translation>Compare</translation>
    </message>
    <message>
        <location filename="../ImageContextMenu.cpp" line="73"/>
        <source>Establir origen JPEG</source>
        <translation>Set JPEG source</translation>
    </message>
    <message>
        <location filename="../ImageContextMenu.cpp" line="78"/>
        <source>Tancar</source>
        <translation>Close</translation>
    </message>
    <message>
        <location filename="../ImageContextMenu.cpp" line="93"/>
        <source>amb </source>
        <translation>with </translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../MainWindow.cpp" line="59"/>
        <source>QJpegRest</source>
        <translation>QJpegRest</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="103"/>
        <source>Fitxer carregat</source>
        <translation>File loaded</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../MainWindow.cpp" line="113"/>
        <source>La imatge té una mida diferent</source>
        <translation>The image has a different size</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="118"/>
        <source>No s&apos;ha pogut obrir la imatge</source>
        <translation>The image could not be loaded</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="136"/>
        <source>Fitxer guardat</source>
        <translation>File saved</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="138"/>
        <source>No s&apos;ha pogut guardar el fitxer</source>
        <translation>The file could not be saved</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="199"/>
        <source>Obrir una &amp;imatge...</source>
        <translation>Open &amp;image...</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="200"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="201"/>
        <source>Obrir una imatge guardada</source>
        <translation>Open a saved image</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="204"/>
        <source>Guardar la imatge com...</source>
        <translation>Save the image as...</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="205"/>
        <source>Guardar la imatge amb un nou nom</source>
        <translation>Save the image with a new name</translation>
    </message>
    <message>
        <location filename="gui/MainWindow.cpp" line="208"/>
        <source>E&amp;xit</source>
        <translation type="obsolete">E&amp;xit</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="209"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../MainWindow.cpp" line="210"/>
        <source>Sortir de l&apos;aplicació</source>
        <translation>Exit the application</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="213"/>
        <source>&amp;Tancar</source>
        <translation>&amp;Close</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="214"/>
        <source>Ctrl+F4</source>
        <translation>Ctrl+F4</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="215"/>
        <source>Tancar la finestra activa</source>
        <translation>Close the active window</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="219"/>
        <source>T&amp;ancar-ho tot</source>
        <translation>Close &amp;all</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="220"/>
        <source>Tancar totes les finestres</source>
        <translation>Close all the windows</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../MainWindow.cpp" line="224"/>
        <source>&amp;Quadrícula</source>
        <translation>&amp;Grid</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../MainWindow.cpp" line="225"/>
        <source>Posar les finestres en quadrícula</source>
        <translation>Arrange the windows in a grid</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="228"/>
        <source>&amp;Cascada</source>
        <translation>&amp;Cascade</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="229"/>
        <source>Posar les finestres en cascada</source>
        <translation>Arrange the windows in cascade</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../MainWindow.cpp" line="232"/>
        <source>Recol·locar les &amp;icones</source>
        <translation>Rearrange &amp;icons</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../MainWindow.cpp" line="233"/>
        <source>Recol·locar les icones</source>
        <translation>Rearrange icons</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="236"/>
        <source>Veure la &amp;Cadena</source>
        <translation>Show up the &amp;Chain</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="237"/>
        <source>Veure la Cadena</source>
        <translation>Show up the Chain</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="248"/>
        <source>&amp;Fitxer</source>
        <translation>&amp;File</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="254"/>
        <source>&amp;Finestra</source>
        <translation>&amp;Window</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="257"/>
        <source>&amp;Veure</source>
        <translation>&amp;View</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="263"/>
        <source>Preparat</source>
        <translation>Ready</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="371"/>
        <source>Cadena aplicada</source>
        <translation>Chain applied</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="208"/>
        <source>&amp;Sortir</source>
        <translation>E&amp;xit</translation>
    </message>
</context>
<context>
    <name>MdiChildImage</name>
    <message>
        <location filename="../MdiChildImage.cpp" line="52"/>
        <source>Sense Nom %1</source>
        <translation>NoName %1</translation>
    </message>
</context>
<context>
    <name>MeasureThread</name>
    <message>
        <location filename="../MeasureThread.cpp" line="99"/>
        <source>Imatge: </source>
        <translation>Image: </translation>
    </message>
    <message>
        <location filename="../MeasureThread.cpp" line="106"/>
        <source>1a imatge : </source>
        <translation>1st image: </translation>
    </message>
    <message>
        <location filename="../MeasureThread.cpp" line="109"/>
        <source>2a imatge : </source>
        <translation>2nd image: </translation>
    </message>
</context>
<context>
    <name>QChain</name>
    <message>
        <location filename="../QChain.cpp" line="65"/>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../QChain.cpp" line="177"/>
        <source>Mètodes</source>
        <translation>Methods</translation>
    </message>
    <message>
        <location filename="../QChain-image.cpp" line="35"/>
        <source>No es pot aplicar la cadena</source>
        <translation>The Chain could not be applied</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../QChain-image.cpp" line="37"/>
        <source>No es pot aplicar la cadena perquè hi ha baules sense algoritme assignat.</source>
        <translation>The Chain could not be applied because there are links without algorithm assigned.</translation>
    </message>
</context>
<context>
    <name>QFroment</name>
    <message>
        <location filename="../QFroment.cpp" line="58"/>
        <source>Configurant</source>
        <translation>Configuring</translation>
    </message>
    <message>
        <location filename="../QFroment.cpp" line="60"/>
        <source>Pesos</source>
        <translation>Weights</translation>
    </message>
    <message>
        <location filename="../QFroment.cpp" line="70"/>
        <source>Plans</source>
        <translation>Plain</translation>
    </message>
    <message>
        <location filename="../QFroment.cpp" line="71"/>
        <source>De Froment</source>
        <translation>Froment&apos;s</translation>
    </message>
    <message>
        <location filename="../QFroment.cpp" line="93"/>
        <source>Passos</source>
        <translation>Steps</translation>
    </message>
    <message>
        <location filename="../QFroment.cpp" line="94"/>
        <source>Mida del pas</source>
        <translation>Step size</translation>
    </message>
    <message>
        <location filename="../QFroment.cpp" line="108"/>
        <source>Pas constant</source>
        <translation>Constant step</translation>
    </message>
    <message>
        <location filename="../QFroment.cpp" line="117"/>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <location filename="../QFroment.cpp" line="118"/>
        <source>Restablir</source>
        <translation>Reset</translation>
    </message>
</context>
<context>
    <name>QHContrast</name>
    <message>
        <location filename="../QHContrast.cpp" line="46"/>
        <source>Configurant</source>
        <translation>Configuring</translation>
    </message>
    <message>
        <location filename="../QHContrast.cpp" line="50"/>
        <source>Mida de finestra XxX:</source>
        <translation>Window size XxX:</translation>
    </message>
    <message>
        <location filename="../QHContrast.cpp" line="54"/>
        <source>Nivell:</source>
        <translation>Level:</translation>
    </message>
    <message>
        <location filename="../QHContrast.cpp" line="74"/>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <location filename="../QHContrast.cpp" line="75"/>
        <source>Restablir</source>
        <translation>Reset</translation>
    </message>
</context>
<context>
    <name>QHP</name>
    <message>
        <location filename="../QHP.cpp" line="46"/>
        <source>Configurant</source>
        <translation>Configuring</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../QHP.cpp" line="50"/>
        <source>Desplaçaments:</source>
        <translation>Shifts:</translation>
    </message>
    <message>
        <location filename="../QHP.cpp" line="53"/>
        <source>Percentatge de transformades:</source>
        <translation>Percent of transformations:</translation>
    </message>
    <message>
        <location filename="../QHP.cpp" line="75"/>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <location filename="../QHP.cpp" line="76"/>
        <source>Restablir</source>
        <translation>Reset</translation>
    </message>
</context>
<context>
    <name>QIDCTFExp</name>
    <message>
        <location filename="../QIDCTFExp.cpp" line="46"/>
        <source>Configurant</source>
        <translation>Configuring</translation>
    </message>
    <message>
        <location filename="../QIDCTFExp.cpp" line="50"/>
        <source>Nivell:</source>
        <translation>Level:</translation>
    </message>
    <message>
        <location filename="../QIDCTFExp.cpp" line="65"/>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <location filename="../QIDCTFExp.cpp" line="66"/>
        <source>Restablir</source>
        <translation>Reset</translation>
    </message>
</context>
<context>
    <name>QLumScaler</name>
    <message>
        <location filename="../QLumScaler.cpp" line="46"/>
        <source>Configurant</source>
        <translation>Configuring</translation>
    </message>
    <message>
        <location filename="../QLumScaler.cpp" line="50"/>
        <source>Epsilon horitzontal:</source>
        <translation>Horiziontal epsilon:</translation>
    </message>
    <message>
        <location filename="../QLumScaler.cpp" line="53"/>
        <source>Epsilon vertical:</source>
        <translation>Vertical epsilon:</translation>
    </message>
    <message>
        <location filename="../QLumScaler.cpp" line="74"/>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <location filename="../QLumScaler.cpp" line="75"/>
        <source>Restablir</source>
        <translation>Reset</translation>
    </message>
</context>
<context>
    <name>QNosratinia</name>
    <message>
        <location filename="../QNosratinia.cpp" line="47"/>
        <source>Configurant</source>
        <translation>Configuring</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../QNosratinia.cpp" line="49"/>
        <source>Desplaçaments:</source>
        <translation>Shifts:</translation>
    </message>
    <message>
        <location filename="../QNosratinia.cpp" line="56"/>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <location filename="../QNosratinia.cpp" line="57"/>
        <source>Restablir</source>
        <translation>Reset</translation>
    </message>
</context>
<context>
    <name>QORourke</name>
    <message>
        <location filename="../QORourke.cpp" line="46"/>
        <source>Configurant</source>
        <translation>Configuring</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../QORourke.cpp" line="50"/>
        <source>Desplaçaments:</source>
        <translation>Shifts:</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../QORourke.cpp" line="53"/>
        <source>Mida de desplaçament:</source>
        <translation>Shift size:</translation>
    </message>
    <message>
        <location filename="../QORourke.cpp" line="56"/>
        <source>T de Huber:</source>
        <translation>Huber T:</translation>
    </message>
    <message>
        <location filename="../QORourke.cpp" line="83"/>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <location filename="../QORourke.cpp" line="84"/>
        <source>Restablir</source>
        <translation>Reset</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../QLoadPlane.cpp" line="56"/>
        <source>No es pot obrir el fitxer</source>
        <translation>The file could not be opened</translation>
    </message>
    <message>
        <location filename="../QLoadPlane.cpp" line="49"/>
        <source>No es pot obrir el fitxer: </source>
        <translation>Couldn&apos;t open the file: </translation>
    </message>
    <message>
        <location filename="../QLoadPlane.cpp" line="58"/>
        <source>Format de fitxer incorrecte. Cal un sol pla de 8 bits.</source>
        <translation>Wrong file format. It needs a single 8bit plane.</translation>
    </message>
    <message>
        <location filename="../QSavePlane.cpp" line="36"/>
        <source>Guardar pla</source>
        <translation>Save plane</translation>
    </message>
    <message>
        <location filename="../QSavePlane.cpp" line="36"/>
        <source>Pla 8 bits (*.pgm)</source>
        <translation>8 bits plane (*.pgm)</translation>
    </message>
</context>
<context>
    <name>QQCSKeepHF</name>
    <message>
        <location filename="../QQCSKeepHF.cpp" line="46"/>
        <source>Configurant</source>
        <translation>Configuring</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../QQCSKeepHF.cpp" line="50"/>
        <source>Últims coeficients:</source>
        <translation>Last coefficients:</translation>
    </message>
    <message>
        <location filename="../QQCSKeepHF.cpp" line="53"/>
        <source>Nivell:</source>
        <translation>Level:</translation>
    </message>
    <message>
        <location filename="../QQCSKeepHF.cpp" line="73"/>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <location filename="../QQCSKeepHF.cpp" line="74"/>
        <source>Restablir</source>
        <translation>Reset</translation>
    </message>
</context>
<context>
    <name>QRobertson</name>
    <message>
        <location filename="../QRobertson.cpp" line="46"/>
        <source>Configurant</source>
        <translation>Configuring</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../QRobertson.cpp" line="50"/>
        <source>Desplaçaments:</source>
        <translation>Shifts:</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../QRobertson.cpp" line="53"/>
        <source>Mida de desplaçament:</source>
        <translation>Shift size:</translation>
    </message>
    <message>
        <location filename="../QRobertson.cpp" line="56"/>
        <source>T de Huber:</source>
        <translation>Huber T:</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../QRobertson.cpp" line="59"/>
        <source>Paràmetre Laplacià:</source>
        <translation>Laplacian parameter:</translation>
    </message>
    <message>
        <location filename="../QRobertson.cpp" line="93"/>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <location filename="../QRobertson.cpp" line="94"/>
        <source>Restablir</source>
        <translation>Reset</translation>
    </message>
</context>
<context>
    <name>QTrianta</name>
    <message>
        <location filename="../QTrianta.cpp" line="47"/>
        <source>Configurant</source>
        <translation>Configuring</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../QTrianta.cpp" line="51"/>
        <source>Variància per baixes freq.:</source>
        <translation>Low freq. variance:</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../QTrianta.cpp" line="55"/>
        <source>Variància per altes freq.:</source>
        <translation>High freq. variance:</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../QTrianta.cpp" line="59"/>
        <source>Variància per WSMM:</source>
        <translation>WSMM variance:</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../QTrianta.cpp" line="63"/>
        <source>Const. d&apos;atenuació (mu):</source>
        <translation>Attenuation constant (mu):</translation>
    </message>
    <message>
        <location filename="../QTrianta.cpp" line="67"/>
        <source>Llindar:</source>
        <translation>Threshold:</translation>
    </message>
    <message>
        <location filename="../QTrianta.cpp" line="71"/>
        <source>Estructures internes:</source>
        <translation>Internal structures:</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../QTrianta.cpp" line="104"/>
        <source>Donar només la segmentació</source>
        <translation>Give only the segmentation</translation>
    </message>
    <message>
        <location filename="../QTrianta.cpp" line="110"/>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <location filename="../QTrianta.cpp" line="111"/>
        <source>Restablir</source>
        <translation>Reset</translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>SceneBox</name>
    <message>
        <location filename="../SceneBox.cpp" line="53"/>
        <source>En blanc</source>
        <translation>Void</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../SceneBox.cpp" line="158"/>
        <source>Afegir acció</source>
        <translation>Add action</translation>
    </message>
    <message>
        <location filename="../SceneBox.cpp" line="165"/>
        <source>Configurar</source>
        <translation>Configuring</translation>
    </message>
    <message>
        <location filename="../SceneBox.cpp" line="172"/>
        <source>Eliminar</source>
        <translation>Remove</translation>
    </message>
</context>
</TS>
