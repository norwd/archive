#!/bin/sh

lrelease qjpegrest_en.ts
