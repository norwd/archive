#!/bin/sh

lupdate ../*.cpp ../*.h -ts qjpegrest_en.ts
