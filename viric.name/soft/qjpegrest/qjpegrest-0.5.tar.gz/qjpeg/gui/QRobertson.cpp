/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <Actions.h>
#include <ActionType.h>
#include <ActionCreator.h>
#include <ActionManager.h>

#include <FloatPlane.h>
#include <JPEGData.h>
#include <CoefsPlane.h>

#include <Robertson.h>

#include <QDialog>
#include <QSpinBox>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLabel>

#include "QTConfigurable.h"
#include "QRobertson.moc"

QRobertson::QRobertson()
{
    GUIconfigurable = true;
    dialog = 0;
}

QRobertson::~QRobertson()
{
    /* This will free all the elements of the dialog */
    if (dialog)
        delete dialog;
}

void QRobertson::startQtConfiguration()
{
    if (!dialog)
    {
        dialog = new QDialog();
        dialog->setWindowTitle(trUtf8("Configurant") + QString(" Robertson"));
        QHBoxLayout *h = new QHBoxLayout(dialog);

        QVBoxLayout *vlabels = new QVBoxLayout();
        QLabel *l = new QLabel(trUtf8("Desplaçaments:"), dialog);
        l->setAlignment(Qt::AlignRight);

        QLabel *lvar = new QLabel(trUtf8("Mida de desplaçament:"), dialog);
        lvar->setAlignment(Qt::AlignRight);

        QLabel *lthuber = new QLabel(trUtf8("T de Huber:"), dialog);
        lthuber->setAlignment(Qt::AlignRight);

        QLabel *llambda = new QLabel(trUtf8("Paràmetre Laplacià:"), dialog);
        llambda->setAlignment(Qt::AlignRight);

        vlabels->addWidget(l);
        vlabels->addWidget(lvar);
        vlabels->addWidget(lthuber);
        vlabels->addWidget(llambda);
        h->addLayout(vlabels);

        QVBoxLayout *vspins = new QVBoxLayout();
        spinSteps = new QSpinBox(dialog);
        spinSteps->setMaximum(64);
        spinSteps->setMinimum(0);
        spinSteps->setSingleStep(1);
        vspins->addWidget(spinSteps);
        spinStepSize = new QDoubleSpinBox(dialog);
        spinStepSize->setMaximum(10000);
        spinStepSize->setMinimum(0);
        spinStepSize->setSingleStep(1);
        vspins->addWidget(spinStepSize);
        spinT_Huber = new QDoubleSpinBox(dialog);
        spinT_Huber->setMaximum(1000);
        spinT_Huber->setMinimum(0);
        spinT_Huber->setSingleStep(0.1);
        vspins->addWidget(spinT_Huber);
        spinLambda = new QDoubleSpinBox(dialog);
        spinLambda->setMaximum(10000);
        spinLambda->setMinimum(0);
        spinLambda->setDecimals(5);
        spinLambda->setSingleStep(0.001);
        vspins->addWidget(spinLambda);
        h->addLayout(vspins);

        QVBoxLayout *vbuttons = new QVBoxLayout();
        QPushButton *applyButton = new QPushButton(trUtf8("Aplicar"), dialog);
        QPushButton *resetButton = new QPushButton(trUtf8("Restablir"), dialog);

        vbuttons->addWidget(applyButton);
        vbuttons->addWidget(resetButton);
        vbuttons->addStretch();
        h->addLayout(vbuttons);

        connect(applyButton, SIGNAL(released()), this, SLOT(setConfig()));
        connect(resetButton, SIGNAL(released()), this, SLOT(resetConfig()));
        resetConfig();
    }
    dialog->show();
}

void QRobertson::setConfig()
{
    steps = spinSteps->value();
    step_size = spinStepSize->value();
    T_Huber = spinT_Huber->value();
    lambda = spinLambda->value();
}

void QRobertson::resetConfig()
{
    spinSteps->setValue(steps);
    spinStepSize->setValue(step_size);
    spinT_Huber->setValue(T_Huber);
    spinLambda->setValue(lambda);
}

QRobertsonCreator::QRobertsonCreator()
{
    type = e_ImproveRawPlane;
}

void QRobertsonCreator::init()
{
    ActionCreator *a = new QRobertsonCreator();
    ActionManager::sreg("Robertson", a);
}

ImproveRawPlane * QRobertsonCreator::createImproveRawPlane() const
{
    QRobertson *ptr;
    ptr = new QRobertson();
    return ptr;
}

bool QRobertsonCreator::isapplicable(const JPEGParameters &p)
{
    return true;
}
