/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QPainter>
#include <QImage>
#include <QMouseEvent>
#include "QZoomImageSettings.h"
#include "QZoomImage.moc"

QZoomImage::QZoomImage(QWidget *parent) : QWidget(parent)
{
    setZoomFactor(0);
    s.offsetx = 0;
    s.offsety = 0;
    lastmousex = -1;
    lastmousey = -1;
    hasImage = false;
    setVisible(false);
    ismoving = false;
}

QZoomImage::~QZoomImage()
{
    if (hasImage)
        delete image;
}


void QZoomImage::setZoomFactor(const int z)
{
    if (z >= 0)
    {
        expand = 1 << z;
        s.zoom = z;
    }
}

void QZoomImage::setViewSettings(QZoomImageSettings ns)
{
    s = ns;
    setZoomFactor(ns.zoom);
    calcBorders();
    update();
}

void QZoomImage::setViewSettings(const int _zoom, const int _offsetx, const int _offsety)
{
    if (_zoom != s.zoom || _offsetx != s.offsetx || _offsety != s.offsety)
    {
        setZoomFactor(_zoom);
        s.offsetx = _offsetx;
        s.offsety = _offsety;
        calcBorders();
        emit viewSettingsChanged(s);
        update();
    }
}

int QZoomImage::getZoomFactor() const
{
    return s.zoom;
}

bool QZoomImage::mouseOverImage(QMouseEvent *event)
{
    if (event->x() >= btarget.left && event->x() <= btarget.right
            && event->y() >= btarget.top && event->y() <= btarget.bottom)
        return true;
    else
        return false;
}

QSize QZoomImage::sizeHint() const
{
    QSize size;

    if (hasImage)
    {
        size.setWidth(image->width());
        size.setHeight(image->height());
    } else
    {
        size.setWidth(0);
        size.setHeight(0);
    }

    return size;
}

/* Should not be called if expand <= 1 */
QRect QZoomImage::pixelRect(int col, int row)
{
    return QRect(col*expand, row*expand, expand, expand);
}

void QZoomImage::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);

    if (!hasImage)
        return;

    calcBorders();
    int twidth = btarget.right-btarget.left;
    int theight = btarget.bottom-btarget.top;
    QRect target(btarget.left,btarget.top,
            twidth,
            theight);
    QRect source(bsource.left,bsource.top,
            bsource.right-bsource.left,
            bsource.bottom-bsource.top);
    painter.drawImage(target, *image, source);
}

void QZoomImage::mousePressEvent(QMouseEvent *event)
{
    if (!mouseOverImage(event))
    {
        ismoving = false;
        return;
    }

    ismoving = true;

    unsigned int mouseonimagex = s.offsetx + event->x()/expand;
    unsigned int mouseonimagey = s.offsety + event->y()/expand;

    if ((event->modifiers() & Qt::ControlModifier)
            && event->button() == Qt::LeftButton)
    {
        setZoomFactor(s.zoom+1);
        s.offsetx = mouseonimagex - width()/expand/2;
        s.offsety = mouseonimagey - height()/expand/2;
        emit viewSettingsChanged(s);
    } else if ((event->modifiers() & Qt::ControlModifier)
            && event->button() == Qt::RightButton && s.zoom > 0)
    {
        setZoomFactor(s.zoom-1);
        s.offsetx = mouseonimagex - width()/expand/2;
        s.offsety = mouseonimagey - height()/expand/2;
        emit viewSettingsChanged(s);
    } else if ((event->modifiers() == 0) && event->button() == Qt::RightButton)
    {
        emit rightClick(event);
    }
    calcBorders();
    update();

    lastmousex = event->x();
    lastmousey = event->y();
}

void QZoomImage::mouseMoveEvent(QMouseEvent *event)
{
    if (!ismoving)
        return;

    if (lastmousex >= 0 || lastmousey >= 0) {
        int movementx, movementy;
        movementx = (event->x() - lastmousex);
        movementy = (event->y() - lastmousey);

        s.offsetx -= movementx/expand;
        s.offsety -= movementy/expand;
        emit viewSettingsChanged(s);
        update();
    }

    lastmousex = event->x();
    lastmousey = event->y();
}

void QZoomImage::calcBorders()
{
    /* X - columns - width */
    if (s.offsetx < 0)
    {
        bsource.left = 0;
        btarget.left = -s.offsetx*expand;
    } else
    {
        bsource.left = s.offsetx;
        btarget.left = 0;
    };
    if ((image->width() - s.offsetx)*expand < width())
    {
        bsource.right = image->width();
        btarget.right = (image->width() - s.offsetx)*expand;
    } else
    {
        bsource.right = s.offsetx + width()/expand;
        btarget.right = width();
    }

    /* Y - rows - height */
    if (s.offsety < 0)
    {
        bsource.top = 0;
        btarget.top = -s.offsety*expand;
    } else
    {
        bsource.top = s.offsety;
        btarget.top = 0;
    }
    if ((image->height() - s.offsety)*expand < height())
    {
        bsource.bottom = image->height();
        btarget.bottom = (image->height() - s.offsety)*expand;
    } else
    {
        bsource.bottom = s.offsety + height()/expand;
        btarget.bottom = height();
    }
    /*
    qDebug("s.ox: %i s.oy: %i", s.offsetx, s.offsety);
    showBorders();
    */
}

void QZoomImage::showBorders()
{
    qDebug("BSource: %i %i %i %i", bsource.left, bsource.top, bsource.right,
            bsource.bottom);
    qDebug("BTarget: %i %i %i %i", btarget.left, btarget.top, btarget.right,
            btarget.bottom);
}

void QZoomImage::setImage(QImage *newimage)
{
    setZoomFactor(0);
    s.offsetx = 0;
    s.offsety = 0;
    image = newimage;
    hasImage = true;
    updateGeometry();
    update();
}

QSize QZoomImage::getImageSize() const
{
    QSize size;

    if (hasImage)
    {
        size.setWidth(image->width());
        size.setHeight(image->height());
    } else
    {
        /* !!! exception? */
        size.setWidth(0);
        size.setHeight(0);
    }

    return size;
}

QZoomImageSettings QZoomImage::getViewSettings() const
{
    return s;
}

QImage * QZoomImage::getQImage() const
{
    return image;
}
