/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QObject>
#include <QString>
#include <QGraphicsRectItem>
/* Requires <ActionType.h> */

class QGraphicsSimpleTextItem;
class QGraphicsSceneDragDropEvent;
class QChain;
class ActionBase;

class SceneBox : public QObject, public QGraphicsRectItem
{
    Q_OBJECT

    QString name;
    enum ActionType type;
    QGraphicsSimpleTextItem * graphicstext;

    QChain *mychain;

    ActionBase *action;

    void contextMenuEvent(QGraphicsSceneContextMenuEvent * event);
    void mousePressEvent(QGraphicsSceneMouseEvent * event);

private slots:
    void insertAfter();
    void removeMe();
    void configureAction();

public:
    SceneBox(QString _name, enum ActionType _type,
        qreal x, qreal y,
        QGraphicsItem *parent, QGraphicsScene *scene);
    ~SceneBox();
    void dragEnterEvent(QGraphicsSceneDragDropEvent *event);
    void dropEvent(QGraphicsSceneDragDropEvent *event);
    void setChain(QChain *newchain);
    void setAction(ActionBase *newaction);

    void updateText( const QString &_name );

    bool isVoid() const;
    enum ActionType getType() const;
};
