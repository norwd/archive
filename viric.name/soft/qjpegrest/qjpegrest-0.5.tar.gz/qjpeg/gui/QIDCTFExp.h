/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QObject>

class QDialog;
class QSpinBox;
class QDoubleSpinBox;

class QIDCTFExp : public QObject, public IDCTFExp, public QTConfigurable
{
    Q_OBJECT

    QDialog *dialog;
    QDoubleSpinBox *spinMu;

public slots:
    void setConfig();
    void resetConfig();

public:
    QIDCTFExp();
    virtual ~QIDCTFExp();
    void startQtConfiguration();
};

class QIDCTFExpCreator : public ActionCreator
{
    QIDCTFExpCreator();

public:
    static void init();

    IDCTPlane * createIDCTPlane() const;
	bool isapplicable(const JPEGParameters &p);
};
