/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QGraphicsSceneDragDropEvent>
#include <QGraphicsSimpleTextItem>
#include <QMimeData>
#include <QString>
#include <QMenu>
#include <QMouseEvent>

#include <Chain.h>
#include "QChain.h"

#include <ActionType.h>
#include <Actions.h>
#include "QTConfigurable.h"
#include "SceneBox.moc"

#include <QDebug>


SceneBox::SceneBox(QString _name, enum ActionType _type,
        qreal x, qreal y,
        QGraphicsItem *parent, QGraphicsScene *scene)
    : QGraphicsRectItem(x,y,50,50,parent,scene)
{
    type = _type;

    graphicstext = new QGraphicsSimpleTextItem(_name, this, scene);
    graphicstext->setPos(x,y); /* For sure. It should be relative to
                                  the rect's 0,0 */

    /* This updates 'name' */
    updateText(_name);

    if (type != e_Undefined)
    {
        setAcceptDrops(true);
    }

    mychain = 0;
    action = 0;
}

void SceneBox::updateText( const QString &_name )
{
    name = _name;

    if (name.isEmpty())
        graphicstext->setText(trUtf8("En blanc"));
    else
        graphicstext->setText(name);

    /* Set a proper size for the rectangle */
    QRectF rtext = graphicstext->boundingRect();
    QRectF rrect = this->rect();
    rrect.setWidth(rtext.width());
    rrect.setHeight(rtext.height());
    this->setRect(rrect);
}

bool SceneBox::isVoid() const
{
    if (name.isEmpty())
        return true;
    else
        return false;
}

void SceneBox::dragEnterEvent(QGraphicsSceneDragDropEvent *event)
{
    if (event->mimeData()->hasFormat("text/plain"))
    {
        QString text = event->mimeData()->text();
        enum ActionType comingtype;
        QStringList l = text.split('\n');
        if (l.size() != 2)
        {
            event->ignore();
            return;
        }

        comingtype = string2ActionType(l.at(0));
        if (comingtype != type && comingtype != e_Undefined)
        {
            event->ignore();
            return;
        }
        event->acceptProposedAction();
    }
}

void SceneBox::dropEvent(QGraphicsSceneDragDropEvent *event)
{
    if (event->mimeData()->hasFormat("text/plain"))
    {
        QString text = event->mimeData()->text();
        enum ActionType comingtype;
        QStringList l = text.split('\n');
        /* It should be two lines of text. Ignore, if the drop isn't like this*/
        if (l.size() != 2)
        {
            event->ignore();
            return;
        }

        /* The first line should be the Action Type */
        comingtype = string2ActionType(l.at(0));
        if (comingtype != type && comingtype != e_Undefined)
        {
            event->ignore();
            return;
        }

        event->acceptProposedAction();
        if(mychain)
        {
            /* Update with the named action */
            mychain->updateBox(this, l.at(1));
        }
    }
}

void SceneBox::setChain(QChain *newchain)
{
    mychain = newchain;
}

void SceneBox::setAction(ActionBase *newaction)
{
    if (action)
        delete action;
    action = newaction;
}

void SceneBox::contextMenuEvent(QGraphicsSceneContextMenuEvent * event)
{
    QMenu mymenu;

    QAction *insertafter = mymenu.addAction(trUtf8("Afegir acció"));
    connect(insertafter, SIGNAL(triggered()), this,
            SLOT(insertAfter()));

    mymenu.exec(event->screenPos());
}

void SceneBox::mousePressEvent(QGraphicsSceneMouseEvent * event)
{

    if (event->button() == Qt::RightButton && type != e_Undefined)
    {
        QMenu mymenu;

        /* In any case I add "add action" */
        QAction *insertafter = mymenu.addAction(trUtf8("Afegir acció"));
        connect(insertafter, SIGNAL(triggered()), this,
                SLOT(insertAfter()));

        if (action && action->isGUIconfigurable())
        {
            QAction *configure = mymenu.addAction(trUtf8("Configurar") +
                    QString(" ") + name);
            connect(configure, SIGNAL(triggered()), this,
                    SLOT(configureAction()));
        }

        if (type == e_ImproveRawPlane || type == e_ColorMap)
        {
            QAction *insertafter = mymenu.addAction(trUtf8("Eliminar"));
            connect(insertafter, SIGNAL(triggered()), this,
                    SLOT(removeMe()));
        }
        mymenu.exec(event->screenPos());
    }
}

void SceneBox::insertAfter()
{
    if(mychain)
        mychain->addBox(this,"");
}

void SceneBox::configureAction()
{
    if (action && action->isGUIconfigurable())
    {
        QTConfigurable *qaction = dynamic_cast<QTConfigurable *> (action);
        qaction->startQtConfiguration();
    }
}

void SceneBox::removeMe()
{
    if(mychain)
        mychain->removeBox(this);
}

enum ActionType SceneBox::getType() const
{
    return type;
}

SceneBox::~SceneBox()
{
    if (action)
        delete action;
}

