/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QTreeWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QPushButton>
#include <QProgressBar>

#include <QGraphicsRectItem>
#include <QGraphicsSimpleTextItem>

#include <map>
#include <Chain.h>
#include <ChainStorage.h>

#include <JPEGData.h>
#include <CoefsImage.h>
#include <ActionType.h>
#include <ActionManager.h>
#include <ActionCreator.h>
#include <Actions.h>

#include "SceneBox.h"
#include "QTreeActionItem.h"
#include "QTreeActions.h"
#include "SceneActionsView.h"
#include "QChain.moc"

#include <QDebug>

class BoxesChainStorage :
    public ChainStorage<SceneBox, SceneBox, SceneBox, SceneBox> { };

QChain::QChain(QWidget *parent) : QDialog(parent), Chain()
{
    create();
}

QChain::QChain(CoefsImage *ini, QWidget *parent) : QDialog(parent), Chain(ini)
{
    create();
    createSceneElements();
    placeBoxes();
}

void QChain::create()
{
    /* Build the scene */
    QHBoxLayout *l = new QHBoxLayout(this);
    QVBoxLayout *v = new QVBoxLayout();
    QHBoxLayout *buttons = new QHBoxLayout();
    scene = new QGraphicsScene(0,0, 400, 50, this);
    graphicsView = new SceneActionsView(scene, this);

    /* Build the tree with Actions*/
    treeActions = new QTreeActions(this);
    fillTree();

    QPushButton *applyButton = new QPushButton(trUtf8("Aplicar"));
    connect(applyButton, SIGNAL(released()), this, SLOT(applyChain()));

    /* Build the Progress Bar */
    progressbar = new QProgressBar(this);

    /* Build the dialog */
    l->addWidget(graphicsView);
    l->addLayout(v);
    v->addWidget(treeActions);
    v->addWidget(progressbar);
    v->addLayout(buttons);
    buttons->addWidget(applyButton);
    graphicsView->show();
    treeActions->show();

    /* The chain storages */
    boxes = new BoxesChainStorage();
}

void QChain::deleteSceneElements()
{
    delete imagebox;

    boxes->free();
    components = 0;
}


void QChain::createSceneElements()
{
    /* Build the internal data structures for the scene*/
    boxes->setPlanes(components);

    imagebox = new SceneBox("Imatge", e_Undefined, 0, 0, 0, scene);
    imagebox->setChain(this);

    for(int i=0; i < components; ++i)
    {
        SceneBox *box;
        /* The IDCTPlanes */
        boxes->idcts[i] = new SceneBox("", e_IDCTPlane,
                0, 0, 0, scene);
        boxes->idcts[i]->setChain(this);
    }

    boxes->scaler = new SceneBox("", e_Scaler, 0, 0, 0, scene);
    boxes->scaler->setChain(this);
}

void QChain::placeBoxes()
{
    qreal offsetx, offsety;
    qreal finaloffsetx;
    QString label;

    offsetx = 0.;
    offsety = 0.;
    imagebox->setPos(QPointF(offsetx, offsety));

    /* The 'x' where to put the IDCTPlanes */
    offsetx = imagebox->boundingRect().width()+2.;
    /* The vertical separation between IDCTPlanes */
    offsety = imagebox->boundingRect().height()+2.;

    /* Draw the IDCTPlanes */
    finaloffsetx = 0.;
    for(int i=0; i < components; ++i)
    {
        boxes->idcts[i]->setPos(QPointF(offsetx, offsety*i));
        if (boxes->idcts[i]->boundingRect().width() > finaloffsetx)
            finaloffsetx = boxes->idcts[i]->boundingRect().width();
    }

    offsetx += finaloffsetx+2;

    /* Draw the ImproveRawPlanes: */
    finaloffsetx = 0.;
    for(int i=0; i < components; ++i)
    {
        float newfinaloffsetx = 0.;
        SceneBox *box; 
        foreach (SceneBox *element, boxes->improverawplanes[i])
        {
            element->setPos(QPointF(offsetx + newfinaloffsetx,
                        offsety*i));
            newfinaloffsetx += element->boundingRect().width() + 2;
        }
        if (newfinaloffsetx >= finaloffsetx)
            finaloffsetx = newfinaloffsetx;
    }

    /* Draw the Scaler: */
    offsetx += finaloffsetx;
    finaloffsetx = 0.;
    boxes->scaler->setPos(QPointF(offsetx, offsety));
    finaloffsetx += boxes->scaler->boundingRect().width() + 2;

    /* Draw the ColorMaps: */
    offsetx += finaloffsetx;
    finaloffsetx = 0.;
    foreach (SceneBox *element, boxes->colormaps)
    {
        element->setPos(QPointF(offsetx + finaloffsetx, offsety));
        finaloffsetx += element->boundingRect().width() + 2;
    }
}

void QChain::fillTree()
{
    QTreeWidgetItem *method, *type;

    treeActions->setHeaderLabel(trUtf8("Mètodes"));

    /* Actions for IDCTPlane */
    type = new QTreeActionItem(treeActions, ActionGroup);
    type->setText(0, "IDCTPlane");
    foreach (QString str, ActionManager::getListOf(e_IDCTPlane))
    {
        method = new QTreeActionItem(type, Action, e_IDCTPlane);
        method->setText(0, str);
    }
    treeActions->expandItem(type);

    /* Actions for ImproveRawPlane */
    type = new QTreeActionItem(treeActions, ActionGroup);
    type->setText(0, "ImproveRawPlane");
    foreach (QString str, ActionManager::getListOf(e_ImproveRawPlane))
    {
        method = new QTreeActionItem(type, Action, e_ImproveRawPlane);
        method->setText(0, str);
    }
    treeActions->expandItem(type);

    /* Actions for Scaler */
    type = new QTreeActionItem(treeActions, ActionGroup);
    type->setText(0, "Scaler");
    foreach (QString str, ActionManager::getListOf(e_Scaler))
    {
        method = new QTreeActionItem(type, Action, e_Scaler);
        method->setText(0, str);
    }
    treeActions->expandItem(type);

    /* Actions for ColorMap */
    type = new QTreeActionItem(treeActions, ActionGroup);
    type->setText(0, "ColorMap");
    foreach (QString str, ActionManager::getListOf(e_ColorMap))
    {
        method = new QTreeActionItem(type, Action, e_ColorMap);
        method->setText(0, str);
    }
    treeActions->expandItem(type);

    treeActions->addTopLevelItem(type);
}

void QChain::updateBox(SceneBox *box, const QString &text)
{
    /* Update the chain object */
    if (box->getType() == e_IDCTPlane)
    {
        int i;
        /* Creating 'atext' is the only way to assure ztext is a valid
         * pointer */
        QByteArray atext = text.toAscii();
        const char *ztext = atext.data();
        IDCTPlane *newaction = ActionManager::sfind(ztext)->createIDCTPlane();
        /* The next will destroy the old action */
        box->setAction(newaction);
        /* Find the box */
        for(i = 0; i < components; ++i)
        {
            if (box == boxes->idcts[i])
                break;
        }
        assert(i < components);
        /* Set the Chain element */
        storage->idcts[i] = newaction;
    } else if (box->getType() == e_ImproveRawPlane)
    {
        int p, e; 
        QByteArray atext = text.toAscii();
        const char *ztext = atext.data();
        ImproveRawPlane *newaction = ActionManager::sfind(ztext)->createImproveRawPlane();
        /* The next will destroy the old action */
        box->setAction(newaction);
        /* Find the box */
        for(p = 0; p < components; ++p) /* for each plane */
        {
            for(e = 0; e < boxes->improverawplanes[p].size(); ++e) /* for each element in list */
            {
                if (boxes->improverawplanes[p][e] == box)
                    break;
            }
            if (e < boxes->improverawplanes[p].size())
                    break;
        }
        assert(p < components);
        /* Set the Chain element */
        storage->improverawplanes[p][e] = newaction;
    } else if (box->getType() == e_Scaler)
    {
        QByteArray atext = text.toAscii();
        const char *ztext = atext.data();
        Scaler *newaction = ActionManager::sfind(ztext)->createScaler();
        /* The next will destroy the old action */
        box->setAction(newaction);
        storage->scaler = newaction;
    } else if (box->getType() == e_ColorMap)
    {
        int e;
        QByteArray atext = text.toAscii();
        const char *ztext = atext.data();
        ColorMap *newaction = ActionManager::sfind(ztext)->createColorMap();
        /* The next will destroy the old action */
        box->setAction(newaction);
        /* Find the box */
        for(e = 0; e < boxes->colormaps.size(); ++e) /* for each element in list */
        {
            if (boxes->colormaps[e] == box)
                break;
        }
        assert(e < boxes->colormaps.size());
        /* Set the Chain element */
        storage->colormaps[e] = newaction;
    }
    /* TODO: Other boxes */
    /* Update the box text */
    box->updateText(text);
    placeBoxes();
}

void QChain::addBox(SceneBox *box, const QString &text)
{
    if (box->getType() == e_IDCTPlane)
    {
        /* Look for the component clicked */
        int comp;
        for(int i=0; i<components; ++i)
            if (box == boxes->idcts[i])
                comp = i;

        /* New box */
        SceneBox *box = new SceneBox("", e_ImproveRawPlane,
                0, 0, 0, scene);
        box->setChain(this);
        boxes->improverawplanes[comp].insert(
                boxes->improverawplanes[comp].begin(), box);
        storage->improverawplanes[comp].insert(
                storage->improverawplanes[comp].begin(), 0);

    } else if (box->getType() == e_ImproveRawPlane)
    {
        int comp; /* Component */
        int pos; /* Position in the array */

        /* Search the notifying box */
        for(int i=0; i<components; ++i)
        {
            int j = 0;
            foreach (SceneBox *element, boxes->improverawplanes[i])
            {
                if (box == element)
                {
                    /* Element found. Store component and position */
                    comp = i;
                    pos = j;
                }
                ++j;
            }
        }

        SceneBox *box = new SceneBox("", e_ImproveRawPlane,
                0, 0, 0, scene);
        box->setChain(this);
        boxes->improverawplanes[comp].insert(
                boxes->improverawplanes[comp].begin()+pos+1, box);
        storage->improverawplanes[comp].insert(
                storage->improverawplanes[comp].begin()+pos+1, 0);
    } else if (box->getType() == e_Scaler)
    {
        /* New box */
        SceneBox *box = new SceneBox("", e_ColorMap,
                0, 0, 0, scene);
        box->setChain(this);
        boxes->colormaps.insert(
                boxes->colormaps.begin(), box);
        storage->colormaps.insert(storage->colormaps.begin(), 0);
    } else if (box->getType() == e_ColorMap)
    {
        int pos; /* Position in the array */

        /* Search the notifying box */
        int j = 0;
        foreach (SceneBox *element, boxes->colormaps)
        {
            if (box == element)
            {
                /* Element found. Store component and position */
                pos = j;
            }
            ++j;
        }

        SceneBox *box = new SceneBox("", e_ColorMap,
                0, 0, 0, scene);
        box->setChain(this);
        boxes->colormaps.insert(
                boxes->colormaps.begin()+pos+1, box);
        storage->colormaps.insert(storage->colormaps.begin()+pos+1, 0);
    }

    placeBoxes();
}

void QChain::removeBox(SceneBox *box)
{
    if (box->getType() == e_ImproveRawPlane)
    {
        int comp; /* Component */
        int pos; /* Position in the array */

        /* Search the notifying box */
        for(int i=0; i<components; ++i)
        {
            int j = 0;
            foreach (SceneBox *element, boxes->improverawplanes[i])
            {
                if (box == element)
                {
                    /* Element found. Store component and position */
                    comp = i;
                    pos = j;
                }
                ++j;
            }
        }

        delete boxes->improverawplanes[comp].at(pos);
        boxes->improverawplanes[comp].erase(
                boxes->improverawplanes[comp].begin() + pos);
        storage->improverawplanes[comp].erase(
                storage->improverawplanes[comp].begin() + pos);
    } else if (box->getType() == e_ColorMap)
    {
        int pos; /* Position in the array */

        /* Search the notifying box */
        int j = 0;
        foreach (SceneBox *element, boxes->colormaps)
        {
            if (box == element)
            {
                /* Element found. Store component and position */
                pos = j;
            }
            ++j;
        }

        delete boxes->colormaps.at(pos);
        boxes->colormaps.erase(
                boxes->colormaps.begin() + pos);
        storage->colormaps.erase(storage->colormaps.begin() + pos);
    }
    placeBoxes();
}

QChain::~QChain()
{
    deleteSceneElements();
    delete boxes;
}

void QChain::setInitial(CoefsImage *init)
{
    if (components > 0)
    {
        deleteSceneElements();
    }
    Chain::setInitial(init);
    createSceneElements();
    placeBoxes();
}
