/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QObject>

class QDialog;
class QSpinBox;
class QDoubleSpinBox;
class QCheckBox;

class QTrianta : public QObject, public Trianta, public QTConfigurable
{
    Q_OBJECT

    QDialog *dialog;
    QDoubleSpinBox *spinRadiusLF;
    QDoubleSpinBox *spinRadiusHF;
    QDoubleSpinBox *spinRadiusWSMM;
    QDoubleSpinBox *spinAttenMu;
    QDoubleSpinBox *spinThreshold;
    QCheckBox *checkGiveThreshold;

public slots:
    void setConfig();
    void resetConfig();

public:
    QTrianta();
    virtual ~QTrianta();
    void startQtConfiguration();
};

class QTriantaCreator : public ActionCreator
{
    QTriantaCreator();

public:
    static void init();

    ImproveRawPlane * createImproveRawPlane() const;
	bool isapplicable(const JPEGParameters &p);
};
