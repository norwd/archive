/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QObject>

class QDialog;
class QSpinBox;
class QDoubleSpinBox;

class QORourke : public QObject, public ORourke, public QTConfigurable
{
    Q_OBJECT

    QDialog *dialog;
    QSpinBox *spinSteps;
    QDoubleSpinBox *spinStepSize;
    QDoubleSpinBox *spinT_Huber;

public slots:
    void setConfig();
    void resetConfig();

public:
    QORourke();
    virtual ~QORourke();
    void startQtConfiguration();
};

class QORourkeCreator : public ActionCreator
{
    QORourkeCreator();

public:
    static void init();

    ImproveRawPlane * createImproveRawPlane() const;
	bool isapplicable(const JPEGParameters &p);
};
