/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QGraphicsView>

class SceneActionsView : public QGraphicsView
{
    Q_OBJECT

public:
    SceneActionsView(QGraphicsScene * scene, QWidget * parent = 0);
};
