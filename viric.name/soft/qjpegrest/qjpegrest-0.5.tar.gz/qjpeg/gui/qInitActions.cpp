/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <initActions.h>

#include <ActionType.h>
#include <Actions.h>
#include <ActionCreator.h>
#include <ActionManager.h>

#include <FloatPlane.h>
#include <JPEGData.h>
#include <CoefsPlane.h>

#include <Stat.h> /* Required by lumstat */

#include "QTConfigurable.h"

#include <Nosratinia.h>
#include <Froment.h>
#include <HP.h>
#include <ORourke.h>
#include <Robertson.h>
#include <GBIM.h>
#include <PSNR.h>
#include <LumStat.h>
#include <IDCTFloat.h>
#include <IntScaler.h>
#include <FancyScaler.h>
#include <QCS.h>
#include <YCC2RGB.h>
#include <LumScaler.h>
#include <QCSKeepHF.h>
#include <HContrast.h>
#include <LoadPlane.h>
#include <SavePlane.h>
#include <IDCTFExp.h>
#include <Trianta.h>

#include "QNosratinia.h"
#include "QFroment.h"
#include "QHP.h"
#include "QORourke.h"
#include "QRobertson.h"
#include "QLumScaler.h"
#include "QQCSKeepHF.h"
#include "QHContrast.h"
#include "QLoadPlane.h"
#include "QSavePlane.h"
#include "QIDCTFExp.h"
#include "QTrianta.h"
#include "qInitActions.h"

void qInitActions()
{
    new ActionManager();
    GBIMCreator::init();
    PSNRCreator::init();
    LumStatCreator::init();
    IDCTFloatCreator::init();
    IntScalerCreator::init();
    FancyScalerCreator::init();
    QCSCreator::init();
    YCC2RGBCreator::init();

    QNosratiniaCreator::init();
    QFromentCreator::init();
    QHPCreator::init();
    QORourkeCreator::init();
    QRobertsonCreator::init();
    QLumScalerCreator::init();
    QQCSKeepHFCreator::init();
    QHContrastCreator::init();
    QLoadPlaneCreator::init();
    QSavePlaneCreator::init();
    QIDCTFExpCreator::init();
    QTriantaCreator::init();
}
