/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QString>
#include <QImage>

#include <ActionType.h>
#include <ActionManager.h>
#include <ActionCreator.h>
#include <Actions.h>
#include <ARGBImage.h>
#include <GrayImage.h>
#include "MdiChildBase.h"
#include "MdiChildImage.h"
#include <Error.h>
#include <MeasureResult.h>

#include "MeasureThread.moc"

MeasureThread::MeasureThread(const QString _method, const MdiChildImage *img1,
            const MdiChildImage *img2, QObject *parent) : QThread()
{
    method = _method;

    argbimg1 = 0;
    argbimg2 = 0;
    grayimg1 = 0;
    grayimg2 = 0;

    if (img2 == 0)
    {
        /* Measure */
        measure = ActionManager::sfind(
                method.toAscii().data() )->createMeasure();
        QImage * qimg = img1->getQImage();
        if (qimg->format() == QImage::Format_RGB32)
        {
            type = ARGB_Measure;
            argbimg1 = qimage2argb(qimg);
            measure->prepare(argbimg1);
        } else if (qimg->format() == QImage::Format_Indexed8)
        {
            type = Gray_Measure;
            grayimg1 = qimage2gray(qimg);
            /* !!! Not finished */
            measure->prepare(grayimg1);
        }

        compare = 0;
    } else
    {
        type = ARGB_Compare;
        /* Compare */
        compare = ActionManager::sfind(method.toAscii().data())->createCompare();

        QImage * qimg1 = img1->getQImage();
        QImage * qimg2 = img2->getQImage();
        if (qimg1->format() == QImage::Format_RGB32)
        {
            type = ARGB_Compare;
            argbimg1 = qimage2argb(qimg1);
            argbimg2 = qimage2argb(qimg2);
            compare->prepare(argbimg1, argbimg2);
        } else if (qimg1->format() == QImage::Format_Indexed8)
        {
            type = Gray_Compare;
            grayimg1 = qimage2gray(qimg1);
            grayimg2 = qimage2gray(qimg2);
            /* !!! Not finished */
            compare->prepare(grayimg1, grayimg2);
        }

        measure = 0;
    }

    getTitles(img1, img2);
}

void MeasureThread::run()
{
    MeasureResult *mr;
    switch(type)
    {
    case Gray_Measure:
    case ARGB_Measure:
        mr = measure->apply();
        break;
    case Gray_Compare:
    case ARGB_Compare:
        mr = compare->apply();
        break;
    };

    if (title2.isEmpty())
    {
        QString line(trUtf8("Imatge: "));
        line += title1;
        line += "\n";
        mr->text.prepend(line);
    }
    else
    {
        QString line(trUtf8("1a imatge : "));
        line += title1;
        line += "\n";
        line += trUtf8("2a imatge : ");
        line += title2;
        line += "\n";
        mr->text.prepend(line);
    }

    emit newResult(mr, method);
}

void MeasureThread::getTitles(const MdiChildImage *img1,
            const MdiChildImage *img2)
{
    title1 = img1->getTitle();
    if (img2 != 0)
        title2 = img2->getTitle();
    else
        title2 = "";
}

const ARGBImage *MeasureThread::qimage2argb(const QImage * img)
{
    if(img->format() != QImage::Format_RGB32)
        throw new Error::UnsupportedColorspace;
    ARGBImage *argb = new ARGBImage((unsigned int *) img->bits(),
            img->width(), img->height());
    return argb;
}

const GrayImage *MeasureThread::qimage2gray(const QImage * img)
{
    if(img->format() != QImage::Format_Indexed8 && img->isGrayscale())
        throw new Error::UnsupportedColorspace;
    const GrayImage *gray = new GrayImage((unsigned char *) img->bits(),
            img->width(), img->height(), img->bytesPerLine());
    return gray;
}

MeasureThread::~MeasureThread()
{
    if (argbimg1 != 0) delete argbimg1;
    if (argbimg2 != 0) delete argbimg2;
    if (grayimg1 != 0) delete grayimg1;
    if (grayimg2 != 0) delete grayimg2;
    if (measure != 0) delete measure;
    if (compare != 0) delete compare;
}
