/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QThread>
#include <QString>

class Measure;
class Compare;
class ARGBImage;
class GrayImage;

class MeasureThread : public QThread
{
    Q_OBJECT

    enum { ARGB_Measure,
        Gray_Measure,
        ARGB_Compare,
        Gray_Compare } type;
    QString method;
    Measure *measure;
    Compare *compare;

    QString title1, title2;

    const ARGBImage *argbimg1, *argbimg2;
    const GrayImage *grayimg1, *grayimg2;

    const ARGBImage * qimage2argb(const QImage *img);
    const GrayImage * qimage2gray(const QImage *img);
    
    void getTitles(const MdiChildImage *img1, const MdiChildImage *img2);

public:
    MeasureThread(const QString _method,
            const MdiChildImage *img1,
            const MdiChildImage *img2 = 0,
            QObject * parent = 0);
    void run();
    ~MeasureThread();

signals:
    void newResult(MeasureResult *mr, const QString &);
};
