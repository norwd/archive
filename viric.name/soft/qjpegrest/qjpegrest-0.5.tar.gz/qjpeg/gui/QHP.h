/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QObject>

class QDialog;
class QSpinBox;
class QDoubleSpinBox;

class QHP : public QObject, public HP, public QTConfigurable
{
    Q_OBJECT

    QDialog *dialog;
    QSpinBox *spinShifts;
    QDoubleSpinBox *spinPercent;

public slots:
    void setConfig();
    void resetConfig();

public:
    QHP();
    virtual ~QHP();
    void startQtConfiguration();
};

class QHPCreator : public ActionCreator
{
    QHPCreator();

public:
    static void init();

    ImproveRawPlane * createImproveRawPlane() const;
	bool isapplicable(const JPEGParameters &p);
};
