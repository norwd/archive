/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <Actions.h>
#include <ActionType.h>
#include <ActionCreator.h>
#include <ActionManager.h>

#include <FloatPlane.h>
#include <JPEGData.h>
#include <CoefsPlane.h>

#include <LumScaler.h>

#include <QDialog>
#include <QSpinBox>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLabel>

#include "QTConfigurable.h"
#include "QLumScaler.moc"

QLumScaler::QLumScaler()
{
    GUIconfigurable = true;
    dialog = 0;
}

QLumScaler::~QLumScaler()
{
    /* This will free all the elements of the dialog */
    if (dialog)
        delete dialog;
}

void QLumScaler::startQtConfiguration()
{
    if (!dialog)
    {
        dialog = new QDialog();
        dialog->setWindowTitle(trUtf8("Configurant") + QString(" LumScaler"));
        QHBoxLayout *h = new QHBoxLayout(dialog);

        QVBoxLayout *vlabels = new QVBoxLayout();
        QLabel *lEpsilon_h = new QLabel(trUtf8("Epsilon horitzontal:"), dialog);
        lEpsilon_h->setAlignment(Qt::AlignRight);

        QLabel *lEpsilon_v = new QLabel(trUtf8("Epsilon vertical:"), dialog);
        lEpsilon_v->setAlignment(Qt::AlignRight);

        vlabels->addWidget(lEpsilon_h);
        vlabels->addWidget(lEpsilon_v);
        h->addLayout(vlabels);

        QVBoxLayout *vspins = new QVBoxLayout();
        spinEpsilon_h = new QDoubleSpinBox(dialog);
        spinEpsilon_h->setMaximum(10);
        spinEpsilon_h->setMinimum(0);
        spinEpsilon_h->setSingleStep(0.1);
        vspins->addWidget(spinEpsilon_h);
        spinEpsilon_v = new QDoubleSpinBox(dialog);
        spinEpsilon_v->setMaximum(10);
        spinEpsilon_v->setMinimum(0);
        spinEpsilon_v->setSingleStep(0.1);
        vspins->addWidget(spinEpsilon_v);
        h->addLayout(vspins);

        QVBoxLayout *vbuttons = new QVBoxLayout();
        QPushButton *applyButton = new QPushButton(trUtf8("Aplicar"), dialog);
        QPushButton *resetButton = new QPushButton(trUtf8("Restablir"), dialog);

        vbuttons->addWidget(applyButton);
        vbuttons->addWidget(resetButton);
        h->addLayout(vbuttons);

        connect(applyButton, SIGNAL(released()), this, SLOT(setConfig()));
        connect(resetButton, SIGNAL(released()), this, SLOT(resetConfig()));
        resetConfig();
    }
    dialog->show();
}

void QLumScaler::setConfig()
{
    epsilon_h = spinEpsilon_h->value();
    epsilon_v = spinEpsilon_v->value();
}

void QLumScaler::resetConfig()
{
    spinEpsilon_h->setValue(epsilon_h);
    spinEpsilon_v->setValue(epsilon_v);
}

QLumScalerCreator::QLumScalerCreator()
{
    type = e_Scaler;
}

void QLumScalerCreator::init()
{
    ActionCreator *a = new QLumScalerCreator();
    ActionManager::sreg("LumScaler", a);
}

Scaler * QLumScalerCreator::createScaler() const
{
    QLumScaler *ptr;
    ptr = new QLumScaler();
    return ptr;
}

bool QLumScalerCreator::isapplicable(const JPEGParameters &p)
{
    return true;
}
