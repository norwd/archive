/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QTreeWidget>

class QTreeActions : public QTreeWidget
{
    Q_OBJECT
public:
    QTreeActions(QWidget *parent = 0);
protected:
    void mousePressEvent(QMouseEvent *event);
};
