/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QMenu>
#include <QList>

class MdiChildImage;
class QSignalMapper;
class MainWindow;

class ImageContextMenu : public QMenu
{
    Q_OBJECT

    QSignalMapper *mapperCompare;
    QSignalMapper *mapperMeasure;

    MdiChildImage *myWindow;
    QList<MdiChildImage *> *myWindowList;

    MainWindow *mainwindow;

    void listOptions();
    void addMeasures(QMenu *);
    void addCompares(QMenu *menu);
    void addOtherImages(QMenu *menu, QString &method);

private slots:
    void setJPEG();

public:
    ImageContextMenu(MainWindow *main, MdiChildImage *from,
            QList<MdiChildImage *> *list = 0, QWidget *parent = 0);

public slots:
    void applyMeasure(QObject *image);
    void applyCompare(QObject *_params);
};
