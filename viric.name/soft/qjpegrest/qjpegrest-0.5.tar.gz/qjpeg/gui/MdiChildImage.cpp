/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QImage>
#include <QVBoxLayout>
#include <QFileInfo>
#include "QZoomImageSettings.h"
#include "QZoomImage.h"
#include "MdiChildBase.h"
#include "MdiChildImage.moc"

/* Static */
int MdiChildImage::noNamedNumber = 1;

MdiChildImage::MdiChildImage(QWidget *parent) : MdiChildBase(parent)
{
    zoom = new QZoomImage(this);
    layout = new QVBoxLayout(this);
    layout->setMargin(1);
    layout->addWidget(zoom);
    setLayout(layout);
    mynoNamedNumber = -1;
}

bool MdiChildImage::loadFile(const QString &fileName)
{
    QImage *img = new QImage(fileName);

    curFile = fileName;
    updateTitle();

    if (img->isNull())
        return false;

    zoom->setImage(img);
    zoom->show();

    resize(zoom->sizeHint());
    return true;
}

void MdiChildImage::updateTitle()
{
    if (curFile.isNull())
    {
        if (mynoNamedNumber == -1)
            mynoNamedNumber = noNamedNumber++;

        title = QString(trUtf8("Sense Nom %1")).arg(mynoNamedNumber);
    } else
    {
        title = strippedName(curFile);
    }

    if (! restoreSource.isNull())
        title += QString(" - de ") + strippedName(restoreSource);
    setWindowTitle(title);
}

void MdiChildImage::fromQImage(QImage *from)
{
    zoom->setImage(from);
    zoom->show();
    resize(zoom->sizeHint());
    updateTitle();
}

bool MdiChildImage::saveFileAs(const QString &filename)
{
    bool result;
    QImage *img = zoom->getQImage();
    result = img->save(filename);
    if (curFile.isNull())
    {
        curFile = filename;
        updateTitle();
    }

    return result;
}

QSize MdiChildImage::getImageSize() const
{
    return zoom->getImageSize();
}

QZoomImage * MdiChildImage::getQZoom() const
{
    return zoom;
}

QImage * MdiChildImage::getQImage() const
{
    return zoom->getQImage();
}

QString MdiChildImage::strippedName(const QString &fullFileName) const
{
    return QFileInfo(fullFileName).fileName();
}

QString MdiChildImage::getFileName() const
{
    return curFile;
}

QString MdiChildImage::getBaseFileName() const
{
    return strippedName(curFile);
}

bool MdiChildImage::isRestored() const
{
    if (restoreSource.isNull())
        return false;
    return true;
}

void MdiChildImage::setRestored(const QString &src)
{
    restoreSource = src;
    updateTitle();
}
