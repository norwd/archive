/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <JPEGData.h>
#include <FloatImage.h>
#include <ARGBImage.h>
#include <GrayImage.h>
#include <QImage>
#include <Chain.h>
#include <QVector>
#include <QRgb>
#include <QMessageBox>

#include "MainWindow.h"
#include "QChain.h"
#include "QImagePtr.h"

static QVector<QRgb> getGrayscale()
{
    QVector<QRgb> v;
    for (int i = 0; i < 256; ++i)
    {
        v.append(qRgb(i,i,i));
    }
    return v;
}

void QChain::applyChain()
{
    if (!isChainFull())
    {
        QMessageBox::information(this, trUtf8("No es pot aplicar la cadena"),
                trUtf8("No es pot aplicar la cadena perquè hi ha baules sense "
                    "algoritme assignat."), QMessageBox::Ok, QMessageBox::Ok);
        return;
    }

    QImagePtr *img = 0;

    FloatImage *out = Chain::apply();

    if (out == 0)
        return; /* ERROR applying chain */

    if (out->getComponents() == 3)
    {
        ARGBImage *rgb = out->getARGB();

        delete out;
        img = new QImagePtr((uchar *) rgb->data(), rgb->getWidth(),
            rgb->getHeight(), rgb->getWidth()*4, QImage::Format_RGB32);
        delete rgb;
    } else if (out->getComponents() == 1)
    {
        GrayImage *gray = out->getGray();
        delete out;

        img = new QImagePtr((uchar *) gray->data(), gray->getWidth(),
            gray->getHeight(), gray->getWidth(), QImage::Format_Indexed8);
        img->setColorTable(getGrayscale());
        delete gray;
    } else
    {
        delete out;
    }



    MainWindow::newImage(img);
}
