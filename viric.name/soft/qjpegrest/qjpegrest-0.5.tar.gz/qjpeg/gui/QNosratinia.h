/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QObject>

class QDialog;
class QSpinBox;

class QNosratinia : public QObject, public Nosratinia, public QTConfigurable
{
    Q_OBJECT

    QDialog *dialog;
    QSpinBox *spin;

public slots:
    void setShifts();
    void resetShifts();

public:
    QNosratinia();
    virtual ~QNosratinia();
    void startQtConfiguration();
};

class QNosratiniaCreator : public ActionCreator
{
    QNosratiniaCreator();

public:
    static void init();

    ImproveRawPlane * createImproveRawPlane() const;
	bool isapplicable(const JPEGParameters &p);
};
