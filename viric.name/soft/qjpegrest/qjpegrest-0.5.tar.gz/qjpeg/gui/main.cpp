/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QtGui>
#include <QImage>
#include <QLocale>
#include <QTranslator>
#include "MainWindow.h"

#ifdef STATIC
    Q_IMPORT_PLUGIN(qjpeg)
#endif

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    /* Set that all strings for trUtf8() are in UTF-8 */
    QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF-8"));

    QString lang = QLocale::system().name().left(2);
    if (lang == "C")
        lang = "en";

    QTranslator qtTranslator;
    qtTranslator.load("qt_" + lang);
    app.installTranslator(&qtTranslator);

    QTranslator appTranslator;
    qtTranslator.load(":/lang/qjpegrest_" + lang);
    app.installTranslator(&qtTranslator);

    /*
     * this would show the language locale 
    QByteArray blangname = lang.toUtf8();
    qDebug("System language locale: %s", blangname.constData());
    */

    MainWindow mainWin;
    mainWin.show();

    int ret = app.exec();

    return ret;
}
