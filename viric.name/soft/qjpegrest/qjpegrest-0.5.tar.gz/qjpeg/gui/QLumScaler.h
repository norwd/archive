/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QObject>

class QDialog;
class QSpinBox;
class QDoubleSpinBox;

class QLumScaler : public QObject, public LumScaler, public QTConfigurable
{
    Q_OBJECT

    QDialog *dialog;
    QDoubleSpinBox *spinEpsilon_h;
    QDoubleSpinBox *spinEpsilon_v;

public slots:
    void setConfig();
    void resetConfig();

public:
    QLumScaler();
    virtual ~QLumScaler();
    void startQtConfiguration();
};

class QLumScalerCreator : public ActionCreator
{
    QLumScalerCreator();

public:
    static void init();

    Scaler * createScaler() const;
	bool isapplicable(const JPEGParameters &p);
};
