/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QMainWindow>

class QMenu;
class QString;
class QAction;
class QWorkspace;
class QSignalMapper;
class MdiChildBase;
class MdiChildImage;
class MeasureResult;
class QChain;
class JPEGFile;
class QImage;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow();
    static MainWindow * mainWindow;
    void setMainJPEG(const char *filename);
    static void newImage(QImage *img);

private slots:
    void openImage();
    void saveImage();
    void updateWindowMenu();
    void openImageContextMenu(QMouseEvent *event);
    void updateMenus();
    void createMdiChildMResult(MeasureResult *mr, const QString &title);
    void viewChain();

private:
    void createActions();
    void createMenus();
    void createStatusBar();
    MdiChildBase *activeMdiChild();
    QList<MdiChildImage *> otherMdiChildImages();
    QList<MdiChildImage *> allMdiChildImages();
    MdiChildImage *createMdiChildImage();

    QWorkspace *workspace;
    QSignalMapper *windowMapper;

    QMenu *fileMenu;
    QMenu *viewMenu;
    QMenu *windowMenu;

    QAction *saveImageAction;
    QAction *openImageAction;
    QAction *exitAction;
    QAction *closeAction;
    QAction *closeAllAction;
    QAction *tileAction;
    QAction *cascadeAction;
    QAction *arrangeAction;
    QAction *viewChainAction;

    QChain *mainchain;

    JPEGFile *mainjpeg;

};
