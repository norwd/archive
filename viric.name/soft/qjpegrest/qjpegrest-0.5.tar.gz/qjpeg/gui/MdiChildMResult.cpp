/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QString>
#include <QTextEdit>
#include <QVBoxLayout>
#include "MeasureResult.h"
#include "MdiChildBase.h"
#include "MdiChildMResult.moc"

MdiChildMResult::MdiChildMResult(MeasureResult * mr, QWidget *parent)
    : MdiChildBase(parent)
{
    int row;
    QVBoxLayout *layout = new QVBoxLayout(this);
    this->setLayout(layout);
    layout->setMargin(0);
    layout->setSpacing(0);

    QTextEdit *textedit = new QTextEdit(this);
    textedit->insertPlainText(mr->text);
    delete mr;
    textedit->setReadOnly(true);

    textedit->resize(40,40);

    layout->addWidget(textedit);
}
