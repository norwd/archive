/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class QString;
class MeasureResult;
class QGridLayout;
class QProgressBar;
class MdiChildBase;

class MdiChildMResult : public MdiChildBase
{
	Q_OBJECT

public:
	MdiChildMResult(MeasureResult * mr, QWidget *parent = 0);
};
