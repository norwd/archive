/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QWidget>
#include <QString>

class QZoomImage;
class QLayout;
class MdiChildBase;

class MdiChildImage : public MdiChildBase
{
	Q_OBJECT

	QLayout *layout;

	QZoomImage *zoom;
    QString curFile;
    QString restoreSource;

    QString strippedName(const QString &fullFileName) const;

    void updateTitle();

    static int noNamedNumber;
    int mynoNamedNumber;

public:
	MdiChildImage(QWidget *parent = 0);
	bool loadFile(const QString &fileName);
    void fromQImage(QImage *from);
    bool saveFileAs(const QString &filename);
    QZoomImage *getQZoom() const;
    QImage *getQImage() const;
    QSize getImageSize() const;
    QString getFileName() const;
    QString getBaseFileName() const;
    bool isImage() const {
        return true;
    }
    bool isRestored() const;
    void setRestored(const QString &src);
};
