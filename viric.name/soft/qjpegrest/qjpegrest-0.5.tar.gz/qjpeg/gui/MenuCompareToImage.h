/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QObject>

class QString;
class MdiChildImage;

class MenuCompareToImage : public QObject
{
    Q_OBJECT

public:
    MenuCompareToImage(QObject * parent = 0);
    MdiChildImage *targetWindow;
    QString method;
};
