/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <Actions.h>
#include <ActionType.h>
#include <ActionCreator.h>
#include <ActionManager.h>

#include <FloatPlane.h>
#include <JPEGData.h>
#include <CoefsPlane.h>

#include <Nosratinia.h>

#include <QDialog>
#include <QSpinBox>
#include <QPushButton>
#include <QHBoxLayout>
#include <QLabel>

#include "QTConfigurable.h"
#include "QNosratinia.moc"

QNosratinia::QNosratinia()
{
    GUIconfigurable = true;
    dialog = 0;
    spin = 0;
}

QNosratinia::~QNosratinia()
{
    /* This will free all the elements of the dialog,
     * including spin */
    if (dialog)
        delete dialog;
}

void QNosratinia::startQtConfiguration()
{
    if (!dialog)
    {
        dialog = new QDialog();
        dialog->setWindowTitle(trUtf8("Configurant") + QString(" Nosratinia"));
        QHBoxLayout *h = new QHBoxLayout(dialog);
        QLabel *l = new QLabel(trUtf8("Desplaçaments:"), dialog);
        spin = new QSpinBox(dialog);
        spin->setMaximum(64);
        spin->setMinimum(0);
        spin->setSingleStep(1);
        spin->setValue(64);

        QPushButton *applyButton = new QPushButton(trUtf8("Aplicar"), dialog);
        QPushButton *resetButton = new QPushButton(trUtf8("Restablir"), dialog);

        h->addWidget(l);
        h->addWidget(spin);
        h->addWidget(applyButton);
        h->addWidget(resetButton);

        connect(applyButton, SIGNAL(released()), this, SLOT(setShifts()));
        connect(resetButton, SIGNAL(released()), this, SLOT(resetShifts()));
        resetShifts();
    }
    dialog->show();
}

void QNosratinia::setShifts()
{
    shifts = spin->value();
}

void QNosratinia::resetShifts()
{
    spin->setValue(shifts);
}

QNosratiniaCreator::QNosratiniaCreator()
{
    type = e_ImproveRawPlane;
}

void QNosratiniaCreator::init()
{
    ActionCreator *a = new QNosratiniaCreator();
    ActionManager::sreg("Nosratinia", a);
}

ImproveRawPlane * QNosratiniaCreator::createImproveRawPlane() const
{
    QNosratinia *ptr;
    ptr = new QNosratinia();
    return ptr;
}

bool QNosratiniaCreator::isapplicable(const JPEGParameters &p)
{
    return true;
}
