/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <ActionType.h>
#include <QTreeWidgetItem>
#include "QTreeActionItem.h"


QTreeActionItem::QTreeActionItem(QTreeWidget * parent, int type, enum ActionType atype)
    :QTreeWidgetItem(parent, type), type(atype)
{
}

QTreeActionItem::QTreeActionItem(QTreeWidgetItem * parent, int type, enum ActionType atype)
    :QTreeWidgetItem(parent, type), type(atype)
{
}
