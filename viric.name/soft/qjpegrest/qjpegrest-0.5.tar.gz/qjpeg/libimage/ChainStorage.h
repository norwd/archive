/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
template <class tIDCTPlane, class tImproveRawPlane, class tScaler,
         class tColorMap>
class ChainStorage
{
    int planes;

public:
    /*! The IDCTPlane for each plane. array. */
    tIDCTPlane **idcts;

    /*! The ImproveRawPlane vectors for each plane. */
    vector<tImproveRawPlane *> *improverawplanes;

    /*! The colormap changes to apply. vector for each plane. */
    vector<tColorMap *> colormaps;

    /*! The final scaler */
    tScaler *scaler;

    ChainStorage();
    void voidAll();
    void clearStructs();
    void setPlanes(int nplanes);
    void freeImproveRawPlanes();
    void freeColorMaps();
    void free();
};

class NormalChainStorage :
    public ChainStorage<IDCTPlane, ImproveRawPlane, Scaler, ColorMap> { };

template <class tIDCTPlane, class tImproveRawPlane, class tScaler, class tColorMap>
ChainStorage<tIDCTPlane,tImproveRawPlane,tScaler,tColorMap>::
    ChainStorage()
{
    planes = 0;
    idcts = 0;
    improverawplanes = 0;
    scaler = 0;
}

template <class tIDCTPlane, class tImproveRawPlane, class tScaler, class tColorMap>
void ChainStorage<tIDCTPlane,tImproveRawPlane,tScaler,tColorMap>
    ::clearStructs()
{
    voidAll();
    delete[] idcts;
    idcts = 0;
    delete[] improverawplanes;
    improverawplanes = 0;
}

template <class tIDCTPlane, class tImproveRawPlane, class tScaler, class tColorMap>
void ChainStorage<tIDCTPlane,tImproveRawPlane,tScaler,tColorMap>::
    setPlanes(int nplanes)
{
    if ( planes != 0 )
        clearStructs();
    planes = nplanes;
    if (nplanes > 0)
    {
        idcts = new tIDCTPlane* [nplanes];
        for (int i=0; i < planes; ++i)
            idcts[i] = 0;
        improverawplanes = new vector<tImproveRawPlane *>[planes];
    }
}

template <class tIDCTPlane, class tImproveRawPlane, class tScaler, class tColorMap>
void ChainStorage<tIDCTPlane,tImproveRawPlane,tScaler,tColorMap>
    ::voidAll()
{
    if (planes > 0)
        for (int i=0; i < planes; ++i)
        {
            idcts[i] = 0;
            improverawplanes[i].clear();
        }
    scaler = 0;
    colormaps.clear();
}

template <class tIDCTPlane, class tImproveRawPlane, class tScaler, class tColorMap>
void ChainStorage<tIDCTPlane,tImproveRawPlane,tScaler,tColorMap>
    ::free()
{
    freeImproveRawPlanes();
    for (int i=0; i < planes; ++i)
    {
        delete idcts[i];
        idcts[i] = 0;
        improverawplanes[i].clear();
    }
    delete scaler;
    scaler = 0;

    freeColorMaps();
    colormaps.clear();
}

/*! Deletes everything contained in improverawplanes */
template <class tIDCTPlane, class tImproveRawPlane, class tScaler, class tColorMap>
void ChainStorage<tIDCTPlane,tImproveRawPlane,tScaler,tColorMap>
    ::freeImproveRawPlanes()
{
    for(unsigned int i = 0; i < planes; ++i)
    {
        /* Free the elements of the vector */
        typename vector<tImproveRawPlane *>::const_iterator v;
        for(v = improverawplanes[i].begin(); v != improverawplanes[i].end();
                ++v)
        {
            delete (*v);
        }
    }
}

/*! Destroys all the colormaps stored in this Chain object. */
template <class tIDCTPlane, class tImproveRawPlane, class tScaler, class tColorMap>
void ChainStorage<tIDCTPlane,tImproveRawPlane,tScaler,tColorMap>
    ::freeColorMaps()
{
    typename vector<tColorMap *>::const_iterator i;
    for(i = colormaps.begin(); i != colormaps.end(); ++i)
        delete (*i);
}
