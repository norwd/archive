/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class QString;

enum ActionType
{
    e_Undefined,
    e_IDCTPlane,
    e_ImproveRaw,
    e_ImproveRawPlane,
    e_ColorMap,
    e_Scaler,
    e_Measure,
    e_Compare
};

QString actionType2String(enum ActionType type);
enum ActionType string2ActionType(const QString &str);
