/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
/* Needs include JPEGData.h */
class CoefsPlane;

class CoefsImage
{
    unsigned int components;
    bool ready;


public:
    JPEGParameters jpegparameters;

    CoefsPlane *plane;

    CoefsImage();
    CoefsImage(CoefsPlane _plane[], const unsigned int _components);

    void free();
    void setComponents(unsigned int n);
    void writePPM(const char *filename) const;
    unsigned int getComponents() const
    {
        return components;
    }
};
