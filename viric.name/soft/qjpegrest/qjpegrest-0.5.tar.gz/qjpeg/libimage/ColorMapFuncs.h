/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
namespace ColorMapFuncs
{
    float RGB2Y(int r, int g, int b)
    {
        float sum;
        sum = r + g + b;
        return sum / 3.;
    }
}
