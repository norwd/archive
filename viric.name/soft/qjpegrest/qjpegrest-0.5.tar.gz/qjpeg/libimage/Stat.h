/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <cmath>

template<class DataType> class Stat
{
    int n;
    DataType sum;
    DataType sum2;

    public:
    Stat();
    void reset();
    void addData(const DataType &f);
    double getMean() const;
    double getStdDev() const;
};

template<class DataType>
Stat<DataType>::Stat()
{
    reset();
}

template<class DataType>
void Stat<DataType>::reset()
{
    n = 0;
    sum = 0;
    sum2 = 0;
}

template<class DataType>
void Stat<DataType>::addData(const DataType &f)
{
    sum += f;
    sum2 += f*f;
    n += 1;
}

template<class DataType>
double Stat<DataType>::getMean() const
{
    if (n > 0)
        return (double) sum / (double) n;
    else
        return 0;
}

template<class DataType>
double Stat<DataType>::getStdDev() const
{
    double mean = getMean();

    if (n > 1)
        return std::sqrt((double) (sum2 - mean*mean) / (double) (n-1));
    else
        return 0;
}
