/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
typedef float RCOEF;
typedef float RSAMP;
typedef float * RSAMPBUFFER;
typedef float * RCOEFBUFFER;
typedef float * RBLOCK;

void fdct_image (RCOEFBUFFER coefdct, RSAMPBUFFER in,
    const int w, int const h);

void fdct_inverse_image(RCOEFBUFFER coefdct, RSAMPBUFFER out,
    const int w, int const h);

void fidct_buffer(RCOEFBUFFER coef_block, RSAMPBUFFER output_buf);

void fdct_buffer(RSAMPBUFFER in_data, RCOEFBUFFER out_data);
