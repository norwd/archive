/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QString>
class CoefsPlane;
class FloatPlane;
class CoefsImage;
class FloatImage;
class ARGBImage;
class GrayImage;
class MeasureResult;

class ActionBase
{
protected:
    /*! The name of the action */
    QString name;
    /*! Layer broken - but the code is much easier this way.
     * It tells if the child class can be casted to a QConfigurable,
     * at the time of writing this. */
    bool GUIconfigurable;
    /*! The maximum value that actualProgress will have */
    int maxProgress;
    /*! Part of maxProgress actually done */
    int progress;
    /*! Function to set the actual progress. It's provided as a function,
     * because it may need to call progress handlers */
    virtual void setProgress(int p);

public:
    /*! Sets the progress and maxProgress to 0 */
    ActionBase();
    virtual ~ActionBase() {};
    /*! Get configured using the environment */
    virtual bool getConfiguredEnv() { } ;
    /*! Give the maximum value of the progress */
    virtual int getMaxProgress();
    /*! Get the progress value */
    virtual int getProgress();
    bool isGUIconfigurable() const;

    QString getName() const;
};

class IDCTPlane : public ActionBase
{
public:
    virtual void prepare(const CoefsPlane *in) = 0;
	virtual FloatPlane * apply() = 0;
};

class ImproveRawPlane : public ActionBase
{
public:
    virtual void prepare(const CoefsPlane *coefs,
            const FloatPlane *initial) = 0;
	virtual FloatPlane * apply() = 0;
};

class ImproveRaw : public ActionBase
{
public:
    virtual void prepare(const CoefsImage *coefs,
            const FloatImage *initial) = 0;
	virtual FloatImage * apply() = 0;
};

class ColorMap : public ActionBase
{
public:
	virtual void prepare(FloatImage *initial) = 0;
	virtual void apply() = 0;
};

class Scaler : public ActionBase
{
public:
	virtual void prepare(const CoefsImage *coefs,
            const FloatImage *initial) = 0;
	virtual FloatImage * apply() = 0;
};

class Compare : public ActionBase
{
public:
	virtual void prepare(const ARGBImage *img1,
            const ARGBImage *img2) = 0;
	virtual void prepare(const GrayImage *img1,
            const GrayImage *img2) = 0;
	virtual MeasureResult * apply() = 0;
};

class Measure : public ActionBase
{
public:
	virtual void prepare(const ARGBImage *img) = 0;
	virtual void prepare(const GrayImage *img) = 0;
	virtual MeasureResult * apply() = 0;
};
