/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <cstdio>
#include <vector>

class FloatImage;
class CoefsImage;
class JPEGParameters;

extern "C" {
struct jpeg_decompress_struct;
struct jpeg_error_mgr;
}

class JPEGFile
{
    char * filename;
    FloatImage *iDCTImage;
    FloatImage *unpackedImage;

    typedef int *torig_qtable; /* length 64 */
    typedef float *tqtable; /* length 64 */
    std::vector<torig_qtable> orig_qtables;
    std::vector<tqtable> qtables;
    float qtable_factors[64];

    JPEGParameters params;

    FILE *inputh;

    struct jpeg_decompress_struct *srcinfo;
    struct jpeg_error_mgr *jsrcerr;

    /*! Reads the jpeg header.
     * \throw UnsupportedColorspace Colorspace not supported. */
    int readHeader();

    /*! Wipes out the content of qtables, freeing its memory */
    void clearQtables();
    /*! Create the qtable_factors. Called at construct time. */
    void createQtableFactors();
    /*! Loads new tables from the file to the object.
     * It requires srcinfo with header read.
     * The original tables are loaded into orig_qtables and also a version
     * multiplied with the AA&N factors for a proper IDCT (as we use
     * AA&N DCT/IDCT methods) is created into qtables. */
    void newQtables(unsigned int planes);

    /*! Load the file qtables into the object. The libjpeg functions for
     * reading the coefficients of the file don't provide a way of getting
     * the qtables, so we need this special function which opens de file, loads
     * the qtables and closes the file again
     *
     * \deprecated (This information is no longer valid) */
    int loadQtables();

public:
    JPEGFile (const char *_filename);
    ~JPEGFile();

    char * getFileName() const;

    /*! Opens the file, and gets the raw planes.
     * These planes aren't postprocessed.
     * \throw UnsupportedColorspace Colorspace not supported. */
    FloatImage * getiDCTImage();
    /*! Opens the file, and gets the image planes with all libjpeg
     * postprocessing.
     * \throw UnsupportedColorspace Colorspace not supported. */
    FloatImage * getUnpackedImage();
    /*! Opens the file, and gets coefficients dequantized and scaled for
     * proper use with AA&N DCT/IDCT methods.
     * \throw UnsupportedColorspace Colorspace not supported. */
    CoefsImage * getCoefs();
};
