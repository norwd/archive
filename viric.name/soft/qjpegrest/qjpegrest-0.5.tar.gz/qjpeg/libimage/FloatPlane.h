/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class FloatPlane
{
    unsigned int width;
    unsigned int height;

    enum {
        MAXVALUE = 255,
        MINVALUE = 0
    };

    bool ready;

public:
    float *ptr;

    FloatPlane();
    FloatPlane(float *_ptr);
    FloatPlane(const unsigned int _width, const unsigned int _height);

    void allocate(const unsigned int _width, const unsigned int _height);
    inline unsigned int getWidth() const
    {
        return width;
    }
    inline unsigned int getHeight() const
    {
        return height;
    }
    inline unsigned int getMaxValue() const
    {
        return MAXVALUE;
    }
    inline float * getPtr() const
    {
        return ptr;
    }
    void writePGM(const char * filename) const;
    void free();
    inline void set(unsigned int column, unsigned int row, float val)
    {
        ptr[(row * width) + column] = val;
    }

    inline float get(unsigned int column, unsigned int row) const
    {
        return ptr[(row * width) + column];
    }

    inline float * getrow(unsigned int row) const
    {
        return &ptr[(row * width)];
    }

    inline static unsigned char roundsample(float val)
    {
        val += 0.5;
        if (val > MAXVALUE)
            val = MAXVALUE;
        else if (val < MINVALUE)
            val = MINVALUE;

        return (unsigned char) val;
    }

    /*! Set all the values of the image to 0 */
    void setzero();
    /*! Add the given plane to this plane */
    void add(const FloatPlane &in);
    /*! Create a copy of this plane, copying also the data to a new ptr */
    FloatPlane newcopy();
    FloatPlane check();

    FloatPlane & operator=(const FloatPlane &in);
};
