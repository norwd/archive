/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <cstring>
extern "C" {
#include <stdio.h>
#include <pam.h>
}
#include "ARGBImage.h"

/*! Writes the planes as an RGB PPM to the given filename. */
void ARGBImage::writePPM(const char *filename) const
{
    int components = 3;

    unsigned int MAXVALUE = 255;

    struct pam outpam;
    unsigned int row;
    tuple *tuplerow;
 
    FILE* file;

    if (!ptr)
        return;

    file = fopen(filename, "wb");
    if (file == NULL)
        return;


    outpam.size = sizeof(outpam);
    outpam.len = outpam.size;
    outpam.file = file;
    if (components == 3)
    {
        outpam.format = PPM_FORMAT;
        outpam.depth = 3; /* RGB - 3 sample per tuple */
        std::strcpy(outpam.tuple_type, "RGB"); /* PNM non transparent */
    }
    else
    {
        outpam.format = PGM_FORMAT;
        outpam.depth = 1; /* GRAYSCALE - 1 sample per tuple */
        std::strcpy(outpam.tuple_type, "GRAYSCALE"); /* PGM non transparent */
    }
    outpam.plainformat = 0; /* false */
    outpam.width = width;
    outpam.height = height;
    outpam.allocation_depth = 0; /* Same as depth. */
    outpam.maxval = MAXVALUE;

    /* needs size,len,file,format,height,width,depth,maxval, tuple_type */
    pnm_writepaminit(&outpam);
 
    tuplerow = pnm_allocpamrow(&outpam);
 
    for (row = 0; row < height; row++) {
        unsigned int column;
        for (column = 0; column < width; ++column) {
            /* Only one plane */
            /* float to int! */
            {
                unsigned int val = ptr[column+width*row];
                tuplerow[column][0] = (val >> 16) & 0xff;
                tuplerow[column][1] = (val >> 8) & 0xff;
                tuplerow[column][2] = val & 0xff;
            }
        }
        pnm_writepamrow(&outpam, tuplerow);
    }
 
    pnm_freepamrow(tuplerow);
    fclose(file);
}
