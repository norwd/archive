/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class GrayImage
{
    unsigned char *ptr;
    unsigned int width;
    unsigned int height;
    unsigned int bytes_per_line;

public:
    GrayImage(const unsigned int _width, const unsigned int _height,
            const unsigned int _bytes_per_line = 0)
    {
        width = _width;
        height = _height;
        if (_bytes_per_line)
            bytes_per_line = _bytes_per_line;
        else
            bytes_per_line = _width;
        ptr = new unsigned char[bytes_per_line * _height];
    }

    GrayImage(unsigned char *p, const unsigned int _width, const unsigned int _height, const unsigned int _bytes_per_line = 0)
    {
        ptr = p;
        width = _width;
        height = _height;
        if (_bytes_per_line)
            bytes_per_line = _bytes_per_line;
        else
            bytes_per_line = _width;
    }

    inline unsigned char *data() const
    {
        return ptr;
    }

    inline unsigned int getHeight() const
    {
        return height;
    }
    
    inline unsigned int getWidth() const
    {
        return width;
    }

    inline unsigned char getPixel(const unsigned int x, const unsigned int y) const
    {
        return ptr[y*bytes_per_line + x];
    } 
    inline void setPixel(const unsigned int x, const unsigned int y, unsigned char val)
    {
         ptr[y*bytes_per_line + x] = val;
    }
};
