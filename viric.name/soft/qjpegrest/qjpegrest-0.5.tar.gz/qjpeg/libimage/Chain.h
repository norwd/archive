/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <vector>
class CoefsImage;
class IDCTPlane;
class ImproveRawPlane;
class ColorMap;
class Scaler;
class FloatImage;
class NormalChainStorage;

using std::vector;

class Chain
{
protected:
    unsigned int components;

    CoefsImage *initial;

    NormalChainStorage *storage;

    void freeImproveRawPlanes();
    void freeColorMaps();

public:
    Chain();
    /*! Build a chain for the given CoefsImage. */
    Chain(CoefsImage *ini);
    /*! \sa free() */
    ~Chain();
    /*! Free all the structures of the chain. */
    void free();
    /*! Set the initial CoefsImage, to which the chain process will be applied.
     * */
    void setInitial(CoefsImage *ini);

    /*! set an IDCTPlane action for the specified plane. */
    void setIDCTPlane(const unsigned int plane, IDCTPlane *idct);
    /*! set an IDCTPlane action for the specified plane, giving its name for
     * ActionCreator. */
    void setIDCTPlane(const unsigned int plane, const char *name);
    /*! add (chain) an ImproveRawPlane action for the specified plane. */
    void addImproveRawPlane(const unsigned int plane,
            ImproveRawPlane *improver);
    /*! add (chain) an ImproveRawPlane action for the specified plane,
     * giving its name for ActionCreator. */
    void addImproveRawPlane(const unsigned int plane, const char *name);
    /*! set the Scaler action for the decompression chain. */
    void setScaler(Scaler *newscaler);
    /*! set the Scaler action for the decompression chain, giving
     * its name for ActionCreator. */
    void setScaler(const char *name);
    /*! add (chain) a ColorMap action. */
    void addColorMap(ColorMap *cmap);
    /*! add (chain) a ColorMap action, giving its name for ActionCreator. */
    void addColorMap(const char *name);
    /*! Are there void pointers in the chain? */
    bool isChainFull();

    /*! Apply the set decompression chain of actions to the initial CoefsImage,
     * and give a final FloatImage. */
    FloatImage * apply();
};
