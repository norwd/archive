/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
/* REQUIRES ActionType.h */

class IDCTPlane;
class ImproveRaw;
class ImproveRawPlane;
class ColorMap;
class Scaler;
class Measure;
class Compare;
class JPEGParameters;

/*!  Abstract for creating Actions.
 *
 * Every plugin should provide creators for the provided actions. The
 * PluginManager will be called for the creation of any Action needed, and
 * it will call its ActionCreator.
 *
 * It's expected that only one ActionCreator will exist in the process for each 
 * Action.
 */
class ActionCreator
{
protected:
    enum ActionType type;
public:
    ActionCreator();

    virtual IDCTPlane * createIDCTPlane() const;
    virtual ImproveRaw * createImproveRaw() const;
    virtual ImproveRawPlane * createImproveRawPlane() const;
    virtual ColorMap * createColorMap() const;
    virtual Scaler * createScaler() const;
    virtual Measure * createMeasure() const;
    virtual Compare * createCompare() const;
    /*! Determines if the Action can be applied to the given JPEG file */
	virtual bool isapplicable(const JPEGParameters &p) = 0;
    enum ActionType getType() const;
};
