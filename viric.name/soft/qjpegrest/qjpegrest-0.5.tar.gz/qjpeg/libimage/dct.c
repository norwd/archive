/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
/*#include <math.h>*/
#include "cdct.h"

/*#define cap_data(val) min(RAWMAX,max(RAWMIN,(val)))*/


enum {
  RAWCENTER = 128,
  RAWMAX = 255,
  RAWMIN = 0,
  DCTSIZE = 8,
  DCTSIZE2 = 64
};

/* Inverse DCT (ANN method) in float on a 8x8 block. From Froment.  */

void
  /* const on coef_block */
fidct_block(RCOEF * coef_block, RSAMP* output_buf)
{
  float tmp0, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7;
  float tmp10, tmp11, tmp12, tmp13;
  float z5, z10, z11, z12, z13;
  RCOEF * inptr;
  RSAMP * outptr;
  float * wsptr;
  int ctr;
  float workspace[DCTSIZE2]; /* buffers data between passes */

  /* Pass 1: process columns from input, store into work array. */

  
  inptr = coef_block;
  wsptr = workspace;
  for (ctr = DCTSIZE; ctr > 0; ctr--) {
    /* Due to quantization, we will usually find that many of the input
     * coefficients are zero, especially the AC terms.  We can exploit this
     * by short-circuiting the IDCT calculation for any column in which all
     * the AC terms are zero.  In that case each output is equal to the
     * DC coefficient (with scale factor as needed).
     * With typical images and quantization tables, half or more of the
     * column DCT calculations can be simplified this way.
     */

    if ((inptr[DCTSIZE*1]==0) && (inptr[DCTSIZE*2]==0) && (inptr[DCTSIZE*3]==0) &&
	(inptr[DCTSIZE*4]==0) && (inptr[DCTSIZE*5]==0) && (inptr[DCTSIZE*6]==0) &&
	(inptr[DCTSIZE*7] == 0)) {
      /* AC terms all zero */
      float dcval = inptr[DCTSIZE*0];

      wsptr[DCTSIZE*0] = dcval;
      wsptr[DCTSIZE*1] = dcval;
      wsptr[DCTSIZE*2] = dcval;
      wsptr[DCTSIZE*3] = dcval;
      wsptr[DCTSIZE*4] = dcval;
      wsptr[DCTSIZE*5] = dcval;
      wsptr[DCTSIZE*6] = dcval;
      wsptr[DCTSIZE*7] = dcval;

      inptr++;			/* advance pointers to next column */
      wsptr++;
      continue;
    }

    /* Even part */

    tmp0 = inptr[DCTSIZE*0];
    tmp1 = inptr[DCTSIZE*2];
    tmp2 = inptr[DCTSIZE*4];
    tmp3 = inptr[DCTSIZE*6];

    tmp10 = tmp0 + tmp2;	/* phase 3 */
    tmp11 = tmp0 - tmp2;

    tmp13 = tmp1 + tmp3;	/* phases 5-3 */
    tmp12 = (tmp1 - tmp3) * ((double) 1.414213562) - tmp13; /* 2*c4 */

    tmp0 = tmp10 + tmp13;	/* phase 2 */
    tmp3 = tmp10 - tmp13;
    tmp1 = tmp11 + tmp12;
    tmp2 = tmp11 - tmp12;

    /* Odd part */

    tmp4 = inptr[DCTSIZE*1];
    tmp5 = inptr[DCTSIZE*3];
    tmp6 = inptr[DCTSIZE*5];
    tmp7 = inptr[DCTSIZE*7];

    z13 = tmp6 + tmp5;		/* phase 6 */
    z10 = tmp6 - tmp5;
    z11 = tmp4 + tmp7;
    z12 = tmp4 - tmp7;

    tmp7 = z11 + z13;		/* phase 5 */
    tmp11 = (z11 - z13) * ((float) 1.414213562); /* 2*c4 */

    z5 = (z10 + z12) * ((float) 1.847759065); /* 2*c2 */
    tmp10 = ((float) 1.082392200) * z12 - z5; /* 2*(c2-c6) */
    tmp12 = ((float) -2.613125930) * z10 + z5; /* -2*(c2+c6) */

    tmp6 = tmp12 - tmp7;	/* phase 2 */
    tmp5 = tmp11 - tmp6;
    tmp4 = tmp10 + tmp5;

    wsptr[DCTSIZE*0] = tmp0 + tmp7;
    wsptr[DCTSIZE*7] = tmp0 - tmp7;
    wsptr[DCTSIZE*1] = tmp1 + tmp6;
    wsptr[DCTSIZE*6] = tmp1 - tmp6;
    wsptr[DCTSIZE*2] = tmp2 + tmp5;
    wsptr[DCTSIZE*5] = tmp2 - tmp5;
    wsptr[DCTSIZE*4] = tmp3 + tmp4;
    wsptr[DCTSIZE*3] = tmp3 - tmp4;

    inptr++;			/* advance pointers to next column */
    wsptr++;
  }

  /* Pass 2: process rows from work array, store into output array. */
  /* Note that we must descale the results by a factor of 8 == 2**3. */

  wsptr = workspace;
  outptr = output_buf;
  for (ctr = 0; ctr < DCTSIZE; ctr++) {

    /* Even part */

    tmp10 = wsptr[0] + wsptr[4];
    tmp11 = wsptr[0] - wsptr[4];

    tmp13 = wsptr[2] + wsptr[6];
    tmp12 = (wsptr[2] - wsptr[6]) * ((float) 1.414213562) - tmp13;

    tmp0 = tmp10 + tmp13;
    tmp3 = tmp10 - tmp13;
    tmp1 = tmp11 + tmp12;
    tmp2 = tmp11 - tmp12;

    /* Odd part */

    z13 = wsptr[5] + wsptr[3];
    z10 = wsptr[5] - wsptr[3];
    z11 = wsptr[1] + wsptr[7];
    z12 = wsptr[1] - wsptr[7];

    tmp7 = z11 + z13;
    tmp11 = (z11 - z13) * ((float) 1.414213562);

    z5 = (z10 + z12) * ((float) 1.847759065); /* 2*c2 */
    tmp10 = ((float) 1.082392200) * z12 - z5; /* 2*(c2-c6) */
    tmp12 = ((float) -2.613125930) * z10 + z5; /* -2*(c2+c6) */

    tmp6 = tmp12 - tmp7;
    tmp5 = tmp11 - tmp6;
    tmp4 = tmp10 + tmp5;

    /* Final output stage: scale down by a factor of 8 and range-limit */

    outptr[0] = (tmp0 + tmp7)*(float)0.125 + RAWCENTER;
    outptr[7] = (tmp0 - tmp7)*(float)0.125 + RAWCENTER;
    outptr[1] = (tmp1 + tmp6)*(float)0.125 + RAWCENTER;
    outptr[6] = (tmp1 - tmp6)*(float)0.125 + RAWCENTER;
    outptr[2] = (tmp2 + tmp5)*(float)0.125 + RAWCENTER;
    outptr[5] = (tmp2 - tmp5)*(float)0.125 + RAWCENTER;
    outptr[4] = (tmp3 + tmp4)*(float)0.125 + RAWCENTER;
    outptr[3] = (tmp3 - tmp4)*(float)0.125 + RAWCENTER;
   
    outptr += DCTSIZE;
    wsptr += DCTSIZE;		/* advance pointer to next row */
  }
}

/* DCT (ANN method) in float on a 8x8 block. From Froment.  */

void
fdct_block(const RSAMP * in_data, RBLOCK out_data)
{
  float tmp0, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7;
  float tmp10, tmp11, tmp12, tmp13;
  float z1, z2, z3, z4, z5, z11, z13;
  RCOEF *dataptr;
  int ctr,i;

  /* step 0 :  make data signed */

  dataptr = out_data;
  for(i=0;i<DCTSIZE;i++) {
    *dataptr++ = ( *in_data++ - RAWCENTER  );
    *dataptr++ = ( *in_data++ - RAWCENTER );
    *dataptr++ = ( *in_data++ - RAWCENTER );
    *dataptr++ = ( *in_data++ - RAWCENTER );
    *dataptr++ = ( *in_data++ - RAWCENTER );
    *dataptr++ = ( *in_data++ - RAWCENTER );
    *dataptr++ = ( *in_data++ - RAWCENTER );
    *dataptr++ = ( *in_data++ - RAWCENTER );
  }

  /* Pass 1: process rows. */

  dataptr = out_data;
  for (ctr = DCTSIZE-1; ctr >= 0; ctr--) {
    tmp0 = dataptr[0] + dataptr[7];
    tmp7 = dataptr[0] - dataptr[7];
    tmp1 = dataptr[1] + dataptr[6];
    tmp6 = dataptr[1] - dataptr[6];
    tmp2 = dataptr[2] + dataptr[5];
    tmp5 = dataptr[2] - dataptr[5];
    tmp3 = dataptr[3] + dataptr[4];
    tmp4 = dataptr[3] - dataptr[4];

    /* Even part */

    tmp10 = tmp0 + tmp3;	/* phase 2 */
    tmp13 = tmp0 - tmp3;
    tmp11 = tmp1 + tmp2;
    tmp12 = tmp1 - tmp2;

    dataptr[0] = tmp10 + tmp11; /* phase 3 */
    dataptr[4] = tmp10 - tmp11;

    z1 = (tmp12 + tmp13) * ((float) 0.707106781); /* c4 */
    dataptr[2] = tmp13 + z1;	/* phase 5 */
    dataptr[6] = tmp13 - z1;

    /* Odd part */

    tmp10 = tmp4 + tmp5;	/* phase 2 */
    tmp11 = tmp5 + tmp6;
    tmp12 = tmp6 + tmp7;

    /* The rotator is modified from fig 4-8 to avoid extra negations. */
    z5 = (tmp10 - tmp12) * ((float) 0.382683433); /* c6 */
    z2 = ((float) 0.541196100) * tmp10 + z5; /* c2-c6 */
    z4 = ((float) 1.306562965) * tmp12 + z5; /* c2+c6 */
    z3 = tmp11 * ((float) 0.707106781); /* c4 */

    z11 = tmp7 + z3;		/* phase 5 */
    z13 = tmp7 - z3;

    dataptr[5] = z13 + z2;	/* phase 6 */
    dataptr[3] = z13 - z2;
    dataptr[1] = z11 + z4;
    dataptr[7] = z11 - z4;

    dataptr += DCTSIZE;		/* advance pointer to next row */
  }

  /* Pass 2: process columns. */

  dataptr = out_data;
  for (ctr = DCTSIZE-1; ctr >= 0; ctr--) {
    tmp0 = dataptr[DCTSIZE*0] + dataptr[DCTSIZE*7];
    tmp7 = dataptr[DCTSIZE*0] - dataptr[DCTSIZE*7];
    tmp1 = dataptr[DCTSIZE*1] + dataptr[DCTSIZE*6];
    tmp6 = dataptr[DCTSIZE*1] - dataptr[DCTSIZE*6];
    tmp2 = dataptr[DCTSIZE*2] + dataptr[DCTSIZE*5];
    tmp5 = dataptr[DCTSIZE*2] - dataptr[DCTSIZE*5];
    tmp3 = dataptr[DCTSIZE*3] + dataptr[DCTSIZE*4];
    tmp4 = dataptr[DCTSIZE*3] - dataptr[DCTSIZE*4];

    /* Even part */

    tmp10 = tmp0 + tmp3;	/* phase 2 */
    tmp13 = tmp0 - tmp3;
    tmp11 = tmp1 + tmp2;
    tmp12 = tmp1 - tmp2;

    dataptr[DCTSIZE*0] = (tmp10 + tmp11) * (float) 0.125; /* phase 3 */
    dataptr[DCTSIZE*4] = (tmp10 - tmp11) * (float) 0.125;

    z1 = (tmp12 + tmp13) * ((float) 0.707106781); /* c4 */
    dataptr[DCTSIZE*2] = (tmp13 + z1) * (float) 0.125; /* phase 5 */
    dataptr[DCTSIZE*6] = (tmp13 - z1) * (float) 0.125;

    /* Odd part */

    tmp10 = tmp4 + tmp5;	/* phase 2 */
    tmp11 = tmp5 + tmp6;
    tmp12 = tmp6 + tmp7;

    /* The rotator is modified from fig 4-8 to avoid extra negations. */
    z5 = (tmp10 - tmp12) * ((float) 0.382683433); /* c6 */
    z2 = ((float) 0.541196100) * tmp10 + z5; /* c2-c6 */
    z4 = ((float) 1.306562965) * tmp12 + z5; /* c2+c6 */
    z3 = tmp11 * ((float) 0.707106781); /* c4 */

    z11 = tmp7 + z3;		/* phase 5 */
    z13 = tmp7 - z3;

    dataptr[DCTSIZE*5] = (z13 + z2) * (float) 0.125; /* phase 6 */
    dataptr[DCTSIZE*3] = (z13 - z2) * (float) 0.125;
    dataptr[DCTSIZE*1] = (z11 + z4) * (float) 0.125;
    dataptr[DCTSIZE*7] = (z11 - z4) * (float) 0.125;

    dataptr++;			/* advance pointer to next column */
  }
}


/* Inverse DCT (ANN method) in float on a 8x8 block */

void
fidct_buffer(RCOEFBUFFER coef_block, RSAMPBUFFER output_buf)
{
  float tmp0, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7;
  float tmp10, tmp11, tmp12, tmp13;
  float z5, z10, z11, z12, z13;
  float * inptr;
  RSAMPBUFFER outptr;
  float * wsptr;
  int ctr;
  float workspace[DCTSIZE2]; /* buffers data between passes */

  /* Pass 1: process columns from input, store into work array. */

  
  inptr = coef_block;
  wsptr = workspace;
  for (ctr = DCTSIZE; ctr > 0; ctr--) {
    /* Due to quantization, we will usually find that many of the input
     * coefficients are zero, especially the AC terms.  We can exploit this
     * by short-circuiting the IDCT calculation for any column in which all
     * the AC terms are zero.  In that case each output is equal to the
     * DC coefficient (with scale factor as needed).
     * With typical images and quantization tables, half or more of the
     * column DCT calculations can be simplified this way.
     */

    if ((inptr[DCTSIZE*1]==0) && (inptr[DCTSIZE*2]==0) && (inptr[DCTSIZE*3]==0) &&
	(inptr[DCTSIZE*4]==0) && (inptr[DCTSIZE*5]==0) && (inptr[DCTSIZE*6]==0) &&
	(inptr[DCTSIZE*7] == 0)) {
      /* AC terms all zero */
      float dcval = inptr[DCTSIZE*0];

      wsptr[DCTSIZE*0] = dcval;
      wsptr[DCTSIZE*1] = dcval;
      wsptr[DCTSIZE*2] = dcval;
      wsptr[DCTSIZE*3] = dcval;
      wsptr[DCTSIZE*4] = dcval;
      wsptr[DCTSIZE*5] = dcval;
      wsptr[DCTSIZE*6] = dcval;
      wsptr[DCTSIZE*7] = dcval;

      inptr++;			/* advance pointers to next column */
      wsptr++;
      continue;
    }

    /* Even part */

    tmp0 = inptr[DCTSIZE*0];
    tmp1 = inptr[DCTSIZE*2];
    tmp2 = inptr[DCTSIZE*4];
    tmp3 = inptr[DCTSIZE*6];

    tmp10 = tmp0 + tmp2;	/* phase 3 */
    tmp11 = tmp0 - tmp2;

    tmp13 = tmp1 + tmp3;	/* phases 5-3 */
    tmp12 = (tmp1 - tmp3) * ((double) 1.414213562) - tmp13; /* 2*c4 */

    tmp0 = tmp10 + tmp13;	/* phase 2 */
    tmp3 = tmp10 - tmp13;
    tmp1 = tmp11 + tmp12;
    tmp2 = tmp11 - tmp12;

    /* Odd part */

    tmp4 = inptr[DCTSIZE*1];
    tmp5 = inptr[DCTSIZE*3];
    tmp6 = inptr[DCTSIZE*5];
    tmp7 = inptr[DCTSIZE*7];

    z13 = tmp6 + tmp5;		/* phase 6 */
    z10 = tmp6 - tmp5;
    z11 = tmp4 + tmp7;
    z12 = tmp4 - tmp7;

    tmp7 = z11 + z13;		/* phase 5 */
    tmp11 = (z11 - z13) * ((float) 1.414213562); /* 2*c4 */

    z5 = (z10 + z12) * ((float) 1.847759065); /* 2*c2 */
    tmp10 = ((float) 1.082392200) * z12 - z5; /* 2*(c2-c6) */
    tmp12 = ((float) -2.613125930) * z10 + z5; /* -2*(c2+c6) */

    tmp6 = tmp12 - tmp7;	/* phase 2 */
    tmp5 = tmp11 - tmp6;
    tmp4 = tmp10 + tmp5;

    wsptr[DCTSIZE*0] = tmp0 + tmp7;
    wsptr[DCTSIZE*7] = tmp0 - tmp7;
    wsptr[DCTSIZE*1] = tmp1 + tmp6;
    wsptr[DCTSIZE*6] = tmp1 - tmp6;
    wsptr[DCTSIZE*2] = tmp2 + tmp5;
    wsptr[DCTSIZE*5] = tmp2 - tmp5;
    wsptr[DCTSIZE*4] = tmp3 + tmp4;
    wsptr[DCTSIZE*3] = tmp3 - tmp4;

    inptr++;			/* advance pointers to next column */
    wsptr++;
  }

  /* Pass 2: process rows from work array, store into output array. */
  /* Note that we must descale the results by a factor of 8 == 2**3. */

  wsptr = workspace;
  outptr = output_buf;
  for (ctr = 0; ctr < DCTSIZE; ctr++) {

    /* Even part */

    tmp10 = wsptr[0] + wsptr[4];
    tmp11 = wsptr[0] - wsptr[4];

    tmp13 = wsptr[2] + wsptr[6];
    tmp12 = (wsptr[2] - wsptr[6]) * ((float) 1.414213562) - tmp13;

    tmp0 = tmp10 + tmp13;
    tmp3 = tmp10 - tmp13;
    tmp1 = tmp11 + tmp12;
    tmp2 = tmp11 - tmp12;

    /* Odd part */

    z13 = wsptr[5] + wsptr[3];
    z10 = wsptr[5] - wsptr[3];
    z11 = wsptr[1] + wsptr[7];
    z12 = wsptr[1] - wsptr[7];

    tmp7 = z11 + z13;
    tmp11 = (z11 - z13) * ((float) 1.414213562);

    z5 = (z10 + z12) * ((float) 1.847759065); /* 2*c2 */
    tmp10 = ((float) 1.082392200) * z12 - z5; /* 2*(c2-c6) */
    tmp12 = ((float) -2.613125930) * z10 + z5; /* -2*(c2+c6) */

    tmp6 = tmp12 - tmp7;
    tmp5 = tmp11 - tmp6;
    tmp4 = tmp10 + tmp5;

    /* Final output stage: scale down by a factor of 8 and range-limit */

    outptr[0] = (tmp0 + tmp7)*(float)0.125 + RAWCENTER;
    outptr[7] = (tmp0 - tmp7)*(float)0.125 + RAWCENTER;
    outptr[1] = (tmp1 + tmp6)*(float)0.125 + RAWCENTER;
    outptr[6] = (tmp1 - tmp6)*(float)0.125 + RAWCENTER;
    outptr[2] = (tmp2 + tmp5)*(float)0.125 + RAWCENTER;
    outptr[5] = (tmp2 - tmp5)*(float)0.125 + RAWCENTER;
    outptr[4] = (tmp3 + tmp4)*(float)0.125 + RAWCENTER;
    outptr[3] = (tmp3 - tmp4)*(float)0.125 + RAWCENTER;
   
    outptr += DCTSIZE;
    wsptr += DCTSIZE;		/* advance pointer to next row */
  }
}

/* DCT (ANN method) in float on a 8x8 block */

void
fdct_buffer(RSAMPBUFFER in_data, RCOEFBUFFER out_data)
{
  float tmp0, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7;
  float tmp10, tmp11, tmp12, tmp13;
  float z1, z2, z3, z4, z5, z11, z13;
  RCOEFBUFFER dataptr;
  int ctr,i;

  /* step 0 :  make data signed */

  dataptr = out_data;
  for(i=0;i<DCTSIZE;i++) {
    *dataptr++ = ( *in_data++ - RAWCENTER  );
    *dataptr++ = ( *in_data++ - RAWCENTER );
    *dataptr++ = ( *in_data++ - RAWCENTER );
    *dataptr++ = ( *in_data++ - RAWCENTER );
    *dataptr++ = ( *in_data++ - RAWCENTER );
    *dataptr++ = ( *in_data++ - RAWCENTER );
    *dataptr++ = ( *in_data++ - RAWCENTER );
    *dataptr++ = ( *in_data++ - RAWCENTER );
  }

  /* Pass 1: process rows. */

  dataptr = out_data;
  for (ctr = DCTSIZE-1; ctr >= 0; ctr--) {
    tmp0 = dataptr[0] + dataptr[7];
    tmp7 = dataptr[0] - dataptr[7];
    tmp1 = dataptr[1] + dataptr[6];
    tmp6 = dataptr[1] - dataptr[6];
    tmp2 = dataptr[2] + dataptr[5];
    tmp5 = dataptr[2] - dataptr[5];
    tmp3 = dataptr[3] + dataptr[4];
    tmp4 = dataptr[3] - dataptr[4];

    /* Even part */

    tmp10 = tmp0 + tmp3;	/* phase 2 */
    tmp13 = tmp0 - tmp3;
    tmp11 = tmp1 + tmp2;
    tmp12 = tmp1 - tmp2;

    dataptr[0] = tmp10 + tmp11; /* phase 3 */
    dataptr[4] = tmp10 - tmp11;

    z1 = (tmp12 + tmp13) * ((float) 0.707106781); /* c4 */
    dataptr[2] = tmp13 + z1;	/* phase 5 */
    dataptr[6] = tmp13 - z1;

    /* Odd part */

    tmp10 = tmp4 + tmp5;	/* phase 2 */
    tmp11 = tmp5 + tmp6;
    tmp12 = tmp6 + tmp7;

    /* The rotator is modified from fig 4-8 to avoid extra negations. */
    z5 = (tmp10 - tmp12) * ((float) 0.382683433); /* c6 */
    z2 = ((float) 0.541196100) * tmp10 + z5; /* c2-c6 */
    z4 = ((float) 1.306562965) * tmp12 + z5; /* c2+c6 */
    z3 = tmp11 * ((float) 0.707106781); /* c4 */

    z11 = tmp7 + z3;		/* phase 5 */
    z13 = tmp7 - z3;

    dataptr[5] = z13 + z2;	/* phase 6 */
    dataptr[3] = z13 - z2;
    dataptr[1] = z11 + z4;
    dataptr[7] = z11 - z4;

    dataptr += DCTSIZE;		/* advance pointer to next row */
  }

  /* Pass 2: process columns. */

  dataptr = out_data;
  for (ctr = DCTSIZE-1; ctr >= 0; ctr--) {
    tmp0 = dataptr[DCTSIZE*0] + dataptr[DCTSIZE*7];
    tmp7 = dataptr[DCTSIZE*0] - dataptr[DCTSIZE*7];
    tmp1 = dataptr[DCTSIZE*1] + dataptr[DCTSIZE*6];
    tmp6 = dataptr[DCTSIZE*1] - dataptr[DCTSIZE*6];
    tmp2 = dataptr[DCTSIZE*2] + dataptr[DCTSIZE*5];
    tmp5 = dataptr[DCTSIZE*2] - dataptr[DCTSIZE*5];
    tmp3 = dataptr[DCTSIZE*3] + dataptr[DCTSIZE*4];
    tmp4 = dataptr[DCTSIZE*3] - dataptr[DCTSIZE*4];

    /* Even part */

    tmp10 = tmp0 + tmp3;	/* phase 2 */
    tmp13 = tmp0 - tmp3;
    tmp11 = tmp1 + tmp2;
    tmp12 = tmp1 - tmp2;

    dataptr[DCTSIZE*0] = (tmp10 + tmp11) * (float) 0.125; /* phase 3 */
    dataptr[DCTSIZE*4] = (tmp10 - tmp11) * (float) 0.125;

    z1 = (tmp12 + tmp13) * ((float) 0.707106781); /* c4 */
    dataptr[DCTSIZE*2] = (tmp13 + z1) * (float) 0.125; /* phase 5 */
    dataptr[DCTSIZE*6] = (tmp13 - z1) * (float) 0.125;

    /* Odd part */

    tmp10 = tmp4 + tmp5;	/* phase 2 */
    tmp11 = tmp5 + tmp6;
    tmp12 = tmp6 + tmp7;

    /* The rotator is modified from fig 4-8 to avoid extra negations. */
    z5 = (tmp10 - tmp12) * ((float) 0.382683433); /* c6 */
    z2 = ((float) 0.541196100) * tmp10 + z5; /* c2-c6 */
    z4 = ((float) 1.306562965) * tmp12 + z5; /* c2+c6 */
    z3 = tmp11 * ((float) 0.707106781); /* c4 */

    z11 = tmp7 + z3;		/* phase 5 */
    z13 = tmp7 - z3;

    dataptr[DCTSIZE*5] = (z13 + z2) * (float) 0.125; /* phase 6 */
    dataptr[DCTSIZE*3] = (z13 - z2) * (float) 0.125;
    dataptr[DCTSIZE*1] = (z11 + z4) * (float) 0.125;
    dataptr[DCTSIZE*7] = (z11 - z4) * (float) 0.125;

    dataptr++;			/* advance pointer to next column */
  }
}

/* IDCT on the whole image */

void
fdct_inverse_image(RCOEFBUFFER coefdct, RSAMPBUFFER out,
    const int w, int const h)
{
  int i,j,x,y,adr;
  RSAMP * ptr;
  RSAMP out_gray[DCTSIZE2]; 
  for (i=0; i<h; i+=DCTSIZE)
    for (j=0; j<w;j+=DCTSIZE) 
      {
	adr=(i*w+j);    
	fidct_buffer(coefdct, out_gray);
	coefdct+=DCTSIZE2;
	ptr=out_gray;
	for (y=0;y<DCTSIZE;y++)
	  for (x=0;x<DCTSIZE;x++)
	    out[adr+x+y*w]=*(ptr++);
      }
}

/* DCT on the whole image */

void
fdct_image (RCOEFBUFFER coefdct, RSAMPBUFFER in,
    const int w, int const h)
{
  int i,j,x,y,adr;
  RSAMP in_gray[DCTSIZE2];
  RSAMP * ptr;
  for (i=0; i<h; i+=DCTSIZE)
    for (j=0; j<w;j+=DCTSIZE) 
    {
      ptr=in_gray;
      adr=(i*w+j);    
      for (y=0;y<DCTSIZE;y++)
	for (x=0;x<DCTSIZE;x++)
	  *(ptr++)=in[adr+x+y*w];
      fdct_buffer(in_gray, coefdct);
      coefdct+=DCTSIZE2;
    }
}
