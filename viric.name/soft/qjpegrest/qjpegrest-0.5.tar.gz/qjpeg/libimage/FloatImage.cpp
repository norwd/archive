/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include "JPEGData.h"
#include "FloatImage.h"
#include "FloatPlane.h"
#include "ARGBImage.h"
#include "GrayImage.h"
#include "Error.h"
#include <cstring>
extern "C" {
#include <stdio.h>
#include <pam.h>
}

/*! Create the object without any FloatPlane */
FloatImage::FloatImage()
{
    ready = false;
}


/*! Create a FloatImage for the given planes */
FloatImage::FloatImage(FloatPlane _plane[], const unsigned int _components)
{
    components = _components;
    plane = new FloatPlane[3];
    /* Copy FloatPlanes */
    for(unsigned int i=0; i<components; i++)
        plane[i] = _plane[i];
    ready = true;
}

/*! Create new n FloatPlanes for this image */
void FloatImage::setComponents(unsigned int n)
{
    if (ready == true)
        delete[] plane;

    components = n;

    plane = new FloatPlane[n];
    ready = true;
}

/*! Free the floatplanes' pointeres, and delete them */
void FloatImage::free()
{
    if (!ready)
        return;

    for(unsigned int i=0; i<components; i++)
        plane[i].free();

    delete[] plane;

    ready = false;
}

/*! Returns true if all the planes have the same width and height */
bool FloatImage::sameDimensions() const
{
    bool res = true;

    unsigned int width = plane[0].getWidth();
    unsigned int height = plane[0].getHeight();
    for(unsigned int i=1; i<components; i++)
    {
        if(plane[i].getWidth() != width || plane[i].getHeight() != height)
        {
            res = false;
            break;
        }
    }
    return res;
}

/*! Writes the planes as an RGB PPM to the given filename. */
void FloatImage::writePPM(const char *filename) const
{
    if (components != 3 && components != 1)
        return;
    if (!sameDimensions())
        return;

    unsigned int width = plane[0].getWidth();
    unsigned int height = plane[0].getHeight();
    unsigned int MAXVALUE = plane[0].getMaxValue();

    struct pam outpam;
    unsigned int row;
    tuple *tuplerow;
 
    FILE* file;

    if (!ready)
        return;

    file = fopen(filename, "wb");
    if (file == NULL)
        return;


    outpam.size = sizeof(outpam);
    outpam.len = outpam.size;
    outpam.file = file;
    if (components == 3)
    {
        outpam.format = PPM_FORMAT;
        outpam.depth = 3; /* RGB - 3 sample per tuple */
        std::strcpy(outpam.tuple_type, "RGB"); /* PNM non transparent */
    }
    else
    {
        outpam.format = PGM_FORMAT;
        outpam.depth = 1; /* GRAYSCALE - 1 sample per tuple */
        std::strcpy(outpam.tuple_type, "GRAYSCALE"); /* PGM non transparent */
    }
    outpam.plainformat = 0; /* false */
    outpam.width = width;
    outpam.height = height;
    outpam.allocation_depth = 0; /* Same as depth. */
    outpam.maxval = MAXVALUE;

    float *ptr[components];
    for(unsigned int i=0; i<components; ++i)
    {
        ptr[0] = plane[0].ptr;
        ptr[1] = plane[1].ptr;
        ptr[2] = plane[2].ptr;
    }
 
    /* needs size,len,file,format,height,width,depth,maxval, tuple_type */
    pnm_writepaminit(&outpam);
 
    tuplerow = pnm_allocpamrow(&outpam);
 
    for (row = 0; row < height; row++) {
        unsigned int column;
        for (column = 0; column < width; ++column) {
            /* Only one plane */
            /* float to int! */
            for(unsigned int sample = 0; sample < components; ++sample)
                tuplerow[column][sample] =
                    plane[sample].roundsample(ptr[sample][column+width*row]);
        }
        pnm_writepamrow(&outpam, tuplerow);
    }
 
    pnm_freepamrow(tuplerow);
    fclose(file);
}

ARGBImage * FloatImage::getARGB() const
{
    if (!sameDimensions())
        throw new Error::WrongDimensions();

    unsigned int width = plane[0].getWidth();
    unsigned int height = plane[0].getHeight();

    plane[0].check();
    plane[1].check();
    plane[2].check();

    if (components != 3)
        throw new Error::UnsupportedColorspace();

    unsigned int *myptr;
    unsigned int value;

    ARGBImage *img = new ARGBImage(width, height);
    myptr = img->data();
    /* The data should be encoded 0xFFRRGGBB. */
    for(unsigned int j = 0; j < height; ++j)
        for(unsigned int i = 0; i < width; ++i)
        {
            value = 0xff000000;
            value |= (FloatPlane::roundsample(plane[0].get(i,j)) & 0xff)
                << 16;
            value |= (FloatPlane::roundsample(plane[1].get(i,j)) & 0xff)
                << 8;
            value |= (FloatPlane::roundsample(plane[2].get(i,j)) & 0xff);
            *myptr = value;
            ++myptr;
        }
    return img;
}

GrayImage * FloatImage::getGray() const
{
    unsigned int width = plane[0].getWidth();
    unsigned int height = plane[0].getHeight();

    if (components != 1)
        throw new Error::UnsupportedColorspace();

    unsigned char *myptr;

    GrayImage *img = new GrayImage(width, height);
    myptr = img->data();
    for(unsigned int j = 0; j < height; ++j)
        for(unsigned int i = 0; i < width; ++i)
        {
            *myptr = FloatPlane::roundsample(plane[0].get(i,j)) & 0xff;
            ++myptr;
        }
    return img;
}

unsigned int FloatImage::getWidth() const
{
    if (!sameDimensions())
        throw new Error::WrongDimensions();

    return plane[0].getWidth();
}

unsigned int FloatImage::getHeight() const
{
    if (!sameDimensions())
        throw new Error::WrongDimensions();

    return plane[0].getHeight();
}
