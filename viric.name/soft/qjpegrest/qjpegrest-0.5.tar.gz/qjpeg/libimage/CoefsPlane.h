/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class ComponentData;

enum { DCTSize = 8, DCTSize2 = 64 };

class CoefsPlane
{
    unsigned int width_in_blocks;
    unsigned int height_in_blocks;

    bool ready;

    float *ptr;
    /*! JPEG Data related to the component. For example, the quantization
     * tables */
    ComponentData parameters;

public:
    const static int jpeg_natural_order[DCTSize2];
    const static int jpeg_zigzag_order[DCTSize2];

    /*! Forget the last *ptr, and allocate space for a new float * ptr */
    void allocate(const unsigned int _width_in_blocks, const unsigned int _height_in_blocks);

    /*! Create an object, but with no memory related to its float * ptr. */
    CoefsPlane();
    /*! Create an object, with a related * ptr. */
    CoefsPlane(float *_ptr, const unsigned int _width_in_blocks,
            const unsigned int _height_in_blocks);
    /*! Create an object, allocating new memory for its related * ptr. */
    CoefsPlane(const unsigned int _width_in_blocks,
            const unsigned int _height_in_blocks);

    inline unsigned int getWidthInBlocks() const
    {
        return width_in_blocks;
    }
    inline unsigned int getHeightInBlocks() const
    {
        return height_in_blocks;
    }
    /*! Give direct access to the buffer */
    inline float * getPtr() const
    {
        return ptr;
    }

    /*! Get the JPEG parameters related to this component. */
    ComponentData getParameters() const
    {
        return parameters;
    }
    /*! Set the JPEG parameters related to this component. */
    ComponentData setParameters(const ComponentData &c)
    {
        parameters = c;
    }
    /*! Free the memory allocated to ptr and any heap memory managed by this
     * object. */
    void free();
    /*! Set the pixel value */
    inline void set(unsigned int bcolumn, unsigned int brow, 
            unsigned int coef, float val)
    {
        ptr[((brow * width_in_blocks) + bcolumn)*64 + coef] = val;
    }

    /*! Get the pixel value */
    inline float get(unsigned int bcolumn, unsigned int brow, 
            unsigned int coef) const
    {
        return ptr[((brow * width_in_blocks) + bcolumn)*64 + coef];
    }

    /*! Create a copy of this plane, copying also the data to a new ptr */
    CoefsPlane newcopy();
};
