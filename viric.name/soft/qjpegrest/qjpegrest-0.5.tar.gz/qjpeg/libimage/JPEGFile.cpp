/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <cstring>
#include <vector>
extern "C"
{
#include <stdio.h>
#include <jpeglib.h>
}

#include "FloatPlane.h"
#include "JPEGData.h"
#include "CoefsPlane.h"
#include "FloatImage.h"
#include "CoefsImage.h"
#include "JPEGFile.h"
#include "Error.h"

using std::vector;

JPEGFile::JPEGFile(const char *_filename)
{
    using namespace std;
    filename = new char[std::strlen(_filename) + 1];
    std::strcpy(filename, _filename);
    srcinfo = new jpeg_decompress_struct;
    jsrcerr = new jpeg_error_mgr;
    createQtableFactors();
}

char * JPEGFile::getFileName() const
{
    return filename;
}

void JPEGFile::createQtableFactors()
{
    static const double aanscalefactor[DCTSIZE] =
    {
        1.0, 1.387039845, 1.306562965, 1.175875602,
        1.0, 0.785694958, 0.541196100, 0.275899379
    };

    int i = 0;
    for(int row = 0; row < DCTSIZE; ++row)
        for(int col = 0; col < DCTSIZE; ++col)
        {
            qtable_factors[i] = aanscalefactor[row] * aanscalefactor[col];
            i++;
        }
}

int JPEGFile::readHeader()
{
    srcinfo->err = jpeg_std_error(jsrcerr);

    jpeg_create_decompress(srcinfo);

    inputh = fopen(filename, "rb");
    if (inputh == 0)
        return -1;

    jpeg_stdio_src(srcinfo, inputh);
    jpeg_read_header(srcinfo, TRUE);

    if (srcinfo->num_components > 4)
    {
        /* Error - unknown colorspace */
        jpeg_destroy_decompress(srcinfo);
        fclose(inputh);
        throw Error::UnsupportedColorspace();
    }
    params.num_components = srcinfo->num_components;
    params.width = srcinfo->image_width;
    params.height = srcinfo->image_height;
    params.max_h_samp_factor = srcinfo->max_h_samp_factor;
    params.max_v_samp_factor = srcinfo->max_v_samp_factor;
    if (srcinfo->jpeg_color_space == JCS_YCbCr)
        params.colorspace = Colorspace(YCbCr);
    else if (srcinfo->jpeg_color_space == JCS_GRAYSCALE)
        params.colorspace = Colorspace(GRAYSCALE);
    else
    {
        /* Error - unknown colorspace */
        jpeg_destroy_decompress(srcinfo);
        fclose(inputh);
        throw Error::UnsupportedColorspace();
    }

    for(int c = 0; c < params.num_components; ++c)
    {
        params.components[c].h_samp_factor =
            srcinfo->comp_info[c].h_samp_factor;
        params.components[c].v_samp_factor =
            srcinfo->comp_info[c].v_samp_factor;
        params.components[c].width_in_blocks =
            srcinfo->comp_info[c].width_in_blocks;
        params.components[c].height_in_blocks =
            srcinfo->comp_info[c].height_in_blocks;
    }
    return 0; /* OK */
}

void JPEGFile::clearQtables()
{
    vector<torig_qtable>::const_iterator i;
    for(i = orig_qtables.begin(); i != orig_qtables.end(); ++i)
    {
        delete[] *i;
    }
    orig_qtables.clear();

    vector<tqtable>::const_iterator j;
    for(j = qtables.begin(); j != qtables.end(); ++j)
    {
        delete[] *j;
    }
    qtables.clear();
}

void JPEGFile::newQtables(unsigned int nplanes)
{
    clearQtables();
    for (int p=0; p<nplanes; ++p)
    {
        torig_qtable oq = new int [64];
        tqtable q = new float [64];
        for (int i=0; i < 64; ++i)
        {
            oq[i] = srcinfo->comp_info[p].quant_table->quantval[i];
            q[i] = qtable_factors[i] * oq[i];
            params.components[p].qtable[i] = q[i];
        }
        qtables.push_back(q);
        orig_qtables.push_back(oq);
    }
}

FloatImage *JPEGFile::getiDCTImage()
{
    int res;
    res = readHeader();
    if (res != 0)
        return 0;

    /* Set our JPEG decompression parameters */
    srcinfo->dct_method = JDCT_FLOAT;

    /* jpeglib don't do any postprocessing (scaling/colorq). */
    srcinfo->raw_data_out = TRUE;
    
    /* Start decompression of pixels */
    jpeg_start_decompress(srcinfo);

    unsigned int nplanes = srcinfo->num_components;

    /* Create the planes */
    FloatPlane *planes = new FloatPlane[nplanes];
    unsigned int width[nplanes];
    unsigned int height[nplanes];
    unsigned int max_width_in_blocks = 0;

    /* Get the pointers to the planes */
    float *bmp[srcinfo->out_color_components];
    for (unsigned int i=0; i < nplanes; i++)
    {
        /* get the dimensions for every plane*/
        width[i] = srcinfo->comp_info[i].downsampled_width;
        height[i] = srcinfo->comp_info[i].downsampled_height;

        if (srcinfo->comp_info[i].width_in_blocks > max_width_in_blocks)
            max_width_in_blocks = srcinfo->comp_info[i].width_in_blocks;
        /* Allocate and prepare bmp[] */
        planes[i].allocate(width[i], height[i]);
        bmp[i] = planes[i].ptr;
    }

    /* The function jpeg_read_raw_data will return an MCU per call */
    int nscanlines = srcinfo->max_v_samp_factor*DCTSIZE;

    /* Get memory for the buffer scanline pointers */
    JSAMPARRAY *scanplanes = new JSAMPARRAY[nplanes];

    /* Get memory for each scanline in the buffer */
    for (unsigned int plane = 0; plane < nplanes; ++plane)
    {
        scanplanes[plane] = new JSAMPROW[nscanlines];
        for (int isl = 0; isl < nscanlines; ++isl)
            scanplanes[plane][isl] = new JSAMPLE[max_width_in_blocks * DCTSIZE];
    }

    unsigned int row[nplanes];
    unsigned int div_v_factor[nplanes];
    for (unsigned int plane = 0; plane < nplanes; ++plane)
    {
        row[plane] = 0;
        div_v_factor[plane] = srcinfo->max_v_samp_factor /
            srcinfo->comp_info[plane].v_samp_factor;
    }

    while (srcinfo->output_scanline < srcinfo->output_height) {
        int read_scanlines =
            jpeg_read_raw_data(srcinfo, scanplanes, nscanlines);
        for (unsigned int plane = 0; plane < nplanes; ++plane)
        {
            if (row[plane] >= height[plane])
                continue;
            for (int isl = 0; isl < (read_scanlines / (int) div_v_factor[plane]); ++isl)
            {
                for (unsigned int column = 0; column < width[plane];
                    ++column) {
                    bmp[plane][row[plane] * width[plane] + column] =
                        scanplanes[plane][isl][column];
                }
            ++row[plane];
            }
        }
    }


    FloatImage *i = new FloatImage(planes, nplanes);

    i->jpegparameters = params;

    jpeg_destroy_decompress(srcinfo);

    fclose(inputh);

    delete[] planes;
    for (unsigned int plane = 0; plane < nplanes; ++plane)
    {
        for (int isl = 0; isl < nscanlines; ++isl)
            delete[] scanplanes[plane][isl];
        delete[] scanplanes[plane];
    }
    delete[] scanplanes;

    return i;
}

FloatImage *JPEGFile::getUnpackedImage()
{
    int res;
    res = readHeader();
    if (res != 0)
        return 0;

    /* Set our JPEG decompression parameters */
    srcinfo->do_fancy_upsampling = 1;
    srcinfo->dct_method = JDCT_FLOAT;

    /* Get the number of planes */
    if (srcinfo->num_components == 1 &&
            srcinfo->jpeg_color_space == JCS_GRAYSCALE) {
        srcinfo->out_color_components = 1;
        srcinfo->out_color_space = JCS_GRAYSCALE;
    }
    else {
        srcinfo->out_color_components = 3;
        srcinfo->out_color_space = JCS_RGB;
    }

    /* Start decompression of pixels */
    jpeg_start_decompress(srcinfo);

    unsigned int nplanes = srcinfo->out_color_components;

    /* Create the planes */
    FloatPlane *planes = new FloatPlane[nplanes];

    /* Get the pointers to the planes */
    float *bmp[srcinfo->out_color_components];
    for (unsigned int i=0; i < nplanes; i++)
    {
        planes[i].allocate(srcinfo->output_width, srcinfo->output_height);
        bmp[i] = planes[i].ptr;
    }

    /* Get the recommended number of buffer scanlines */
    int nscanlines = srcinfo->rec_outbuf_height;

    /* Get memory for the buffer scanline pointers */
    JSAMPROW *scanlines = new JSAMPROW[nscanlines];

    /* Get memory for each scanline in the buffer */
    for (int isl = 0; isl < nscanlines; ++isl)
    {
        scanlines[isl] = new JSAMPLE[srcinfo->output_width * nplanes];
    }

    int row = 0;
    while (srcinfo->output_scanline < srcinfo->output_height) {
        int read_scanlines =
            jpeg_read_scanlines(srcinfo, scanlines, nscanlines);
        for (int isl = 0; isl < read_scanlines; ++isl)
        {
            for (unsigned int column = 0; column < srcinfo->output_width;
                    ++column) {
                for (unsigned int plane = 0; plane < nplanes; plane++)
                    bmp[plane][row * srcinfo->output_width + column] =
                        scanlines[isl][column * srcinfo->out_color_components
                        + plane];
            }
            ++row;
        }
    }


    FloatImage *i = new FloatImage(planes, nplanes);

    i->jpegparameters = params;

    jpeg_destroy_decompress(srcinfo);

    fclose(inputh);

    delete[] planes;
    for (int isl = 0; isl < nscanlines; ++isl)
        delete[] scanlines[isl];
    delete[] scanlines;

    return i;
}

int JPEGFile::loadQtables()
{
    int res;
    res = readHeader();
    if (res != 0)
        return -1;

    unsigned int nplanes = srcinfo->num_components;

    jpeg_start_decompress(srcinfo);

    /* The qtables are not read before calling jpeg_read_coefficients() */
    newQtables(nplanes);

    fclose(inputh);
    return 0;
}

CoefsImage *JPEGFile::getCoefs()
{
    int res;
    res = readHeader();
    if (res != 0)
        return 0;

    unsigned int nplanes = srcinfo->num_components;


    /* Create the planes */
    CoefsPlane *planes = new CoefsPlane[nplanes];
    unsigned int width_in_blocks[nplanes];
    unsigned int height_in_blocks[nplanes];
    unsigned int max_width_in_blocks = 0;

    /* Pointers to the planes of Image (FloatPlanes) */
    float *bmp[srcinfo->out_color_components];
    for (unsigned int i=0; i < nplanes; ++i)
    {
        /* get the dimensions for every plane*/
        width_in_blocks[i] = srcinfo->comp_info[i].width_in_blocks;
        height_in_blocks[i] = srcinfo->comp_info[i].height_in_blocks;

        if (srcinfo->comp_info[i].width_in_blocks > max_width_in_blocks)
            max_width_in_blocks = srcinfo->comp_info[i].width_in_blocks;
        /* Allocate and prepare bmp[] */
        planes[i].allocate(width_in_blocks[i], height_in_blocks[i]);
        bmp[i] = planes[i].getPtr();
    }

    jvirt_barray_ptr *arrays = jpeg_read_coefficients(srcinfo);

    newQtables(nplanes);

    /* Load the coefs */
    for(unsigned int plane=0; plane < nplanes; plane++)
    {
        tqtable pqtable = qtables[plane]; /* vector operator */
        planes[plane].setParameters(params.components[plane]);

        for (unsigned int brow = 0; brow < height_in_blocks[plane]; ++brow)
        {
            JBLOCKARRAY buffer = (*srcinfo->mem->access_virt_barray)
                ((j_common_ptr) srcinfo, arrays[plane],
                 (JDIMENSION) brow,
                 (JDIMENSION) 1, FALSE);
            for (unsigned int bcolumn = 0; bcolumn < width_in_blocks[plane];
                ++bcolumn) 
            {
                unsigned int offset = (brow*width_in_blocks[plane] +
                        bcolumn)*DCTSize2;
                /* We apply a factor conversion for the IDCTs _assumed_ in all
                 * the program. For them to work, all coefficients should be
                 * scaled. */
                for (unsigned int c = 0; c < DCTSIZE2; ++c)
                    bmp[plane][offset + c] = (float) buffer[0][bcolumn][c] * pqtable[c];
            }
        }
    }


    CoefsImage *i = new CoefsImage(planes, nplanes);

    i->jpegparameters = params;

    jpeg_destroy_decompress(srcinfo);

    fclose(inputh);

    delete[] planes;

    return i;
}

JPEGFile::~JPEGFile()
{
    clearQtables();
    delete[] filename;
    delete srcinfo;
    delete jsrcerr;
}
