/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QString>
#include "ActionType.h"
#include "ActionManager.h"
#include "ActionCreator.h"

ActionManager * ActionManager::manager;

ActionManager::ActionManager()
{
    manager = this;
}

void ActionManager::sreg(const char *name, const ActionCreator *creator)
{
    manager->reg(name, creator);
}

void ActionManager::reg(const char *name, const ActionCreator *creator)
{
    /* qDebug("Registered %s of type %i", name, creator->getType()); */
    mymap[name] = creator;
}

const ActionCreator * ActionManager::find(const char *name) const
{
    return mymap.constFind(name).value();
}

const ActionCreator * ActionManager::sfind(const char *name)
{
    return manager->find(name);
}

void ActionManager::destroy()
{
    delete manager;
}

ActionManager::~ActionManager()
{
    typedef QMap<QString, const ActionCreator *>::const_iterator CI;
    /* Delete all ActionCreators from the map */
    for (CI i = mymap.begin(); i != mymap.end(); ++i)
    {
        delete i.value();
    };
}

QList<QString> ActionManager::getListOf(const ActionType t)
{
    typedef QMap<QString, const ActionCreator *>::const_iterator CI;
    QList<QString> out;
    for (CI i = manager->mymap.begin(); i != manager->mymap.end(); ++i)
        if (i.value()->getType() == t)
            out.append(QString(i.key()));
    return out;
}
