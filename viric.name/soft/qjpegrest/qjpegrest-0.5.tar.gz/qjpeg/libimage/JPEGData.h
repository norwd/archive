/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
/*! Colorspaces known to the application. By now, not referring to FloatImage,
 * but only to JPEGFiles.
 * \sa JPEGParameters */
enum Colorspace{
    GRAYSCALE,
    YCbCr,
    sRGB
};

typedef float Qtable[64];

/*! Stores the basic parameters to be known for a component of a JPEG file */
struct ComponentData
{
    int h_samp_factor;
    int v_samp_factor;

    int width_in_blocks;
    int height_in_blocks;
    /*! This will store the qtable for the component, not directly from the
     * file, but ready for AA&N DCT operations. */
    Qtable qtable;
};

/*! Stores the basic parameters for unpacking the JPEG file */
struct JPEGParameters
{
    unsigned int num_components;
    unsigned int width;
    unsigned int height;

    int max_h_samp_factor;
    int max_v_samp_factor;

    Colorspace colorspace;

    ComponentData components[4];
};
