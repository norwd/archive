/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include "FloatPlane.h"
#include "Error.h"
#include <cstring>

extern "C" {
#include <stdio.h>
#include <pam.h>
}

FloatPlane::FloatPlane()
{
    ready = false;
    ptr = 0;
}

FloatPlane::FloatPlane(float *_ptr)
{
    ptr = _ptr;
    ready = true;
}

FloatPlane::FloatPlane(const unsigned int _width, const unsigned int _height)
{
    allocate(_width, _height);

    ready = true;
}

void FloatPlane::allocate(const unsigned int _width, const unsigned int _height)
{
    width = _width;
    height = _height;
    ptr = new float[width*height];
    ready = true;
}

void FloatPlane::writePGM(const char * filename) const
{
    struct pam outpam;
    unsigned int row;
    tuple *tuplerow;
 
    FILE* file;

    if (!ready)
        return;

    file = fopen(filename, "wb");
    if (file == NULL)
        return;

    outpam.size = sizeof(outpam);
    outpam.len = outpam.size;
    outpam.file = file;
    outpam.format = PGM_FORMAT;
    outpam.plainformat = 0; /* false */
    outpam.width = width;
    outpam.height = height;
    outpam.depth = 1; /* Grayscale - 1 sample per tuple */
    outpam.allocation_depth = 0; /* Same as depth. */
    outpam.maxval = MAXVALUE;
    std::strcpy(outpam.tuple_type, "GRAYSCALE"); /* PGM non transparent */
 
    /* needs size,len,file,format,height,width,depth,maxval, tuple_type */
    pnm_writepaminit(&outpam);
 
    tuplerow = pnm_allocpamrow(&outpam);
 
    for (row = 0; row < height; row++) {
        unsigned int column;
        for (column = 0; column < width; ++column) {
            /* Only one plane */
            /* float to int! */
            tuplerow[column][0] = roundsample(ptr[column+width*row]);
        }
        pnm_writepamrow(&outpam, tuplerow);
    }
 
    pnm_freepamrow(tuplerow);
    fclose(file);
}

void FloatPlane::free()
{
    if (ready)
        delete[] ptr;
}

void FloatPlane::setzero()
{
    std::memset(ptr, 0, width*height*sizeof(float));
}

void FloatPlane::add(const FloatPlane &in)
{
    /* Check dimensions */
    if(in.getWidth() != width || in.getHeight() != height)
        throw new Error::WrongDimensions();

    for(unsigned int r=0; r<height; ++r)
        for(unsigned int c=0; c<width; ++c)
        {
            unsigned int adr = r*width + c;
            ptr[adr] += in.getPtr()[adr];
        }
}

FloatPlane FloatPlane::newcopy()
{
    FloatPlane n;

    n.allocate(width, height);
    std::memcpy(n.getPtr(), ptr,
            sizeof(float)*width*height);

    return n;
}

FloatPlane & FloatPlane::operator=(const FloatPlane &in)
{
    ptr = in.getPtr();
    width = in.getWidth();
    height = in.getHeight();
    ready = in.ready;
    return *this;
}

/*! This is a help for valgrind, because it can detect "jump condition of an
 * uninitialized value". With it we can know when a plane has uninitialized
 * pixels. */
FloatPlane FloatPlane::check()
{
    for(unsigned int i =0; i < width*height; ++i)
    {
        if (ptr[i] > 300)
        {
            ptr[i] = ptr[i];
        }
    }
}
