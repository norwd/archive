/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QString>
#include "ActionType.h"


QString actionType2String(enum ActionType type)
{
    switch(type)
    {
        case e_Undefined:
            return "Undefined";
        case e_IDCTPlane:
            return "IDCTPlane";
        case e_ImproveRawPlane:
            return "ImproveRawPlane";
        case e_Scaler:
            return "Scaler";
        case e_ColorMap:
            return "ColorMap";
        default:
            return "Error";
    };
}

enum ActionType string2ActionType(const QString &str)
{
    if (str.operator==("Undefined"))
        return e_Undefined;
    else if (str.operator==("IDCTPlane"))
        return e_IDCTPlane;
    else if (str.operator==("ImproveRawPlane"))
        return e_ImproveRawPlane;
    else if (str.operator==("Scaler"))
        return e_Scaler;
    else if (str.operator==("ColorMap"))
        return e_ColorMap;
    else
        return e_Undefined;
}
