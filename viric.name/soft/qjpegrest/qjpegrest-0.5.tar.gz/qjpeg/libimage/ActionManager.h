/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QList>
#include <QString>
#include <QMap>
/* REQUIRES ActionType.h */
class ActionCreator;
#include <iosfwd>


/*! Manages the Actions provided by the plugins.
 *
 * Only a single instance of it will exist in the whole process. Each plugin
 * will call the reg() method for getting into the global process database of
 * plugins.
 *
 * Each new Action will be asked to the ActionManager using get() proviting
 * a name (in string form), who will return the ActionCreator for it. */
class ActionManager
{
    /*! The pointer to the single ActionManager of the process */
    static ActionManager * manager;

public:
    ActionManager();

    QMap<QString,const ActionCreator*> mymap;

    /*! Register an action to the ActionManager */
    static void sreg(const char *name, const ActionCreator *creator);
    void reg(const char *name, const ActionCreator *creator);

    /*! Dump to stderr the list of registered actions */
    void dump() const;

    /*! Ask for the creator of the named plugin. */
   const ActionCreator * find(const char *name) const;
    static const ActionCreator * sfind(const char *name);
    static void destroy();
    static QList<QString> getListOf(const ActionType t);
    ~ActionManager();
};
