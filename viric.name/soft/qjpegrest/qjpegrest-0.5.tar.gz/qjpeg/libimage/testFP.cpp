/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include "FloatPlane.h"

int main()
{
    FloatPlane a;

    a.allocate(100,100);

    float *p = a.getPtr();
    unsigned int w = a.getWidth();

    for(int j=0; j < 100; j++)
        for(int i=0; i < 100; i++)
            p[j*w + i] = (float) ((i+j) % 255);

    a.writePGM("prova.pgm");

    a.free();
}
