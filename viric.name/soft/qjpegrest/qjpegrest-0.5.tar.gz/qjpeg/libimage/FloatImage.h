/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
/* Needs include JPEGData.h */
class FloatPlane;
class JPEGData;
class ARGBImage;
class GrayImage;

class FloatImage
{
    unsigned int components;
    bool ready;

public:
    JPEGParameters jpegparameters;

    FloatPlane *plane;

    FloatImage();
    FloatImage(FloatPlane _plane[], const unsigned int _components);

    bool sameDimensions() const;
    void free();
    void setComponents(unsigned int n);
    void writePPM(const char *filename) const;
    ARGBImage * getARGB() const;
    GrayImage * getGray() const;
    unsigned int getComponents() const
    {
        return components;
    }

    unsigned int getWidth() const;
    unsigned int getHeight() const;
};
