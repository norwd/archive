/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include "JPEGData.h"
#include "CoefsImage.h"
#include "CoefsPlane.h"

CoefsImage::CoefsImage()
{
    ready = false;
}


CoefsImage::CoefsImage(CoefsPlane _plane[], const unsigned int _components)
{
    components = _components;
    plane = new CoefsPlane[3];
    /* Copy CoefsPlanes */
    for(unsigned int i=0; i<components; i++)
        plane[i] = _plane[i];
    ready = true;
}

void CoefsImage::setComponents(unsigned int n)
{
    if (ready == true)
        delete[] plane;

    components = n;

    plane = new CoefsPlane[n];
    ready = true;
}

void CoefsImage::free()
{
    if (!ready)
        return;

    for(unsigned int i=0; i<components; i++)
        plane[i].free();

    delete[] plane;

    ready = false;
}
