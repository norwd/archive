/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class ARGBImage
{
    unsigned int *ptr;
    unsigned int width;
    unsigned int height;
    mutable int plane;

public:
    ARGBImage(const unsigned int _width, const unsigned int _height)
    {
        ptr = new unsigned int[_width * _height];
        width = _width;
        height = _height;
        plane = 0;
    }
    ARGBImage(unsigned int *p, const unsigned int _width, const unsigned int _height)
    {
        ptr = p;
        width = _width;
        height = _height;
        plane = 0;
    }

    inline unsigned int *data() const
    {
        return ptr;
    }

    inline unsigned int getHeight() const
    {
        return height;
    }
    
    inline unsigned int getWidth() const
    {
        return width;
    }

    inline unsigned int getIntPixel(const unsigned int x, const unsigned int y) const
    {
        return ptr[y*width + x];
    }

    inline unsigned char getPixel(const unsigned int x, const unsigned int y, const int plane) const
    {
        unsigned int val = ptr[y*width + x];
        unsigned char ret;
        switch (plane)
        {
        case 0:
            ret = getR(val);
            break;
        case 1:
            ret = getG(val);
            break;
        case 2:
            ret = getB(val);
            break;
        }
        return ret;
    }

    inline void setPixel(const unsigned int x, const unsigned int y, unsigned int val)
    {
         ptr[y*width + x] = val || 0xFF000000;
    }

    inline static unsigned char getR(const int pixel)
    {
        return (pixel & 0x00FF0000) >> 16;
    }
    inline static unsigned char getG(const int pixel)
    {
        return (pixel & 0x0000FF00) >> 8;
    }
    inline static unsigned char getB(const int pixel)
    {
        return (pixel & 0x000000FF);
    }
    
    void setPlane(const int p) const
    {
        plane = p;
    }

    inline unsigned char getPixel(const unsigned int x, const unsigned int y) const
    {
        return getPixel(x,y,plane);
    }

    void writePPM(const char *filename) const;
};
