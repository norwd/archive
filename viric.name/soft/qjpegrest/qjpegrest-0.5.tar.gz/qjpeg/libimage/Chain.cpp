/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include "Chain.h"
#include "JPEGData.h"
#include "Actions.h"
#include "FloatPlane.h"
#include "FloatImage.h"
#include "CoefsImage.h"
#include "CoefsPlane.h"
#include "ActionType.h"
#include "ActionCreator.h"
#include "ActionManager.h"

#include "ChainStorage.h"

Chain::Chain()
{
    components = 0;
    initial = 0;
    storage = new NormalChainStorage();
}

Chain::Chain(CoefsImage *ini)
{
    components = 0;
    storage = new NormalChainStorage();
    setInitial(ini);
}

/*! Destroys all the Action objects and frees the internal structures. */
void Chain::free()
{
    if (components > 0)
    {
        delete initial; /* This was a copy of the given data */
        initial = 0;

        storage->clearStructs();

        components = 0;
    }
}

void Chain::setInitial(CoefsImage *ini)
{
    free();
    initial = new CoefsImage();
    *initial = *ini;
    components = initial->getComponents();
    storage->setPlanes(components);
}

void Chain::setIDCTPlane(const unsigned int plane, IDCTPlane *idct)
{
    if (storage->idcts != 0 && plane < components)
    {
        storage->idcts[plane] = idct;
    }
}

void Chain::setIDCTPlane(const unsigned int plane, const char *name)
{
    IDCTPlane *idct;
    idct = ActionManager::sfind(name)->createIDCTPlane();
    setIDCTPlane(plane, idct);
}

void Chain::addImproveRawPlane(const unsigned int plane,
        ImproveRawPlane *improver)
{
    if (storage->improverawplanes != 0 && plane < components)
    {
        storage->improverawplanes[plane].push_back(improver);
    }
}

void Chain::addImproveRawPlane(const unsigned int plane, const char *name)
{
    ImproveRawPlane *improver;
    improver = ActionManager::sfind(name)->createImproveRawPlane();
    addImproveRawPlane(plane, improver);
}

void Chain::addColorMap(ColorMap *cmap)
{
    storage->colormaps.push_back(cmap);
}

void Chain::addColorMap(const char *name)
{
    ColorMap *cmap;
    cmap = ActionManager::sfind(name)->createColorMap();
    addColorMap(cmap);
}

void Chain::setScaler(Scaler *newscaler)
{
    storage->scaler = newscaler;
}

void Chain::setScaler(const char *name)
{
    setScaler(ActionManager::sfind(name)->createScaler());
}

bool Chain::isChainFull()
{
    for(unsigned int i = 0; i < components; ++i)
    {
        if (storage->idcts[i] == 0)
            return false;
    }
    for(unsigned int i = 0; i < components; ++i)
    {
        vector<ImproveRawPlane *>::const_iterator v;
        FloatPlane *improved;
        for(v = storage->improverawplanes[i].begin();
                v != storage->improverawplanes[i].end();
                ++v)
        {
            if ((*v) == 0)
                return false;
        }
    }

    if (storage->scaler == 0)
        return false;

    vector<ColorMap *>::const_iterator i;
    for(i = storage->colormaps.begin(); i != storage->colormaps.end(); ++i)
    {
        if ((*i) == 0)
            return false;
    }

    return true;
}

FloatImage * Chain::apply()
{
    /* Apply IDCTs */
    FloatPlane *idcted[components];
    for(unsigned int i = 0; i < components; ++i)
    {
        storage->idcts[i]->prepare(&initial->plane[i]);
        idcted[i] = storage->idcts[i]->apply();
    }

    using namespace std;

    /* Apply ImproveRaw chain for each plane */
    for(unsigned int i = 0; i < components; ++i)
    {
        vector<ImproveRawPlane *>::const_iterator v;
        FloatPlane *improved;
        for(v = storage->improverawplanes[i].begin();
                v != storage->improverawplanes[i].end();
                ++v)
        {
            (*v)->prepare(&initial->plane[i], idcted[i]);
            improved = (*v)->apply();
            idcted[i]->free();
            delete idcted[i];
            idcted[i] = improved;
        }
    }

    /* Create the array of planes */
    FloatPlane idcted_local[components];
    for(unsigned int i = 0; i < components; ++i)
    {
        idcted_local[i] = *idcted[i];
        delete idcted[i];
    }

    /* Apply the Scaler */
    FloatImage fi(idcted_local, components);
    storage->scaler->prepare(initial, &fi);
    FloatImage *scaled = storage->scaler->apply();
    fi.free();

    /* Apply the colormaps */
    vector<ColorMap *>::const_iterator i;
    for(i = storage->colormaps.begin(); i != storage->colormaps.end(); ++i)
    {
        (*i)->prepare(scaled);
        (*i)->apply(); /* Changes "scaled" */
    }

    return scaled;
}

/*! Calls free() */
Chain::~Chain()
{
    free();
    delete storage;
}
