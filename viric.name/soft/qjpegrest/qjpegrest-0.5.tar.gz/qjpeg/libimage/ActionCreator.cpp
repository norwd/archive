/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include "ActionType.h"
#include "ActionCreator.h"

ActionCreator::ActionCreator()
{
    type = ActionType(e_Undefined);
}

IDCTPlane * ActionCreator::createIDCTPlane() const
{
}
ImproveRaw * ActionCreator::createImproveRaw() const
{
}
ImproveRawPlane * ActionCreator::createImproveRawPlane() const
{
}
ColorMap * ActionCreator::createColorMap() const
{
}
Scaler * ActionCreator::createScaler() const
{
}
Measure * ActionCreator::createMeasure() const
{
}
Compare * ActionCreator::createCompare() const
{
}
enum ActionType ActionCreator::getType() const
{
    return type;
}
