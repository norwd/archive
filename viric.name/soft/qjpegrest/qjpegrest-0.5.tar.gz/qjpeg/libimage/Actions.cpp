/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <iostream>
#include "Actions.h"

ActionBase::ActionBase() {
    name = "Unknown";
    progress = 0;
    maxProgress = 0;
    GUIconfigurable = false;
}

void ActionBase::setProgress(int p)
{
    if (p != progress)
    {
        std::cerr << "New progress [" << name.toUtf8().data() <<
            "]: " << p << "/" << maxProgress << '\n';
        progress = p;
    }
}

int ActionBase::getMaxProgress()
{
    return maxProgress;
}
/*! Get the progress value */
int ActionBase::getProgress()
{
    return progress;
}

QString ActionBase::getName() const
{
    return name;
}

bool ActionBase::isGUIconfigurable() const
{
    return GUIconfigurable;
}
