/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include "JPEGData.h"
#include "JPEGFile.h"
#include "FloatImage.h"
#include "FloatPlane.h"
#include "CoefsImage.h"

int main()
{
    JPEGFile a("a.jpg");

    FloatImage *i;

    i = a.getUnpackedImage();

    /* Write the planes */
    i->plane[0].writePGM("hola1.pgm");
    i->plane[1].writePGM("hola2.pgm");
    i->plane[2].writePGM("hola3.pgm");

    i->writePPM("hola.ppm");
    /* Remove the image and its planes */
    i->free();
    delete i;

    i = a.getiDCTImage();

    /* Write the planes */
    i->plane[0].writePGM("ihola1.pgm");
    i->plane[1].writePGM("ihola2.pgm");
    i->plane[2].writePGM("ihola3.pgm");

    i->free();
    delete i;

    /* Coefs testing */
    CoefsImage *ci;

    ci = a.getCoefs();

    ci->free();
    delete ci;
}
