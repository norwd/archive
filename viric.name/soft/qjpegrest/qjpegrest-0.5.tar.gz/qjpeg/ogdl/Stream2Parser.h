/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QChar>

class Parser;
class QTextStream;

class Stream2Parser
{
public:
    Stream2Parser(QTextStream &tstream, Parser &p);
    void read_element();
    void start();

private:
    bool is_ungetchar;
    QChar ungetchar;
    Parser &parser;
    QTextStream &stream;
    QList<int> levels;
    int lastlevel;
    bool stream_available;
    bool start_of_line;
    bool newline_read;

    int get(QChar &c);
    void unget(QChar c);
    int eatspaces();
    QString eatword();
    int newlevel(int spaces);
    int findlevel(int spaces);
    int getlevel();
};
