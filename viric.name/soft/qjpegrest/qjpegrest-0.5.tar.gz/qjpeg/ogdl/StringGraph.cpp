/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include "StringGraph.h"


StringGraph::StringGraph ()
{
    mytext = "";
}
StringGraph::StringGraph (const QString &_text)
{
    mytext = _text;
}

StringGraph::~StringGraph()
{
    free();
}

void StringGraph::free ()
{
    foreach(StringGraph *g, childs)
    {
        /* The destruction will call free() */
        delete g;
    }
    childs.clear();
}

QString StringGraph::text() const
{
    return mytext;
}

void StringGraph::setText(const QString &_text)
{
    mytext = _text;
}

StringGraph *StringGraph::at(const int pos) const
{
    if (pos >= childs.size())
        return 0;

    return childs.at(pos);
}

StringGraph *StringGraph::insertAt(const int pos, StringGraph *g)
{
    bool create = false;

    if (g == 0)
        create = true;

    if (create)
        g = new StringGraph();

    if (pos > childs.size())
    {
        if (create)
            delete g;
        return 0;
    }

    childs.insert(pos, g);

    return g;
}

StringGraph * StringGraph::append(StringGraph *g)
{
    if (g == 0)
        g = new StringGraph();

    childs.append(g);
    return g;
}

void StringGraph::removeAt(const int pos)
{
    if (pos >= childs.size())
        return;

    childs.removeAt(pos);
}

const QList<StringGraph *> StringGraph::getChilds() const
{
    return childs;
}
