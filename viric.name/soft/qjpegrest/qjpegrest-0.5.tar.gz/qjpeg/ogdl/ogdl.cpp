/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QTextStream>
#include "StringGraph.h"
#include "Parser.h"
#include "StringGraphParser.h"
#include "DumpParser.h"
#include "Stream2Parser.h"
#include "ogdl.h"

StringGraph * OGDL::Stream2Graph(QTextStream &stream)
{
    StringGraph *g = new StringGraph();
    OGDL2StringGraph p(g);
    Stream2Parser sp(stream, p);

    sp.start();

    /* Now the contents should be in the graph */
    g->setText("Root");
    return g;
}

static void writeSpaces(QTextStream &stream, int spaces)
{
    for(int i=0; i < spaces; ++i)
    {
        stream.operator<<(' ');
    }
}

static void writeGraphContents(QTextStream &stream, const StringGraph *g, int spaces)
{
    QList<StringGraph *> listcopy = g->getChilds();

    foreach(const StringGraph * child, listcopy)
    {
        writeSpaces(stream, spaces);
        stream.operator<<(child->text());
        stream.operator<<('\n');
        writeGraphContents(stream, child, spaces+2);
    }
}

/* This should not write the text of the root node. And it doesn't. */
void OGDL::Graph2Stream(QTextStream &stream, const StringGraph *root)
{
    writeGraphContents(stream, root, 0);
}
