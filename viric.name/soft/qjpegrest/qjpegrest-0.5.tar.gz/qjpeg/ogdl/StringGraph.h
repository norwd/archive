/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QString>
#include <QList>

class StringGraph
{
    public:
        StringGraph ();
        StringGraph (const QString &_text);
        ~StringGraph();

        StringGraph *at(const int pos) const;
        StringGraph *insertAt(const int pos, StringGraph *g = 0);
        StringGraph *append(StringGraph *g = 0);
        void removeAt(const int pos);
        QString text() const;
        void setText(const QString &_text);
        void free();
        const QList<StringGraph *> getChilds() const;
        void dump(int level = 0);

    private:
        QList<StringGraph *> childs;
        QString mytext;
};
