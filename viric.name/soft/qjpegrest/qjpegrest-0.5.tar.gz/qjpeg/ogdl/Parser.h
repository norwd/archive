/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class QString;

enum EventType
{
    Content
};

class Parser
{
    public:
    virtual void event(enum EventType t, int level, const QString &str) = 0;
};
