/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QString>
#include <QTextStream>

#include <QDebug>

#include "Stream2Parser.h"
#include "OGDLChars.h"
#include "Parser.h"

using namespace OGDLChars;

Stream2Parser::Stream2Parser(QTextStream &tstream, Parser &p)
    : stream(tstream), parser(p)
{
    is_ungetchar = false;
    stream_available = true;
    start_of_line = true;
}

void Stream2Parser::unget(QChar c)
{
    /* Error if  is_ungetchar == true*/
    is_ungetchar = true;
    ungetchar = c;
}

int Stream2Parser::get(QChar &c)
{
    if (is_ungetchar)
    {
        is_ungetchar = false;
        c = ungetchar;
        return 1;
    }

    QString s;

    s = stream.read(1);

    /* End of stream */
    if (s.size() == 0)
    {
        stream_available = false;
        return -1;
    }
    c = s[0];

    return 1;
}

void Stream2Parser::read_element()
{

}

void Stream2Parser::start()
{
    lastlevel = -1;

    /* loop */ 
    do {
        int level;
        QString str;

        /* Get level */
        level = getlevel();

        /* Get data */
        if (stream_available)
        {
            str = eatword();
            if (str.size() > 0)
                parser.event(Content, level, str);
        }
        lastlevel = level;
    } while(stream_available);
}

int Stream2Parser::eatspaces()
{
	QChar c;
	int count = 0;

    newline_read = false;

	do {
		get(c);
		++count;
        if (c == '\n')
        {
            newline_read = true;
            count = 0;
        }
	} while ((isspace(c) || c == '\n') && stream_available);
	/* The loops counts one more */
	unget(c);
	--count;
    return count;
}

QString Stream2Parser::eatword()
{
	QString word;
	QChar c;
	int count = 0;
	bool inquotes = false;
    int res;

	while(true) {
		res = get(c);
        /* This checks stream_available, in fact */
        if (res != 1)
            break;
		++count;
		if (inquotes)
		{
			if(c == '"')
			{
				inquotes = false;
				break;
			}
			/* all else is part of the word */
			word.append(c);
			continue;
		} else {
			if(c == '"')
			{
				inquotes = true;
				continue;
			}
		}
		if (ischarword(c))
		{
			word.append(c);
			continue;
		} else
        {
            unget(c);
            break;
        }
	}
    /*qDebug() << "Read: " << word;*/
	return word;
}

int Stream2Parser::findlevel(int spaces)
{
    int element;
    int i;

    for (i = 0; i < levels.size(); ++i)
    {
        if (levels.at(i) == spaces)
            return i;
    }
    return -1;
}

static void dumplevels(const QList<int> &levels)
{
    int i;

    for (i = 0; i < levels.size(); ++i)
    {
        qDebug() << levels.at(i) << ",";
    }
    qDebug() << '\n';
}

int Stream2Parser::newlevel(int spaces)
{
    if (!levels.isEmpty())
    {
        /* DEBUG */
        /*if (spaces < levels.last())
        {
            qDebug() << "spaces: " << spaces;
            dumplevels(levels);
        }*/
        if (spaces <= levels.last())
            qFatal("Error parsing the OGDL file. A new level is read,\n"
                    "and it shouldn't be.");
        assert(spaces > levels.last());
    }
    levels.append(spaces);

    /* Return the new level. The last in the list. */
    return levels.size() - 1;
}

int Stream2Parser::getlevel()
{
    int spaces;
    int l;

    if (start_of_line)
    {
        /* The next call will update 'newline_read' */
        spaces = eatspaces();
        if (!stream_available)
            return -1;

        if (lastlevel == -1 && spaces != 0)
        {
            qFatal("Error parsing the OGDL file. Spaces in the begining.");
            abort();
        }

        if (!newline_read && !levels.isEmpty())
            return newlevel(levels.last()+1);

        /* a newline has been read. Then, spaces from start of line. */
        l = findlevel(spaces);
        if (l == -1)
            return newlevel(spaces);
        else
        {
            if (l == levels.last())
                return l;
            else
            {
                /* Delete the inner levels */
                int i;
                int total = levels.size() - l - 1;
                for (i=0; i < total; ++i)
                    levels.removeLast();
            }
        }
    }

    return l;
}
