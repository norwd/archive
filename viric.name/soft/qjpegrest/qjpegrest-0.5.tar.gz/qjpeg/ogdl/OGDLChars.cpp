/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QChar>
#include "OGDLChars.h"

bool OGDLChars::isspace(QChar c)
{
	if (c == ' ' || c == '\t')
		return true;
	return false;
}

bool OGDLChars::isbreak(QChar c)
{
	if (c == '\n')
		return true;
	return false;
}

bool OGDLChars::isseparator(QChar c)
{
	if (c == ',' || c == '(' || c == ')')
		return true;
	return false;
}

bool OGDLChars::ischarword(QChar c)
{
	if (!isspace(c) && !isbreak(c) && !isseparator(c))
		return true;
	return false;
}
