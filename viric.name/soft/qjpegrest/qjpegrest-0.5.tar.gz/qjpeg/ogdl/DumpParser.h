/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QList>

class DumpParser : public Parser
{
public:
    DumpParser();
    void event(enum EventType t, int level, const QString &str);
};
