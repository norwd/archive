/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include "StringGraph.h"
#include "Parser.h"
#include "StringGraphParser.h"
#include "DumpParser.h"
#include "Stream2Parser.h"
#include "ogdl.h"

#include <QFile>
#include <QTextStream>

static void dumpStream(QTextStream &stream)
{
    DumpParser p;
    Stream2Parser sp(stream, p);

    sp.start();
}

static void graphStream(QTextStream &stream)
{
    StringGraph g;
    OGDL2StringGraph p(&g);
    Stream2Parser sp(stream, p);

    sp.start();

    /* Now the contents should be in the graph */
    g.setText("Root");
    g.dump();
}

static int trydump(const char *filename)
{
	bool res;
    QFile file;
    QTextStream stream;

    file.setFileName(filename);
    res = file.open(QIODevice::ReadOnly);

	if ( res == false )
	{
		fprintf(stderr, "error opening file %s\n", filename);
		return -1;
	}

    /* The file is correctly opened */
    stream.setDevice(&file);
    dumpStream(stream);
    file.close();

    return 0;
}

static int trygraph(const char *filename)
{
	bool res;
    QFile file;
    QTextStream stream;
    StringGraph *g;

    file.setFileName(filename);
    res = file.open(QIODevice::ReadOnly);

	if ( res == false )
	{
		fprintf(stderr, "error opening file %s\n", filename);
		return -1;
	}

    /* The file is correctly opened */
    stream.setDevice(&file);
    g = OGDL::Stream2Graph(stream);
    file.close();

    g->dump();

    file.setFileName("out.g");
    res = file.open(QIODevice::WriteOnly);

	if ( res == false )
	{
		fprintf(stderr, "error opening file %s for writting\n", filename);
		return -1;
	}

    OGDL::Graph2Stream(stream, g);

    file.close();

    delete g;

    return 0;
}

int main(int argc, char ** argv)
{
	if (argc < 2)
	{
		fprintf(stderr, "error in # parameters\n");
		return -1;
	}

    /*trydump(argv[1]);*/
    trygraph(argv[1]);
}
