/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include <QList>
#include "StringGraph.h"

#include <cstdio>

using std::printf;

/* Recursive dump */
void StringGraph::dump(int level)
{

    printf("level %i - \"%s\"\n", level, mytext.toUtf8().data());

    foreach(StringGraph *i, childs)
    {
        i->dump(level + 1);
    }
}
