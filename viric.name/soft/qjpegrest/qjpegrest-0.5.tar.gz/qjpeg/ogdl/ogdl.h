/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
namespace OGDL
{
    StringGraph * Stream2Graph(QTextStream &stream);
    void Graph2Stream(QTextStream &stream, const StringGraph *g);
}
