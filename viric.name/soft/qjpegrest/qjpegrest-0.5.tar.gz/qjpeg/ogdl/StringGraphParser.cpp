/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
#include "Parser.h"
#include "StringGraph.h"
#include "StringGraphParser.h"

OGDL2StringGraph::OGDL2StringGraph(StringGraph *g)
{
    depth.append(g);
}

void OGDL2StringGraph::event(enum EventType t, int level, const QString &str)
{
    if (t != Content)
        return;

    if ( (level + 1) > depth.size())
        return;

    StringGraph *g = new StringGraph(str);
    depth.at(level)->append(g);

    int newlevel = level + 1;

    if (newlevel == depth.size())
        depth.append(g);
    else
        depth.replace(newlevel, g);
}
