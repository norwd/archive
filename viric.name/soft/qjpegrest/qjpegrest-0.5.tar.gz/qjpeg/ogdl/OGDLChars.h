/*
    QJpegRest - An interactive JPEG decoder, with restoration algorithms
    Copyright (C) 2007  Lluís Batlle i Rossell

    Please find the license in the provided LICENSE file.
*/
class QChar;

namespace OGDLChars
{
    bool OGDLChars::isspace(QChar c);
    bool OGDLChars::isbreak(QChar c);
    bool OGDLChars::isseparator(QChar c);
    bool OGDLChars::ischarword(QChar c);
}
