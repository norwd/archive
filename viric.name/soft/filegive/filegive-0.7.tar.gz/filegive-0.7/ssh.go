/*
   filegive - Easy sending of files
   Copyright (C) 2013  Lluís Batlle i Rossell

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU Affero General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Affero General Public License for more details.

   You should have received a copy of the GNU Affero General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package main

import (
	"fmt"
	"io"
	"os"
	"os/exec"
)

type SSH struct {
	cmd  *exec.Cmd
	pin  io.WriteCloser
	addr string
}

func NewSSH(addr string, port int) (*SSH, error) {
	cmd := exec.Command("ssh", addr, "-R", fmt.Sprintf(":%d:localhost:%d", port, port),
		"cat")

	pin, err := cmd.StdinPipe()
	if err != nil {
		return nil, err
	}

	err = cmd.Start()
	if err != nil {
		return nil, err
	}
	go func() {
		err := cmd.Wait()
		if err != nil {
			fmt.Fprintln(os.Stderr, "Warning: error setting up ssh tunnel:", err)
		}
	}()

	ssh := &SSH{cmd: cmd, addr: addr, pin: pin}
	return ssh, nil
}

func (ssh *SSH) Finish() {
	ssh.pin.Close()
}
