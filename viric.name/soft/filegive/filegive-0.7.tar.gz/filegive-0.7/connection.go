/* filegive - Easy sending of files
   Copyright (C) 2013  Lluís Batlle i Rossell

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU Affero General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Affero General Public License for more details.

   You should have received a copy of the GNU Affero General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package main

import (
	"fmt"
	"net/http"
)

type ConnectionLogger struct {
	internal http.Handler
	cons     *Connections
}

func NewConnectionLogger(cons *Connections, h http.Handler) http.Handler {
	return &ConnectionLogger{h, cons}
}

func (ds *ConnectionLogger) ServeHTTP(rw http.ResponseWriter, req *http.Request) {
	con, err := ds.cons.Add(req.RemoteAddr)
	if err != nil {
		http.Error(rw, "Cannot open file", http.StatusNotFound)
		return
	}
	defer con.Remove()

	ds.internal.ServeHTTP(rw, req)
}

type ConnectionAck struct {
	Addr     string
	Accepted chan bool
}

type Connections struct {
	Started  chan ConnectionAck
	Finished chan string
	ui       *UI
}

func NewConnections(ui *UI) *Connections {
	c := &Connections{}
	c.Started = make(chan ConnectionAck)
	c.Finished = make(chan string)
	c.ui = ui

	return c
}

type Connection struct {
	addr     string
	finished chan<- string
}

func (c *Connections) Add(addr string) (*Connection, error) {
	ack := ConnectionAck{addr, make(chan bool)}

	c.Started <- ack
	accepted := <-ack.Accepted
	if accepted {
		return &Connection{addr, c.Finished}, nil
	}
	return nil, fmt.Errorf("Refused")
}

func (c *Connection) Remove() {
	c.finished <- c.addr
}
