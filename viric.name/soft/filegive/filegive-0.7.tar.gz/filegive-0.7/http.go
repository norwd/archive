/* filegive - Easy sending of files
   Copyright (C) 2013  Lluís Batlle i Rossell

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU Affero General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Affero General Public License for more details.

   You should have received a copy of the GNU Affero General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package main

import (
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"strconv"
	"time"
)

var rateLimit *RateLimit

var uploadHtml = `
<html>
<body>
Choose the file:
<form method="POST" enctype="multipart/form-data">
<input name="f" type="file"></input>
<input type="submit"></input>
</form>
</body>
</html>
`

func createFile(name string) (*os.File, error) {
	suffix := ""
	count := 0
	for {
		f, err := os.Open(name + suffix)
		if os.IsNotExist(err) {
			break
		}
		if err == nil {
			f.Close()
		}
		suffix = fmt.Sprintf("_%d", count)
		count += 1
	}

	f, err := os.Create(name + suffix)
	return f, err
}

func uploadPage(rw http.ResponseWriter, req *http.Request, user int) {
	if req.Method == "GET" {
		fmt.Fprint(rw, uploadHtml)
	} else if req.Method == "POST" {
		r, err := req.MultipartReader()
		if err != nil {
			fmt.Fprint(rw, "Error creating multipart reader!", err)
			return
		}

		for {
			p, err := r.NextPart()
			if err == io.EOF {
				return
			}
			if err != nil {
				fmt.Fprint(rw, "Error in nextpart: ", err)
				return
			}

			filename := p.FileName()

			fmt.Fprintf(os.Stderr, "New incoming file: %s\n", filename)

			f, err := createFile(filename)
			if err != nil {
				fmt.Fprintf(os.Stderr, "Error creating new file %s: %s\n", filename, err)
				fmt.Fprintf(rw, "Error in transmission\n")
				return
			}
			defer f.Close()

			clength := req.Header.Get("Content-Length")
			if clength != "" {
				nclength, err := strconv.Atoi(clength)
				if err == nil {
					fileSize = int64(nclength)
				}
			}

			counter := NewCounter(p, users.v[user])

			_, err = io.Copy(f, counter)
			if err != nil {
				fmt.Fprintf(os.Stderr, "Error receiving file (io.Copy): %s\n", err)
				fmt.Fprintf(rw, "Error in transmission\n")
				return
			}

			fmt.Fprintf(rw, "File %s sent. Thank you.\n", p.FileName())
			users.v[user].SetLast(fileSize)
		}
	}
}

func serveHttp(file, basename string, listener net.Listener) error {
	if *rate > 0 {
		rateLimit = NewRateLimit(*rate * 1024)
	}

	ui := NewUI(file != "-")

	cons := NewConnections(ui)
	for i := range users.v {
		username := users.v[i].userpwd
		userprefix := ""
		if len(username) >= 1 {
			userprefix = username + "/"
		}

		isDir := false
		stat, err := os.Stat(file)
		if err == nil {
			isDir = stat.IsDir()
		}

		// Always deliver the CA certificate on request
		http.HandleFunc("/ca.pem",
			func(rw http.ResponseWriter, req *http.Request) {
				if req.Method == "GET" {
					f, err := os.Open(fileCert)
					if err != nil {
						http.Error(rw, "Cannot open file", http.StatusNotFound)
					}
					defer f.Close()
					rw.Header().Add("Content-Type", "application/x-x509-ca-cert")
					http.ServeContent(rw, req, "ca.cert", time.Time{}, f)
				} else {
					http.Error(rw, "Cannot open file", http.StatusNotFound)
				}
			})

		// Distinguish -R and normal behaviour
		if *receive {
			http.HandleFunc("/"+userprefix+"upload",
				func(rw http.ResponseWriter, req *http.Request) {
					con, err := cons.Add(req.RemoteAddr)
					if err != nil {
						http.Error(rw, "Cannot open file", http.StatusNotFound)
						return
					}
					defer con.Remove()

					uploadPage(rw, req, i)
				})
		} else if isDir {
			// StripPrefix wants and ending '/', but we need a special case for
			// the file == "/".
			lastPart := basename + "/"
			if file == "/" || file == "." {
				lastPart = ""
			}
			prefix := "/" + userprefix + lastPart
			http.Handle(prefix,
				NewConnectionLogger(cons,
					http.StripPrefix(prefix, http.FileServer(FileSystem{file, users.v[i]}))))
		} else {
			http.HandleFunc("/"+userprefix+basename,
				func(rw http.ResponseWriter, req *http.Request) {
					con, err := cons.Add(req.RemoteAddr)
					if err != nil {
						http.Error(rw, "Cannot open file", http.StatusNotFound)
						return
					}
					defer con.Remove()

					if file == "-" {
						reader := NewCounter(os.Stdin, users.v[i])
						io.Copy(rw, reader)

						// We can't serve Stdin more than once
						exitChan <- true

						return
					}

					f, err := os.Open(file)
					if err != nil {
						http.Error(rw, "Cannot open file", http.StatusNotFound)
						return
					}
					defer f.Close()

					// Get the modtime if possible
					mtime := time.Now()
					s, err := f.Stat()
					if err == nil {
						mtime = s.ModTime()
					}

					counter := NewCounterSeeker(f, users.v[i])

					http.ServeContent(rw, req, basename, mtime, counter)
				})
		}
	}

	endChan := make(chan error)
	go func() {
		// HTTP Blocking Server
		endChan <- http.Serve(listener, nil)
	}()

	setupSignals(exitChan)

	statusTimer := time.NewTicker(2 * time.Second)

	checkErr := true

	lastStatus := users.GetStatus()
	nconnections := 0
loop:
	for {
		select {
		case <-statusTimer.C:
			s := users.GetStatus()
			if !s.Equal(lastStatus) {
				s.ShowDiff(lastStatus)
			}
			lastStatus = s
		case <-exitChan:
			checkErr = false
			listener.Close()
		case input := <-ui.Input:
			if input[0] == 'q' {
				checkErr = false
				listener.Close()
			}
		case toAck := <-cons.Started:
			b := true
			if *interactive {
				b = ui.ApproveConnection(toAck.Addr)
			}
			toAck.Accepted <- b
			if b {
				fmt.Fprintln(os.Stderr, "Connection from", toAck.Addr)
				nconnections += 1
			}

		case addr := <-cons.Finished:
			fmt.Fprintln(os.Stderr, "Connection from", addr, "finished")
			nconnections -= 1

			// Count if all users downloaded all
			if fileSize != 0 && users.AllFinished() && nconnections == 0 && !*noExit {
				checkErr = false
				fmt.Fprintln(os.Stderr, "Shutting down")

				// Timeout to close it, because of TLS finishing handshake.
				// I don't know how to make it not-racy.
				time.Sleep(2 * time.Second)

				listener.Close()
			}
		case err := <-endChan:
			if checkErr && err != nil {
				fmt.Println("error serving http: ", err)
			}
			break loop
		}
	}

	return nil
}
