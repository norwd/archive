package main

import (
	"crypto/rand"
	"fmt"
	"os"
	"sync"
	"time"
)

type User struct {
	id      int
	userpwd string
	last    int64
	m       sync.Mutex
}

type Users struct {
	v []*User
	m sync.Mutex
}

var users Users

// Return the input string, changing X by a random lowercase letter
func randomString(pattern string) string {
	out := []byte(pattern)
	for i, v := range out {
		if v == 'X' {
			_, err := rand.Reader.Read(out[i : i+1])
			if err != nil {
				fmt.Fprint(os.Stderr, "Error generating username: ", err)
				os.Exit(1)
			}
			out[i] = 'a' + byte(out[i])%byte('z'-'a')
		}
	}
	return string(out)
}

func randomUser() string {
	return randomString(*urldirectory)
}

func (u *User) SetLast(i int64) {
	u.m.Lock()
	defer u.m.Unlock()
	u.last = i
}

func (u *User) GetLast() int64 {
	u.m.Lock()
	defer u.m.Unlock()
	return u.last
}

func (us *Users) Add() *User {
	us.m.Lock()
	defer us.m.Unlock()

	if us.v == nil {
		us.v = make([]*User, 0)
	}

	u := &User{id: len(us.v), userpwd: randomUser()}
	us.v = append(us.v, u)
	return u
}

func (us *Users) Find(s string) *User {
	us.m.Lock()
	defer us.m.Unlock()

	for _, u := range us.v {
		if u.userpwd == s {
			return u
		}
	}

	return nil
}

func (us *Users) AllFinished() bool {
	us.m.Lock()
	defer us.m.Unlock()

	ndownloaded := 0
	for _, u := range us.v {
		if u.GetLast() == fileSize {
			fmt.Fprintf(os.Stderr, "User %d downloaded all.\n", u.id)
			ndownloaded++
		}
	}

	return ndownloaded == len(us.v)
}

type UserStatus struct {
	id   int
	last int64
}

type Status struct {
	v []UserStatus
	t time.Time
}

func (us *Users) GetStatus() Status {
	us.m.Lock()
	defer us.m.Unlock()

	s := Status{}
	s.v = make([]UserStatus, len(us.v))
	for i, u := range us.v {
		s.v[i].id = u.id
		s.v[i].last = u.GetLast()
	}
	s.t = time.Now()

	return s
}

func (s Status) ShowDiff(old Status) {
	str := ""
	for i, u := range s.v {
		bdiff := u.last - old.v[i].last
		speed := float64(bdiff) / s.t.Sub(old.t).Seconds()
		percent := float64(0)
		if fileSize > 0 {
			percent = float64(u.last*1000/fileSize) / 10
		}
		prefix := ""
		if len(s.v) > 1 {
			prefix = fmt.Sprintf("%d: ", u.id)
		}
		str += fmt.Sprintf("%s%.1f%% (%.0f B/s) ", prefix, percent, speed)
	}

	if len(s.v) > 1 {
		str += "\n"
	} else {
		str += "\r"
	}
	fmt.Fprint(os.Stderr, str)
}

func (s Status) Equal(old Status) bool {
	for i, u := range s.v {
		if u.last != old.v[i].last {
			return false
		}
	}
	return true
}
