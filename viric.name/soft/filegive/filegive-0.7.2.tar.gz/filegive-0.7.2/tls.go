/*
   filegive - Easy sending of files
   Copyright (C) 2013  Lluís Batlle i Rossell

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU Affero General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Affero General Public License for more details.

   You should have received a copy of the GNU Affero General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package main

import (
	"crypto/sha1"
	"crypto/tls"
	"crypto/x509"
	"fmt"
	"net"
)

func ShowCert(title string, cert []byte) string {
	c, h := GetCNAndHash(cert)
	str := fmt.Sprintf("%s SHA1 (s: %s): ", title, c)
	for i := range h {
		if i > 0 {
			str += ":"
		}
		str += fmt.Sprintf("%02X", h[i])
	}
	fmt.Println(str)

	return str
}

func GetCNAndHash(cert []byte) (string, []byte) {
	dec, err := x509.ParseCertificate(cert)
	if err != nil {
		return "", nil
	}
	h := sha1.New()
	h.Write(cert)
	return dec.Subject.Organization[0], h.Sum(nil)
}

func NewHttpsListener(l net.Listener, cert tls.Certificate) (nl net.Listener, err error) {
	config := &tls.Config{}
	config.Certificates = []tls.Certificate{cert}

	chooseCiphers(config)

	// Required in go 1.1, or with firefox it will be conn reset.
	config.NextProtos = []string{"http/1.1"}

	// Show Fingerprint
	str := ShowCert("Certificate", cert.Certificate[0])

	// Windows
	forClipboard = str + "\r\n"

	// Show Fingerprint of CA if it is available
	if len(cert.Certificate) > 1 {
		ShowCert("CA", cert.Certificate[1])
	}

	nl = tls.NewListener(l, config)
	return
}
