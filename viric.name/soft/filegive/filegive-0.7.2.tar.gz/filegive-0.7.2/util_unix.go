// +build bsd darwin linux

/*
   filegive - Easy sending of files
   Copyright (C) 2013  Lluís Batlle i Rossell

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU Affero General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Affero General Public License for more details.

   You should have received a copy of the GNU Affero General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package main

import (
	"bufio"
	"fmt"
	"os"
	"os/signal"
	"strings"
	"syscall"
)

func setupSignals(exitChan chan<- bool) {
	c := make(chan os.Signal)

	signal.Notify(c, syscall.SIGTERM, syscall.SIGINT, syscall.SIGHUP)

	ignore := make(chan os.Signal)
	signal.Notify(ignore, syscall.SIGTTIN)

	go func() {
		for _ = range c {
			exitChan <- true
		}
	}()
}

func isWindows() bool {
	return false
}

func homePath() string {
	return os.Getenv("HOME")
}

func FindGateway() string {
	fr, err := os.Open("/proc/net/route")
	if err != nil {
		return ""
	}
	defer fr.Close()
	f := bufio.NewReader(fr)
	for {
		l, err := f.ReadString('\n')
		if err != nil {
			return ""
		}

		// take out the '\n'
		l = l[:len(l)-1]
		fields := strings.Fields(l)
		if len(fields) > 3 && fields[1] == "00000000" && fields[7] == "00000000" {
			hexgateway := fields[2]
			var ip [4]byte
			n, err := fmt.Sscanf(hexgateway, "%2X%2X%2X%2X", &ip[0], &ip[1], &ip[2], &ip[3])
			if n == 4 && err == nil {
				return fmt.Sprintf("%d.%d.%d.%d", ip[3], ip[2], ip[1], ip[0])
			}
		}
	}
	return ""
}

func showQ() {
}

func setClipboard(s string) {
}
