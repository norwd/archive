/* filegive - Easy sending of files
   Copyright (C) 2013  Lluís Batlle i Rossell

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU Affero General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Affero General Public License for more details.

   You should have received a copy of the GNU Affero General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package main

import (
	"io"
)

type Counter struct {
	base io.Reader
	last int64
	user *User
}

type CounterSeeker struct {
	Counter
}

func NewCounter(f io.Reader, user *User) *Counter {
	c := &Counter{base: f, user: user}
	return c
}

func NewCounterSeeker(f io.ReadSeeker, user *User) *CounterSeeker {
	c := &CounterSeeker{Counter: Counter{base: f, user: user}}
	return c
}

func (c *Counter) Read(d []byte) (n int, err error) {
	if rateLimit != nil {
		l := rateLimit.Want(len(d))
		d = d[:l]
	}
	n, err = c.base.Read(d)
	c.last += int64(n)
	c.user.SetLast(c.last)
	return
}

func (c *CounterSeeker) Seek(offset int64, whence int) (ret int64, err error) {
	baseseek := c.base.(io.ReadSeeker)
	ret, err = baseseek.Seek(offset, whence)
	c.last = ret
	c.user.SetLast(c.last)
	return
}
