/* filegive - Easy sending of files
   Copyright (C) 2013  Lluís Batlle i Rossell

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU Affero General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Affero General Public License for more details.

   You should have received a copy of the GNU Affero General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package main

import (
	"fmt"
	"os"
)

type UI struct {
	f       *os.File
	display chan string
	Input   chan string
}

func NewUI(readInput bool) *UI {
	ui := &UI{os.Stdin, make(chan string), make(chan string)}

	if readInput {
		go ui.Loop()
	}
	return ui
}

func (ui *UI) Loop() {
	b := make([]byte, 50)
	var err error
	for err == nil {
		n, err := ui.f.Read(b)
		//fmt.Fprintln(os.Stderr, "Stdin unblocked: %v %v %v", n, err, b[:n])
		if err == nil {
			ui.Input <- string(b[:n])
		}
	}
}

func (ui *UI) ApproveConnection(addr string) bool {
	fmt.Fprintf(os.Stderr, "Accept request from %s (y/n)? ", addr)
	x := <-ui.Input
	if len(x) > 0 && x[0] == 'y' {
		return true
	}
	return false
}
