// +build windows

/*
   filegive - Easy sending of files
   Copyright (C) 2013  Lluís Batlle i Rossell

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU Affero General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Affero General Public License for more details.

   You should have received a copy of the GNU Affero General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package main

import (
	"fmt"
	"os"
)

func setupSignals(exitChan <-chan bool) {
}

func homePath() string {
	return os.Getenv("HOMEPATH")
}

func isWindows() bool {
	return true
}

func FindGateway() string {
	// Not supported in windows
	return ""
}

func showQ() {
	fmt.Fprintln(os.Stderr, "(Type 'q[enter]' to force quit. Simply closing, will leave the UPnP rule)")
}
