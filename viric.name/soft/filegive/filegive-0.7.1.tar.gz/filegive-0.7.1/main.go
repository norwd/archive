/* filegive - Easy sending of files
   Copyright (C) 2013  Lluís Batlle i Rossell

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU Affero General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Affero General Public License for more details.

   You should have received a copy of the GNU Affero General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package main

import (
	"flag"
	"fmt"
	"math/rand"
	"net"
	"net/url"
	"os"
	"path/filepath"
	"runtime/pprof"
	"strconv"
	"strings"
	"time"
)

var useUpnp = flag.Bool("u", false, "use UPnP")
var useNatpmp = flag.Bool("A", false, "use NAT-PMP")
var natpmpGateway = flag.String("G", "", "manual gateway IP address (for NAT-PMP)")
var useSsh = flag.String("s", "", "use ssh host tunnel (requires non-default sshd_config)")
var useSshSocat = flag.String("ss", "", "use ssh tunnel, with socat at the remote side")
var useSshNetcat = flag.String("sn", "", "use ssh tunnel, with GNU netcat at the remote side")
var forwardTimeout = flag.Int("t", 0, "UPnP/NAT-PMP forwarding timeout in secs (0, unlimited)")
var extAddress = flag.String("e", "", "known external address (ip:port)")
var genCert = flag.Bool("g", false, "regenerate CA certificate")
var disableHttps = flag.Bool("p", false, "disable https serving files")
var noExit = flag.Bool("N", false, "don't exit at end of downloads")
var nusers = flag.Int("n", 1, "number of destination users")
var rate = flag.Int("r", 0, "rate limit to these KiB/S (0=unlimited)")
var urldirectory = flag.String("D", "XXXXXX", "directory in URL (X means random char)")
var receive = flag.Bool("R", false, "receive a file, not send (http upload)")
var port = flag.Int("P", 0, "port to bind to (local, UPnP, NAT-PMP, ...)")
var tlsFromCA = flag.Bool("ca", false, "use the CA certificate instead of generating one")
var interactive = flag.Bool("i", false, "interactively acknowledge each connection")

var helpText = `options:
  -A          use NAT-PMP
  -D <str>    directory in URL (X means random char, XXXXXX default)
  -G          manual gateway IP address (for NAT-PMP)
  -N          don't exit at end of downloads
  -P <port>   port to bind to (local, UPnP, NAT-PMP, ...)
  -R          receive a file, not send (http upload, in browser side)
  -ca         use the CA certificate instead of generating one
  -e <h:p>    known external address (ip:port)
  -g          regenerate CA certificate
  -i          interactive mode, you acknowledge download attempts
  -n <n>      number of destination users (default 1)
  -p          disable https serving files
  -r          rate limit to these KiB/S (0=unlimited, default)
  -s <host>   use ssh tunnel (requires non-default sshd_config)
  -ss <host>  use ssh tunnel, with socat at the remote side
  -sn <host>  use ssh tunnel, with GNU netcat at the remote side
  -t          UPnP/NAT-PMP forwarding timeout in secs (0, unlimited)
  -u          use UPnP
`

var fileKey = homePath() + "/.filegive_key"
var fileCert = homePath() + "/.filegive_cert"

var exitChan chan bool = make(chan bool)

var extIP int

var fileSize int64

var forClipboard string

const shouldProfile = false

func checkExit(msg string, err error) {
	if err != nil {
		fmt.Fprint(os.Stderr, msg, ": ", err)
		os.Exit(1)
	}
}

func decideHttps() {
	if *disableHttps {
		return
	}

	canDo := true

	triedGeneration := false
	for !triedGeneration {
		if f, err := os.Open(fileKey); err == nil {
			f.Close()
		} else {
			canDo = false
		}

		if f, err := os.Open(fileCert); err == nil {
			f.Close()
		} else {
			canDo = false
		}

		if canDo {
			break
		}

		if !canDo && !triedGeneration {
			GenerateCertFiles(fileKey, fileCert)
			triedGeneration = true
			canDo = true
		}
	}

	if !canDo {
		fmt.Fprintln(os.Stderr, "Disabling https, can't open key/cert files (use -g).")
		*disableHttps = true
	}
}

func decideLocalPort() (int, error) {
	if *extAddress != "" {
		_, pstr, err := net.SplitHostPort(*extAddress)
		if err != nil {
			return 0, fmt.Errorf("Error parsing external address port: %s", err)
		}
		localPort, err := strconv.Atoi(pstr)
		checkExit("Error parsing port in decideLocalPort", err)
		return localPort, nil
	}

	return 0, nil
}

type Forwarding struct {
	extPort int
	extIP   string
	nat     NAT
	ssh     *SSH
	sshSocat     *SSHSocat
	sshNetcat     *SSHNetcat
}

func NewUPNP(localPort int) (f Forwarding, err error) {
	f = Forwarding{}

	style := "UPnP"
	proto := "TCP"
	if *useUpnp {
		f.nat, err = Discover()
	} else {
		if len(*natpmpGateway) == 0 {
			*natpmpGateway = FindGateway()
			if len(*natpmpGateway) == 0 {
				err = fmt.Errorf("Could find the gateway address for NAT-PMP (use -G)")
				return
			}
		}
		gatewayIP := net.ParseIP(*natpmpGateway)
		if gatewayIP == nil {
			err = fmt.Errorf("Could not parse gateway %q", *natpmpGateway)
			return
		}
		f.nat = NewNatPMP(gatewayIP)
		style = "Nat-PMP"
		proto = "tcp"
	}

	if err != nil {
		err = fmt.Errorf("Error discovering %s gateway: %s", style, err)
		return
	}

	upnpaddr, err := f.nat.GetExternalAddress()
	if err != nil {
		err = fmt.Errorf("%s error getting external address: %s", style, err)
		return
	}
	f.extIP = upnpaddr.String()

	f.extPort, err = f.nat.AddPortMapping(proto, localPort, localPort,
		"filegive", *forwardTimeout)
	if err != nil {
		fmt.Fprintf(os.Stderr,
			"Warning: %s error setting the port mapping (tcp %d): %s\n",
			style, localPort, err)
		err = nil
		f.extPort = localPort
	}

	return
}

func (f Forwarding) Delete() {
	proto := "TCP"
	if *useNatpmp {
		proto = "tcp"
	}

	if f.nat != nil {
		fmt.Fprintln(os.Stderr, "Removing UPnP/Nat-PMP port mapping")
		err := f.nat.DeletePortMapping(proto, f.extPort, f.extPort)
		if err != nil {
			fmt.Fprintf(os.Stderr,
				"Warning: UPnP error setting the port mapping (tcp %d): %s\n",
				f.extPort, err)
		}
	}

	if f.ssh != nil {
		f.ssh.Finish()
	}

	if f.sshSocat != nil {
		f.sshSocat.Finish()
	}
}

func setupListener(localPort int) (listener net.Listener, err error) {
	listener, err = net.Listen("tcp4", fmt.Sprintf(":%d", localPort))
	if err != nil {
		err = fmt.Errorf("Error listening: %s", err)
		return
	}
	return
}

func updateFileSize(file string) error {
	if file == "-" {
		return nil
	}

	f, err := os.Open(file)
	if err != nil {
		return fmt.Errorf("Cannot open file: %s", err)
	}
	defer f.Close()

	// Check if it is a directory
	stat, err := f.Stat()
	if stat.IsDir() {
		return nil
	}

	fileSize, err = f.Seek(0, os.SEEK_END)
	if err != nil {
		return fmt.Errorf("Cannot seek file: %s", err)
	}
	return nil
}

func main() {
	if shouldProfile {
		f, _ := os.Create("profile")
		pprof.StartCPUProfile(f)
		defer pprof.StopCPUProfile()
	}

	// Initialize random, for certificates
	rand.Seed(time.Now().UnixNano())

	flag.Usage = func() {
		fmt.Fprintf(os.Stderr, "filegive v0.7.1 - Copyright 2013 Lluis Batlle i Rossell - AGPLv3+\n")
		fmt.Fprintf(os.Stderr, "usage: %s [options] <file|dir|->\n", os.Args[0])
		fmt.Fprintf(os.Stderr, helpText);
	}
	flag.Parse()

	if *genCert {
		GenerateCertFiles(fileKey, fileCert)

		// Finish normally, if we don't have any file to serve
		if flag.NArg() == 0 {
			return
		}
	}

	if !*receive && flag.NArg() != 1 {
		fmt.Println("Error: No file specified")
		flag.Usage()
		os.Exit(1)
	}

	file := ""
	if !*receive {
		file = flag.Arg(0)
		err := updateFileSize(file)
		if err != nil {
			fmt.Fprintln(os.Stderr, "Error checking file size:", err)
			os.Exit(1)
		}
	}

	decideHttps()

	localPort := *port

	/* Admit *extAddress port setting */
	if localPort == 0 {
		_, extPort, err := net.SplitHostPort(*extAddress)
		if err == nil {
			localPort, err = strconv.Atoi(extPort)
			if err != nil {
				fmt.Println("Error parsing external address port: ", err)
				os.Exit(1)
			}
		}
	}

	// localPort may be 0, to let the listener decide
	listener, err := setupListener(localPort)
	if err != nil {
		fmt.Fprintln(os.Stderr, "Error setting up listener:", err)
		os.Exit(1)
	}

	// Get the localPort used
	_, pstr, err := net.SplitHostPort(listener.Addr().String())
	if err != nil {
		fmt.Println("Error parsing listener address: ", err)
		os.Exit(1)
	}
	localPort, err = strconv.Atoi(pstr)
	checkExit("Error parsing local port used", err)

	// Decide the shownIP and shownPort
	var shownIP string
	var shownPort string

	var forw Forwarding
	if *useUpnp || *useNatpmp {
		forw, err = NewUPNP(localPort)
		if err != nil {
			fmt.Fprintln(os.Stderr, "Error setting up forwarding:", err)
			os.Exit(1)
		}
		defer forw.Delete()

		shownIP = forw.extIP
		shownPort = fmt.Sprint(forw.extPort)
	} else if len(*useSsh) > 0 {
		ssh, err := NewSSH(*useSsh, localPort)
		if err != nil {
			fmt.Fprintln(os.Stderr, "Error setting up ssh tunnel:", err)
			os.Exit(1)
		}
		forw.ssh = ssh
		forw.extPort = localPort
		splitUser := strings.Split(*useSsh, "@")
		forw.extIP = splitUser[len(splitUser)-1]
		shownIP = forw.extIP
		shownPort = fmt.Sprint(forw.extPort)
		defer forw.Delete()
	} else if len(*useSshSocat) > 0 {
		ssh, err := NewSSHSocat(*useSshSocat, localPort)
		if err != nil {
			fmt.Fprintln(os.Stderr, "Error setting up ssh tunnel:", err)
			os.Exit(1)
		}
		forw.sshSocat = ssh
		forw.extPort = localPort
		splitUser := strings.Split(*useSshSocat, "@")
		forw.extIP = splitUser[len(splitUser)-1]
		shownIP = forw.extIP
		shownPort = fmt.Sprint(forw.extPort)
		defer forw.Delete()
	} else if len(*useSshNetcat) > 0 {
		ssh, err := NewSSHNetcat(*useSshNetcat, localPort)
		if err != nil {
			fmt.Fprintln(os.Stderr, "Error setting up ssh tunnel:", err)
			os.Exit(1)
		}
		forw.sshNetcat = ssh
		forw.extPort = localPort
		splitUser := strings.Split(*useSshNetcat, "@")
		forw.extIP = splitUser[len(splitUser)-1]
		shownIP = forw.extIP
		shownPort = fmt.Sprint(forw.extPort)
		defer forw.Delete()
	}

	if *extAddress != "" {
		shownIP, shownPort, err = net.SplitHostPort(*extAddress)
		if err != nil {
			shownIP = *extAddress
			shownPort = ""
		}
	}

	if shownPort == "" {
		shownPort = fmt.Sprint(localPort)
	}

	if shownIP == "" {
		shownIP, err = GetOurIP(nil)
		if err != nil {
			fmt.Println("Error getting the logal IP: ", err)
			shownIP = "127.0.0.1"
		}
	}

	protocol := "http"
	if !*disableHttps {
		protocol = "https"
		cert, err := GetTLSCert(shownIP)
		if err != nil {
			fmt.Fprintln(os.Stderr, "Error setting up TLS: ", err)
			os.Exit(1)
		}
		listener, err = NewHttpsListener(listener, cert)
		if err != nil {
			fmt.Fprintln(os.Stderr, "Error setting up https: ", err)
			os.Exit(1)
		}
	}

	basename := ""
	if *receive {
		basename = "upload"
	} else {
		basename = filepath.Base(file)
	}

	for i := 0; i < *nusers; i++ {
		u := users.Add()
		var prefix string
		if *nusers > 1 {
			prefix = fmt.Sprintf("%d: ", i)
		}
		userprefix := ""
		if len(*urldirectory) >= 1 {
			userprefix = u.userpwd + "/"
		}
		urlraw := fmt.Sprintf("%s://%s:%s/%s%s", protocol, shownIP,
			shownPort, userprefix, basename)
		url, err := url.Parse(urlraw)
		checkExit("Cannot parse the own url", err)
		urlstr := strings.Replace(url.String(), "?", "%3F", -1)

		// Windows
		if i == 0 {
			forClipboard += urlstr + "\r\n"
		}

		fmt.Println(prefix + urlstr)
	}

	// Attention about 'q[enter]', for Windows, where I don't know how to
	// handle signals
	if *useUpnp {
		showQ()
	}

	setClipboard(forClipboard)

	err = serveHttp(file, basename, listener)
	if err != nil {
		fmt.Fprintln(os.Stderr, "Error serving:", err)
		os.Exit(1)
	}
}
