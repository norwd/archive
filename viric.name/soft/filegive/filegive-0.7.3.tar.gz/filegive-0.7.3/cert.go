// Copyright 2009 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license.

// Modifications by Lluís Batlle i Rossell

// Generate a self-signed X.509 certificate for a TLS server.

package main

import (
	"crypto"
	"crypto/rand"
	"crypto/rsa"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"fmt"
	"math/big"
	mrand "math/rand"
	"os"
	"time"
)

type KeyPair struct {
	cert   []byte
	secret crypto.PrivateKey
}

// If parent == nil, self-sign
func GenerateCert(cn string, parent *x509.Certificate, parentPriv *rsa.PrivateKey) *KeyPair {
	// Ephemeral keys.
	keySize := 2048

	if parent == nil {
		keySize = 4096
	}

	priv, err := rsa.GenerateKey(rand.Reader, keySize)
	if err != nil {
		fmt.Fprintln(os.Stderr, "failed to generate private key:", err)
		return nil
	}

	now := time.Now()

	// Firefox checks the Subject, to compare certificate authorities.
	// Multiple authorities issuing a cert with the same serial number,
	// having the same Subject, will make firefox complain. Thus,
	// we put a random part in the subject.
	randname := randomString("XXXXXXXX")

	template := x509.Certificate{
		SerialNumber: new(big.Int).SetInt64(0),
		Subject: pkix.Name{
			CommonName:   cn,
			Organization: []string{"filegive " + randname},
			OrganizationalUnit: []string{"filegive"},
			Locality: []string{"somewhere"},
			Province: []string{"somewhere"},
			Country: []string{"sw"},
		},
		NotBefore: now.Add(-5 * time.Minute).UTC(),
		NotAfter:  now.AddDate(10, 0, 0).UTC(), // valid for 10 years.

		// Enabling SubjectKeyId makes Chrome and IE refuse it
		//SubjectKeyId: []byte{1, 2, 3, 4},
		KeyUsage:     x509.KeyUsageKeyEncipherment | x509.KeyUsageDigitalSignature |
			x509.KeyUsageKeyAgreement | x509.KeyUsageDataEncipherment,
	}

	if parent == nil {
		parent = &template
		parentPriv = priv
		template.BasicConstraintsValid = true
		template.IsCA = true
		template.KeyUsage |= x509.KeyUsageCertSign
	} else {
		template.SerialNumber = new(big.Int).SetInt64(mrand.Int63())
	}
	derBytes, err := x509.CreateCertificate(rand.Reader, &template, parent, &priv.PublicKey,
		parentPriv)
	if err != nil {
		fmt.Fprintln(os.Stderr, "Failed to create certificate:", err)
		return nil
	}

	return &KeyPair{derBytes, priv}
}

func GenerateCertFiles(keyFile, certFile string) {
	kp := GenerateCert("Filegive CA", nil, nil)
	if kp == nil {
		return
	}

	certOut, err := os.Create(certFile)
	if err != nil {
		fmt.Fprintln(os.Stderr, "failed to open cert.pem for writing:", err)
		return
	}
	pem.Encode(certOut, &pem.Block{Type: "CERTIFICATE", Bytes: kp.cert})
	certOut.Close()
	fmt.Fprintln(os.Stderr, "Generated", certFile)

	keyOut, err := os.OpenFile(keyFile, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, 0600)
	if err != nil {
		fmt.Fprintln(os.Stderr, "failed to open key.pem for writing:", err)
		return
	}
	pem.Encode(keyOut, &pem.Block{Type: "RSA PRIVATE KEY",
		Bytes: x509.MarshalPKCS1PrivateKey(kp.secret.(*rsa.PrivateKey))})
	keyOut.Close()
	fmt.Fprintln(os.Stderr, "Generated", keyFile)
}

func GetTLSCert(cn string) (cert tls.Certificate, err error) {
	cert, err = tls.LoadX509KeyPair(fileCert, fileKey)
	if err != nil {
		err = fmt.Errorf("Cannot load TLS certificates: %s", err)
		return
	}

	if *tlsFromCA {
		return
	}

	// Generate ephemereal
	parentCert, err2 := x509.ParseCertificate(cert.Certificate[0])
	if err2 != nil {
		err = fmt.Errorf("Cannot parse the stored cert: %s", err2)
		return
	}
	kp := GenerateCert(cn, parentCert, cert.PrivateKey.(*rsa.PrivateKey))

	x509Cert, err2 := x509.ParseCertificate(kp.cert)
	if err2 != nil {
		err = fmt.Errorf("Cannot parse the internal new cert: %s", err2)
		return
	}

	newCert := tls.Certificate{}
	newCert.PrivateKey = kp.secret
	newCert.Leaf = x509Cert
	newCert.Certificate = [][]byte{kp.cert, cert.Certificate[0]}

	cert = newCert

	return
}
