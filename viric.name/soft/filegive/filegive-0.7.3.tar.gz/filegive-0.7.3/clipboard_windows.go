// +build windows

/*
   filegive - Easy sending of files
   Copyright (C) 2013  Lluís Batlle i Rossell

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU Affero General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Affero General Public License for more details.

   You should have received a copy of the GNU Affero General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package main

import (
	"fmt"
	"os"
	"syscall"
	"unsafe"
)

var (
	user32           = syscall.MustLoadDLL("user32")
	kernel32         = syscall.MustLoadDLL("kernel32")
	openClipboard    = user32.MustFindProc("OpenClipboard")
	closeClipboard   = user32.MustFindProc("CloseClipboard")
	setClipboardData = user32.MustFindProc("SetClipboardData")
	emptyClipboard   = user32.MustFindProc("EmptyClipboard")
	globalAlloc      = kernel32.MustFindProc("GlobalAlloc")
	globalLock       = kernel32.MustFindProc("GlobalLock")
	globalUnlock     = kernel32.MustFindProc("GlobalUnlock")
)

func setClipboard(s string) {
	r, _, err := openClipboard.Call(0)
	if r == 0 {
		fmt.Fprintln(os.Stderr, "OpenClipboard failed: ", err)
		return
	}
	defer closeClipboard.Call()

	r, _, err = emptyClipboard.Call()
	if r == 0 {
		fmt.Fprintln(os.Stderr, "EmptyClipboard failed: ", err)
		return
	}

	zstr := append([]byte(s), 0)
	h, _, err := globalAlloc.Call(2, uintptr(len(zstr)))
	if h == 0 {
		fmt.Fprintln(os.Stderr, "GlobalAlloc failed: ", err)
		return
	}
	ptr, _, err := globalLock.Call(h)
	if r == 0 {
		fmt.Fprintln(os.Stderr, "GlobalLock failed: ", err)
		return
	}
	palloc := (*[1 << 20]byte)(unsafe.Pointer(ptr))
	for i := range zstr {
		palloc[i] = zstr[i]
	}
	r, _, err = globalUnlock.Call(h)
	if r != 0 {
		fmt.Fprintln(os.Stderr, "GlobalUnlock failed: ", err)
		return
	}
	r, _, err = setClipboardData.Call(1, ptr)
	if r == 0 {
		fmt.Fprintln(os.Stderr, "SetClipboardData failed: ", err)
		return
	}
}
