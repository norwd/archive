/* filegive - Easy sending of files
   Copyright (C) 2013  Lluís Batlle i Rossell

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU Affero General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Affero General Public License for more details.

   You should have received a copy of the GNU Affero General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package main

import (
	"io"
	"os"
	"net/http"
)

type FileSystem struct {
	root string
	user *User
}

type File struct {
	internal *os.File
	reader io.ReadSeeker
}

func (fs FileSystem) Open(name string) (http.File, error) {
	f, err := os.Open(fs.root + "/" + name)

	if err == nil {
		return &File{f, NewCounterSeeker(f, fs.user)}, nil
	}
	return nil, err
}

func (f *File) Close() error {
	return f.internal.Close()
}

func (f *File) Stat() (os.FileInfo, error) {
	return f.internal.Stat()
}

func (f *File) Readdir(count int) ([]os.FileInfo, error) {
	return f.internal.Readdir(count)
}

func (f *File) Read(p []byte) (int, error) {
	return f.reader.Read(p)
}

func (f *File) Seek(offset int64, whence int) (int64, error) {
	return f.reader.Seek(offset, whence)
}
