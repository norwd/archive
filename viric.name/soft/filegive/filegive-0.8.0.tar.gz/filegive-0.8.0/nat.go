// BSD license, file developed based on Taipei-Torrent's.

package main

import (
	"net"
)

// protocol is either "udp" or "tcp"
type NAT interface {
	GetExternalAddress() (addr net.IP, err error)
	GetLocalAddress() (addr net.IP, err error)
	AddPortMapping(proto string, port int, description string, timeout int) (mappedExternalPort int, err error)
	DeletePortMapping(proto string, port int) (err error)
}
