/* filegive - Easy sending of files
   Copyright (C) 2013  Lluís Batlle i Rossell

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU Affero General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Affero General Public License for more details.

   You should have received a copy of the GNU Affero General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package main

import (
	"flag"
	"fmt"
	"math/rand"
	"net"
	"net/url"
	"os"
	"path/filepath"
	"runtime/pprof"
	"strconv"
	"strings"
	"time"
	"github.com/mdp/qrterminal"
)

var useUpnp = flag.Bool("u", false, "use UPnP")
var useNatpmp = flag.Bool("A", false, "use NAT-PMP")
var natpmpGateway = flag.String("G", "", "manual gateway IP address (for NAT-PMP)")
var useSsh = flag.String("s", "", "use ssh host tunnel (requires non-default sshd_config)")
var useSshSocat = flag.String("ss", "", "use ssh tunnel, with socat at the remote side")
var useSshNetcat = flag.String("sn", "", "use ssh tunnel, with GNU netcat at the remote side")
var forwardTimeout = flag.Int("t", 0, "UPnP/NAT-PMP forwarding timeout in secs (0, unlimited)")
var extAddress = flag.String("e", "", "known external address (ip:port)")
var genCert = flag.Bool("g", false, "regenerate CA certificate")
var disableHttps = flag.Bool("p", false, "disable https serving files")
var noExit = flag.Bool("N", false, "don't exit at end of downloads")
var nusers = flag.Int("n", 1, "number of destination users")
var rate = flag.Int("r", 0, "rate limit to these KiB/S (0=unlimited)")
var urldirectory = flag.String("D", "XXXXXX", "directory in URL (X means random char)")
var receive = flag.Bool("R", false, "receive a file, not send (http upload)")
var port = flag.Int("P", 0, "port to bind to (local, UPnP, NAT-PMP, ...)")
var tlsFromCA = flag.Bool("ca", false, "use the CA certificate instead of generating one")
var interactive = flag.Bool("i", false, "interactively acknowledge each connection")
var downloadFile = flag.Bool("d", false, "offer download to the browser")
var isVideo = flag.Bool("V", false, "serve WebRTC videoconference")

var helpText = `options:
  -A          use NAT-PMP
  -D <str>    directory in URL (X means random char, XXXXXX default)
  -d          make the browser download to a file
  -G          manual gateway IP address (for NAT-PMP)
  -N          don't exit at end of downloads
  -P <port>   port to bind to (local, UPnP, NAT-PMP, ...)
  -R          receive a file, not send (http upload, in browser side)
  -ca         use the CA certificate instead of generating one
  -e <h:p>    known external address (ip:port)
  -g          regenerate CA certificate
  -i          interactive mode, you acknowledge download attempts
  -n <n>      number of destination users (default 1)
  -p          disable https serving files
  -r          rate limit to these KiB/S (0=unlimited, default)
  -s <host>   use ssh tunnel (requires non-default sshd_config)
  -ss <host>  use ssh tunnel, with socat at the remote side
  -sn <host>  use ssh tunnel, with GNU netcat at the remote side
  -t          UPnP/NAT-PMP forwarding timeout in secs (0, unlimited)
  -u          use UPnP
  -V          serve WebRTC videoconference

Env vars:
  FILEGIVE_START_PORT   Serve at this port or next if busy
`

var fileKey = homePath() + "/.filegive_key"
var fileCert = homePath() + "/.filegive_cert"

var exitChan chan bool = make(chan bool)

var fileSize int64

var forClipboard string

const shouldProfile = false

var extIP string
var ourIP string
var forw Forwarding

func checkExit(msg string, err error) {
	if err != nil {
		fmt.Fprint(os.Stderr, msg, ": ", err)
		os.Exit(1)
	}
}

func decideHttps() {
	if *disableHttps {
		return
	}

	canDo := true

	triedGeneration := false
	for !triedGeneration {
		if f, err := os.Open(fileKey); err == nil {
			f.Close()
		} else {
			canDo = false
		}

		if f, err := os.Open(fileCert); err == nil {
			f.Close()
		} else {
			canDo = false
		}

		if canDo {
			break
		}

		if !canDo && !triedGeneration {
			GenerateCertFiles(fileKey, fileCert)
			triedGeneration = true
			canDo = true
		}
	}

	if !canDo {
		fmt.Fprintln(os.Stderr, "Disabling https, can't open key/cert files (use -g).")
		*disableHttps = true
	}
}

func decideLocalPort() (int, error) {
	if *extAddress != "" {
		_, pstr, err := net.SplitHostPort(*extAddress)
		if err != nil {
			return 0, fmt.Errorf("Error parsing external address port: %s", err)
		}
		localPort, err := strconv.Atoi(pstr)
		checkExit("Error parsing port in decideLocalPort", err)
		return localPort, nil
	}

	return 0, nil
}

type Forwarding struct {
	extPort int
	extIP   string
	proto   string
	nat     NAT
	ssh     *SSH
	sshSocat     *SSHSocat
	sshNetcat     *SSHNetcat
}

var forwardings []Forwarding

func deleteForwardings() {
	for i := range forwardings {
		forwardings[i].Delete()
	}
}

func NewUPNP(localPort int, proto string) (f Forwarding, err error) {
	f = Forwarding{}

	style := "UPnP"
	if *useUpnp {
		f.nat, err = UpnpDiscover()
	} else {
		if len(*natpmpGateway) == 0 {
			*natpmpGateway = FindGateway()
			if len(*natpmpGateway) == 0 {
				err = fmt.Errorf("Could find the gateway address for NAT-PMP (use -G)")
				return
			}
		}
		gatewayIP := net.ParseIP(*natpmpGateway)
		if gatewayIP == nil {
			err = fmt.Errorf("Could not parse gateway %q", *natpmpGateway)
			return
		}
		f.nat = NewNatPMP(gatewayIP)
		style = "Nat-PMP"
	}

	if err != nil {
		err = fmt.Errorf("Error discovering %s gateway: %s", style, err)
		return
	}

	upnpaddr, err := f.nat.GetExternalAddress()
	if err != nil {
		err = fmt.Errorf("%s error getting external address: %s", style, err)
		return
	}
	f.extIP = upnpaddr.String()

	// This is for video; we may ignore it if we don't have it
	localaddr, err := f.nat.GetLocalAddress()
	if err == nil {
		ourIP = localaddr.String()
		extIP = f.extIP
	}

	f.extPort, err = f.nat.AddPortMapping(proto, localPort, "filegive", *forwardTimeout)
	if err != nil {
		fmt.Fprintf(os.Stderr,
			"Warning: %s error setting the port mapping (tcp %d): %s\n",
			style, localPort, err)
		err = nil
		f.extPort = localPort
	}
	f.proto = proto

	return
}

func (f Forwarding) Delete() {
	if f.nat != nil {
		fmt.Fprintln(os.Stderr, "Removing UPnP/Nat-PMP port mapping (", f.proto, f.extPort, ")")
		err := f.nat.DeletePortMapping(f.proto, f.extPort)
		if err != nil {
			fmt.Fprintf(os.Stderr,
				"Warning: UPnP error setting the port mapping (tcp %d): %s\n",
				f.extPort, err)
		}
	}

	if f.ssh != nil {
		f.ssh.Finish()
	}

	if f.sshSocat != nil {
		f.sshSocat.Finish()
	}
}

func setupListener(localPort int) (listener net.Listener, err error) {
	listener, err = net.Listen("tcp", fmt.Sprintf(":%d", localPort))
	if err != nil {
		err = fmt.Errorf("Error listening: %s", err)
		return
	}
	return
}

func setupListenerStart(startPort int) (listener net.Listener, err error) {
	for {
		listener, err = net.Listen("tcp", fmt.Sprintf(":%d", startPort))
		if err == nil {
			return
		}
		startPort += 1
	}
}

func updateFileSize(file string) error {
	if file == "-" || *isVideo {
		return nil
	}

	f, err := os.Open(file)
	if err != nil {
		return fmt.Errorf("Cannot open file: %s", err)
	}
	defer f.Close()

	// Check if it is a directory
	stat, err := f.Stat()
	if stat.IsDir() {
		return nil
	}

	fileSize, err = f.Seek(0, os.SEEK_END)
	if err != nil {
		return fmt.Errorf("Cannot seek file: %s", err)
	}
	return nil
}

func main() {
	if shouldProfile {
		f, _ := os.Create("profile")
		pprof.StartCPUProfile(f)
		defer pprof.StopCPUProfile()
	}

	// Initialize random, for certificates
	rand.Seed(time.Now().UnixNano())

	flag.Usage = func() {
		fmt.Fprintf(os.Stderr, "filegive v0.8.0 - Copyright 2020 Lluis Batlle i Rossell - AGPLv3+\n")
		fmt.Fprintf(os.Stderr, "usage: %s [options] <file|dir|-|-V>\n", os.Args[0])
		fmt.Fprintf(os.Stderr, helpText);
	}
	flag.Parse()

	if *genCert {
		GenerateCertFiles(fileKey, fileCert)

		// Finish normally, if we don't have any file to serve
		if flag.NArg() == 0 {
			return
		}
	}

	if (!*receive && !*isVideo) && flag.NArg() != 1 {
		fmt.Println("Error: No file specified")
		flag.Usage()
		os.Exit(1)
	}

	file := ""
	if !*receive && !*isVideo {
		file = flag.Arg(0)
		err := updateFileSize(file)
		if err != nil {
			fmt.Fprintln(os.Stderr, "Error checking file size:", err)
			os.Exit(1)
		}
	}

	decideHttps()

	localPort := *port

	/* Admit *extAddress port setting */
	if localPort == 0 {
		_, extPort, err := net.SplitHostPort(*extAddress)
		if err == nil {
			localPort, err = strconv.Atoi(extPort)
			if err != nil {
				fmt.Println("Error parsing external address port: ", err)
				os.Exit(1)
			}
		}
	}

	startPortStr := os.Getenv("FILEGIVE_START_PORT")
	var listener net.Listener
	if (startPortStr != "" && localPort == 0) {
		startPort, err := strconv.Atoi(startPortStr)
		if err != nil {
			fmt.Fprintln(os.Stderr, "Error parsing FILEGIVE_START_PORT:", err)
			os.Exit(1)
		}
		listener, err = setupListenerStart(startPort)
		if err != nil {
			fmt.Fprintln(os.Stderr, "Error setting up listener:", err)
			os.Exit(1)
		}
	} else {
		// localPort may be 0, to let the listener decide
		var err error
		listener, err = setupListener(localPort)
		if err != nil {
			fmt.Fprintln(os.Stderr, "Error setting up listener:", err)
			os.Exit(1)
		}
	}

	// Get the localPort used
	_, pstr, err := net.SplitHostPort(listener.Addr().String())
	if err != nil {
		fmt.Println("Error parsing listener address: ", err)
		os.Exit(1)
	}
	localPort, err = strconv.Atoi(pstr)
	checkExit("Error parsing local port used", err)

	// Decide the shownIP and shownPort
	var shownIP string
	var shownPort string

	defer deleteForwardings()

	if *useUpnp || *useNatpmp {
		forw, err = NewUPNP(localPort, "tcp")
		if err != nil {
			fmt.Fprintln(os.Stderr, "Error setting up forwarding:", err)
			os.Exit(1)
		}
		forwardings = append(forwardings, forw)

		shownIP = forw.extIP
		shownPort = fmt.Sprint(forw.extPort)
	} else if len(*useSsh) > 0 {
		ssh, err := NewSSH(*useSsh, localPort)
		if err != nil {
			fmt.Fprintln(os.Stderr, "Error setting up ssh tunnel:", err)
			os.Exit(1)
		}
		forw.ssh = ssh
		forw.extPort = localPort
		splitUser := strings.Split(*useSsh, "@")
		forw.extIP = splitUser[len(splitUser)-1]
		shownIP = forw.extIP
		shownPort = fmt.Sprint(forw.extPort)
		forwardings = append(forwardings, forw)
	} else if len(*useSshSocat) > 0 {
		ssh, err := NewSSHSocat(*useSshSocat, localPort)
		if err != nil {
			fmt.Fprintln(os.Stderr, "Error setting up ssh tunnel:", err)
			os.Exit(1)
		}
		forw.sshSocat = ssh
		forw.extPort = localPort
		splitUser := strings.Split(*useSshSocat, "@")
		forw.extIP = splitUser[len(splitUser)-1]
		shownIP = forw.extIP
		shownPort = fmt.Sprint(forw.extPort)
		forwardings = append(forwardings, forw)
	} else if len(*useSshNetcat) > 0 {
		ssh, err := NewSSHNetcat(*useSshNetcat, localPort)
		if err != nil {
			fmt.Fprintln(os.Stderr, "Error setting up ssh tunnel:", err)
			os.Exit(1)
		}
		forw.sshNetcat = ssh
		forw.extPort = localPort
		splitUser := strings.Split(*useSshNetcat, "@")
		forw.extIP = splitUser[len(splitUser)-1]
		shownIP = forw.extIP
		shownPort = fmt.Sprint(forw.extPort)
		forwardings = append(forwardings, forw)
	}

	if *extAddress != "" {
		shownIP, shownPort, err = net.SplitHostPort(*extAddress)
		if err != nil {
			shownIP = *extAddress
			shownPort = ""
		}
	}

	if shownPort == "" {
		shownPort = fmt.Sprint(localPort)
	}

	if shownIP == "" {
		shownIP, err = GetOurIP(nil)
		if err != nil {
			fmt.Println("Error getting the logal IP: ", err)
			shownIP = "127.0.0.1"
		}
	}

	protocol := "http"
	if !*disableHttps {
		protocol = "https"
		cert, err := GetTLSCert(shownIP)
		if err != nil {
			fmt.Fprintln(os.Stderr, "Error setting up TLS: ", err)
			os.Exit(1)
		}
		listener, err = NewHttpsListener(listener, cert)
		if err != nil {
			fmt.Fprintln(os.Stderr, "Error setting up https: ", err)
			os.Exit(1)
		}
	}

	basename := ""
	if *receive {
		basename = "upload"
	} else if *isVideo {
		basename = "video"
	} else {
		basename = filepath.Base(file)
	}

	for i := 0; i < *nusers; i++ {
		u := users.Add()
		var prefix string
		if *nusers > 1 {
			prefix = fmt.Sprintf("%d: ", i)
		}
		userprefix := ""
		if len(*urldirectory) >= 1 {
			userprefix = u.userpwd + "/"
		}
		myurl := url.URL{Scheme: protocol,
			Host: shownIP + ":" + shownPort,
			Path: userprefix + basename}
		urlstr := myurl.String()

		// Windows
		if i == 0 {
			forClipboard += urlstr + "\r\n"
		}
		qrterminal.Generate(urlstr, 0/*redund level*/, os.Stdout)

		fmt.Println(prefix + urlstr)
		if *isVideo && *useUpnp && len(ourIP) > 0 {
			internalURL := url.URL{Scheme: protocol,
				Host: ourIP + ":" + shownPort,
				Path: userprefix + basename}
			internalURLstr := internalURL.String()

			fmt.Println(prefix + internalURLstr)
		}

		isSSH := len(*useSsh) > 0;
		isSSH = isSSH || len(*useSshSocat) > 0;
		isSSH = isSSH || len(*useSshNetcat) > 0;

		if *isVideo && isSSH {
			internalURL := url.URL{Scheme: protocol,
				Host: "localhost:" + shownPort,
				Path: userprefix + basename}
			internalURLstr := internalURL.String()

			fmt.Println(prefix + internalURLstr)
		}
	}

	// Attention about 'q[enter]', for Windows, where I don't know how to
	// handle signals
	if *useUpnp {
		showQ()
	}

	setClipboard(forClipboard)

	err = serveHttp(file, basename, listener)
	if err != nil {
		fmt.Fprintln(os.Stderr, "Error serving:", err)
		os.Exit(1)
	}
}
