// Just enough UPnP to be able to forward ports
//
// Copyright jackpal, BSD license, file developed based on Taipei-Torrent's.

// Modifications by Lluís Batlle i Rossell

package main

import (
    "errors"
    "net"
    "strings"
    "fmt"
    "github.com/huin/goupnp"
    //"github.com/huin/goupnp/dcps/internetgateway1"
    "github.com/huin/goupnp/dcps/internetgateway2"
)

type upnpNAT struct {
    client     UPNPClient
}

type UPNPClient interface {
  GetExternalIPAddress() (NewExternalIPAddress string, err error)
  AddPortMapping(NewRemoteHost string, NewExternalPort uint16, NewProtocol string, NewInternalPort uint16, NewInternalClient string, NewEnabled bool, NewPortMappingDescription string, NewLeaseDuration uint32) (err error)
  DeletePortMapping(NewRemoteHost string, NewExternalPort uint16, NewProtocol string) (err error)
  GetServiceClient() *goupnp.ServiceClient
}

func UpnpDiscover() (NAT, error) {
	nat := &upnpNAT{}

    ppp1clients, _, err := internetgateway2.NewWANPPPConnection1Clients()
    if err != nil {
        return nil, err
    }
	if len(ppp1clients) > 0 {
		if len(ppp1clients) > 1 {
			fmt.Println("More than one UPNP device. Using the first.")
		}
		nat.client = ppp1clients[0]
	}


    wan2clients, _, err := internetgateway2.NewWANIPConnection2Clients()
    if err != nil {
        return nil, err
    }
	if len(wan2clients) > 0 {
		if len(wan2clients) > 1 {
			fmt.Println("More than one UPNP device. Using the first.")
		}
		nat.client = wan2clients[0]
	}

    wan1clients, _, err := internetgateway2.NewWANIPConnection1Clients()
    if err != nil {
        return nil, err
    }
	if len(wan1clients) > 0 {
		if len(wan1clients) > 1 {
			fmt.Println("More than one UPNP device. Using the first.")
		}
		nat.client = wan1clients[0]
	} else {
        return nat, errors.New("No UPNP devices found")
    }
    return nat, nil
}



func GetOurIP(destIP net.IP) (ip string, err error) {
    var ifs []net.Interface
    ifs, err = net.Interfaces()
    if err != nil {
        return
    }

    for i := range ifs {
        var addrs []net.Addr
        addrs, err = ifs[i].Addrs()
        if err == nil {
            for j := range addrs {
                var parsed net.IP
                var ipnet *net.IPNet

                // Linux adds "/8" or "/24" to interfaces, windows not.
                ipString := addrs[j].String()
                if strings.Contains(ipString, "/") {
                    parsed, ipnet, err = net.ParseCIDR(ipString)
                } else {
                    parsed = net.ParseIP(ipString)
                }

                // Handle 0.0.0.0 addresses windows gives in some interfaces
                if parsed == nil || parsed.IsUnspecified() {
                    continue
                }
                ip4 := parsed.To4()
                if ip4 == nil {
                    continue
                }

                if !ip4.IsLoopback() {
                    if destIP != nil && ipnet != nil && !ipnet.Contains(destIP) {
                        continue
                    }
                    ip = ip4.String()
                    return
                }
            }
        }
    }
    err = errors.New("Cannot find the local IP address")
    return
}

// Funciton from: https://gitlab.com/NebulousLabs/go-upnp/-/raw/master/upnp.go
// MIT License
// Copyright (c) 2015 Nebulous 
func (n *upnpNAT) GetLocalAddress() (addr net.IP, err error) {
	host, _, _ := net.SplitHostPort(n.client.GetServiceClient().RootDevice.URLBase.Host)
	devIP := net.ParseIP(host)
	if devIP == nil {
		return nil, errors.New("could not determine router's internal IP")
	}

	ifaces, err := net.Interfaces()
	if err != nil {
		return nil, err
	}

	addresses := make([]net.IP, 0)
	for _, iface := range ifaces {
		addrs, err := iface.Addrs()
		if err != nil {
			return nil, err
		}

		for _, addr := range addrs {
			if x, ok := addr.(*net.IPNet); ok && x.Contains(devIP) {
				addresses = append(addresses, x.IP)
			}
		}
	}

	if len(addresses) > 0 {
		if len(addresses) > 1 {
			fmt.Println("WARNING! UPnP may fail because we have more than one local address reaching the gateway:")
			for _, a := range addresses {
				fmt.Println("  ", a)
			}
		}
		return addresses[0], nil
	}

	return nil, errors.New("could not determine internal IP")
}

func (n *upnpNAT) GetExternalAddress() (addr net.IP, err error) {
    var addrstr string
    addrstr, err = n.client.GetExternalIPAddress()
    if err != nil {
        return
    }
    addr = net.ParseIP(addrstr)
    return
}

func (n *upnpNAT) AddPortMapping(proto string, port int, description string, timeout int) (mappedExternalPort int, err error) {
    mappedExternalPort = port
	var local net.IP
	local, err = n.GetLocalAddress()
	if err != nil {
		return
	}
    err = n.client.AddPortMapping("", uint16(port),
		strings.ToUpper(proto), uint16(port),
        local.String(), true /*enabled*/, description, uint32(timeout))
	return
}

func (n *upnpNAT) DeletePortMapping(proto string, port int) (err error) {
    err = n.client.DeletePortMapping("", uint16(port), strings.ToUpper(proto))
	return
}
