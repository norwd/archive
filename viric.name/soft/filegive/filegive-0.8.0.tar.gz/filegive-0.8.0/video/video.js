'use strict';

var startButton = document.getElementById('startButton');
var callButton = document.getElementById('callButton');
var hangupButton = document.getElementById('hangupButton');
var muteButton = document.getElementById('muteButton');
var sendButton = document.getElementById('sendButton');

var socket = new WebSocket(socketUrl);

var isChannelReady = false;
var isStarted = false;
var localStream;
var pc;
var remoteStream;
var candidateBuffer = [];
var nick = "nonamed";
var totalPeers;

var offerOptions = {
  offerToReceiveAudio: 1,
  offerToReceiveVideo: 1
};


// Set up audio and video regardless of what devices are present.
var sdpConstraints = {
  'mandatory': {
    'OfferToReceiveAudio': true,
    'OfferToReceiveVideo': true
  }
};

var lastResult;

window.setInterval(function() {
    if (localVideo.videoWidth) {
      var res = document.querySelector('div#localResolution');
      res.innerHTML = '<strong>Resolution:</strong> ' + localVideo.videoWidth
        + "x" + localVideo.videoHeight;
    }
    if (remoteVideo.videoWidth) {
      var res = document.querySelector('div#remoteResolution');
      res.innerHTML = '<strong>Resolution:</strong> ' + remoteVideo.videoWidth
        + "x" + remoteVideo.videoHeight;
    }
    if (!pc) {
        return;
    }
    var remoteBitrate = document.querySelector('div#remoteBitrate');
    remoteBitrate.innerHTML = '';
    var localBitrate = document.querySelector('div#localBitrate');
    localBitrate.innerHTML = '';

    pc.getStats(null).then(function(res) {
        Object.keys(res).forEach(function(key) {
            var report = res[key];
            var bytes;

            var now = report.timestamp;
            if (report.type === 'inboundrtp' && report.mediaType === 'video' &&
                    !report.isRemote) {
                remoteBitrate.innerHTML = '<strong>VideoIn Bitrate:</strong>' +
                   Math.floor(report.bitrateMean / 1024) + ' kbps';
            }
            if (report.type === 'outboundrtp' && report.mediaType === 'video' &&
                    !report.isRemote) {
                localBitrate.innerHTML = '<strong>VideoOut Bitrate:</strong>' +
                   Math.floor(report.bitrateMean / 1024) + ' kbps';
            }

            if ((report.type === 'outboundrtp') ||
                (report.type === 'outbound-rtp') ||
                (report.type === 'ssrc' && report.bytesSent)) {

                bytes = report.bytesSent;
                if (lastResult && lastResult[report.id]) {
                    var byterate = (bytes - lastResult[report.id].bytesSent) /
                        (now - lastResult[report.id].timestamp);
                        console.log("Byte rate " + key + ": " + byterate + " KB/s")
                }
            }

            if (report.type === 'localcandidate') {
                localAddress.innerHTML = '<strong>IP address:</strong> ' +
                  report.ipAddress + ':' + report.portNumber + '/' +
                  report.transport;
            }
            if (report.type === 'remotecandidate') {
                remoteAddress.innerHTML = '<strong>IP address:</strong> ' +
                  report.ipAddress + ':' + report.portNumber + '/' +
                  report.transport;
            }
        })
        lastResult = res;
    })
}, 2000)

function chatLog(text) {
    var item = document.createElement("div");
    item.innerHTML = "<b>" + text + "</b>";
    appendLog(item);
}

socket.onmessage = function (event) {
    var msg = JSON.parse(event.data);
    //console.log(msg)
    if (msg.type === "joined") {
        if (!isChannelReady)
        {
            isChannelReady = true;
            nick = "id" + msg.id;
        }
        totalPeers = msg.len;
        chatLog("Joined id" + msg.id + " (Total: " + totalPeers + ")");
    } else if (msg.type === "chat") {
      var item = document.createElement("div");
      item.innerText = msg.nick + ": " + msg.data;
      appendLog(item);
    } else if (msg.type === "message") {
        var message = msg.data
        //console.log("Message data: " + JSON.stringify(message, null,1))
        if (message.type === 'offer') {
         var ans = window.confirm("Accept call?");
         if (ans)
         {
             var fun = function () {
                 if (localStream)
                    startLocalPC();
                 if (pc)
                 {
                     pc.setRemoteDescription(new RTCSessionDescription(message));
                     for (var i = 0; i < candidateBuffer.length; i++) {
                         var cand = candidateBuffer[i];
                         pc.addIceCandidate(cand);
                     }
                     candidateBuffer = [];
                     doAnswer();
                 }
             }
             if (!localStream)
                start().then(fun);
             else
                fun();
         } else {
             stop();
         }
       } else if (message.type === 'answer' && isStarted) {
         pc.setRemoteDescription(new RTCSessionDescription(message));
       } else if (message.type === 'candidate') {
             var candidate = new RTCIceCandidate({
               sdpMLineIndex: message.label,
               candidate: message.candidate
             });
         if (pc) {
             pc.addIceCandidate(candidate);
         } else {
             candidateBuffer.push(candidate);
         }
       } else if ((message === 'hangup' || message === 'bye') && isStarted) {
         chatLog('Remote hanged up');
         hangup();
       }
    }
}

socket.onopen = function(event) {
    socket.send(JSON.stringify("join",null,1))
}

function sendMessage(msg) {
    var obj = { type: "message", data: msg }
    socket.send(JSON.stringify(obj,null,1))
}

function sendChat(msg) {
    var res = msg.split(" ", 2);
    if (res.length == 2 && res[0] == "/name")
    {
        nick = res[1];
        return;
    }
    var obj = { type: "chat", data: msg, nick: nick }
    socket.send(JSON.stringify(obj,null,1))
}

var localVideo = document.querySelector('#localVideo');
var remoteVideo = document.querySelector('#remoteVideo');
var maxWidth = document.querySelector('#resmaxwidth');
var audioVideo = document.querySelector('#audiovideo');

function start() {
    startButton.disabled = true

    var constraints = {
      audio: true
    }
    var videoOption = audioVideo.value;
    if(videoOption.indexOf("Video") !== -1)
    {
        var isScreen = 
        constraints.video = {
            width: {
                max: Number(maxWidth.value),
                min: Number(maxWidth.value)-300
            },
            height: {
                max: 2048,
                min: 100
            }
        }
        if (videoOption.indexOf("Screen") !== -1) {
            constraints.video.mediaSource = "screen";
        }
        console.log(constraints.video)
    } else {
        constraints.video = false;
    }

    if (localStream) {
        localStream.getTracks().forEach(function(track) {
            track.stop();
        });
    }

    return navigator.mediaDevices.getUserMedia(constraints)
    .then(gotStream)
    .catch(function(e) {
      startButton.disabled = false
      alert('getUserMedia() error: ' + e.name);
    });
}

function muteUnmute() {
    if (localStream)
    {
        var v = localStream.getAudioTracks()[0].enabled;
        localStream.getAudioTracks()[0].enabled = !v;
        if (v) {
            muteButton.textContent = "Unmute";
        } else {
            muteButton.textContent = "Mute";
        }
    }
}

startButton.onclick = start;
startButton.disabled = false;
callButton.disabled = false;
callButton.onclick = startCall;
hangupButton.disabled = true;
hangupButton.onclick = hangup;
muteButton.onclick = muteUnmute;

/* meter */
var meterControl = document.querySelector('div#local meter');
try {
  window.AudioContext = window.AudioContext || window.webkitAudioContext;
  window.audioContext = new AudioContext();
} catch (e) {
  alert('Web Audio API not supported.');
}

var meterMic;

var meterScript = window.audioContext.createScriptProcessor(2048, 1, 1);
meterScript.onaudioprocess = function(event) {
  var input = event.inputBuffer.getChannelData(0);
  var max = 0.0;
  for (var i = 0; i < input.length; ++i) {
      var a = Math.abs(input[i]);
      if (a > max)
        max = a;
  }
  meterControl.value = max;
}

function gotStream(stream) {
  console.log('Adding local stream.');
  localVideo.srcObject = stream;
  localVideo.play();
  muteButton.textContent = "Mute";

  /* Allow call + stop */
  hangupButton.disabled = false

  meterMic = window.audioContext.createMediaStreamSource(stream);
  meterMic.connect(meterScript)
  meterScript.connect(window.audioContext.destination);
  localStream = stream;
}


function startLocalPC() {
    hangupButton.disabled = false
    createPeerConnection();
    pc.addStream(localStream);
    /* In firefox we should run addTrack:
    stream.getTracks().forEach(track => pc.addTrack(track, stream));
    Then we can run things like bandwidth limit:
    var sender = pc1.addTrack(..., stream)
    var encoding = { maxBitrate: 60000, scaleResolutionDownBy: 2 };
    sender.setParameters({ encodins: [encoding] })
    */

    isStarted = true;
}

function startCall() {
  var fun = function() {
      if (isChannelReady && localStream) {
        startLocalPC();
        doCall();
      } else if (!isChannelReady) {
        chatLog("Cannot call if the other side is not joined")
      }
  }
  if (!localStream)
    start().then(fun).catch(function(e) {
      stop();
    });
  else
    fun();
}

window.onbeforeunload = function() {
  stop()
  sendMessage('bye');
};

/////////////////////////////////////////////////////////

function createPeerConnection() {
  try {
    var stunSel = document.querySelector('#stun');
    var pcConfig = {
            'iceServers': []
    };
    if (stunSel.value == "Google")
    {
        pcConfig.iceServers.push({
                'url': 'stun:stun.l.google.com:19302'
            });
    }
    pc = new RTCPeerConnection(pcConfig);
    pc.onicecandidate = handleIceCandidate;
    pc.onaddstream = handleRemoteStreamAdded;
    pc.onremovestream = handleRemoteStreamRemoved;
    console.log('Created RTCPeerConnnection');
  } catch (e) {
    console.log('Failed to create PeerConnection, exception: ' + e.message);
    alert('Cannot create RTCPeerConnection object.');
    return;
  }
}

function handleIceCandidate(event) {
  //console.log('icecandidate event: ', event);
  if (event.candidate) {
    sendMessage({
      type: 'candidate',
      label: event.candidate.sdpMLineIndex,
      id: event.candidate.sdpMid,
      candidate: event.candidate.candidate
    });
  } else {
    console.log('End of candidates.');
  }
}

function handleRemoteStreamAdded(event) {
  console.log('Remote stream added.');
  remoteVideo.srcObject = event.stream;
  remoteStream = event.stream;
}

function handleCreateOfferError(event) {
  console.log('createOffer() error: ', event);
}

function doCall() {
  console.log('Sending offer to peer');
  chatLog("Calling");
  pc.createOffer(setLocalAndSendMessage, handleCreateOfferError, offerOptions);
}

function doAnswer() {
  console.log('Sending answer to peer.');
  chatLog("Answering")
  pc.createAnswer(null).then(
    setLocalAndSendMessage,
    onCreateSessionDescriptionError
  );
}

function updateBandwidthRestriction(sdp) {
    var videobw = document.querySelector('#videobw');
    var audiobw = document.querySelector('#audiobw');
    var videoLimit = videobw.value;
    var audioLimit = audiobw.value;

    if (audioLimit !== "auto")
    {
        sdp = sdp.replace(/(m=audio[^\r]*\r\n)/g,
            '$1b=TIAS:' + audioLimit + '\r\n' +
            'b=AS:' + audioLimit + '\r\n');
    }

    if (videoLimit !== "auto")
    {
        sdp = sdp.replace(/(m=video[^\r]*\r\n)/g,
            '$1b=TIAS:' + videoLimit + '\r\n' +
            'b=AS:' + videoLimit+ '\r\n');
    }

    return sdp;
}


function setLocalAndSendMessage(sessionDescription) {
  // Set Opus as the preferred codec in SDP if Opus is present.
  sessionDescription.sdp = preferOpus(sessionDescription.sdp);
  sessionDescription.sdp = updateBandwidthRestriction(sessionDescription.sdp)
  pc.setLocalDescription(sessionDescription);
  console.log('setLocalAndSendMessage sending message', sessionDescription);
  sendMessage(sessionDescription);
}

function onCreateSessionDescriptionError(error) {
  console.log('Failed to create session description: ' + error.toString());
}

function handleRemoteStreamRemoved(event) {
  console.log('Remote stream removed. Event: ', event);
}

function hangup() {
  stop();
  startButton.disabled = false;
  callButton.disabled = false;
  hangupButton.disabled = true;
  chatLog('Hanged up');
  sendMessage("hangup")
}

function handleRemoteHangup() {
  console.log('Session terminated.');
  stop();
}

function stop() {
  isStarted = false;
  // isAudioMuted = false;
  // isVideoMuted = false;
  if (pc) {
      pc.close();
      pc = null;
  }

  if (localStream) {
    localStream.getTracks().forEach(function(track) {
        track.stop();
    });
  }
  localStream = null;

  if (meterMic)
    meterMic.disconnect();
  if (meterScript)
    meterScript.disconnect();
  startButton.disable = false;
}

///////////////////////////////////////////

// Set Opus as the default audio codec if it's present.
function preferOpus(sdp) {
  var sdpLines = sdp.split('\r\n');
  var mLineIndex;
  // Search for m line.
  for (var i = 0; i < sdpLines.length; i++) {
    if (sdpLines[i].search('m=audio') !== -1) {
      mLineIndex = i;
      break;
    }
  }
  if (mLineIndex === null) {
    return sdp;
  }

  // If Opus is available, set it as the default in m line.
  for (var i = 0; i < sdpLines.length; i++) {
    if (sdpLines[i].search('opus/48000') !== -1) {
      var opusPayload = extractSdp(sdpLines[i], /:(\d+) opus\/48000/i);
      if (opusPayload) {
        sdpLines[mLineIndex] = setDefaultCodec(sdpLines[mLineIndex],
          opusPayload);
      }
      break;
    }
  }

  // Remove CN in m line and sdp.
  sdpLines = removeCN(sdpLines, mLineIndex);

  sdp = sdpLines.join('\r\n');
  return sdp;
}

function extractSdp(sdpLine, pattern) {
  var result = sdpLine.match(pattern);
  return result && result.length === 2 ? result[1] : null;
}

// Set the selected codec to the first in m line.
function setDefaultCodec(mLine, payload) {
  var elements = mLine.split(' ');
  var newLine = [];
  var index = 0;
  for (var i = 0; i < elements.length; i++) {
    if (index === 3) { // Format of media starts from the fourth.
      newLine[index++] = payload; // Put target payload to the first.
    }
    if (elements[i] !== payload) {
      newLine[index++] = elements[i];
    }
  }
  return newLine.join(' ');
}

// Strip CN from sdp before CN constraints is ready.
function removeCN(sdpLines, mLineIndex) {
  var mLineElements = sdpLines[mLineIndex].split(' ');
  // Scan from end for the convenience of removing an item.
  for (var i = sdpLines.length - 1; i >= 0; i--) {
    var payload = extractSdp(sdpLines[i], /a=rtpmap:(\d+) CN\/\d+/i);
    if (payload) {
      var cnPos = mLineElements.indexOf(payload);
      if (cnPos !== -1) {
        // Remove CN payload from m line.
        mLineElements.splice(cnPos, 1);
      }
      // Remove CN line in sdp
      sdpLines.splice(i, 1);
    }
  }

  sdpLines[mLineIndex] = mLineElements.join(' ');
  return sdpLines;
}


// CHAT

var msgForm = document.getElementById("msgForm");
var log = document.getElementById("log");
function appendLog(item) {
    var doScroll = log.scrollTop === log.scrollHeight - log.clientHeight;
    log.appendChild(item);
    if (true) {
        log.scrollTop = log.scrollHeight - log.clientHeight;
    }
}

document.getElementById("form").onsubmit = function () {
    if (!socket) {
        return false;
    }
    if (!msgForm.value) {
        return false;
    }
    sendChat(msgForm.value)
    msgForm.value = "";
    return false;
};

socket.onclose = function (evt) {
    var item = document.createElement("div");
    item.innerHTML = "<b>The server closed the connection.</b>";
    appendLog(item);
    callButton.disabled = true;
    hangupButton.disabled = true;
    sendButton.disabled = true;
};
