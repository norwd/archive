/* filegive - Easy sending of files
   Copyright (C) 2020  Lluís Batlle i Rossell

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU Affero General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Affero General Public License for more details.

   You should have received a copy of the GNU Affero General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
package main

import (
	"fmt"
	"net/http"
	"github.com/gorilla/websocket"
	"encoding/json"
	"sync"
	"strings"
	"strconv"
	"github.com/GeertJohan/go.rice"
)

var upgrader = websocket.Upgrader{
	ReadBufferSize:  1024,
	WriteBufferSize: 1024,
}

var numClients = 0;

type ClientList struct {
	list map[int]*websocket.Conn
	mutex sync.Mutex
	counter int
}

func (c *ClientList) AddClient(nc *websocket.Conn) int {
	c.mutex.Lock()
	defer c.mutex.Unlock()
	if c.list == nil {
		c.list = make(map[int]*websocket.Conn)
	}
	c.list[c.counter] = nc
	v := c.counter;
	c.counter++;
	return v;
}

func (c *ClientList) RemoveClient(nc *websocket.Conn) {
	c.mutex.Lock()
	defer c.mutex.Unlock()
	for i := range c.list {
		if nc == c.list[i] {
			delete(c.list, i)
			return
		}
	}
}

func (c *ClientList) Len() int {
	c.mutex.Lock()
	defer c.mutex.Unlock()
	return len(c.list)
}

func (c *ClientList) Broadcast(m []byte) error {
	c.mutex.Lock()
	defer c.mutex.Unlock()
	for i := range c.list {
		err := c.list[i].WriteMessage(websocket.TextMessage, m)
		if err != nil {
			return err
		}
	}
	return nil
}

func (c *ClientList) SendToOthers(me *websocket.Conn, m []byte) error {
	c.mutex.Lock()
	defer c.mutex.Unlock()
	for i := range c.list {
		if me != c.list[i] {
			err := c.list[i].WriteMessage(websocket.TextMessage, m)
			if err != nil {
				return err
			}
		}
	}
	return nil
}

var clients ClientList

func wsHandler(w http.ResponseWriter, r *http.Request) {
	if clients.Len() >= 2 {
		http.Error(w, "Too many people connected", http.StatusUnauthorized)
		return
	}
	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		fmt.Println(err)
		return
	}

	for {
		messageType, p, err := conn.ReadMessage()
		if websocket.IsCloseError(err, websocket.CloseNormalClosure) ||
				websocket.IsCloseError(err, websocket.CloseGoingAway) {
			fmt.Println("Closing websocket")
			clients.RemoveClient(conn)
			conn.Close()
			return
		} else if err != nil {
			fmt.Println("Error from websocket: ", err)
			exitChan <- true
			return
		}
		if messageType != websocket.TextMessage {
			fmt.Println("Error from websocket: not TextMessage")
			exitChan <- true
			return
		}

		var mymap interface{}
		err = json.Unmarshal(p, &mymap)
		if err != nil {
			fmt.Println("Error json: ", err)
			fmt.Println("Json: ", string(p))
			return
		}

		switch v := mymap.(type) {
			case string:
				fmt.Println("Message received (string): ", v)
				if v == "join" {
					num := clients.AddClient(conn)
					fmt.Println("Hello received!", num)
					answer := make(map[string]interface{})
					answer["type"] = "joined"
					answer["id"] = num
					answer["len"] = clients.Len()
					bytes, _ := json.Marshal(answer)
					err = clients.Broadcast(bytes)
				}
				if v == "bye" {
					err = clients.SendToOthers(conn, p)
				}
			case map[string]interface{}:
				/* Catch for UPNP forward */
				if len(ourIP) > 0 {
					if data, ok := v["data"]; ok {
						switch data2 := data.(type) {
							case map[string]interface{}:
								if cand, ok := data2["candidate"]; ok {
									fmt.Println("OurIP: " + ourIP)
									candidate := strings.Split(cand.(string)," ")

									if len(candidate) <= 4 {
										fmt.Println("filegive warning: unexpected candidate string: ", candidate)
									}
									if len(candidate) > 4 && candidate[4] == ourIP {
										proto := strings.ToLower(candidate[2])
										port, _ := strconv.Atoi(candidate[5])
										candidate[4] = extIP
										data2["candidate"] = strings.Replace(cand.(string), " "+ourIP+" ",
											" "+extIP+" ", 1)
										fmt.Println("Forwarding "+proto+": " +
											data2["candidate"].(string))

										/* Check if forwarding exists. candidate messages
										are repeated so we may receive this multiple times.*/
										found := false
										for _, f := range forwardings {
											if f.extPort == port && f.proto == proto {
												found = true
											}
										}

										if !found {
											forw, err := NewUPNP(port, proto)
											if err != nil {
												fmt.Println("Error setting up forwarding:", err)
											}
											forwardings = append(forwardings,forw)
										}
									}
								}
						}
					}
				}
				bytes, _ := json.Marshal(v)
				if v["type"] == "chat" {
					err = clients.Broadcast(bytes)
				} else {
					err = clients.SendToOthers(conn, bytes)
				}
				fmt.Println("Message received+broadcasted (struct): ", v)
			default:
				fmt.Println("Message received (unknown)")
		}

		if err != nil {
			fmt.Println(err)
			break;
		}
	}
}

func socketUrlHandler(prefix string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/javascript; charset=utf-8")
		proto := "wss"
		if *disableHttps {
			proto = "ws"
		}
		wsUrl := proto + "://" + r.Host + prefix + "ws"
		fmt.Fprintf(w, "var socketUrl = \"%s\";\n", wsUrl)
	}
}

func handleVideo(userprefix string) {
	if *disableHttps {
		fmt.Println("WARNING: most browsers disable WebRTC without https")
	}
	prefix := "/"+userprefix

	box := rice.MustFindBox("video")
	http.HandleFunc(prefix + "ws", wsHandler)
	subdir := prefix + "video/"
	http.Handle(subdir,
		http.StripPrefix(subdir, http.FileServer(box.HTTPBox())))
	
	http.Handle(subdir + "socketurl.js", socketUrlHandler(prefix))
}
