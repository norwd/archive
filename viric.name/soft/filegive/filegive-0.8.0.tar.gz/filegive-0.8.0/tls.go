/*
   filegive - Easy sending of files
   Copyright (C) 2013  Lluís Batlle i Rossell

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU Affero General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Affero General Public License for more details.

   You should have received a copy of the GNU Affero General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package main

import (
	"crypto/sha1"
	"crypto/tls"
	"crypto/x509"
	"fmt"
	"net"
)

func ShowCert(title string, cert []byte) string {
	c, h := GetCNAndHash(cert)
	str := fmt.Sprintf("%s SHA1 (s: %s): ", title, c)
	for i := range h {
		if i > 0 {
			str += ":"
		}
		str += fmt.Sprintf("%02X", h[i])
	}
	fmt.Println(str)

	return str
}

func GetCNAndHash(cert []byte) (string, []byte) {
	dec, err := x509.ParseCertificate(cert)
	if err != nil {
		return "", nil
	}
	h := sha1.New()
	h.Write(cert)
	return dec.Subject.Organization[0], h.Sum(nil)
}

type MyListener struct {
	netListener net.Listener
}

func (l *MyListener) Accept() (c net.Conn, err error) {
	c, err = l.netListener.Accept()

	if err != nil {
		return
	}

	// It has to be a TLS connection
	tlsc := c.(*tls.Conn)
	
	cs := tlsc.ConnectionState()
	if !cs.HandshakeComplete {
		tlsc.Handshake()
		// We ignore the error, or bad handshakes will kill filegive
	}
	cs = tlsc.ConnectionState()

	fmt.Printf("New TLS connection from %s, ciphersuite: %s\n", c.RemoteAddr(),
		getCipherSuiteName(cs.CipherSuite))

	return
}

func (l *MyListener) Close() error {
	return l.netListener.Close()
}

func (l *MyListener) Addr() net.Addr {
	return l.netListener.Addr()
}

func getCipherSuiteName(n uint16) string {
	switch(n) {
        case 5:
        	return "TLS_RSA_WITH_RC4_128_SHA"
        case 0x0a:
        	return "TLS_RSA_WITH_3DES_EDE_CBC_SHA"
        case 0x2f:
        	return "TLS_RSA_WITH_AES_128_CBC_SHA"
        case 0x35:
        	return "TLS_RSA_WITH_AES_256_CBC_SHA"
        case 0xc007:
        	return "TLS_ECDHE_ECDSA_WITH_RC4_128_SHA"
        case 0xc009:
        	return "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA"
        case 0xc00a:
        	return "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA"
        case 0xc011:
        	return "TLS_ECDHE_RSA_WITH_RC4_128_SHA"
        case 0xc012:
        	return "TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA"
        case 0xc013:
        	return "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA"
        case 0xc014:
        	return "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA"
        case 0xc02f:
        	return "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256"
        case 0xc02b:
        	return "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256"
		default:
			return fmt.Sprintf("TLS_UNKNOWN_%x", n)
	}
}

func NewHttpsListener(l net.Listener, cert tls.Certificate) (nl net.Listener, err error) {
	config := &tls.Config{}
	config.Certificates = []tls.Certificate{cert}

	chooseCiphers(config)

	// Required in go 1.1, or with firefox it will be conn reset.
	config.NextProtos = []string{"http/1.1"}

	// Show Fingerprint
	str := ShowCert("Certificate", cert.Certificate[0])

	// Windows
	forClipboard = str + "\r\n"

	nl = &MyListener{tls.NewListener(l, config)}
	return
}
