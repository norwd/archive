/*
    offline rss reader
    Copyright (C) 2011  Lluís Batlle i Rossell

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    */
#include <string.h>
#include <iconv.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <errno.h>

#include "offrss.h"

char *
conv_to_utf8(const char *in, const char *encoding)
{
    char *enc;
    iconv_t cd;
    size_t inleft;
    size_t outleft = 0;
    int allocated = 0;
    char *out = 0;
    char *outmove = out;
    char *inmove = (char *) in; /* iconv does not want const */
    int res;
    int diff = 0;

    if (encoding == 0 || strcmp(encoding, "utf-8") == 0)
        return strdup(in);

    cd = iconv_open("utf-8", encoding);
    assert(cd != (iconv_t) -1);

    inleft = strlen(in) + 1; /* We want to convert the ending \0 */

    do
    {
        char *outmove;

        allocated += 100;
        out = realloc(out, allocated);
        outleft += 100;

        outmove = out + diff;
        if (0)
            fprintf(stderr, "allocated: %i outleft: %i in: %p inleft: %i out: %p outleft: %i\n",
                    allocated, outleft, inmove, inleft, outmove, outleft);
        res = iconv(cd, &inmove, &inleft, &outmove, &outleft);
        if (0)
            fprintf(stderr, "res: %i allocated: %i outleft: %i in: %p inleft: %i out:%p outleft: %i /\n",
                    res, allocated, outleft, inmove, inleft, out + diff, outleft);
        diff = outmove - out;
    } while(inleft != 0 && (res == -1 && errno == E2BIG));

    iconv_close(cd);

    if (0)
        fprintf(stderr, "Recoding from %s: %s -> %s\n", encoding, in, out);

    return out;
}
