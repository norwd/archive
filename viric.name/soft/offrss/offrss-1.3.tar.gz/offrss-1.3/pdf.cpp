#include <podofo/podofo.h>
#include <iostream>
#include "pdf.h"

using namespace PoDoFo;

static
struct PdfParam
{
    double pwidth;
    double pheight;
    double text_size;
    double title_size;
    const char *font;
    double margin_left;
    double margin_right;
    double margin_top;
    double margin_bottom;
    double inter_line;
} pdfparam;

static double mmtopoints(double mm);

static int
pdf_init()
{
    /* Dimensions of the Sony PRS 505 */
    pdfparam.pwidth = mmtopoints(92);
    pdfparam.pheight = mmtopoints(117);

    /* I like this in PRS 505 */
    pdfparam.text_size = 9;
    pdfparam.title_size = 16;
    pdfparam.margin_left = mmtopoints(1);
    pdfparam.margin_right = mmtopoints(1);
    pdfparam.margin_top = mmtopoints(1);
    pdfparam.margin_bottom = mmtopoints(1);
    pdfparam.inter_line = 1;
}

namespace {

const bool debug = false;

double
get_line_width()
{
    return pdfparam.pwidth - pdfparam.margin_left - pdfparam.margin_right;
}

class Container
{
    public:
    Container()
        :outdevice(&buffer),
        doc(&outdevice),
        page(0),
        painter(0),
        set_as_outline(false)
    {
        font = doc.CreateFont("FreeSerif", new PdfIdentityEncoding());
        font->SetFontSize(pdfparam.text_size);

        outlines = doc.GetOutlines();

        new_page();
    }

    void new_page()
    {
        if (painter)
        {
            painter->FinishPage();
            delete painter;
        }
        page = doc.CreatePage(PdfRect(0, 0, pdfparam.pwidth,
                    pdfparam.pheight));

        painter = new PdfPainter();
        painter->SetPage(page);
        painter->SetFont(font);

        line_coord = pdfparam.pheight - pdfparam.margin_top;
        column_coord = pdfparam.margin_left;
    }

    void finish()
    {
        if (painter)
        {
            painter->FinishPage();
            delete painter;
        }
        doc.Close();
    }

    void add_paragraph(const char *text)
    {
        font->SetFontSize(pdfparam.text_size);
        painter->SetFont(font);
        plot_text(text);
    }

    void add_title(const char *text)
    {
        font->SetFontSize(pdfparam.title_size);
        painter->SetFont(font);

        set_as_outline = true;
        plot_text(text);
    }

    private:
    void plot_text(const char *text)
    {
        std::string mytext(text);

        for(int i=0; mytext[i] != 0; ++i)
        {
            if (mytext[i] == '\n')
                mytext[i] = ' ';
        }

        PdfString str(reinterpret_cast<const pdf_utf8 *>(mytext.c_str()));

        const double line_width = get_line_width();

        const pdf_utf16be *startline = str.GetUnicode();

        int line_left = str.GetCharacterLength();
        if (debug) 
            std::cerr << "Total " << line_left << " chars in line.\n";

        const pdf_utf16be space = ' ' << 8;
        const pdf_utf16be enter = '\n' << 8;
        int linestep = pdfparam.inter_line + font->GetFontSize();

        while (line_left > 0)
        {
            int used_pt_in_line = 0;
            int chars_in_line = 0;
            int prev_chars_in_line = 0;
            while(used_pt_in_line < line_width && chars_in_line < line_left)
            {
                int j;

                prev_chars_in_line = chars_in_line;

                for(j=chars_in_line+1; j < line_left; ++j)
                {
                    if (startline[j] == space || startline[j] == '\n')
                    {
                        break;
                    }
                }
                chars_in_line = j;

                const PdfFontMetrics *metrics = font->GetFontMetrics();
                used_pt_in_line = metrics->StringWidth(startline, chars_in_line);
            }

            /* If it is the last line, then consider it as if it was until
             * what to print */
            if (used_pt_in_line < line_width)
                prev_chars_in_line = chars_in_line;

            if (debug)
                std::cerr << prev_chars_in_line << " chars in line.\n";

            int text_line = line_coord - linestep;
            if (text_line < pdfparam.margin_bottom)
            {
                new_page();
                text_line = line_coord - linestep;
            }

            if (set_as_outline)
            {
                outlines->CreateChild(str, PdfDestination(page));
                set_as_outline = false;
            }
            PdfString line(startline, prev_chars_in_line);
            painter->DrawText(column_coord, text_line, line);

            startline += prev_chars_in_line+1;
            line_left -= prev_chars_in_line+1;
            line_coord -= linestep;
        }

        /* Free half-line between add-text */
        line_coord -= linestep/2;
    }
    

    public:
    PdfRefCountedBuffer buffer;

    private:
    PdfOutputDevice outdevice;
    PdfStreamedDocument doc;
    PdfPage *page;
    PdfPainter *painter;
    PdfFont *font;
    PdfOutlines *outlines;

    int line_coord;
    int column_coord;
    bool set_as_outline;
};
}

static double
mmtopoints(double mm)
{
    return mm*72/25.4;
}

int pdf_create(struct PDFBuffer *buffer)
{
    pdf_init();

    Container *ourcontainer = new Container();
    /* Create PDF */

    buffer->p = 0;
    buffer->size = 0;
    buffer->ref = ourcontainer;
}

int pdf_add_paragraph(struct PDFBuffer *buffer, const char *text)
{
    Container *ourcontainer = reinterpret_cast<Container *>
        (buffer->ref);

    ourcontainer->add_paragraph(text);
}

int pdf_add_title(struct PDFBuffer *buffer, const char *text)
{
    Container *ourcontainer = reinterpret_cast<Container *>
        (buffer->ref);

    ourcontainer->add_title(text);
}

int pdf_finish(struct PDFBuffer *buffer)
{
    Container *ourcontainer = reinterpret_cast<Container *>
        (buffer->ref);

    ourcontainer->finish();

    buffer->p = ourcontainer->buffer.GetBuffer();
    buffer->size = ourcontainer->buffer.GetSize();
}

void pdf_free(struct PDFBuffer *buffer)
{
    if (buffer->ref)
    {
        Container *ourcontainer = reinterpret_cast<Container *>
            (buffer->ref);

        delete ourcontainer;
    }
}
