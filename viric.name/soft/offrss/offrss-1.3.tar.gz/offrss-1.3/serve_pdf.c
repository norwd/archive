#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

#include "offrss.h"
#include "pdf.h"

/* Returns if it found an entity or not */
static int
entity_to_out(const char *ptr, char **optr)
{
    int res = 0;
    int i;

    struct 
    {
        const char *str;
        const char *utf8;
    } entity[] = {
        { "&nbsp;", "" },
        { "&quot;", "\"" },
        { "&uml;", "\"" }, /* Spacing dieresis? */
        { "&amp;", "&" }
    };

    if (*ptr == '&' && ptr[1] == '#')
    {
        entity_to_utf8(ptr, optr);
        res = 1;
    }
    else
    {
        const int nelem = (sizeof(entity)/sizeof(entity[0]));
        for(i=0; i < nelem; ++i)
        {
            int isequal = 0;
            int j;
            const char *str = entity[i].str;
            for(j=0; ptr[j] != '\0'; ++j)
            {
                if (str[j] == 0)
                {
                    isequal = 1;
                    break;
                }
                else if (ptr[j] != str[j])
                {
                    isequal = 0;
                    break;
                }
            }
            if (isequal)
            {
                int size = strlen(entity[i].utf8);
                memcpy(*optr, entity[i].utf8, size);
                *optr += size;
                res = 1;
                break;
            }
        }
    }

    return res;
}

static void
html_to_pdf(struct PDFBuffer *pdf, const char *html)
{
    char *filtered = strdup(html);
    const char *ptr = html;
    char *optr = filtered;
    int in_tag = 0;
    int in_entity = 0;
    int ignore_tag = 0;

    /* Process the title. First line: <h2>title</h2> */
    if (strlen(filtered) > 4)
    {
        ptr += 4;
        while(*ptr != '\0')
        {
            if(*ptr == '<')
            {
                if (!strncmp(ptr, "</h2>", 5))
                {
                    break;
                }
                else
                    in_tag = 1;
            }
            else if (in_tag)
            {
                if (*ptr == '>')
                    in_tag = 0;
            }
            else if (entity_to_out(ptr, &optr))
            {
                in_entity = 1;
            }
            else if (in_entity)
            {
                if (*ptr == ';')
                    in_entity = 0;
            }
            else
            {
                *optr = *ptr;
                ++optr;
            }
            ++ptr;
        }

        if (*ptr != '\0')
        {
            /* Found */
            *optr = '\0';
            if (0)
                fprintf(stderr, "Title: %s", filtered);
            pdf_add_title(pdf, filtered);
            ptr += 5; /* strlen("</h2>") */
        }
    }

    /* ptr points after the title */
    while(*ptr != '\n' && *ptr != '\0')
        ++ptr;
    optr = filtered;

    while(*ptr != '\0')
    {
        if(*ptr == '<')
        {
            if (!strncasecmp(ptr, "</p>", 4) ||
                    !strncasecmp(ptr, "<br", 3) ||
                    !strncasecmp(ptr, "</h", 3) ||
                    !strncasecmp(ptr, "</div>", 6)
                    )
            {
                /* If we have some chars, print them as paragraph */
                if (optr != filtered)
                {
                    *optr = '\0';
                    pdf_add_paragraph(pdf, filtered);
                    optr = filtered;
                }
            }
            in_tag = 1;
        }
        else if (in_tag)
        {
            if (*ptr == '>')
                in_tag = 0;
        }
        else if (entity_to_out(ptr, &optr))
        {
            in_entity = 1;
        }
        else if (in_entity)
        {
            if (*ptr == ';')
                in_entity = 0;
        }
        else
        {
            if ((optr == filtered || (
                            optr[-1] == ' ' ||
                            optr[-1] == '\t' ||
                            optr[-1] == '\n')) &&
                    (*ptr == ' ' ||
                     *ptr == '\t' ||
                     *ptr == '\n'))
            {
                /* Skip initial spaces or accumulated spaces */
            }
            else
            {
                *optr = *ptr;
                ++optr;
            }
        }
        ++ptr;
    }

    if (optr != filtered)
    {
        *optr = '\0';
        pdf_add_paragraph(pdf, filtered);
        optr = filtered;
    }

    free(filtered);
}

static void
send_pdf_contents(struct PDFBuffer *pdf, const char *feedname, const char *path)
{
    char *buf = 0;
    int already_read = 0;
    int allocated = 0;
    FILE *f;

    f = fopen(path, "rb");
    if (f == NULL)
        return;

    do
    {
        int res;

        allocated += 1000;
        buf = realloc(buf, allocated);

        /* Reserving 1 for \0 at the end - reasonable as the file should be in utf8 */
        res = fread(buf + already_read, 1, allocated - already_read - 1, f);
        if (res > 0)
        {
            already_read += res;
        }
    } while(!feof(f));
    fclose(f);

    /* space assured above */
    assert(already_read < allocated);
    buf[already_read] = '\0';

    html_to_pdf(pdf, buf);

    free(buf);
}

static void
send_pdf_item(int s, const char *path, const struct feed_meta_t *fm, int j,
        struct PDFBuffer *pdf)
{
    char base[400];
    char filename[400];

    strncpy(base, "files/", sizeof base);
    mystrncat(base, path, sizeof base);
    strncpy(filename, base, sizeof filename);
    mystrncat(filename, "/", sizeof filename);
    mystrncat(filename, fm->item[j].filename, sizeof filename);

    // URI
    send_pdf_contents(pdf, path, filename);
}

void
send_pdf(int s, const char *path)
{
    char str_params[400];
    int i;

    send_http_headers(s, HEADER_PDF, -1, 0);

    for(i = 0; i < nfeed_urls; ++i)
    {
        if (!feed_urls[i].is_section && strcmp(path, feed_urls[i].filename) == 0)
        {
            char base[400];
            char metafilename[400];
            int j;
            struct feed_meta_t *fm;
            struct PDFBuffer pdf;

            strncpy(base, "files/", sizeof base);
            mystrncat(base, path, sizeof base);
            strncpy(metafilename, base, sizeof metafilename);
            mystrncat(metafilename, "/meta", sizeof metafilename);

            pdf_create(&pdf);

            pdf_add_title(&pdf, path);

            fm = open_meta(base, metafilename);

            if (param_posts)
            {
                struct ParamPosts *pivot;

                pivot = param_posts;
                while (pivot != 0)
                {
                    send_pdf_item(s, path, fm, pivot->num, &pdf);
                    pivot = pivot->next;
                }
            }
            else
            {
                for(j = 0; j < fm->nitems; ++j)
                {
                    if (param_show_read || ! fm->item[j].marked_read)
                    {
                        send_pdf_item(s, path, fm, j, &pdf);
                    }
                }
            }

            pdf_finish(&pdf);

            send_sure(s, pdf.p, pdf.size);

            pdf_free(&pdf);

            close_meta(fm);

            break;
        }
    }
}

static void
send_only_title(int s, const char *filename)
{
    char title[1000];
    char *optr = title;
    int in_tag = 0;
    int i;
    int c;
    char tag[10];
    char *otag = tag;

    FILE *f = fopen(filename, "r");
    if (!f)
        return;

    /* Process the title. First line: <h2>title</h2> */
    for(i=0; i < 4; ++i)
        fgetc(f);

    if (feof(f))
    {
        fclose(f);
        return;
    }

    while((c = fgetc(f)) != EOF)
    {
        if(c == '<')
        {
            in_tag = 1;
        }
        else if (in_tag)
        {
            if (c == '>')
            {
                if (!strncmp(tag,"/h2",3))
                    break;
                in_tag = 0;
                otag = tag;
            }
            else
            {
                if (otag < &tag[sizeof(tag)-1])
                {
                    *otag = c;
                    ++otag;
                }
            }
        }
        else
        {
            if (optr < &title[sizeof(title) - 1])
                *optr = c;
            else
            {
                *optr = '\0';
                break;
            }
            ++optr;
        }
    }

    fclose(f);

    if (c != EOF)
    {
        /* Found */
        *optr = '\0';
        if (0)
            fprintf(stderr, "Title: %s", title);
        send_line(s, title);
    }
}

void
send_plan_pdf(int s, const char *path)
{
    char str_params[400];
    int i;

    send_http_headers(s, HEADER_HTML, -1, 0);

    for(i = 0; i < nfeed_urls; ++i)
    {
        if (!feed_urls[i].is_section && strcmp(path, feed_urls[i].filename) == 0)
        {
            char base[400];
            char metafilename[400];
            int j;
            struct feed_meta_t *fm;

            strncpy(base, "files/", sizeof base);
            mystrncat(base, path, sizeof base);
            strncpy(metafilename, base, sizeof metafilename);
            mystrncat(metafilename, "/meta", sizeof metafilename);

            send_line(s, "<html><head>\n");
            send_line(s, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\n");
            send_line(s, "<title>%s - planpdf - offrss</title>\n", path);
            send_line(s, "</head><body>\n");

            send_line(s, "<h1><a href=\"%s/%s\">%s</a></h1>\n", cgi_url_path,
                    path, path);

            send_line(s, "<p>Choose the articles to put on the PDF:</p>\n");
            send_line(s, "<form method=\"get\" action=\"%s/pdf/%s.pdf\">\n",
                    cgi_url_path, path);
            send_line(s, "<select multiple=\"1\" size=\"10\"name=\"posts\">\n");

            fm = open_meta(base, metafilename);

            for(j = 0; j < fm->nitems; ++j)
            {
                if (param_show_read || ! fm->item[j].marked_read)
                {
                    char filename[400];

                    strncpy(filename, base, sizeof filename);
                    mystrncat(filename, "/", sizeof filename);
                    mystrncat(filename, fm->item[j].filename, sizeof filename);

                    send_line(s, "<option value=\"%i\">", j);
                    send_only_title(s, filename);
                    send_line(s, "</option>\n");
                }
            }

            send_line(s, "<input type=\"submit\" value=\"Make PDF\"/>\n");

            send_line(s, "</select>\n");

            close_meta(fm);

            break;
        }
    }

    send_line(s, "</body></html>\n");
}
