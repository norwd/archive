/*
    offline rss reader
    Copyright (C) 2011  Lluís Batlle i Rossell

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    */
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <sys/stat.h>
#include <stdarg.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <signal.h>
#include <time.h>

#include "offrss.h"

static int listen_socket;
static int is_cgi;
static const char *cgi_url_path;
static int param_show_read;
static int param_mark_read;
static int param_mark_unread;
static int param_lastchecked;
static int param_local_images;
const static int port = 8090;

void send_http_headers(int s, int is_image, int length, int cache);

void error(const char *msg, ...)
{
    va_list v;

    va_start(v, msg);
    vfprintf(stderr, msg, v);
    putc('\n', stderr);
    fprintf(stderr, " errno %i: %s\n", errno, strerror(errno));
    exit(-1);
}

void ignore_sigpipe()
{
    sigset_t set;

    sigemptyset(&set);
    sigaddset(&set, SIGPIPE);
    sigprocmask(SIG_BLOCK, &set, NULL);
}

static void start_listening()
{
    int ls;
    struct sockaddr_in addr;
    int res;

    ls = socket(AF_INET, SOCK_STREAM, 0);
    if (ls == -1)
        error("Cannot create the tcp listen socket in the server");

    {
        int on = 1;
        res = setsockopt(ls, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));
        if (res == -1)
            error("Cannot set SO_REUSEADDR");
    }

    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);

    res = bind(ls, (struct sockaddr *) & addr, sizeof(addr));
    if (res == -1)
        error("Error binding tcp to port %i", port);

    /* NUANCE: 0 backlog. Why should we assure future connections? */
    res = listen(ls, 0);
    if (res == -1)
        error("Error listening on the binded tcp socket");

    listen_socket = ls;
}

void
send_sure(int s, const char *buf, int size)
{
    int sent = 0;
    
    do
    {
        int res;
        res = write(s, buf + sent, size - sent);
        if (0 && verbose)
            fprintf(stderr, "write res: %i\n", res);
        if (res < 0)
        {
            if (errno == EINTR)
                continue;
            else
                return;
        }
        sent += res;
    } while(sent < size);
}

void
send_line(int s, const char *msg, ...)
{
    va_list v;
    char line[400];
    int res;

    va_start(v, msg);
    res = vsnprintf(line, sizeof line, msg, v);

    send_sure(s, line, res);
}

char *
find_next_img_url(const char *buf, int *begin, int *end)
{
    const char *pos = buf;

    *begin = 0;
    *end = 0;

    pos = strstr(pos, "<img ");
    if (pos)
    {
        const char *pos2;

        pos += strlen("<img ");

        pos2 = strstr(pos, "src=\"");
        if (pos2)
        {
            const char *endpos, *url, *filename;

            pos2 += strlen("src=\"");
            endpos = strchr(pos2, '\"');

            if (endpos)
            {
                *begin = pos2 - buf;
                *end = endpos - buf;
            }

            url = strndup(pos2, endpos - pos2);
            return img_url_to_filename(url);
        }
    }
    return 0;
}

void
replace_img(char **content, const char *feedname)
{
    char *simplename;
    char *start = *content;
    int needed;

    needed = strlen(*content) + 1;

    do
    {
        int begin, end;
        simplename = find_next_img_url(start, &begin, &end);
        if (simplename)
        {
            char filename[400];
            struct stat st;
            int res;
            int begin_from_contents = (start - *content) + begin;
            int end_from_contents = (start - *content) + end;

            strncpy(filename, "files/", sizeof filename);
            mystrncat(filename, feedname, sizeof filename);
            mystrncat(filename, "/images/", sizeof filename);
            mystrncat(filename, simplename, sizeof filename);

            if (0)
                fprintf(stderr, "img found: %s\n", filename);

            /* Does file exist? */
            res = stat(filename, &st);
            if (res == 0 && S_ISREG(st.st_mode))
            {
                /* Replace the url */
                char newurl[400];
                int diff;
                char *newcontent;

                if (!is_cgi)
                    strncpy(newurl, "/", sizeof newurl);
                else
                {
                    strncpy(newurl, cgi_url_path, sizeof newurl);
                    mystrncat(newurl, "/", sizeof newurl);
                }
                mystrncat(newurl, feedname, sizeof newurl);
                mystrncat(newurl, "/images/", sizeof newurl);
                mystrncat(newurl, simplename, sizeof newurl);

                diff = strlen(newurl) - (end - begin);

                newcontent = malloc(needed + diff);

                if (0)
                {
                    fprintf(stderr, "begin: %i end: %i needed: %i diff: %i newurl: <%s>\n",
                            begin_from_contents, end_from_contents, needed, diff, newurl);
                    // Leak
                    fprintf(stderr, "start: %s end: %s\n",
                            strndup(*content,begin), *content + end);
                }

                strncpy(newcontent, *content, begin_from_contents);
                newcontent[begin_from_contents] = '\0';
                assert(strlen(newcontent) == begin_from_contents);
                mystrncat(newcontent, newurl, needed + diff);
                assert(strlen(newcontent) == begin_from_contents + strlen(newurl));
                mystrncat(newcontent, *content + end_from_contents, needed + diff);
                assert(strlen(newcontent) == needed+diff-1);

                free(*content);
                *content = newcontent;
		needed = needed + diff;
            }
            start = *content + begin_from_contents;
            free(simplename);
        }
    } while(simplename);
}

void
send_file(int s, const char *path)
{
    char buf[10000];
    FILE *f;

    f = fopen(path, "rb");
    if (f == NULL)
        return;

    send_http_headers(s, 1, -1, 0);

    do
    {
        int res;

        res = fread(buf, 1, sizeof buf, f);
        if (res > 0)
            send_sure(s, buf, res);
    } while(!feof(f));

    fclose(f);
}

void
send_contents(int s, const char *feedname, const char *path)
{
    char *buf = 0;
    int already_read = 0;
    int allocated = 0;
    FILE *f;

    f = fopen(path, "rb");
    if (f == NULL)
        return;

    do
    {
        int res;

        allocated += 1000;
        buf = realloc(buf, allocated);

        /* Reserving 1 for \0 at the end - reasonable as the file should be in utf8 */
        res = fread(buf + already_read, 1, allocated - already_read - 1, f);
        if (res > 0)
        {
            already_read += res;
        }
    } while(!feof(f));
    fclose(f);

    /* space assured above */
    assert(already_read < allocated);
    buf[already_read] = '\0';

    if (param_local_images)
        replace_img(&buf, feedname);

    send_sure(s, buf, strlen(buf));

    free(buf);
}

struct feed_meta_t *
open_meta_by_feedname(const char *feedname)
{
    char filename[400];
    char base[400];
    struct feed_meta_t *fm;

    strncpy(filename, "files/", sizeof filename);
    mystrncat(filename, feedname, sizeof filename);
    strncpy(base, filename, sizeof base);
    mystrncat(filename, "/meta", sizeof filename);

    return open_meta(base, filename);
}

void
send_css(int s)
{
    char buf[10000];
    FILE *f;

    f = fopen("offrss.css", "rb");
    if (f == NULL)
        return;

    send_line(s, "<style type=\"text/css\">\n");

    do
    {
        int res;

        res = fread(buf, 1, sizeof buf, f);
        if (res > 0)
            send_sure(s, buf, res);
    } while(!feof(f));

    fclose(f);

    send_line(s, "</style>\n");
}

void
send_feed(int s, const char *path)
{
    char str_params[400];
    int i;

    send_http_headers(s, 0, -1, 0);

    for(i = 0; i < nfeed_urls; ++i)
    {
        if (!feed_urls[i].is_section && strcmp(path, feed_urls[i].filename) == 0)
        {
            char base[400];
            char metafilename[400];
            int j;
            struct feed_meta_t *fm;

            send_line(s, "<html><head>\n");
            send_line(s, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\n");
            send_line(s, "<title>%s - offrss</title>\n", path);
            send_css(s);
            send_line(s, "</head><body>\n");

            {
                str_params[0] = '\0';
                if (!param_local_images)
                    strncpy(str_params, "&local_images=0", sizeof str_params);

                send_line(s, "<p><a href=\"%s/?%s\">[Top]</a>\n", cgi_url_path, str_params);

                if (param_show_read)
                    send_line(s, "<a href=\"?%s\">[Hide read]</a>\n", str_params);
                else
                    send_line(s, "<a href=\"?show_read=1%s\">[Show read]</a>\n", str_params);
            }

            {
                str_params[0] = '\0';
                if (param_show_read)
                    strncpy(str_params, "&show_read=1", sizeof str_params);
                if (param_local_images)
                    send_line(s, "<a href=\"?local_images=0%s\">[Use remote images]</a>\n",
                            str_params);
                else
                    send_line(s, "<a href=\"?%s\">[Use local images]</a>\n",
                            str_params);
            }


            strncpy(base, "files/", sizeof base);
            mystrncat(base, path, sizeof base);
            strncpy(metafilename, base, sizeof metafilename);
            mystrncat(metafilename, "/meta", sizeof metafilename);

            send_line(s, "<h1>%s</h1>\n", path);

            send_line(s, "<p><a href=\"%s\">[feed]</a></p><hr>\n",feed_urls[i].url);

            fm = open_meta(base, metafilename);

            if (param_lastchecked == fm->lastchecked)
            {
                if (param_mark_unread >= 0 && param_mark_unread < fm->nitems)
                {
                    fm->item[param_mark_unread].marked_read = 0;
                    set_noread(base, &fm->item[param_mark_unread]);
                }
                if (param_mark_read >= 0 && param_mark_read < fm->nitems)
                {
                    fm->item[param_mark_read].marked_read = 1;
                    set_read(base, &fm->item[param_mark_read]);
                }
            }

            str_params[0] = '\0';

            if (param_show_read)
                mystrncat(str_params, "&show_read=1", sizeof str_params);
            if (!param_local_images)
                mystrncat(str_params, "&local_images=0", sizeof str_params);

            for(j = 0; j < fm->nitems; ++j)
            {
                if (param_show_read || ! fm->item[j].marked_read)
                {
                    char filename[400];
                    strncpy(filename, base, sizeof filename);
                    mystrncat(filename, "/", sizeof filename);
                    mystrncat(filename, fm->item[j].filename, sizeof filename);

                    // URI
                    if (fm->item[j].marked_read)
                        send_line(s, "<p><a name=\"%i\">"
                                "<a href=\"?mark_unread=%i&lastchecked=%i%s#%i\">"
                                "[Mark unread]</a></a></p>\n",
                                j, j, fm->lastchecked, str_params, j);
                    else
                    {
                        int next = j;
                        if (!param_show_read)
                        {
                            for(next = j+1; next < fm->nitems; ++next)
                                if (!fm->item[next].marked_read)
                                    break;

                            if(next == fm->nitems)
                                for(next = j-1; next >= 0; --next)
                                    if (!fm->item[next].marked_read)
                                        break;

                            if (next < 0)
                                /* An unexistent anchor, but I don't care.
                                 * At least I don't give a negative one */
                                next = 0;
                        }
                        send_line(s, "<p><a name=\"%i\">"
                                "<a href=\"?mark_read=%i&lastchecked=%i%s#%i\">"
                                "[Mark read]</a></p></p>\n",
                                j, j, fm->lastchecked, str_params, next);
                    }

                    send_contents(s, feed_urls[i].filename, filename);
                    send_line(s, "<hr>\n");
                }
            }

            close_meta(fm);

            break;
        }
    }

    send_line(s, "</body></html>\n");
}

void
feed_count_items(const char *feedname, int *nitems, int *nunread)
{
    struct feed_meta_t *fm;
    int j;

    fm = open_meta_by_feedname(feedname);

    *nunread = 0;
    *nitems = fm->nitems;

    for(j = 0; j < fm->nitems; ++j)
        if (!fm->item[j].marked_read)
            *nunread += 1;

    close_meta(fm);
}

static
void
serve_update(int s)
{
    update();
}

void
send_http_headers(int s, int is_image, int length, int cache)
{
    time_t t;
    char strtime[400];

    t = time(NULL);

    if (!is_cgi)
        send_line(s, "HTTP/1.1 300 OK\r\n");

    strftime(strtime, sizeof strtime, "%a, %d %b %Y %T %Z", gmtime(&t));
    send_line(s, "Date: %s\r\n", strtime);
    send_line(s, "Connection: close\r\n");
    send_line(s, "Server: offrss\r\n");
    if (is_image)
    {
        send_line(s, "Content-type: application/octet-stream\r\n");
    }
    else
    {
        send_line(s, "Content-type: text/html\r\n");
    }
    send_line(s, "Cache-control: max-age=%i\r\n", cache);
    if (length >= 0)
        send_line(s, "Content-length: %i\r\n", length);

    send_line(s, "\r\n");
}

void
process_request(int s, char *path, const char *query)
{
    char str_params[400];

    if (0)
        fprintf(stderr, "Process Request: path \"%s\" query \"%s\"\n", path, query);

    param_show_read = 0;
    param_mark_unread = -1;
    param_mark_read = -1;
    param_lastchecked = -1;
    param_local_images = 1;

    if (path != NULL)
    {
        const char *found;
        found = strstr(query, "show_read=1");
        if (found)
            param_show_read = 1;

        found = strstr(query, "mark_unread=");
        if (found)
            sscanf(found, "mark_unread=%i", &param_mark_unread);

        found = strstr(query, "mark_read=");
        if (found)
            sscanf(found, "mark_read=%i", &param_mark_read);

        found = strstr(query, "lastchecked=");
        if (found)
            sscanf(found, "lastchecked=%i", &param_lastchecked);

        found = strstr(query, "local_images=");
        if (found)
            sscanf(found, "local_images=%i", &param_local_images);
    }

    str_params[0] = '\0';
    if (!param_local_images)
        strncpy(str_params, "local_images=0", sizeof str_params);

    if (path == NULL || strcmp(path, "/") == 0)
    {
        int i;
        int in_list = 0;

        open_urls();

        send_http_headers(s, 0, -1, 300);

        send_line(s, "<html><head>\n");
        send_line(s, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\n");
        send_line(s, "<title>offrss %s</title>\n", is_cgi ? "CGI" : "local server");
        send_css(s);
        send_line(s, "</head><body>\n");
        send_line(s, "<p><a href=\"%s/update?%s\">[Update feeds]</a>\n", cgi_url_path, str_params);

        if (param_local_images)
            send_line(s, "<a href=\"?local_images=0\">[Use remote images]</a>\n");
        else
            send_line(s, "<a href=\"?\">[Use local images]</a>\n");
        send_line(s, "</p>\n");

        for(i = 0; i < nfeed_urls; ++i)
        {
            const struct feed_url_t *f = &feed_urls[i];
            if (f->is_section)
            {
                if (in_list)
                {
                    send_line(s, "</ul>\n");
                    in_list = 0;
                }
                send_line(s, "<h2>%s</h2>\n", f->sectionname);
            }
            else
            {
                int nunread, nitems;

                if (0 && verbose)
                    fprintf(stderr, "url: %s\n",
                            feed_urls[i].url);
                if (!in_list)
                {
                    send_line(s, "<ul>\n");
                    in_list = 1;
                }
                feed_count_items(feed_urls[i].filename, &nitems, &nunread);
                send_line(s, "<li><a href=\"%s/%s?%s\">%s</a> (Unread: "
                        "<strong>%i</strong>; Total: %i)\n",
                        cgi_url_path,
                        feed_urls[i].filename,
                        str_params,
                        feed_urls[i].filename,
                        nunread, nitems);
            }
        }
        if (in_list)
        {
            send_line(s, "</ul>\n");
        }
        send_line(s, "</body></html>\n");

        close_urls();
    }
    else if (strcmp(path, "/update") == 0)
    {
        send_http_headers(s, 0, -1, 0);

        send_line(s, "<html><head>\n");
        send_line(s, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\n");
        send_line(s, "<title>offrss - Update feeds</title>\n");
        send_css(s);
        send_line(s, "</head><body><h2>Updating...</h2>\n");
        serve_update(s);
        send_line(s, "<p>Done</p>\n");
        send_line(s, "<p><a href=\"%s/?%s\">[Top]</a>\n", cgi_url_path, str_params);
        send_line(s, "</body></html>\n");
    }
    else
    {
        char *pos;
        char *newpath = path;

        /* Security: Remove leading slashes */
        while(newpath[0] == '/')
            ++newpath;

        /* Security: halt on any ../ */ 
        while(pos = strstr(newpath, "../"))
        {
            break;
        }

        pos = strstr(newpath, "/images/");

        if (pos)
        {
            char filepath[400];
            strncpy(filepath, "files/", sizeof filepath);
            mystrncat(filepath, newpath, sizeof filepath);

            if (0)
                fprintf(stderr, "filepath: %s\n", filepath);

            send_file(s, filepath);
        }
        else
        {
            open_urls();
            send_feed(s, path + 1);
            close_urls();
        }
    }
}

void
url_rewrite(char *url)
{
    int len = strlen(url);
    int i;

    for(i = 0; i < len; ++i)
    {
        if (url[i] == '%' && (len - i) > 2)
        {
            char *p = &url[i];
            sscanf(&url[i+1], "%2hhx", p);

            p += 1;
            while(p[2])
            {
                p[0] = p[2];
                p += 1;
            }
            p[0] = '\0';
            len -= 2;
        }
    }
}

void
http_parse(int s)
{
    char line[400];
    int pos = 0;
    int res;
    char *path = 0;
    int eol = 0;

    line[sizeof(line) - 1] = '\0';

    do
    {
        eol = 0;

        res = read(s, line + pos, 1);
        if (res == 1)
        {
            if(line[pos] == '\n')
                eol = 1;
            if (pos < sizeof(line) - 2) /* saving \n\0 at the end */
                pos = pos + 1;
            else
                assert(0);
        }

        if (eol)
        {
            assert(pos > 0);
            line[pos-1] = '\0';
            if (0 && verbose)
                fprintf(stderr, "Line: %s\n", line);
            if (strncmp(line, "GET", 3) == 0)
            {
                path = strdup(line + 4); /* after "GET " */
            }
            pos = 0;
        }

    } while(res > 0 && !(eol && strlen(line) <= 1));


    if (path)
    {
        char *pos;
        char *param;
        const char *query;

        if (0 && verbose)
            fprintf(stderr, "Request: %s\n", path);

        pos = strchr(path, ' ');
        assert(pos != NULL);
        *pos = '\0';

        /* Query string */
        param = strchr(path, '?');
        if (param)
        {
            *param = '\0';
            query = param + 1;
        }
        else
            query = "";

        url_rewrite(path);
        process_request(s, path, query);

        free(path);
    }
}

void
serve_cgi()
{
    char * query;
    char * path;
    int s;

    is_cgi = 1;

    query = getenv("QUERY_STRING");
    if (query == NULL)
        query = "";

    path = getenv("PATH_INFO");

    cgi_url_path = getenv("SCRIPT_NAME");

    if (0)
        fprintf(stderr, "script: %s pinfo: %s query: %s\n", cgi_url_path, path, query);

    s = 1; /* stdout */

    /* Apache does not need url_rewrite(path) */
    process_request(s, path, query);
}

void
serve()
{
    int s;
    char url[500];

    cgi_url_path = "";
    is_cgi = 0;

    ignore_sigpipe();

    start_listening();

    snprintf(url, sizeof url, "http://localhost:%i/", port);
    printf("%s\n", url);

    {
        /* Start the web browser if an environment variable tells so */
        char *browser;
        char command[500];

        browser = getenv("WEBBROWSER");
        if (browser)
        {
            snprintf(command, sizeof command, "%s %s", browser, url);

            system(command);
        }
    }

    do
    {
        if (0 && verbose)
            fprintf(stderr, "Accepting...\n");

        s = accept(listen_socket, NULL, NULL);
        if (s >= 0)
        {
            if (0 && verbose)
                fprintf(stderr, "New socket: %i\n", s);
            http_parse(s);
            close(s);
        }
    } while(s >= 0);

}
