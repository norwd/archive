/*
    offline rss reader
    Copyright (C) 2011  Lluís Batlle i Rossell

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    */
#include <stdio.h>

/* rss2.c */
struct feed_url_t
{
    char *url;
    char *filename;
    int is_section; /* if section != 0, filename means a section name */
    char *sectionname;
};

struct feed_meta_t
{
    int nitems;
    struct item_meta_t
    {
        char *filename;
        int marked_read;
        int pubdate;
    } * item;
    int lastchecked;
    int has_been_downloaded; /* Indicates if save_meta has to write the feedinfo */
    char *alternate_url;
    FILE *handle;
};

extern int nfeed_urls;
extern struct feed_url_t *feed_urls;

extern int verbose;

void open_urls();
void close_urls();
struct feed_meta_t * open_meta(const char *base, const char *filename);
void save_meta(const char *filename, const struct feed_meta_t *fm);
void close_meta(struct feed_meta_t *fm);
char * title_to_filename(const char *title);
void update();
char * img_url_to_filename(const char *url);
int is_read(const char *base, struct item_meta_t *fm);
void set_read(const char *base, struct item_meta_t *fm);
void set_noread(const char *base, struct item_meta_t *fm);

/* server.c */
enum e_header
{
    HEADER_IMAGE,
    HEADER_HTML,
    HEADER_PDF
};
struct ParamPosts
{
    int num;
    struct ParamPosts *next;
};
extern struct ParamPosts *param_posts;
extern int param_show_read;
const char *cgi_url_path;
void serve();
void serve_cgi();
void url_rewrite(char *url);
void send_http_headers(int s, enum e_header header, int length, int cache);
void send_sure(int s, const char *buf, int size);

/* encoding.c */
void entity_to_utf8(const char *entity, char **out);
char * conv_to_utf8(const char *in, const char *encoding);

/* util.c */
char * mystrncat(char *dst, const char *src, size_t maxdst);

/* serve_pdf.c */
void send_pdf(int s, const char *path);
void send_plan_pdf(int s, const char *path);
