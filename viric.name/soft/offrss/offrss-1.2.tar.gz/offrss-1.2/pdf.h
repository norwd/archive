struct PDFBuffer
{
    char *p;
    int size;
    void *ref;
};

#ifdef __cplusplus
#define EXTERN extern "C" 
#else
#define EXTERN
#endif

EXTERN int pdf_create(struct PDFBuffer *buffer);
EXTERN int pdf_add_paragraph(struct PDFBuffer *buffer, const char *text);
EXTERN int pdf_add_title(struct PDFBuffer *buffer, const char *text);
EXTERN int pdf_finish(struct PDFBuffer *buffer);
EXTERN void pdf_free(struct PDFBuffer *buffer);

