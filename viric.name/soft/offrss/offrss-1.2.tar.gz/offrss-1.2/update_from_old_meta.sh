#!/bin/sh

# Update old meta files (of [3af2fceedf]) into metafiles understood by
# [c509b24ff7].

# Basically, the first line of /meta had the lastchecked timestamp, and now
# it has the version format of the file: 1

# offrss uses /feedinfo files, but those will be created properly on the next
# update.

for a in `find files -name meta`; do
    sed -i '1s/.*/1/' $a
done
