/*
    offline rss reader
    Copyright (C) 2011  Lluís Batlle i Rossell

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    */
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <sys/stat.h>
#include <stdarg.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <signal.h>
#include <time.h>

#include "offrss.h"

static int listen_socket;
static int is_cgi;
const char *cgi_url_path;
int param_show_read;
static int param_mark_read;
static int param_mark_unread;
static int param_lastchecked;
static int param_local_images;
static int param_offset;
static int param_single_page;

struct ParamPosts *param_posts;

const static int port = 8090;
const int per_page = 10;

void error(const char *msg, ...)
{
    va_list v;

    va_start(v, msg);
    vfprintf(stderr, msg, v);
    putc('\n', stderr);
    fprintf(stderr, " errno %i: %s\n", errno, strerror(errno));
    exit(-1);
}

void ignore_sigpipe()
{
    sigset_t set;

    sigemptyset(&set);
    sigaddset(&set, SIGPIPE);
    sigprocmask(SIG_BLOCK, &set, NULL);
}

static void start_listening()
{
    int ls;
    struct sockaddr_in addr;
    int res;

    ls = socket(AF_INET, SOCK_STREAM, 0);
    if (ls == -1)
        error("Cannot create the tcp listen socket in the server");

    {
        int on = 1;
        res = setsockopt(ls, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));
        if (res == -1)
            error("Cannot set SO_REUSEADDR");
    }

    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);

    res = bind(ls, (struct sockaddr *) & addr, sizeof(addr));
    if (res == -1)
        error("Error binding tcp to port %i", port);

    /* NUANCE: 0 backlog. Why should we assure future connections? */
    res = listen(ls, 0);
    if (res == -1)
        error("Error listening on the binded tcp socket");

    listen_socket = ls;
}

void
send_sure(int s, const char *buf, int size)
{
    int sent = 0;
    
    do
    {
        int res;
        res = write(s, buf + sent, size - sent);
        if (0 && verbose)
            fprintf(stderr, "write res: %i\n", res);
        if (res < 0)
        {
            if (errno == EINTR)
                continue;
            else
                return;
        }
        sent += res;
    } while(sent < size);
}

void
send_line(int s, const char *msg, ...)
{
    va_list v;
    char line[400];
    int res;

    va_start(v, msg);
    res = vsnprintf(line, sizeof line, msg, v);

    send_sure(s, line, res);
}

char *
find_next_img_url(const char *buf, int *begin, int *end)
{
    const char *pos = buf;

    *begin = 0;
    *end = 0;

    pos = strstr(pos, "<img ");
    if (pos)
    {
        const char *pos2;

        pos += strlen("<img ");

        pos2 = strstr(pos, "src=\"");
        if (pos2)
        {
            const char *endpos, *url, *filename;

            pos2 += strlen("src=\"");
            endpos = strchr(pos2, '\"');

            if (endpos)
            {
                *begin = pos2 - buf;
                *end = endpos - buf;
            }

            url = strndup(pos2, endpos - pos2);
            return img_url_to_filename(url);
        }
    }
    return 0;
}

void
replace_img(char **content, const char *feedname)
{
    char *simplename;
    char *start = *content;
    int needed;

    needed = strlen(*content) + 1;

    do
    {
        int begin, end;
        simplename = find_next_img_url(start, &begin, &end);
        if (simplename)
        {
            char filename[400];
            struct stat st;
            int res;
            int begin_from_contents = (start - *content) + begin;
            int end_from_contents = (start - *content) + end;

            strncpy(filename, "files/", sizeof filename);
            mystrncat(filename, feedname, sizeof filename);
            mystrncat(filename, "/images/", sizeof filename);
            mystrncat(filename, simplename, sizeof filename);

            if (0)
                fprintf(stderr, "img found: %s\n", filename);

            /* Does file exist? */
            res = stat(filename, &st);
            if (res == 0 && S_ISREG(st.st_mode))
            {
                /* Replace the url */
                char newurl[400];
                int diff;
                char *newcontent;

                if (!is_cgi)
                    strncpy(newurl, "/", sizeof newurl);
                else
                {
                    strncpy(newurl, cgi_url_path, sizeof newurl);
                    mystrncat(newurl, "/", sizeof newurl);
                }
                mystrncat(newurl, feedname, sizeof newurl);
                mystrncat(newurl, "/images/", sizeof newurl);
                mystrncat(newurl, simplename, sizeof newurl);

                diff = strlen(newurl) - (end - begin);

                newcontent = malloc(needed + diff);

                if (0)
                {
                    fprintf(stderr, "begin: %i end: %i needed: %i diff: %i newurl: <%s>\n",
                            begin_from_contents, end_from_contents, needed, diff, newurl);
                    // Leak
                    fprintf(stderr, "start: %s end: %s\n",
                            strndup(*content,begin), *content + end);
                }

                strncpy(newcontent, *content, begin_from_contents);
                newcontent[begin_from_contents] = '\0';
                assert(strlen(newcontent) == begin_from_contents);
                mystrncat(newcontent, newurl, needed + diff);
                assert(strlen(newcontent) == begin_from_contents + strlen(newurl));
                mystrncat(newcontent, *content + end_from_contents, needed + diff);
                assert(strlen(newcontent) == needed+diff-1);

                free(*content);
                *content = newcontent;
		needed = needed + diff;
            }
            start = *content + begin_from_contents;
            free(simplename);
        }
    } while(simplename);
}

void
send_file(int s, const char *path)
{
    char buf[10000];
    FILE *f;

    f = fopen(path, "rb");
    if (f == NULL)
        return;

    send_http_headers(s, HEADER_IMAGE, -1, 0);

    do
    {
        int res;

        res = fread(buf, 1, sizeof buf, f);
        if (res > 0)
            send_sure(s, buf, res);
    } while(!feof(f));

    fclose(f);
}


void
send_contents(int s, const char *feedname, const char *path)
{
    char *buf = 0;
    int already_read = 0;
    int allocated = 0;
    FILE *f;

    f = fopen(path, "rb");
    if (f == NULL)
        return;

    do
    {
        int res;

        allocated += 1000;
        buf = realloc(buf, allocated);

        /* Reserving 1 for \0 at the end - reasonable as the file should be in utf8 */
        res = fread(buf + already_read, 1, allocated - already_read - 1, f);
        if (res > 0)
        {
            already_read += res;
        }
    } while(!feof(f));
    fclose(f);

    /* space assured above */
    assert(already_read < allocated);
    buf[already_read] = '\0';

    if (param_local_images)
        replace_img(&buf, feedname);

    send_sure(s, buf, strlen(buf));

    free(buf);
}

struct feed_meta_t *
open_meta_by_feedname(const char *feedname)
{
    char filename[400];
    char base[400];
    struct feed_meta_t *fm;

    strncpy(filename, "files/", sizeof filename);
    mystrncat(filename, feedname, sizeof filename);
    strncpy(base, filename, sizeof base);
    mystrncat(filename, "/meta", sizeof filename);

    return open_meta(base, filename);
}

static void
send_css(int s, const char *filename, const char *media)
{
    char buf[10000];
    FILE *f;

    f = fopen(filename, "rb");
    if (f == NULL)
        return;

    send_line(s, "<style type=\"text/css\" media=\"%s\">\n", media);

    do
    {
        int res;

        res = fread(buf, 1, sizeof buf, f);
        if (res > 0)
            send_sure(s, buf, res);
    } while(!feof(f));

    fclose(f);

    send_line(s, "</style>\n");
}

static void
send_all_css(int s)
{
    send_css(s, "offrss.css", "screen");
    send_css(s, "offrssprint.css", "print");
}

static int
get_last_paging_offset(const struct feed_meta_t *fm, int *last_article)
{
    int total = 0;
    int in_page = 0;
    int page = 0;
    int j;
    int offset = 0;

    for(j = 0; j < fm->nitems; ++j)
    {
        if (param_show_read || ! fm->item[j].marked_read)
        {
            if (in_page >= per_page)
            {
                offset = total;

                ++page;
                in_page = 0;
            }
            *last_article = j;
            ++in_page;
            ++total;
        }
    }

    return offset;
}

void
send_feed(int s, const char *path)
{
    char str_params[400];
    int i;

    send_http_headers(s, HEADER_HTML, -1, 0);

    for(i = 0; i < nfeed_urls; ++i)
    {
        if (!feed_urls[i].is_section && strcmp(path, feed_urls[i].filename) == 0)
        {
            char base[400];
            char metafilename[400];
            int j;
            struct feed_meta_t *fm;
            int before_show;
            int shown;
            int offset_shown = 0;

            send_line(s, "<html><head>\n");
            send_line(s, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\n");
            send_line(s, "<title>%s - offrss</title>\n", path);
            send_all_css(s);
            send_line(s, "</head><body>\n");

            {
                str_params[0] = '\0';
                if (!param_local_images)
                    strncpy(str_params, "&local_images=0", sizeof str_params);

                send_line(s, "<div><a href=\"%s/?%s\">[Top]</a>\n", cgi_url_path, str_params);
            }

            {
                send_line(s, "<form style=\"display: inline;\" method=\"get\">\n");
                send_line(s, "<input type=\"hidden\" name=\"show_read\" value=\"%i\"/>\n",
                        param_show_read?0:1);
                send_line(s, "<input type=\"hidden\" name=\"single_page\" value=\"%i\"/>\n",
                        param_single_page);
                send_line(s, "<input type=\"hidden\" name=\"local_images\" value=\"%i\"/>\n",
                        param_local_images);
                send_line(s, "<input type=\"hidden\" name=\"offset\" value=\"%i\"/>\n",
                        param_offset);

                if (param_show_read)
                    send_line(s, "<input type=\"submit\" value=\"Hide read\"/>\n");
                else
                    send_line(s, "<input type=\"submit\" value=\"Show read\"/>\n");
                send_line(s, "</form>\n");
            }

            {
                send_line(s, "<form style=\"display: inline;\" method=\"get\">\n");
                send_line(s, "<input type=\"hidden\" name=\"show_read\" value=\"%i\"/>\n",
                        param_show_read);
                send_line(s, "<input type=\"hidden\" name=\"single_page\" value=\"%i\"/>\n",
                        param_single_page);
                send_line(s, "<input type=\"hidden\" name=\"local_images\" value=\"%i\"/>\n",
                        param_local_images?0:1);
                send_line(s, "<input type=\"hidden\" name=\"offset\" value=\"%i\"/>\n",
                        param_offset);

                if (param_local_images)
                    send_line(s, "<input type=\"submit\" value=\"Use remote images\"/>\n");
                else
                    send_line(s, "<input type=\"submit\" value=\"Use local images\"/>\n");
                send_line(s, "</form>\n");
            }

            {
                send_line(s, "<form style=\"display: inline;\" method=\"get\">\n");
                send_line(s, "<input type=\"hidden\" name=\"show_read\" value=\"%i\"/>\n",
                        param_show_read);
                send_line(s, "<input type=\"hidden\" name=\"single_page\" value=\"%i\"/>\n",
                        param_single_page?0:1);
                send_line(s, "<input type=\"hidden\" name=\"local_images\" value=\"%i\"/>\n",
                        param_local_images);
                send_line(s, "<input type=\"hidden\" name=\"offset\" value=\"%i\"/>\n",
                        param_offset);

                if (param_single_page)
                    send_line(s, "<input type=\"submit\" value=\"Paged view\"/>\n");
                else
                    send_line(s, "<input type=\"submit\" value=\"Single page\"/>\n");
                send_line(s, "</form>\n");
            }

#ifdef PDF
            {
                send_line(s, "<form style=\"display: inline;\" method=\"get\""
                        " action=\"%s/pdf/%s.pdf\">\n", cgi_url_path, path);
                send_line(s, "<input type=\"hidden\" name=\"show_read\" value=\"%i\"/>\n",
                        param_show_read);
                send_line(s, "<input type=\"submit\" value=\"Make PDF\"/>\n");
                send_line(s, "</form>\n");
            }

            {
                str_params[0] = '\0';
                if (param_show_read)
                    strncpy(str_params, "&show_read=1", sizeof str_params);

                send_line(s, "<a href=\"%s/planpdf/%s?%s\">[Plan PDF]</a>\n",
                        cgi_url_path, path, str_params);
            }
#endif

            send_line(s, "</div>\n");

            strncpy(base, "files/", sizeof base);
            mystrncat(base, path, sizeof base);
            strncpy(metafilename, base, sizeof metafilename);
            mystrncat(metafilename, "/meta", sizeof metafilename);

            send_line(s, "<h1>%s</h1>\n", path);

            send_line(s, "<p><a href=\"%s\">[feed]</a></p><hr>\n",feed_urls[i].url);

            fm = open_meta(base, metafilename);

            if (param_lastchecked == fm->lastchecked)
            {
                if (param_mark_unread >= 0 && param_mark_unread < fm->nitems)
                {
                    fm->item[param_mark_unread].marked_read = 0;
                    set_noread(base, &fm->item[param_mark_unread]);
                }
                if (param_mark_read >= 0 && param_mark_read < fm->nitems)
                {
                    fm->item[param_mark_read].marked_read = 1;
                    set_read(base, &fm->item[param_mark_read]);
                }
            }

            str_params[0] = '\0';

            if (param_show_read)
                mystrncat(str_params, "&show_read=1", sizeof str_params);
            if (!param_local_images)
                mystrncat(str_params, "&local_images=0", sizeof str_params);

            if (!param_single_page)
            {
                int page = 0;
                int offset_is_head = 0;
                int in_page = 0;
                int total = 0;

                send_line(s, "<div class=\"pages\">Pages: ");

                total = 0;
                in_page = 0;
                page = 0;
                if (param_offset == -1)
                {
                    int last_article; /* Not needed here */
                    offset_shown = get_last_paging_offset(fm, &last_article);
                }
                else
                    offset_shown = param_offset;

                total = 0;
                in_page = 0;
                page = 0;
                for(j = 0; j < fm->nitems; ++j)
                {
                    if (param_show_read || ! fm->item[j].marked_read)
                    {
                        if (total == 0 || in_page >= per_page)
                        {
                            if (offset_shown == total)
                                offset_is_head = 1;
                            
                            if (offset_is_head)
                                send_line(s, "[%i]\n", page);
                            else
                                send_line(s, "<a href=\"?offset=%i%s\">[%i]</a>\n", total, str_params,
                                        page);

                            offset_is_head = 0;
                            ++page;
                            in_page = 0;
                        }

                        ++in_page;
                        ++total;
                    }
                }

                send_line(s, "</div>\n<hr>\n");
            }

            before_show = 0;
            shown = 0;
            for(j = 0; j < fm->nitems; ++j)
            {
                if (param_show_read || ! fm->item[j].marked_read)
                {
                    char filename[400];

                    if (!param_single_page && before_show < offset_shown)
                    {
                        ++before_show;
                        continue;
                    }

                    strncpy(filename, base, sizeof filename);
                    mystrncat(filename, "/", sizeof filename);
                    mystrncat(filename, fm->item[j].filename, sizeof filename);

                    int next = j;
                    int new_offset = offset_shown;

                    const char *text = "Mark unread";
                    const char *operation = "mark_unread";
                    // URI
                    if (!fm->item[j].marked_read)
                    {
                        if (!param_show_read)
                        {
                            for(next = j+1; next < fm->nitems; ++next)
                                if (!fm->item[next].marked_read)
                                    break;

                            if(next == fm->nitems)
                            {
                                for(next = j-1; next >= 0; --next)
                                    if (!fm->item[next].marked_read)
                                        break;
                                if (shown == 0)
                                {
                                    new_offset = offset_shown - per_page;
                                    if (new_offset < 0)
                                        new_offset = 0;
                                }
                            }

                            if (next < 0)
                                /* An unexistent anchor, but I don't care.
                                 * At least I don't give a negative one */
                                next = 0;
                        }

                        text = "Mark read";
                        operation = "mark_read";
                    }

                    send_line(s, "<div>");
                    send_line(s, "<form style=\"display: inline;\" method=\"get\" "
                            "action=\"#%i\">\n", next);
                    send_line(s, "<input type=\"hidden\" name=\"show_read\" value=\"%i\"/>\n",
                            param_show_read);
                    send_line(s, "<input type=\"hidden\" name=\"single_page\" value=\"%i\"/>\n",
                            param_single_page?1:0);
                    send_line(s, "<input type=\"hidden\" name=\"local_images\" value=\"%i\"/>\n",
                            param_local_images);

                    send_line(s, "<input type=\"hidden\" name=\"%s\" "
                           "value=\"%i\"/>\n", operation, j);
                    send_line(s, "<input type=\"hidden\" name=\"lastchecked\" "
                           "value=\"%i\"/>\n", fm->lastchecked);
                    send_line(s, "<input type=\"hidden\" name=\"offset\" "
                           "value=\"%i\"/>\n", new_offset);
                    send_line(s, "<input type=\"submit\" value=\"%s\"/>\n", text);

                    send_line(s, "</form><a name=\"%i\"/></div>\n", j);

                    send_contents(s, feed_urls[i].filename, filename);
                    send_line(s, "<hr>\n");

                    ++shown;
                    if (!param_single_page && shown >= per_page)
                        break;
                }
            }

            close_meta(fm);

            break;
        }
    }

    send_line(s, "</body></html>\n");
}

static void
feed_count_items(const char *feedname, int *nitems, int *nunread, int *last_article,
        int *last_page_offset)
{
    struct feed_meta_t *fm;
    int j;

    fm = open_meta_by_feedname(feedname);

    *nunread = 0;
    *nitems = fm->nitems;

    for(j = 0; j < fm->nitems; ++j)
        if (!fm->item[j].marked_read)
            *nunread += 1;

    *last_page_offset = get_last_paging_offset(fm, last_article);

    close_meta(fm);
}

static
void
serve_update(int s)
{
    update();
}

void
send_http_headers(int s, enum e_header header, int length, int cache)
{
    time_t t;
    char strtime[400];

    t = time(NULL);

    if (!is_cgi)
        send_line(s, "HTTP/1.1 200 OK\r\n");

    strftime(strtime, sizeof strtime, "%a, %d %b %Y %T %Z", gmtime(&t));
    send_line(s, "Date: %s\r\n", strtime);
    send_line(s, "Connection: close\r\n");
    send_line(s, "Server: offrss\r\n");
    switch(header)
    {
        case HEADER_IMAGE:
            send_line(s, "Content-type: application/octet-stream\r\n");
            break;
        case HEADER_HTML:
            send_line(s, "Content-type: text/html\r\n");
            break;
        case HEADER_PDF:
            send_line(s, "Content-type: application/pdf\r\n");
            break;
    }
    send_line(s, "Cache-control: max-age=%i\r\n", cache);
    if (length >= 0)
        send_line(s, "Content-length: %i\r\n", length);

    send_line(s, "\r\n");
}

void
add_param_post(int num)
{
    struct ParamPosts **pivot;

    pivot = &param_posts;
    while (*pivot != 0)
        pivot = &((*pivot)->next);

    *pivot = (struct ParamPosts *)malloc(sizeof(*param_posts));
    (*pivot)->next = 0;
    (*pivot)->num = num;
}

void
free_param_posts()
{
    struct ParamPosts *pivot;

    pivot = param_posts;
    while (pivot != 0)
    {
        struct ParamPosts *old = pivot;
        pivot = pivot->next;
        free(old);
    }

    param_posts = 0;
}

void
process_request(int s, char *path, const char *query)
{
    char str_params[400];

    if (0)
        fprintf(stderr, "Process Request: path \"%s\" query \"%s\"\n", path, query);

    param_show_read = 0;
    param_mark_unread = -1;
    param_mark_read = -1;
    param_lastchecked = -1;
    param_local_images = 1;
    param_offset = -1;  /* -1 means the last */
    param_single_page = 0;

    if (path != NULL)
    {
        char *querycopy = strdup(query);
        char *text = querycopy;
        const char *token;
        while(token = strtok(text,"&"))
        {
            if (strstr(token, "show_read=1"))
                param_show_read = 1;

            if (strstr(token, "mark_unread="))
                sscanf(token, "mark_unread=%i", &param_mark_unread);

            if (strstr(token, "mark_read="))
                sscanf(token, "mark_read=%i", &param_mark_read);

            if (strstr(token, "lastchecked="))
                sscanf(token, "lastchecked=%i", &param_lastchecked);

            if (strstr(token, "local_images="))
                sscanf(token, "local_images=%i", &param_local_images);

            if (strstr(token, "offset="))
                sscanf(token, "offset=%i", &param_offset);

            if (strstr(token, "single_page="))
                sscanf(token, "single_page=%i", &param_single_page);

            if (strstr(token, "posts="))
            {
                int npost, res;
                res = sscanf(token, "posts=%i", &npost);
                if (res == 1)
                    add_param_post(npost);
            }

            text = NULL;
        }

        free(querycopy);
    }

    str_params[0] = '\0';
    if (!param_local_images)
        strncpy(str_params, "local_images=0", sizeof str_params);

    if (path == NULL || strcmp(path, "/") == 0)
    {
        int i;
        int in_list = 0;

        open_urls();

        send_http_headers(s, HEADER_HTML, -1, 10);

        send_line(s, "<html><head>\n");
        send_line(s, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\n");
        send_line(s, "<title>offrss %s</title>\n", is_cgi ? "CGI" : "local server");
        send_all_css(s);
        send_line(s, "</head><body>\n");
        send_line(s, "<p><a href=\"%s/update?%s\">[Update feeds]</a>\n", cgi_url_path, str_params);

        if (param_local_images)
            send_line(s, "<a href=\"?local_images=0\">[Use remote images]</a>\n");
        else
            send_line(s, "<a href=\"?\">[Use local images]</a>\n");
        send_line(s, "</p>\n");

        for(i = 0; i < nfeed_urls; ++i)
        {
            const struct feed_url_t *f = &feed_urls[i];
            if (f->is_section)
            {
                if (in_list)
                {
                    send_line(s, "</ul>\n");
                    in_list = 0;
                }
                send_line(s, "<h2>%s</h2>\n", f->sectionname);
            }
            else
            {
                int nunread, nitems;
                int last_page_offset;
                int last_article;
                char my_str_params[400];

                if (0 && verbose)
                    fprintf(stderr, "url: %s\n",
                            feed_urls[i].url);
                if (!in_list)
                {
                    send_line(s, "<ul>\n");
                    in_list = 1;
                }

                feed_count_items(feed_urls[i].filename, &nitems, &nunread, &last_article,
                        &last_page_offset);

                {
                    char soffset[100]; /* enough for an int */

                    strncpy(my_str_params, str_params, sizeof my_str_params);

                    snprintf(soffset, sizeof soffset, "offset=%i", last_page_offset);
                    mystrncat(my_str_params, soffset, sizeof my_str_params);
                }

                send_line(s, "<li><a href=\"%s/%s?%s#%i\">%s</a> (Unread: "
                        "<strong>%i</strong>; Total: %i)\n",
                        cgi_url_path,
                        feed_urls[i].filename,
                        my_str_params,
                        last_article,
                        feed_urls[i].filename,
                        nunread, nitems);
            }
        }
        if (in_list)
        {
            send_line(s, "</ul>\n");
        }
        send_line(s, "</body></html>\n");

        close_urls();
    }
    else if (strcmp(path, "/update") == 0)
    {
        send_http_headers(s, HEADER_HTML, -1, 0);

        send_line(s, "<html><head>\n");
        send_line(s, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\n");
        send_line(s, "<title>offrss - Update feeds</title>\n");
        send_all_css(s);
        send_line(s, "</head><body><h2>Updating...</h2>\n");
        serve_update(s);
        send_line(s, "<p>Done</p>\n");
        send_line(s, "<p><a href=\"%s/?%s\">[Top]</a>\n", cgi_url_path, str_params);
        send_line(s, "</body></html>\n");
    }
    else
    {
        char *pos, *pos_img;
        char *newpath = path;

        /* Security: Remove leading slashes */
        while(newpath[0] == '/')
            ++newpath;

        /* Security: halt on any ../ */ 
        while(pos = strstr(newpath, "../"))
        {
            break;
        }

        pos_img = strstr(newpath, "images/");

        if (pos_img)
        {
            char filepath[400];
            strncpy(filepath, "files/", sizeof filepath);
            mystrncat(filepath, newpath, sizeof filepath);

            if (0)
                fprintf(stderr, "filepath: %s\n", filepath);

            send_file(s, filepath);
        }
#ifdef PDF
        else if (!strncmp(newpath, "pdf/", 4))
        {
            char *file = path + 5 /* /pdf/ */;
            char *p;

            /* Take out the .pdf of the request */
            p = strstr(path, ".pdf");
            if (p)
                *p = '\0';

            open_urls();
            send_pdf(s, file);
            close_urls();
        }
        else if (!strncmp(newpath, "planpdf/", 4))
        {
            open_urls();
            send_plan_pdf(s, path + 9 /* /planpdf/ */);
            close_urls();
        }
#endif
        else
        {
            /* Normal feed */
            open_urls();
            send_feed(s, path + 1 /* '/' */);
            close_urls();
        }
    }

    free_param_posts();
}

void
url_rewrite(char *url)
{
    int len = strlen(url);
    int i;

    for(i = 0; i < len; ++i)
    {
        if (url[i] == '%' && (len - i) > 2)
        {
            char *p = &url[i];
            sscanf(&url[i+1], "%2hhx", p);

            p += 1;
            while(p[2])
            {
                p[0] = p[2];
                p += 1;
            }
            p[0] = '\0';
            len -= 2;
        }
    }
}

void
http_parse(int s)
{
    char line[4000];
    int pos = 0;
    int res;
    char *path = 0;
    int eol = 0;

    line[sizeof(line) - 1] = '\0';

    do
    {
        eol = 0;

        res = read(s, line + pos, 1);
        if (res == 1)
        {
            if(line[pos] == '\n')
                eol = 1;
            if (pos < sizeof(line) - 2) /* saving \n\0 at the end */
                pos = pos + 1;
            else
                assert(0);
        }

        if (eol)
        {
            assert(pos > 0);
            line[pos-1] = '\0';
            if (0 && verbose)
                fprintf(stderr, "Line: %s\n", line);
            if (strncmp(line, "GET", 3) == 0)
            {
                path = strdup(line + 4); /* after "GET " */
            }
            pos = 0;
        }

    } while(res > 0 && !(eol && strlen(line) <= 1));


    if (path)
    {
        char *pos;
        char *param;
        const char *query;

        if (0 && verbose)
            fprintf(stderr, "Request: %s\n", path);

        pos = strchr(path, ' ');
        assert(pos != NULL);
        *pos = '\0';

        /* Query string */
        param = strchr(path, '?');
        if (param)
        {
            *param = '\0';
            query = param + 1;
        }
        else
            query = "";

        url_rewrite(path);
        process_request(s, path, query);

        free(path);
    }
}

void
serve_cgi()
{
    char * query;
    char * path;
    int s;

    is_cgi = 1;

    query = getenv("QUERY_STRING");
    if (query == NULL)
        query = "";

    path = getenv("PATH_INFO");

    cgi_url_path = getenv("SCRIPT_NAME");

    if (0)
        fprintf(stderr, "script: %s pinfo: %s query: %s\n", cgi_url_path, path, query);

    s = 1; /* stdout */

    /* Apache does not need url_rewrite(path) */
    process_request(s, path, query);
}

void
serve()
{
    int s;
    char url[500];

    cgi_url_path = "";
    is_cgi = 0;

    ignore_sigpipe();

    start_listening();

    snprintf(url, sizeof url, "http://localhost:%i/", port);
    printf("%s\n", url);

    {
        /* Start the web browser if an environment variable tells so */
        char *browser;
        char command[500];

        browser = getenv("WEBBROWSER");
        if (browser)
        {
            snprintf(command, sizeof command, "%s %s", browser, url);

            system(command);
        }
    }

    do
    {
        if (0 && verbose)
            fprintf(stderr, "Accepting...\n");

        s = accept(listen_socket, NULL, NULL);
        if (s >= 0)
        {
            if (0 && verbose)
                fprintf(stderr, "New socket: %i\n", s);
            http_parse(s);
            close(s);
        }
    } while(s >= 0);

}
