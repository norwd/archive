#include <podofo/podofo.h>
#include <cstdio>
#include "pdf.h"

using namespace PoDoFo;
using namespace std;

void
makepdf(const char *txt)
{
    struct PDFBuffer b;

    pdf_create(&b);

    pdf_add_title(&b, "Prova");
    pdf_add_paragraph(&b, txt);
    pdf_add_title(&b, "Prova 2 a veure què tal");
    pdf_add_paragraph(&b, txt);
    pdf_finish(&b);

    FILE *f = fopen("test.pdf", "wb");

    fwrite(b.p, 1, b.size, f);

    fclose(f);

    pdf_free(&b);
}

int main(int argc, char *argv[])
{
    char *buf = 0;
    int bufpos = 0;
    FILE *fin;
    fin = fopen("txt","r");
    while(!feof(fin))
    {
        int nread;
        buf = (char *)realloc(buf, bufpos+1000);
        nread = fread(buf+bufpos, 1, 999, fin);
        bufpos += nread;
        buf[bufpos] = '\0';
    }
    fclose(fin);

    makepdf(buf);

    free(buf);

    return 0;
}
