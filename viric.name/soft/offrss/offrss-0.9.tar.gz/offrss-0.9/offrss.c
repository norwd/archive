/*
    offline rss reader
    Copyright (C) 2011  Lluís Batlle i Rossell

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    */

#include <stdio.h>
#include <mrss.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>

#include "offrss.h"

#define STRVERSION_(x) #x
#define STRVERSION(x) STRVERSION_(x)

int nfeed_urls = 0;
FILE * feed_urls_handle = 0;
struct feed_url_t *feed_urls = 0;

int verbose = 1;
int should_get_images = 1;

void read_feedinfo(const char *base, struct feed_meta_t *fm);

char *
title_to_filename(const char *title)
{
    char *n;
    char bad[] = { '\n', ',', '+', ':', '/', ' ', '&', '#', '\'', '"', ';', '?', '*',
        '$', '[', ']', '(', '(', '%' };
    /* Having % here, allows dealing less with the URL encoding by % */
    int i;
    /* Allow names at most 100 bytes long */
    int limit = 100;

    /* While the next character will be part of a utf8 sequence,
     * shorten the limit. We don't want to break utf8 strings. */
    while((title[limit] & 0300) == 0200 && limit > 0)
        --limit;

    n = strndup(title, limit);

    for(i=0; i < sizeof(bad)/sizeof(bad[0]); ++i)
    {
        char *pos;
        do {
            pos = strchr(n, bad[i]);
            if (pos != NULL)
                *pos = '_';
        } while (pos != NULL);
    }

    return n;
}

void
lock_on_urls()
{
    int fd;
    int res;
    assert(feed_urls_handle != NULL);
    fd = fileno(feed_urls_handle);
    res = lockf(fd, F_LOCK, 0);
    if (0)
        fprintf(stderr, "Lock on urls %i res=%i (errno: %s)\n", fd, res,
                strerror(errno));
}

void
unlock_on_urls()
{
    int fd;
    int res;
    assert(feed_urls_handle != NULL);
    fd = fileno(feed_urls_handle);
    res = lockf(fd, F_ULOCK, 0);
    if (0)
        fprintf(stderr, "Unlock on urls %i res=%i (errno: %s)\n", fd, res,
                strerror(errno));
}

struct feed_meta_t *
open_meta(const char *base, const char *filename)
{
    char line[4000];
    FILE *f;
    struct feed_meta_t *fm;
    int version;

    fm = malloc(sizeof *fm);
    fm->lastchecked = -1;
    fm->item = NULL;
    fm->nitems = 0;
    fm->alternate_url = NULL;
    fm->has_been_downloaded = 0;

    f = fopen(filename, "r+");
    if (f == NULL)
    {
        /* Create the file if it does not exist. Needed for proper locking. */
        lock_on_urls();

        mkdir(base, 0777);
        f = fopen(filename, "w+");
        assert(f != NULL);

        unlock_on_urls();
    }

    fm->handle = f;
    {
        int fd;
        int res;
        fd = fileno(f);
        res = lockf(fd, F_LOCK, 0);
        if (0)
            fprintf(stderr, "Opened %i (%s) res=%i (errno: %s)\n", fd, filename, res,
                    strerror(errno));
    }

    line[0] = '\0';
    fgets(line, sizeof line, f);
    sscanf(line, "%i", &version);

    if (!feof(f) && version != 1 && version != 2)
    {
        fprintf(stderr, "Wrong format version in %s\n", filename);
        exit(-1);
    }

    do
    {
        int lenline;
        line[0] = '\0';
        fgets(line, sizeof line, f);
        lenline = strlen(line);

        if(lenline > 0 && line[0] != '#')
        {
            const char *name;
            char *pos;
            const char *next;
            int pubdate = -1;
            int marked_read = 0;
            struct item_meta_t *item;

            pos = strchr(line, ' ');
            assert(pos != NULL);
            *pos = '\0';
            name = line;
            next = pos + 1;
            /* We don't care on marked_read in version 2, only used in version 1 */
            sscanf(next, "%i %i", &pubdate, &marked_read);

            fm->item = realloc(fm->item, (fm->nitems + 1)* sizeof(*fm->item));

            item = &fm->item[fm->nitems];
            fm->nitems += 1;
            item->filename = strdup(name);
            if (version == 1 && marked_read)
                set_read(base, item);
            item->marked_read = is_read(base, item);
            item->pubdate = pubdate;
        }
    } while(!feof(f));

    if (version == 1)
        save_meta(base, fm);

    read_feedinfo(base, fm);

    return fm;
}

void
read_feedinfo(const char *base, struct feed_meta_t *fm)
{
    char filename[400];
    char line[400];
    FILE *f;
    int version;

    strncpy(filename, base, sizeof filename);
    mystrncat(filename, "/feedinfo", sizeof filename);

    f = fopen(filename, "r");
    if (f == NULL)
        return;

    line[0] = '\0';
    fgets(line, sizeof line, f);
    sscanf(line, "%i", &version);

    if (version != 1)
    {
        fprintf(stderr, "Wrong format version in %s\n", filename);
        exit(-1);
    }

    line[0] = '\0';
    fgets(line, sizeof line, f);
    sscanf(line, "%i", &fm->lastchecked);

    line[0] = '\0';
    fgets(line, sizeof line, f);
    fm->alternate_url = strdup(line);

    fclose(f);
}

int
is_read(const char *base, struct item_meta_t *fm)
{
    char filename[400];
    int ret;

    strncpy(filename, base, sizeof filename);
    mystrncat(filename, "/", sizeof filename);
    mystrncat(filename, fm->filename, sizeof filename);
    mystrncat(filename, ".read", sizeof filename);

    return (access(filename, F_OK) == 0);
}

void
set_read(const char *base, struct item_meta_t *fm)
{
    char filename[400];
    FILE *f;
    int ret;

    strncpy(filename, base, sizeof filename);
    mystrncat(filename, "/", sizeof filename);
    mystrncat(filename, fm->filename, sizeof filename);
    mystrncat(filename, ".read", sizeof filename);

    f = fopen(filename, "w");
    assert(f != NULL);

    fclose(f);
}

void
set_noread(const char *base, struct item_meta_t *fm)
{
    char filename[400];
    FILE *f;
    int ret;

    strncpy(filename, base, sizeof filename);
    mystrncat(filename, "/", sizeof filename);
    mystrncat(filename, fm->filename, sizeof filename);
    mystrncat(filename, ".read", sizeof filename);

    unlink(filename);
}

void
save_feedinfo(const char *base, const struct feed_meta_t *fm)
{
    char filename[400];
    FILE *f;
    const int version = 1;

    strncpy(filename, base, sizeof filename);
    mystrncat(filename, "/feedinfo", sizeof filename);

    f = fopen(filename, "r+");
    if (f == NULL)
    {
        mkdir(base, 0777);
        f = fopen(filename, "w");
        assert(f != NULL);
    }

    fprintf(f, "%i\n", version);
    fprintf(f, "%i\n", fm->lastchecked);
    if (fm->alternate_url)
        fprintf(f, "%s\n", fm->alternate_url);
}

static int
items_by_pubdate(const void *a, const void *b)
{
    const struct item_meta_t *ia = (const struct item_meta_t *) a;
    const struct item_meta_t *ib = (const struct item_meta_t *) b;

    return ib->pubdate - ia->pubdate;
}

void
save_meta(const char *base, const struct feed_meta_t *fm)
{
    FILE *f;
    int i;
    const int version = 2;
    char filename[400];

    strncpy(filename, base, sizeof filename);
    mystrncat(filename, "/meta", sizeof filename);

    qsort(fm->item, fm->nitems, sizeof(*fm->item), items_by_pubdate);

    /* I don't reuse fm->handle because I will not be able
     * to truncate the file to whatever needed without closing
     * the handle (and thus losing the lock). */
    f = fopen(filename, "w");
    assert(f != NULL);

    fprintf(f, "%i\n", version);

    for(i = 0; i < fm->nitems; ++i)
    {
        const struct item_meta_t *item = &fm->item[i];

        fprintf(f, "%s %i\n", item->filename,
                item->pubdate);
    }

    if (fm->has_been_downloaded)
        save_feedinfo(base, fm);

    fclose(f);
}

void
close_meta(struct feed_meta_t *fm)
{
    int i;

    for(i = 0; i < fm->nitems; ++i)
    {
        free(fm->item[i].filename);
    }
    free(fm->item);
    free(fm->alternate_url);

    /* This will release the lock */
    if (0)
        fprintf(stderr, "Closing %i\n", fileno(fm->handle));
    fclose(fm->handle);

    free(fm);
}

void
remove_newline(char *s)
{
    char * pos;
    pos = strchr(s, '\n');
    if (pos != NULL)
        *pos = '\0';

    pos = strchr(s, '\r');
    if (pos != NULL)
        *pos = '\0';
}

void
open_urls()
{
    char line[4000];
    FILE *f;
    int numline;
    const char *filename = "feedurls.txt";

    assert(feed_urls == 0);

    f = fopen(filename, "r+");
    if (f == NULL)
    {
        fprintf(stderr, "Cannot open feedurls.txt: %s", strerror(errno));
        exit(-1);
    }

    feed_urls_handle = f;

    numline = 1;
    do
    {
        int lenline;
        line[0] = '\0';
        fgets(line, sizeof line, f);
        lenline = strlen(line);

        if(lenline > 1 /* Count the newline */ && line[0] != '#')
        {
            const char *name;
            char *space;
            char *url;

            /* In case of Section */
            if (line[0] == '-' && line[1] == ' ')
            {
                feed_urls = realloc(feed_urls, (nfeed_urls + 1)* sizeof(*feed_urls));

                remove_newline(line);
                feed_urls[nfeed_urls].sectionname = strdup(line + 2);
                feed_urls[nfeed_urls].is_section = 1;
                feed_urls[nfeed_urls].url = 0;
                feed_urls[nfeed_urls].filename = 0;

                nfeed_urls += 1;
            }
            else
            {
                /* Split the line in name and url */
                space = strchr(line, ' ');
                assert(space != NULL);
                if (space == NULL)
                {
                    fprintf(stderr, "Cannot parse the line %i as \"id URL\"\n", numline);
                    exit(-1);
                }
                *space = '\0';
                name = line;
                url = space + 1;

                feed_urls = realloc(feed_urls, (nfeed_urls + 1)* sizeof(*feed_urls));

                remove_newline(url);
                feed_urls[nfeed_urls].url = strdup(url);
                feed_urls[nfeed_urls].filename = strdup(name);
                feed_urls[nfeed_urls].is_section = 0;
                feed_urls[nfeed_urls].sectionname = 0;

                nfeed_urls += 1;
            }
        }
    } while(!feof(f));
}

static void
dump_urls()
{
    int i;

    for(i = 0; i < nfeed_urls; ++i)
    {
        if (!feed_urls[i].is_section)
            printf("%s %s\n", feed_urls[i].filename, feed_urls[i].url);
    }
}

static
int
get_lastmodified(const char *url)
{
    CURL *curl;
    CURLcode err;
    long lastmodified;

    curl = curl_easy_init();

    err = curl_easy_setopt(curl, CURLOPT_URL, url);
    assert(err == CURLE_OK);
    err = curl_easy_setopt(curl, CURLOPT_FILETIME, 1);
    assert(err == CURLE_OK);
    err = curl_easy_setopt(curl, CURLOPT_NOBODY, 1);
    assert(err == CURLE_OK);
    err = curl_easy_setopt(curl, CURLOPT_VERBOSE, 1);
    assert(err == CURLE_OK);

    err = curl_easy_perform(curl);
    if (err == CURLE_OK)
    {
        assert(err == CURLE_OK);

        err = curl_easy_getinfo(curl, CURLINFO_FILETIME, &lastmodified);
        assert(err == CURLE_OK);
    }
    else
        lastmodified = -1;

    curl_easy_cleanup(curl);

    return lastmodified;
}

int
readlong(char *filename)
{
    FILE *f;
    int val = -1;

    f = fopen(filename, "r");
    if (f == NULL)
        return -1;

    fscanf(f, "%i", &val);

    fclose(f);

    return val;
}

void
writelong(char *filename, int val)
{
    FILE *f;

    f = fopen(filename, "w");
    if (f == NULL)
        return;

    fprintf(f, "%i\n", val);

    fclose(f);
}

void
download_file(const char *filename, const char *url)
{
    CURL *curl;
    CURLcode err;
    CURLcode perform_err;
    long lastmodified;
    long response;
    FILE *out;

    out = fopen(filename, "wb");
    if (out == NULL)
        return;

    curl = curl_easy_init();

    err = curl_easy_setopt(curl, CURLOPT_URL, url);
    assert(err == CURLE_OK);
    err = curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1);
    assert(err == CURLE_OK);
    /*err = curl_easy_setopt(curl, CURLOPT_VERBOSE, 1);
    assert(err == CURLE_OK);*/

    err = curl_easy_setopt(curl, CURLOPT_WRITEDATA, out);
    assert(err == CURLE_OK);

    perform_err = curl_easy_perform(curl);

    fclose(out);

    err = curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response);
    assert(err == CURLE_OK);

    if (err != CURLE_OK || response != 200)
    {
        unlink(filename);
    }
    else
    {
        if (perform_err != CURLE_OK)
            fprintf(stderr, "Error parsing url %s: curl error %i\n", url, perform_err);
        else
            fprintf(stderr, "Error downloading url %s: http status %i\n", url, response);
    }

    curl_easy_cleanup(curl);
}

char *strrchr_2(const char *s, char c)
{
    int len = strlen(s);
    char *p = (char *) s + len - 1;
    int found = 0;

    for(; p >= s; --p)
    {
        if (*p == c)
        {
            ++found;
            if (found == 2)
                return p;
        }
    }
    return 0;
}

char *
img_url_to_filename(const char *url)
{
    char *filename;

    filename = strrchr(url, '/');
    if (filename)
    {
        char *ret;
        if (strchr(filename,'.') == 0)
        {
            /* We expect that if the last part of the URL does not have a
             * dot, maybe the immediately before directory has it.
             * Like in livejournal pictures:
             * http://pics.livejournal.com/cineastabo/pic/000110gs/s640x480 */
            filename = strrchr_2(url, '/');
        }

        if (filename)
        {
            filename += 1;
            ret = title_to_filename(filename);

            if (0)
                fprintf(stderr, "URL: %s\n  Filename: %s\n", url, ret);

            return ret;
        }
    }
    return 0;
}

void
get_images(const char *base, const char *content)
{
    const char *pos = content;

    if (0)
        fprintf(stderr, "  content: %s\n", content);

    do
    {
        pos = strstr(pos, "<img ");
        if (pos)
        {
            const char *pos2;

            pos += strlen("<img ");

            pos2 = strstr(pos, "src=\"");
            if (pos2)
            {
                const char *end, *url;
                char *filename;

                pos2 += strlen("src=\"");
                end = strchr(pos2, '\"');

                url = strndup(pos2, end - pos2);

                filename = img_url_to_filename(url);

                if (filename)
                {
                    char destfilename[400];
                    struct stat st;
                    int res;

                    strncpy(destfilename, base, sizeof destfilename);
                    mystrncat(destfilename, "/images", sizeof destfilename);

                    mkdir(destfilename, 0777);
                    mystrncat(destfilename, "/", sizeof destfilename);

                    mystrncat(destfilename, filename, sizeof destfilename);

                    /* Do not download if the file exists */
                    res = stat(destfilename, &st);
                    if (res != 0 || S_ISREG(st.st_mode))
                    {
                        fprintf(stderr, "  downloading img: %s\n", url);
                        download_file(destfilename, url);
                    }

                    free(filename);
                }
            }
        }
    } while(pos != NULL);
}

const char *
get_link_alternate(const mrss_item_t *item)
{
    /* This is for blogspot.com */
    int i;
    mrss_tag_t *tag = item->other_tags;

    while(tag)
    {
        if (tag->name && strcmp(tag->name, "link") == 0)
        {
            int found_alternate = 0;
            mrss_attribute_t *attr = tag->attributes;
            while(attr)
            {
                if (attr && strcmp(attr->name, "rel") == 0 &&
                        attr->value &&
                        strcmp(attr->value, "alternate") == 0)
                {
                    found_alternate = 1;
                    break;
                }
                attr = attr->next;
            }

            if (found_alternate)
            {
                attr = tag->attributes;
                while(attr)
                {
                    if (attr && strcmp(attr->name, "href") == 0 &&
                            attr->value)
                    {
                        return attr->value;
                    }
                    attr = attr->next;
                }
            }
        }
        tag = tag->next;
    }

    return NULL;
}

int
write_item(const char *filename, const char *base,
        const char *title, const mrss_item_t *item,
        const char *encoding)
{
    FILE *f;
    mrss_tag_t *tag;
    const char *link;

    f = fopen(filename, "w");
    assert(f != NULL);

    link = get_link_alternate(item);
    if (!link)
        link = item->link;
    fprintf(f, "<h2>");
    if (item->link)
        fprintf(f, "<a href=\"%s\">", item->link);
    fprintf(f, "%s", title);
    if (item->link)
        fprintf(f, "</a>");
    fprintf(f, "</h2>\n");

    fprintf(f, "<div class=\"date\"><strong>Date:</strong> %s</div>\n", item->pubDate);

    if (item->description)
    {
        char *description = conv_to_utf8(item->description, encoding);

        fprintf(f, "<div class=\"description\">%s</div>\n", description);
        get_images(base, description);
        free(description);
    }

    if (item->enclosure_url)
    {
        fprintf(f, "<div class=\"enclosure_url\"><a href=\"%s\">[download]</a></div>\n",
                item->enclosure_url);
    }

    tag = item->other_tags;
    // Find the content tag
    while(tag != NULL)
    {
        if (strcmp(tag->name,"content") == 0)
        {
            char *content = conv_to_utf8(tag->value, encoding);
            fprintf(f, "<div class=\"content\">%s</div>\n", content);
            get_images(base, content);
            free(content);
            break;
        }
        tag = tag->next;
    }
    fclose(f);
}

struct item_meta_t *
find_item_meta(struct feed_meta_t *fm, const char *filename)
{
    int i;

    for(i = 0; i < fm->nitems; ++i)
    {
        if (strcmp(fm->item[i].filename, filename) == 0)
        {
            return &fm->item[i];
        }
    }
    return NULL;
}

void
parse_rss(const char *filename, const char *base, struct feed_meta_t *fm)
{
    mrss_error_t err;
    mrss_t *mrss;
    mrss_item_t *item;

    char *filename_noconst = (char *) filename;

    err = mrss_parse_file(filename_noconst, &mrss);
    if (err != MRSS_OK)
        fprintf(stderr, "mrss err: %i\n", err);
    assert(err == MRSS_OK);

    item = mrss->item;

    while(item != NULL)
    {
        if (item->element == MRSS_ELEMENT_ITEM)
        {
            char *filename;
            char fullpath[400];
            struct item_meta_t *item_meta;
            char *title;

            strncpy(fullpath, base, sizeof fullpath);
            mystrncat(fullpath, "/", sizeof fullpath);

            if (item->title)
            {
                title = strdup(item->title);
                char *tmp = title;
                title = conv_to_utf8(tmp, mrss->encoding);
                free(tmp);
            }
            else
                title = strdup(item->guid);

            if (!title)
            {
                free(title);
                item = item->next;
                continue;
            }

            /* We don't want to overwrite the
             * 'meta' or 'feedinfo' files */
            if (strcmp(title, "meta") == 0 || strcmp(title, "feedinfo") == 0)
            {
                free(title);
                item = item->next;
                continue;
            }

            filename = title_to_filename(title);
            mystrncat(fullpath, filename, sizeof fullpath);

            item_meta = find_item_meta(fm, filename);
            if (item_meta == NULL)
            {
                fm->item = realloc(fm->item, (fm->nitems + 1)* sizeof(*fm->item));

                fm->item[fm->nitems].filename = strdup(filename);

                item_meta = &fm->item[fm->nitems];
                item_meta->marked_read = 0;
                item_meta->pubdate = -1;

                if (item->pubDate)
                {
                    /* Dates look like:
                     * Tue, 03 Oct 2006 21:21:27 GMT
                     * we want to skip the weekday, so we add 5
                     */
                    char *oldlocale;
                    struct tm tm;
                    time_t seconds;
                    oldlocale = strdup(setlocale(LC_ALL, "POSIX"));

                    strptime(item->pubDate, "%a, %d %b %Y %H:%M:%S %Z", &tm);
                    seconds = mktime(&tm);

                    setlocale(LC_ALL, oldlocale);

                    item_meta->pubdate = (int) seconds;
                    if (0 && verbose)
                        fprintf(stderr, "pubDate: %s ; timestamp = %i\n",
                                item->pubDate, item_meta->pubdate);
                }

                fm->nitems += 1;

                // We also save again the items we have in the list
                write_item(fullpath, base, title, item, mrss->encoding);
            }

            free(filename);
            free(title);
        }

        item = item->next;
    }

    mrss_free(mrss);
}

int
parse_if_newer(const char *url, const char *base, struct feed_meta_t *fm)
{
    int ret = 0;

    CURL *curl;
    CURLcode err;
    CURLcode perform_err;
    long lastmodified;
    long response = 0;

    curl = curl_easy_init();

    err = curl_easy_setopt(curl, CURLOPT_URL, url);
    assert(err == CURLE_OK);
    err = curl_easy_setopt(curl, CURLOPT_FILETIME, 1);
    assert(err == CURLE_OK);
    err = curl_easy_setopt(curl, CURLOPT_NOBODY, 1);
    assert(err == CURLE_OK);
    err = curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1);
    assert(err == CURLE_OK);
    /*err = curl_easy_setopt(curl, CURLOPT_VERBOSE, 1);
    assert(err == CURLE_OK);*/

    perform_err = curl_easy_perform(curl);

    err = curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response);
    assert(err == CURLE_OK);

    if (perform_err == CURLE_OK && response == 200)
    {
        err = curl_easy_getinfo(curl, CURLINFO_FILETIME, &lastmodified);
        assert(err == CURLE_OK);

        if (lastmodified < 0 || lastmodified > fm->lastchecked)
        {
            FILE *out;
            char *tmpfile = strdup("/tmp/offrssXXXXXX");
            int fd;

            fd = mkstemp(tmpfile);
            assert(fd >= 0);

            out = fdopen(fd, "wb");
            assert(out != NULL);

            err = curl_easy_setopt(curl, CURLOPT_NOBODY, 0);
            assert(err == CURLE_OK);

            err = curl_easy_setopt(curl, CURLOPT_WRITEDATA, out);
            assert(err == CURLE_OK);

            err = curl_easy_perform(curl);
            assert(err == CURLE_OK);

            fclose(out);

            parse_rss(tmpfile, base, fm);

            unlink(tmpfile);

            free(tmpfile);

            fm->lastchecked = lastmodified;
            fm->has_been_downloaded = 1;

            save_meta(base, fm);

            ret = 1;
        }
    }
    else
    {
        if (perform_err != CURLE_OK)
            fprintf(stderr, "Error parsing url %s: curl error %i\n", url, perform_err);
        else
            fprintf(stderr, "Error downloading url %s: http status %i\n", url, response);
    }

    curl_easy_cleanup(curl);

    return ret;
}

void
update()
{
    int i;

    open_urls();

    mkdir("files", 0777);

    for(i = 0; i < nfeed_urls; ++i)
    {
        if (!feed_urls[i].is_section)
        {
            char filename[400];
            int lastchecked;
            int was_checked;
            char *base;
            struct feed_meta_t *fm;

            strcpy(filename, "files/");

            if (verbose)
                fprintf(stderr, "Updating %s\n", feed_urls[i].filename);

            mystrncat(filename, feed_urls[i].filename, sizeof filename);

            base = strdup(filename);

            mystrncat(filename, "/meta", sizeof filename);

            fm = open_meta(base, filename);

            was_checked = parse_if_newer(feed_urls[i].url, base, fm);

            close_meta(fm);
        }
    }

    close_urls();
}

void close_urls()
{
    if (feed_urls)
    {
        int i;

        for(i = 0; i < nfeed_urls; ++i)
        {
            if (feed_urls[i].is_section)
                free(feed_urls[i].sectionname);
            else
            {
                free(feed_urls[i].filename);
                free(feed_urls[i].url);
            }
        }
        free(feed_urls);
    }
    nfeed_urls = 0;
    feed_urls = 0;

    /* Free the handle used for locks */
    assert(feed_urls_handle != NULL);

    fclose(feed_urls_handle);
    feed_urls_handle = NULL;
}

int main(int argc, char **argv)
{
    curl_global_init(CURL_GLOBAL_ALL);
    if (argc == 2)
    {
        if (strcmp(argv[1], "-u") == 0)
        {
            update();
        }
        else if (strcmp(argv[1], "-w") == 0)
        {
            serve();
        }
    }
    else
    {
        const char *cgi_check;

        cgi_check = getenv("GATEWAY_INTERFACE");

        if (cgi_check == NULL)
        {
            fprintf(stderr, "offline rss, version %s\n", STRVERSION(VERSION));
            fprintf(stderr, "Copyright (C) 2010-2011 Lluis Batlle i Rossell\n");
            fprintf(stderr, "usage: offrss [-u] [-w] \n");
            fprintf(stderr, "  -u   Update feeds\n");
            fprintf(stderr, "  -w   Start a web server (URL on stdout) to read the feeds\n");
            fprintf(stderr, "       If the WEBBROWSER env variable is set, it will call \"WEBBROWSER url\"\n");
        }
        else
        {
            serve_cgi();
        }
    }

    return 0;
}
