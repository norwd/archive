struct index_memory
{
    struct block *bo;
    int fd;
};

struct index_memory * index_memory_new(int fd);
void index_memory_prepare_readfds(struct index_memory *im, fd_set *fdset, int *nfds);
void index_memory_check_readfds(struct index_memory *im, fd_set *fdset);
void index_memory_to_tar(struct index_memory *im, struct mytar *tar);
int index_memory_finished(struct index_memory *im);
