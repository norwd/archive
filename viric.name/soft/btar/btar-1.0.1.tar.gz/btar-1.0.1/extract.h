void extract(int fd);
