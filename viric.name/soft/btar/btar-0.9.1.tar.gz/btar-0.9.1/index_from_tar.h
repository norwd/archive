void
index_from_tar(int infd, int outfd);
