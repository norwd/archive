#include <dirent.h>

struct traverse
{
    int dirfd;
    int filefd;
    DIR *dir;
    struct traverse *up;
    char *name;
    int is_dir;
};

int traverse(int datafd, int indexfd);
