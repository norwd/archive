struct String
{
  char *ptr;
  int length;
};

int parse_backslashes(unsigned char *str);
void print_hex(FILE *out, const struct String *str);
