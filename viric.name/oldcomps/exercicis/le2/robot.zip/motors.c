/////////////////////////////////
// LE 2 : Control del robot
// M�dul de control dels motors
//
// Autors: Coral� Planellas i Llongarriu
//         Llu�s Batlle i Rossell
//
// Data: 06/06/2002
/////////////////////////////////

#include "typedefs.h"
#include <stdio.h>

#include "motors.h"
#include "ports.h"
#include "lcd_hit.h"

int Passos[4];       // Comptadors de passos per a cada motor.

int MotorsActius;    // 1er Byte: Els 4 MSB indiquen quins motors van lents
                     // 1er Byte: Els 4 LSB indiquen quins motors estan actius
                     // 2on Byte: Els 4 LSB indiquen la direcci� en qu� van


//-------------------------------------------
// Engega o para els motors (Port 2) segons el contingut
// de la part de motors actius de la variable que se li passa.
// A m�s, actualitza la variable global 'MotorsActius'
//-------------------------------------------
void ActivarMotors(int Motors)
{
   char SortidaPort = 0;
   char i;

   MotorsActius = Motors;


   for (i=1; i <= 4; i++)
   {
      if (MOTORACTIU(MotorsActius,i))
      {
         if(SENTITMOTOR(MotorsActius,i) == RIGHT)
            // Hem de treure un 10b = 2
            SortidaPort += 0x02 << ((i-1)<<1);
         else                 // Direcci� ESQUERRA
            // Hem de treure un 01b = 1
            SortidaPort += 0x01 << ((i-1)<<1);
      }
      else
         // Mantenim el motor parat: treure un 11b = 3
         SortidaPort += 0x03 << ((i-1)<<1);
   }

   SetP2(SortidaPort);
}


//-------------------------------------------
// Obtenim el nombre de passos pel motor NumMotor (1..4)
//-------------------------------------------
int GetPassos(char NumMotor)
{
   return Passos[NumMotor - 1];
}


//-------------------------------------------
// Reinicialitzem els comptadors de passos a 0
//-------------------------------------------
void ResetPassos()
{
   char TempString[16];
   Passos[0] = Passos[1] = Passos[2] = Passos[3] = 0;

/*    LCD_ClearScreen();
   sprintf(TempString, "1%03i 2%03i 3%03i 4%03i", Passos[0], Passos[1]);
   LCD_Print(TempString, 15);
*/

}
