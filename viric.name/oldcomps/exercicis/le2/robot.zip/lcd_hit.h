#ifndef __LCD_HIT_H__
#define __LCD_HIT_H__

#define SHIFT_DISPLAY	1
#define SHIFT_CURSOR		0
#define SHIFT_LEFT      0
#define SHIFT_RIGHT		1

#define LINIA2		40


// Prototips

// ===============================================================
// Controla el LCD segons ENABLED,NOTENABLED,RS_DATA,RS_INST,RW_WRITE,RW_READ
// ===============================================================
void LCD_Control(unsigned char Enable, unsigned char RS, unsigned char RW);


// ===============================================================
// Netejar la pantalla
// ===============================================================
void LCD_ClearScreen();

// ===============================================================
// Posa el cursor a l'inici
// ===============================================================
void LCD_CursorInit();

// ===============================================================
// Estableix el funcionament del LCD
// ===============================================================
void LCD_Function();

// ===============================================================
// Activa/desactiva el display, el cursor, i el blinking
// ===============================================================
void LCD_Screen(char Display, char Cursor, char Blinking);

// ===============================================================
// Sel�lecciona els modes de despla�ament
// ===============================================================
void LCD_Input();

// ===============================================================
// Despla�a el Display / Cursor
// ===============================================================
void LCD_Shift(char DisplayCursor, char Direction);

// ===============================================================
// Sel�lecciona una adre�a de la DDRAM
// ===============================================================
void LCD_Address(char Address);

// ===============================================================
// Mostra un texte de la longitud determinada per l'LCD
// ===============================================================
void LCD_Print(char Text[], char Length);

// ===============================================================
// Inicialitza el LCD
// ===============================================================
void LCD_Init();

#endif
