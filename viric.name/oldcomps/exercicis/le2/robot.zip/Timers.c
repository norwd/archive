/////////////////////////////////
// LE 2 : Control del robot
// M�dul de control dels Timers/Base de Temps
//
// Autors: Coral� Planellas i Llongarriu
//         Llu�s Batlle i Rossell
//
// Data: 06/06/2002
/////////////////////////////////


#include <embedded.h>
#include <stdio.h>
#include "typedefs.h"
#include "int.h"
#include "register.h"

#include "ports.h"
#include "motors.h"
#include "timers.h"


#define TICKS20ms 625
#define TICKS25ms 781   // 781.25 realment

// Variables globals

extern int MotorsActius;
   // 1er Byte: Els 4 MSB indiquen quins motors van lents
   // 1er Byte: Els 4 LSB indiquen quins motors estan actius
   // 2on Byte: Els 4 LSB indiquen la direcci� en qu� van

char ContadorLent;      // Per fer el 20% d'activaci� al cicle del motor

extern int Passos[4];   // Comptadors de passos per a cada motor.

unsigned int UltimsNivellsPassos; // Nomes valen els bits 1..5 (corresponents als 4 motors)

unsigned int Ticks;              // Comptador de ticks per cada 20ms
unsigned int Ticks256us;         // Comptador de ticks per cada 256us


// ------------------------------------------------------------------------
// Inicialitzem els Timers/Base de Temps
// ------------------------------------------------------------------------
void IniTimers(void)
{
   BYTE far *pbyReg;    //punter a un registre
   WORD far *pbyRegW;   //punter a un registre


   // Inicialitzaci� de variables que necessiten les RSIs dels timers
   ContadorLent = 0;    // Estat del contador
   UltimsNivellsPassos = GetPT();

   //substituir el vector d'interrupci� dels Timers
   disable();     //no permetre cap INT
   setvect(INTCOUNTER0, RSITimer0);
   setvect(INTCOUNTER1, RSITimer1);
   setvect(INTBASETEMPS, RSIBaseTemps);
   enable();

   pbyReg = (BYTE far *)MK_FP(RSEG,TMIC0);
   *pbyReg = 0x07;   //permetem interrupcio del timer0 - Prioritat 7

   pbyRegW = (WORD far *)MK_FP(RSEG,MD0);
   *pbyRegW = TICKS25ms;   //programem MD0 per tenir crides cada 25 ms

   pbyReg = (BYTE far *)MK_FP(RSEG,TMC0);
   *pbyReg = 0xD0;      //engeguem el Timer0 (11010000b = 0xD0)
                        //Interval repetitiu a fclk/128


   pbyReg = (BYTE far *)MK_FP(RSEG,TMIC1);
   *pbyReg = 0x07;   //permetem interrupcio del timer1 - Prioritat 7

   pbyRegW = (WORD far *)MK_FP(RSEG,MD1);
   *pbyRegW = TICKS20ms;   //programem MD1 per tenir crides cada 20 ms

   pbyReg = (BYTE far *)MK_FP(RSEG,TMC1);
   *pbyReg = 0xC0;      //Engeguem el Timer1 (11000000b = 0xC0)
                        //Interval repetitiu a fclk/128


   // Programem la base de temps
   pbyReg = (BYTE far *)MK_FP(RSEG, PRC);


   //modificar el registre PRC per a una int cada 2.05 ms
   *pbyReg = 0x00;   //RAM interna deshabilitada
                     //Fclk de 4 MHz

   //apuntar al registre TBIC
   pbyReg = (BYTE far *)MK_FP(RSEG, TBIC);
   *pbyReg &= 0xBF;  //activar interrupcions BT


}


// ------------------------------------------------------------------------
// RSI Del Timer 0 -- Control dels contapassos
// Es crida cada 25ms
// ------------------------------------------------------------------------
void interrupt RSITimer0(void)
{
   char Nivells, Canvis;
   char TempString[16];

   enable();

   Nivells = GetPT();
   // Cal fer: Canvis = Nivells XOR UltimsNivellsPassos
   // A XOR B = ((NOT A) AND B) OR (A AND (NOT B))
   Canvis = (~Nivells & UltimsNivellsPassos) | (Nivells & ~UltimsNivellsPassos);

   // CV1..CV4 <=> PT1..PT4

   // Motor 1
   if (Canvis & 2)
   {
      if (SENTITMOTOR(MotorsActius,1) == LEFT)
         Passos[0] += 1;
      else
         Passos[0] -= 1;
   }
   // Motor 2
   if (Canvis & 4)
   {
      if (SENTITMOTOR(MotorsActius,2) == LEFT)
         Passos[1] += 1;
      else
         Passos[1] -= 1;
   }
   // Motor 3
   if (Canvis & 8)
   {
      if (SENTITMOTOR(MotorsActius,3) == LEFT)
         Passos[2] += 1;
      else
         Passos[2] -= 1;
   }
   // Motor 4
   if (Canvis & 16)
   {
      if (SENTITMOTOR(MotorsActius,4) == LEFT)
         Passos[3] += 1;
      else
         Passos[3] -= 1;
   }

   UltimsNivellsPassos = Nivells;

   FINT;
}


// ------------------------------------------------------------------------
// RSI Del Timer 1 -- Control dels motors quan funcionen lents
// Es crida cada 20ms
// ------------------------------------------------------------------------
void interrupt RSITimer1(void)
{
   char i;
   int NousMotors;

   enable();

   if ((MotorsActius & 0x0F0) && !(ContadorLent & 6))
   {
      NousMotors = MotorsActius;

      if (ContadorLent == 0)
      {
         for (i = 1; i <= 4; i++)
            // Fem anar el motor en el sentit que toca
            // (Activem la part d Motors Actius)
            if (MOTORLENT(MotorsActius,i))
               NousMotors =
                  TOCARMOTOR(NousMotors,i,ON+ONLENT,SENTITMOTOR(NousMotors,i));
      }
      else
         for (i =  1; i <= 4; i++)
            // Parem el motor       (Desactivem la part d Motors Actius)
            if (MOTORLENT(MotorsActius,i))
               NousMotors =
               TOCARMOTOR(NousMotors,i,OFF+ONLENT,SENTITMOTOR(NousMotors,i));


      ActivarMotors(NousMotors);

   }
   // Incrementem el comptador de passos.
   ContadorLent = (ContadorLent + 1) % 1;    // *** Es lent un % ?


   // Part del comptador de temps real
   Ticks += 1;

   FINT;
}


// ------------------------------------------------------------------------
// Retard20ms(unsigned int x) - Fa un retard de 20*x ms
// ------------------------------------------------------------------------
void Retard20ms(unsigned int MaxTicks)
{
   Ticks = 0;
   while(Ticks < MaxTicks);
}


// ------------------------------------------------------------------------
// Chrono20ms - Retorna una refer�ncia de temps (+1 cada 20ms)
// ------------------------------------------------------------------------
unsigned int Chrono20ms()
{
   return Ticks;
}


// ------------------------------------------------------------------------
// RSI de la Base de Temps per a fer ticks cada 256us
// ------------------------------------------------------------------------
void interrupt RSIBaseTemps(void)
{
   enable();

   Ticks256us++;
   FINT;
}


// ------------------------------------------------------------------------
// Retorna despr�s d'un retard de Temps*256us
// ------------------------------------------------------------------------
void Retard256us(unsigned int Temps)
{
   Ticks256us = 0;

   while(Ticks256us < Temps);
}
