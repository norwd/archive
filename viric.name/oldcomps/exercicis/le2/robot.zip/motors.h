#ifndef __MOTORS_H__
#define __MOTORS_H__

// Estats de "engegat" dels motors
#define ON			1
#define OFF			0
#define ONLENT		(1 << 4)
#define OFFLENT	0

// Direccions dels motors
#define LEFT		0
#define RIGHT		1

#define ANTIHORARI	RIGHT
#define HORARI		LEFT

#define ENDAVANT	LEFT
#define ENRADERA	RIGHT

#define PUJAR		RIGHT
#define BAIXAR		LEFT

#define OBRIR		RIGHT
#define TANCAR		LEFT

// Les seg�ents macros serveixen per alterar el contingut de variables del
// tipus "Motors".
// Els seg�ents par�metres s�n comuns:
//  var: Variable del tipus "Motors"
//  num: El n�mero del motor, de 1 a 4
//  sentit: Sentit de gir del motor. Ha de ser LEFT o RIGHT
//  engegat: Estableix si el motor est� actiu o va lent. Ha de ser la
//           suma de ON/OFF + ONLENT/OFFLENT
// ---- Variable de tipus "Motors"
// �s declarada com a 'int', on:
//    1er Byte: Els 4 MSB indiquen quins motors van lents
//    1er Byte: Els 4 LSB indiquen quins motors estan actius
//    2on Byte: Els 4 LSB indiquen la direcci� en qu� van

// Retorna 0 o 1 depenent de si el motor �s actiu o no
#define MOTORACTIU(var,num) (((var)&(1<<(num-1)))>>(num-1))
// Retorna 0 o 1 depenent de si el motor ha d'anar lent o no
#define MOTORLENT(var,num) (((var)&(1<<(num-1+4)))>>(num-1+4))
// Retorna LEFT o RIGHT segons el sentit del motor 
#define SENTITMOTOR(var,num) (((var)&(1<<(num-1+8)))>>(num-1+8))
// Retorna una mateixa variable del tipus "Motors", amb els par�metres
// establerts pel motor sel�leccionat. No altera l'estat dels altres motors.
#define TOCARMOTOR(var,num,engegat,sentit) (((var)&(~((1<<(num-1))+(1<<(num-1+4))+(1<<(num-1+8)))))+((engegat)<<(num-1))+((sentit)<<(num-1+8)))

// Prototips de funcions
void ActivarMotors(int Motors);
int GetPassos(char NumMotor);
void ResetPassos();

#endif
