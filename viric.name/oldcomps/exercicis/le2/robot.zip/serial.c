/////////////////////////////////
// LE 2 : Control del robot
// M�dul de control del port s�rie 0 (Recepci�)
//
// Autors: Coral� Planellas i Llongarriu
//         Llu�s Batlle i Rossell
//
// Data: 06/06/2002
/////////////////////////////////

#include <embedded.h>
#include "typedefs.h"
#include "int.h"
#include "register.h"

#include "serial.h"

// Mida del buffer Circular
/* * Posem la mida a 1, degut al mal disseny del comandament a dist�ncia.
   El bit de Stop es rep tot i que no es transmeti el paquet completament.
   Com que tampoc hi ha bit de paritat, no es poden detectar errors a la
   transmissi�.
   El que es transmet, especificat en s�rie, �s "ABCD1111", on l'�ltim 1 �s
   el bit de Stop. Si per comptes dels primers "111" es transmit�s
   "101", podriem detectar si el byte que hem rebut �s dolent: nom�s caldria
   comprovar que el byte rebut compleix la m�scara 0101xxxxb, on les x poden
   ser 0 o 1.

   Si es fa un buffer circular m�s gran, prement durant poca estona la
   tecla es pot rebre l'�ltim byte que �s defectu�s, i provoca un mal
   comportament del robot.
   La recomanaci� de fer un buffer circular del gui� de pr�ctiques no �s
   bona.
*/

#define LEN_BUFFER 1

int Ser0Buffer[LEN_BUFFER];
unsigned int Ser0BufferPosRead;
unsigned int Ser0BufferPosWrite;
unsigned int Ser0BufferLength;
unsigned int Ser0Errors;

//-------------------------------------------------
// Inicialitzaci� del port s�rie 0 (nom�s recepci�)
//-------------------------------------------------
void InitSerial()
{
   BYTE far *pbyReg; //punter a un registre

   // Programem SCM0
   // 7 bits, no parity, 1 stop => SMC0 = 41h
   pbyReg = (BYTE far *)MK_FP(RSEG, SCM0);
   *pbyReg = 0x41;

   // Programem el generador de bauds a 512bps per fclk=4 MHz
   // B = fclk/(G * (2 << n))
   // fclk = B * G * (2 << n) = 512 * 61 * (2 << 6) = 3997696 Hz
   pbyReg = (BYTE far *)MK_FP(RSEG, BRG0);
   *pbyReg = 61;
   pbyReg = (BYTE far *)MK_FP(RSEG, SCC0);
   *pbyReg = 6;

   // Actualitzem els vectors d'interrupcio
   disable();
   setvect(INTSRX0, RSI_Ser0Rx);
   setvect(INTSERR0, RSI_Ser0Error);
   enable();

   // Permetem les interrupcions
   // SRIC0 = 00000111b
   pbyReg = (BYTE far *)MK_FP(RSEG, SRIC0);
   *pbyReg = 0x07;
   // SEIC0 = 00000110b
   pbyReg = (BYTE far *)MK_FP(RSEG, SEIC0);
   *pbyReg = 0x06;

   Ser0BufferPosRead = 0;
   Ser0BufferPosWrite = 0;
   Ser0BufferLength = 0;
   Ser0Errors = 0;

}


//-------------------------------------------------
// RSI d'atenci� a la recepci� d'un byte pel port s�rie 0
//-------------------------------------------------
void interrupt RSI_Ser0Rx()
{
   BYTE far *pbyReg;

   enable();

   if (Ser0BufferLength < LEN_BUFFER)
   {
      pbyReg = (BYTE far *)MK_FP(RSEG, RxB0);
      Ser0Buffer[Ser0BufferPosWrite] = *pbyReg;

      Ser0BufferPosWrite = (Ser0BufferPosWrite + 1) % LEN_BUFFER;
      Ser0BufferLength++;
   }

   FINT;
}


//-------------------------------------------------
// RSI d'atenci� a un error en el port s�rie 0
//-------------------------------------------------
void interrupt RSI_Ser0Error()
{
   enable();

   Ser0Errors++;

   FINT;
}


//-------------------------------------------------
// Obt� un byte del port s�rie 0
//-------------------------------------------------
unsigned char GetSer0()
{
   unsigned char Result;

   Result = 0x00;

   // Comprovem que tenim bytes de la forma 0111XXXXb
   while((Result & 0xF0) != 0x70)
   {
      // Esperem que hi hagi algo al buffer
      while (Ser0BufferLength == 0);
      Result = Ser0Buffer[Ser0BufferPosRead];
      Ser0BufferPosRead = (Ser0BufferPosRead + 1) % LEN_BUFFER;
      Ser0BufferLength--;
   }

   return Result;
}


//-------------------------------------------------
// Neteja el buffer circular de lectura del port s�rie
//-------------------------------------------------
void ResetSer0()
{
   Ser0BufferPosRead = 0;
   Ser0BufferLength = 0;
   Ser0BufferPosWrite = 0;
}
