/////////////////////////////////
// LE 2 : Control del robot
// M�dul de control principal del robot
//
// Autors: Coral� Planellas i Llongarriu
//         Llu�s Batlle i Rossell
//
// Data: 06/06/2002
/////////////////////////////////


#include <embedded.h>
#include "register.h"
#include "typedefs.h"

#include "timers.h"  // funcions de control dels temporitzadors
#include "ports.h"   // funcions de control dels ports
#include "motors.h"  // funcions del control de motors
#include "serial.h"  // funcions de control de la l�nia s�rie

#define MAX_POSICIONS 50
#define PASSOS_MOTOR_LENT 5

/*
   
   Mando que tenim:
   [ 1 2 3 A ]
   [ 4 5 6 B ]
   [ 7 8 9 C ]
   [ * 0 # D ]

   Mando que es pensen que tenim:
   [ 1 2     ]
   [ 3 4 E R ]
   [ 5 6 B I ]
   [ 7 8     ]
*/
#define KEY_1  0
#define KEY_2  4
#define KEY_3  1
#define KEY_4  5
#define KEY_5  2
#define KEY_6  6
#define KEY_7  3
#define KEY_8  7
#define KEY_A  9
#define KEY_R  13
#define KEY_B  10
#define KEY_I  14

extern int MotorsActius;
extern int Motors;


typedef int POSICIO[4];


void PosarInici()
{
   unsigned int TempMotors;

   TempMotors=0;
   TempMotors=TOCARMOTOR(TempMotors,1,ON,ANTIHORARI);
   TempMotors=TOCARMOTOR(TempMotors,2,ON,ENRADERA);
   TempMotors=TOCARMOTOR(TempMotors,3,ON,PUJAR);
   TempMotors=TOCARMOTOR(TempMotors,4,ON,OBRIR);

   ActivarMotors(TempMotors);

   // Esperem a que els motors arribin a l'inici
   while(GetPT() & 1);

   // Parem els motors
   ActivarMotors(0);

   // Posem a 0 els comptadors de Passos
   ResetPassos();
}


void Reproduir(POSICIO Sequencia[], unsigned int LenSequencia)
{
   unsigned int TempMotors;
   POSICIO UltimaPosicio;
   unsigned int InstantUltimaPosicio;
   int i;
   int j;
   PosarInici();

   TempMotors = 0;

   for (i = 1; i < LenSequencia; i++)
   {
      // Primer engeguem els motors perqu� vagin a la posici� que toca
      for (j = 1; j <= 4; j++)
      {
         // SEGUR que cau en un dels 5 IFs
         if(Sequencia[i][j-1] - GetPassos(j) >
            PASSOS_MOTOR_LENT)
            TempMotors = TOCARMOTOR(TempMotors,j,ON,LEFT);
         else if (Sequencia[i][j-1] - GetPassos(j) <
               -PASSOS_MOTOR_LENT)
            TempMotors = TOCARMOTOR(TempMotors,j,ON,RIGHT);
         else if (Sequencia[i][j-1] - GetPassos(j) > 0)
            TempMotors = TOCARMOTOR(TempMotors,j,ONLENT,LEFT);
         else if (Sequencia[i][j-1] - GetPassos(j) < 0)
            TempMotors = TOCARMOTOR(TempMotors,j,ONLENT,RIGHT);
         else // el motor est� on toca
            TempMotors = TOCARMOTOR(TempMotors,j,OFF,RIGHT);
      }
      ActivarMotors(TempMotors);

      // Guardem la ultima posicio
      UltimaPosicio[0] = GetPassos(1);
      UltimaPosicio[1] = GetPassos(2);
      UltimaPosicio[2] = GetPassos(3);
      UltimaPosicio[3] = GetPassos(4);

      // Per controlar els 300ms de temps m�xim estant parat
      InstantUltimaPosicio = Chrono20ms();

      // Esperem que arribin al final tot controlant quan els
      // hem de fer anar lents o parar-los
      while(Sequencia[i][0] != GetPassos(1) ||
            Sequencia[i][1] != GetPassos(2) ||
            Sequencia[i][2] != GetPassos(3) ||
            Sequencia[i][3] != GetPassos(4))
      {
         for (j = 1; j <= 4; j++)
         {
            // Mirem si cal fer anar el motor lent o b� ha arribat al final.
            // Aquest codi s'executa suficientment sovint com perqu� es salti
            // algun dels passos on es compleixen les condicions.
            if(Sequencia[i][j-1] - GetPassos(j)==PASSOS_MOTOR_LENT ||
               Sequencia[i][j-1] - GetPassos(j)==-PASSOS_MOTOR_LENT)
               TempMotors =
                  TOCARMOTOR(TempMotors,j,ONLENT,SENTITMOTOR(TempMotors,j));
            else if (Sequencia[i][j-1] - GetPassos(j)==0)
               TempMotors = TOCARMOTOR(TempMotors,j,OFF,RIGHT);
         }
         ActivarMotors(TempMotors);

         if (UltimaPosicio[0] != GetPassos(1) ||   // Si hem canviat de posicio
            UltimaPosicio[1] != GetPassos(2) ||
            UltimaPosicio[2] != GetPassos(3) ||
            UltimaPosicio[3] != GetPassos(4))
         {
            // Sabem que la �ltima posicio coneguda �s l'actual
            UltimaPosicio[0] = GetPassos(1);
            UltimaPosicio[1] = GetPassos(2);
            UltimaPosicio[2] = GetPassos(3);
            UltimaPosicio[3] = GetPassos(4);

            InstantUltimaPosicio = Chrono20ms();
         }
         else  // Si no hem canviat de posicio ...
            if (Chrono20ms() > InstantUltimaPosicio+1000/20)
               // ... durant 1000 ms, en comptes dels 300ms suggerits, ja que
               // alguns motors funcionant lents quasi no es mouen (sobretot
               // la pin�a). Falta lubricar el robot!
            {
               // Vol dir que hem arribat al final
               // Sobreescriurem la ultima posici� guardada amb la que estem,
               // que �s m�s fiable i a m�s ens permet parar l'espera d'arribar
               // a la posici� final

               Sequencia[i][0] = GetPassos(1);
               Sequencia[i][1] = GetPassos(2);
               Sequencia[i][2] = GetPassos(3);
               Sequencia[i][3] = GetPassos(4);

            }
      }
   }

   // Es possible que quedi algun motor engegat encara!!!
   ActivarMotors(0);
}



void main()
{
   char Comando;
   POSICIO Sequencia[MAX_POSICIONS];
   unsigned int LenSequencia;
   char TempString[20];

   // Inicialitzem el sistema
   IniPorts();       // Ha de ser el primer a inicialitzar
   IniTimers();
   InitSerial();


   // Inicialitzem l'LCD Hitachi. Ha de ser l'�ltim a inicialitzar
   LCD_Init();
   LCD_ClearScreen();
   LCD_Screen(1,0,0);
   LCD_Address(0);
   LCD_Print("Posant a Inici  ", 16);

   // Posem el bra� a l'inici
   PosarInici();
   LenSequencia = 1;
   Sequencia[0][0] = 0;
   Sequencia[1][0] = 0;
   Sequencia[2][0] = 0;
   Sequencia[3][0] = 0;

   for(;;)
   {

      LCD_Address(0);
      sprintf(TempString, "M1%02iM2%02iM3%02iM4%02i",
         GetPassos(1), GetPassos(2), GetPassos(3), GetPassos(4));
      LCD_Print(TempString, 16);

      // El que rebem pel port serie �s 0111DCBAb i volem 0000DCBAb
      Comando = GetSer0() & 0x0F;

      switch (Comando)
      {
         case KEY_1:             // obrir pin�a
            ActivarMotors(TOCARMOTOR(MotorsActius,4,ON,OBRIR));
            Retard20ms(2);
            ActivarMotors(TOCARMOTOR(MotorsActius,4,OFF,OBRIR));
            break;

         case KEY_2:             // tancar pin�a
            ActivarMotors(TOCARMOTOR(MotorsActius,4,ON,TANCAR));
            Retard20ms(2);
            ActivarMotors(TOCARMOTOR(MotorsActius,4,OFF,TANCAR));
            break;

         case KEY_3:             // pujar
            ActivarMotors(TOCARMOTOR(MotorsActius,3,ON,PUJAR));
            Retard20ms(2);
            ActivarMotors(TOCARMOTOR(MotorsActius,3,OFF,PUJAR));
            break;

         case KEY_4:             // baixar
            ActivarMotors(TOCARMOTOR(MotorsActius,3,ON,BAIXAR));
            Retard20ms(2);
            ActivarMotors(TOCARMOTOR(MotorsActius,3,OFF,BAIXAR));
            break;

         case KEY_5:             // enrera
            ActivarMotors(TOCARMOTOR(MotorsActius,2,ON,ENRADERA));
            Retard20ms(2);
            ActivarMotors(TOCARMOTOR(MotorsActius,2,OFF,ENRADERA));
            break;

         case KEY_6:             // endavant
            ActivarMotors(TOCARMOTOR(MotorsActius,2,ON,ENDAVANT));
            Retard20ms(2);
            ActivarMotors(TOCARMOTOR(MotorsActius,2,OFF,ENDAVANT));
            break;

         case KEY_7:             // gir esquerra
            ActivarMotors(TOCARMOTOR(MotorsActius,1,ON,ANTIHORARI));
            Retard20ms(2);
            ActivarMotors(TOCARMOTOR(MotorsActius,1,OFF,ANTIHORARI));
            break;

         case KEY_8:             // gir dreta
            ActivarMotors(TOCARMOTOR(MotorsActius,1,ON,HORARI));
            Retard20ms(2);
            ActivarMotors(TOCARMOTOR(MotorsActius,1,OFF,HORARI));
            break;

         case KEY_A:                // emmagatzemar
            LCD_Address(0);
            LCD_Print("Grabant         ", 16);
            Sequencia[LenSequencia][0] = GetPassos(1);
            Sequencia[LenSequencia][1] = GetPassos(2);
            Sequencia[LenSequencia][2] = GetPassos(3);
            Sequencia[LenSequencia][3] = GetPassos(4);
            // Nom�s la guardem si la posici� �s diferent de l'�ltima guardada
            if (Sequencia[LenSequencia-1][0] != Sequencia[LenSequencia][0] ||
                  Sequencia[LenSequencia-1][1] != Sequencia[LenSequencia][1] ||
                  Sequencia[LenSequencia-1][2] != Sequencia[LenSequencia][2] ||
                  Sequencia[LenSequencia-1][3] != Sequencia[LenSequencia][3])
               LenSequencia++;
            Retard20ms(10);
            break;

         case KEY_B:                // borrar
            LCD_Address(0);
            LCD_Print("Borrant         ", 16);
            LenSequencia = 1;
            Retard20ms(10);
            break;

         case KEY_R:                // reproduir
            LCD_Address(0);
            LCD_Print("Reproduir       ", 16);
            Reproduir(Sequencia, LenSequencia );
            ResetSer0();   // perqu� nom�s la reprodueixi 1cop
            break;

         case KEY_I:                // inici
            LCD_Address(0);
            LCD_Print("Posant a Inici  ", 16);
            PosarInici();
            break;
      }
   }  //fi del lla� for

}




