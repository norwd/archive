#ifndef __SERIAL_H__
#define __SERIAL_H__

// Prototips de funcions

//-------------------------------------------------
// Inicialitzaci� del port s�rie 0 (nom�s recepci�)
//-------------------------------------------------
void InitSerial();

//-------------------------------------------------
// RSI d'atenci� a la recepci� d'un byte pel port s�rie 0
//-------------------------------------------------
void interrupt RSI_Ser0Rx();

//-------------------------------------------------
// RSI d'atenci� a un error en el port s�rie 0
//-------------------------------------------------
void interrupt RSI_Ser0Error();

//-------------------------------------------------
// Obt� un byte del port s�rie 0
//-------------------------------------------------
unsigned char GetSer0();

//-------------------------------------------------
// Neteja el buffer circular de lectura del port s�rie
//-------------------------------------------------
void ResetSer0();

#endif
