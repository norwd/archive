#if !defined(__TIMERS_H)
#define	__TIMERS_H

// Prototips

// ===============================================================
// Inicialitzem el Timer 0 - Control dels motors
// ===============================================================
void IniTimer0(void);

// ===============================================================
// Inicialitzem el Timer 1 - Per a fer retards
// ===============================================================
void IniTimer1(void);

// ===============================================================
// RSI del Timer 0 - Control de Motors
// ===============================================================
void interrupt RSITimer0(void);

// ===============================================================
// RSI del Timer 1 - Per a fer retards
// ===============================================================
void interrupt RSITimer1(void);
void Retard1ms(unsigned int TotalTicks);


#endif

