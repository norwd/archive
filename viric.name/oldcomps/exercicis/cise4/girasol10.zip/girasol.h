#ifndef __GIRASOL_H__

#define __GIRASOL_H__

#define DRETA 1
#define ESQUERRA 0

// Tecles del teclat de la placa del V25
// Tinguent la placa vertical davant nostre, i
// amb el teclat a la part superior, les tecles
// les definim com: A,B,C,D,E,F,G,H
//         ________
//        |   LCD  |
//   _____|________|
//  |I      ABCD    |
//  |I      EFGH    |
//  |[R]    /----\  |
//  |[O]    | V25|  |
//  |[M]    \----/  |
//  .................
#define TECLA_A 1	// Parar
#define TECLA_B 32
#define TECLA_C 16
#define TECLA_D 128
#define TECLA_E 4
#define TECLA_F 2
#define TECLA_G 8
#define TECLA_H 64


// Prototips

//----------------------------------------------------
// Retorna 0 sii no s'ha tocat el tope dret. NO retorna 1 o TRUE si s'ha tocat.
//----------------------------------------------------
char GetTopeDreta();

//----------------------------------------------------
// Retorna 0 sii no s'ha tocat el tope esquerra. NO retorna 1 o TRUE si s'ha tocat.
//----------------------------------------------------
char GetTopeEsquerra();

//----------------------------------------------------
// Obtenim la lectura dels sensors
//----------------------------------------------------
char GetSensors();

//----------------------------------------------------
// Mostra els autors per l'LCD
//----------------------------------------------------
void MostrarAboutLCD();

#endif


