/*
 * Control del girasol, versi� final 1.0
 * M�dul del control del LCD Hitachi
 *
 * Autors:
 *  Coral� Planellas i Llongarriu
 *  Llu�s Batlle i Rossell
 *
 * Data final:
 *  28/05/2002
*/

#include <embedded.h>

#include "typedefs.h"
#include "int.h"
#include "register.h"

#include "timers.h"     // Control dels temporitzadors i motors
#include "ports.h"      // Control dels ports del V25
#include "lcd_hit.h"		// Control del LCD Hitachi


#define BIT_ENABLE (1 << 6)		// El manual diu bit 4 (despla�ament 5)
#define BIT_RS     (1 << 4)		// El manual diu bit 2
#define BIT_RW     (1 << 5)	   // El manual diu bit 5 (No sabem si va)

#define BIT_BF     (1 << 7)

#define RS_DATA	1
#define RS_INST	0
#define RW_READ	1
#define RW_WRITE	0
#define ENABLED	1
#define NOTENABLED 0



// ===============================================================
// Controla el LCD segons ENABLED,NOTENABLED,RS_DATA,RS_INST,RW_WRITE,RW_READ
// ===============================================================
void LCD_Control(unsigned char Enable, unsigned char RS, unsigned char RW)
{
	BYTE far *pbyP1;	//punter al port

	//crear el punter al registre P1
	pbyP1 = (BYTE far *)MK_FP(RSEG, P1);
   *pbyP1 =  Enable*BIT_ENABLE + RS*BIT_RS + RW*BIT_RW;
}


// ===============================================================
// Esperem lo suficient perqu� el LCD estigui de qualsevol funci�
// ===============================================================
void LCD_Wait()
{
	// Es podria fer obtenint l'status del LCD i mirar la BusyFlag
	Retard1ms(1);
}


// ===============================================================
// Netejar la pantalla
// ===============================================================
void LCD_ClearScreen()
{
   LCD_Wait();

	SetP0Write();
   LCD_Control(NOTENABLED, RS_INST, RW_WRITE);

   SetP0(0x01);		// Esborrar pantalla
   LCD_Control(ENABLED, RS_INST, RW_WRITE);
   LCD_Control(NOTENABLED, RS_INST, RW_WRITE);

}


// ===============================================================
// Posa el cursor a l'inici
// ===============================================================
void LCD_CursorInit()
{
   LCD_Wait();

	SetP0Write();

   LCD_Control(NOTENABLED, RS_INST, RW_WRITE);
   SetP0(0x02);		// Cursor a l'inici (podem sumar 1?)
   LCD_Control(ENABLED, RS_INST, RW_WRITE);
   LCD_Control(NOTENABLED, RS_INST, RW_WRITE);
}


// ===============================================================
// Estableix el funcionament del LCD
// ===============================================================
void LCD_Function()
{
   LCD_Wait();

	SetP0Write();

   LCD_Control(NOTENABLED, RS_INST, RW_WRITE);
   SetP0(0x3F);		// 8 bits, 2 linies, caracters de 5x11 punts
   LCD_Control(ENABLED, RS_INST, RW_WRITE);
   LCD_Control(NOTENABLED, RS_INST, RW_WRITE);
}


// ===============================================================
// Activa/desactiva el display, el cursor, i el blinking
// ===============================================================
void LCD_Screen(char Display, char Cursor, char Blinking)
{
   LCD_Wait();

	SetP0Write();

   LCD_Control(NOTENABLED, RS_INST, RW_WRITE);
   SetP0(0x08 + (Blinking?1:0)*0x01 + (Cursor?1:0)*0x02 + (Display?1:0)*0x04);
   LCD_Control(ENABLED, RS_INST, RW_WRITE);
   LCD_Control(NOTENABLED, RS_INST, RW_WRITE);
}


// ===============================================================
// Sel�lecciona els modes de despla�ament
// ===============================================================
void LCD_Input()
{
   LCD_Wait();

	SetP0Write();
   LCD_Control(NOTENABLED, RS_INST, RW_WRITE);

//   SetP0(0x04 + 0x02 + 0x01);		// Tot a la dreta
   SetP0(0x04);		// Tot a l'esquerra
   LCD_Control(ENABLED, RS_INST, RW_WRITE);
   LCD_Control(NOTENABLED, RS_INST, RW_WRITE);
}


// ===============================================================
// Despla�a el Display / Cursor
// ===============================================================
void LCD_Shift(char DisplayCursor, char Direction)
{
   LCD_Wait();

	SetP0Write();
   LCD_Control(NOTENABLED, RS_INST, RW_WRITE);

   SetP0(0x10 + (DisplayCursor?1:0)*0x08 + (Direction?1:0)*0x04);
   LCD_Control(ENABLED, RS_INST, RW_WRITE);
   LCD_Control(NOTENABLED, RS_INST, RW_WRITE);
}


// ===============================================================
// Sel�lecciona una adre�a de la DDRAM
// ===============================================================
void LCD_Address(char Address)
{
   LCD_Wait();

	SetP0Write();
   LCD_Control(NOTENABLED, RS_INST, RW_WRITE);

   SetP0(0x80 + (Address & 0x7F));
   LCD_Control(ENABLED, RS_INST, RW_WRITE);
   LCD_Control(NOTENABLED, RS_INST, RW_WRITE);
}

// ===============================================================
// Mostra un texte de la longitud determinada per l'LCD
// ===============================================================
void LCD_Print(char Text[], char Length)
{
	int i;

	SetP0Write();

	for (i=0; i<Length; i++)
   {
	   LCD_Wait();
      LCD_Control(ENABLED, RS_DATA, RW_WRITE);
	   SetP0(Text[i]);
      LCD_Control(NOTENABLED, RS_DATA, RW_WRITE);
   }
}

// ===============================================================
// Inicialitza el LCD
// ===============================================================
void LCD_Init()
{
	SetP0Write();
   Retard1ms(15);
   	SetP1(RS_INST * BIT_RS + RW_WRITE * BIT_RW);
	   SetP0(0x3F);		// 8 bits
   	SetP1(RS_INST * BIT_RS + RW_WRITE * BIT_RW + BIT_ENABLE);
   	SetP1(RS_INST * BIT_RS + RW_WRITE * BIT_RW);
   Retard1ms(5);
   	SetP1(RS_INST * BIT_RS + RW_WRITE * BIT_RW);
	   SetP0(0x3F);		// 8 bits
   	SetP1(RS_INST * BIT_RS + RW_WRITE * BIT_RW + BIT_ENABLE);
   	SetP1(RS_INST * BIT_RS + RW_WRITE * BIT_RW);
   Retard1ms(1);
   	SetP1(RS_INST * BIT_RS + RW_WRITE * BIT_RW);
	   SetP0(0x3F);		// 8 bits
   	SetP1(RS_INST * BIT_RS + RW_WRITE * BIT_RW + BIT_ENABLE);
   	SetP1(RS_INST * BIT_RS + RW_WRITE * BIT_RW);
   Retard1ms(1);
   	SetP1(RS_INST * BIT_RS + RW_WRITE * BIT_RW);
	   SetP0(0x3F);		// 8 bits, 2 linies, caracters 5x11
   	SetP1(RS_INST * BIT_RS + RW_WRITE * BIT_RW + BIT_ENABLE);
   	SetP1(RS_INST * BIT_RS + RW_WRITE * BIT_RW);

   LCD_Screen(0,0,0);
   LCD_Screen(1,1,1);
   LCD_Input();

   // Ja que inicialitzem, netegem la pantalla i posem el cursor
   // a l'inici.
   LCD_ClearScreen();
}
