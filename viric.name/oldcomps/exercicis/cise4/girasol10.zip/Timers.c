/*
 * Control del girasol, versi� final 1.0
 * M�dul del control de timers i motors
 *
 * Autors:
 *  Coral� Planellas i Llongarriu
 *  Llu�s Batlle i Rossell
 *
 * Data final:
 *  28/05/2002
*/

#include <embedded.h>

#include "typedefs.h"
#include "int.h"
#include "register.h"

#include "timers.h"     // Control dels temporitzadors i motors
#include "ports.h"      // Control dels ports del V25
#include "girasol.h"		// Definici� de tecles, i DRETA/ESQUERRA

//#define TICKSPERPAS 1560			// 50 passos per segon
#define TICKSPERPAS 500		// Velocitat r�pida arbitr�ria
#define TICKSPER1MS 31		// 31.25

// Per a escollir si volem que quan el motor es pari, no consumeixi
//#define BAIX_CONSUM


// Variables globals del Timer 0
char Direccio;	// 0 a la dreta, 1 a l'esquerra
char Engegat;  // 0 parat, 1 engegat
int IndexPas;	// de 0 a 7
char Posicio[8];	 // Les 8 posicions


// Variables globals del Timer 1
unsigned int Ticks;			// Ticks de clock pel contador del Timer 1
unsigned int TicksMotors;	// Ticks que controlen cada quan s'han de moure els motors


// ===============================================================
// Inicialitzem el Timer 0 - Control dels motors
// ===============================================================
void IniTimer0(void)
{
	BYTE far *pbyReg;	//punter a un registre
	WORD far *pbyRegW;	//punter a un registre


   // Posicions del motor
   Posicio[0] = 8;
   Posicio[1] = 9;
   Posicio[2] = 1;
   Posicio[3] = 5;
   Posicio[4] = 4;
   Posicio[5] = 6;
   Posicio[6] = 2;
   Posicio[7] = 10;

   // Pas inicial
   IndexPas = 0;

   // Motor parat
   Engegat = 0;
   Direccio = DRETA;

	// Engeguem el motor


   //substituir el vector d'interrupci� de la base de temps
   disable();		//no permetre cap INT
   setvect(INTCOUNTER0, RSITimer0);
   enable();

	pbyReg = (BYTE far *)MK_FP(RSEG, TMIC0);
   *pbyReg = 0x03;   //permetem interrupcio del timer0

	pbyRegW = (WORD far *)MK_FP(RSEG, MD0);
   *pbyRegW = TICKSPERPAS;   //programem MD0 per anar als passos/s q toquen

   pbyReg = (BYTE far *)MK_FP(RSEG, TMC0);
   *pbyReg = 0xD0;		//engeguem el Timer0 (11010000b = 0xD0)
   							//Interval repetitiu a fclk/128
}


// ===============================================================
// Inicialitzem el Timer 1 - Per a fer retards
// ===============================================================
void IniTimer1(void)
{
	BYTE far *pbyReg;	//punter a un registre
	WORD far *pbyRegW;	//punter a un registre


   //substituir el vector d'interrupci� de la base de temps
   disable();		//no permetre cap INT
   setvect(INTCOUNTER1, RSITimer1);
   enable();

	pbyReg = (BYTE far *)MK_FP(RSEG, TMIC1);
   *pbyReg = 0x07;   //permetem interrupcio del timer1

	pbyRegW = (WORD far *)MK_FP(RSEG, MD1);
   *pbyRegW = TICKSPER1MS;   //programem MD0 per anar a 1 tick per us.

   pbyReg = (BYTE far *)MK_FP(RSEG, TMC1);
   *pbyReg = 0x40;		//parem el Timer1 (01000000b = 0x40)
   							//Interval repetitiu a fclk/128
}


// ===============================================================
// RSI del Timer 0 - Control de Motors
// ===============================================================
void interrupt RSITimer0(void)
{
	enable();

   if (Engegat == 1)
   {
    	SetP2(Posicio[IndexPas]);	// La mascara 0x0F no cal
   	if (Direccio == DRETA)
         IndexPas = ((IndexPas + 1) % 8);
      else	// Esquerra
         IndexPas = ((IndexPas + 7) % 8);
   }
#ifdef BAIX_CONSUM
   else
   	// Alliberem el motor. Que no consumeixi.
   	SetP2(0);
#endif


   FINT;
}




// ===============================================================
// RSI del Timer 1 - Per a fer retards
// ===============================================================
void interrupt RSITimer1(void)
{
	enable();

   Ticks++;

   FINT;
}



void Retard1ms(unsigned int TotalTicks)
{

	BYTE far *pbyReg;	//punter a un registre


   Ticks = 0;


   // Engeguem el Timer 1
   pbyReg = (BYTE far *)MK_FP(RSEG, TMC1);
   *pbyReg = 0xC0;		//Engeguem el Timer1 (11000000b = 0xC0)
   							//Interval repetitiu a fclk/128


   while (Ticks < TotalTicks);


	// Parem el Timer 1
   pbyReg = (BYTE far *)MK_FP(RSEG, TMC1);
   *pbyReg = 0x40;		//parem el Timer1 (01000000b = 0x40)
   							//Interval repetitiu a fclk/128

}
