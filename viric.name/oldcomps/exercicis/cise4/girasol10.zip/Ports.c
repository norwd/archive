/*
 * Control del girasol, versi� final 1.0
 * M�dul del control de ports
 *
 * Autors:
 *  Coral� Planellas i Llongarriu
 *  Llu�s Batlle i Rossell
 *
 * Data final:
 *  28/05/2002
*/

#include <embedded.h>

#include "register.h"
#include "typedefs.h"

#include "ports.h"      // Control dels ports del V25


// ===============================================================
// Inicialitzaci� dels ports
// (actualment, nom�s P2 i PT)
// ===============================================================
void IniPorts(void)
{
BYTE far *pbyReg;	//punter a un registre

   //crear el punter als registres de control
	pbyReg = (BYTE far *)MK_FP(RSEG, PMC2);
   *pbyReg = 0x00;	//PMC2 = '00' -> mode port 2 I/O
   --pbyReg;		//apuntar a PM2
   *pbyReg = 0xF0;	//PM2 = '00' -> port 2 de sortida els 4 primers bits
   						// i d'entrada els 4 ultims bits.
   --pbyReg;		//apuntar a P2
   *pbyReg = 0x00;	//P2 = '00' -> port 2 valor inicial

   //config PT
	pbyReg = (BYTE far *)MK_FP(RSEG, PMT);
   *pbyReg = 0x08;	//llindar entrades PT a 1.25V

   //config P1 -- Control del LCD
	pbyReg = (BYTE far *)MK_FP(RSEG, PMC1);
   *pbyReg = 0;		// Funcionament I/O pels bits 4, 5 i 6
   pbyReg--;			// Apuntem a PM1
   *pbyReg = 0;		// Tots els bits de sortida

   SetP0Write();	// Inicialitzem P0 amb tots els bits de sortida (dades LCD)
}


// ===============================================================
// Treure valor per P2 (Nomes els bits permesos)
// ===============================================================
void SetP2(BYTE byVal)
{
	BYTE far *pbyP2;	//punter al port

	//crear el punter al registre P2
	pbyP2 = (BYTE far *)MK_FP(RSEG, P2);
   *pbyP2 = byVal;	//P2 = byVal
}

// ===============================================================
// Llegeix P2 (nomes els bits permesos)
// ===============================================================
BYTE GetP2(void)
{
BYTE far *pbyP2;	//punter al port

	//crear el punter al registre P2
	pbyP2 = (BYTE far *)MK_FP(RSEG, P2);
   return(*pbyP2);	//valor P2
}


// ===============================================================
// Llegeix PT
// ===============================================================
BYTE GetPT(void)
{
	BYTE far *pbyPT;	//punter al port

	//crear el punter al registre PT
	pbyPT = (BYTE far *)MK_FP(RSEG, PT);
   return(*pbyPT);	//valor PT
}


// ===============================================================
// Inicialitza el port P0 com a lectura
// ===============================================================
void SetP0Read()
{
	BYTE far *pbyReg;	//punter a un registre

   //config P0	-- Dades del LCD
	pbyReg = (BYTE far *)MK_FP(RSEG, PMC0);
   *pbyReg = 0;		// Funcionament I/O
   pbyReg--;			// Apuntem a PM0
   *pbyReg = 0xFF;	// Tots els bits d'entrada
}


// ===============================================================
// Inicialitza el port P0 com a escriptura
// ===============================================================
void SetP0Write()
{
	BYTE far *pbyReg;	//punter a un registre

   //config P0	-- Dades del LCD
	pbyReg = (BYTE far *)MK_FP(RSEG, PMC0);
   *pbyReg = 0;		// Funcionament I/O
   pbyReg--;			// Apuntem a PM0
   *pbyReg = 0;		// Tots els bits de sortida
}




// ===============================================================
// Posa Data al P0
// ===============================================================
void SetP0(unsigned char Data)
{
	BYTE far *pbyP0;	//punter al port

	//crear el punter al registre P0
	pbyP0 = (BYTE far *)MK_FP(RSEG, P0);
   *pbyP0 = Data;			//P0 = Data
}


// ===============================================================
// Llegeix el P0
// ===============================================================
unsigned char GetP0()
{
	BYTE far *pbyP0;	//punter al port

	//crear el punter al registre P0
	pbyP0 = (BYTE far *)MK_FP(RSEG, P0);
   return (*pbyP0);
}


// ===============================================================
// Posa Data al P1
// ===============================================================
void SetP1(unsigned char Data)
{
	BYTE far *pbyP1;	//punter al port

	//crear el punter al registre P1
	pbyP1 = (BYTE far *)MK_FP(RSEG, P1);
   *pbyP1 = Data;			//P0 = Data
}

