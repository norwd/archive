/*
 * Control del girasol, versi� final 1.0
 * Autors:
 *  Coral� Planellas i Llongarriu
 *  Llu�s Batlle i Rossell
 *
 * Data final:
 *  28/05/2002
*/


#include <embedded.h>

#include "register.h"
#include "typedefs.h"

#include "timers.h"     // Control dels temporitzadors i motors
#include "ports.h"      // Control dels ports del V25
#include "girasol.h"		// Definici� de tecles, i DRETA/ESQUERRA
#include "lcd_hit.h"		// Control del LCD Hitachi


/////////////////////////
// Si la definim, activem el mode que vigila si ens enganyen
// (Si ens posen el llum just on no podem girar m�s, a un tope)
#define VIGILAR_ENGANYS

/////////////////////////
// Valors que rebem pel port P2 de cada sensor
// (Veure funci� GetSensors())
#define SENSORDRET       64
#define SENSORESQUERRA   128

/////////////////////////
// Variables globals
extern char Direccio;		// Direcci� de Motor
extern char Engegat;			// Si el motor est� engegat o no
char Buscar;					// Si estem buscant un llum o no


//----------------------------------------------------
// Mostra els autors per l'LCD
//----------------------------------------------------
void MostrarAboutLCD()
{
	// Assumim que el display �s de 16 car�cters/linia
   // Aix� determina el n�mero d'espais abans del nom
	char Nom1[] = "                Lluis Batlle     ";
   char Nom2[] = "                Corali Planellas ";
   int i;

   // El display �s el model japon�s. No podem fer accents a les
   // vocals.

   // Pantalla de presentaci� dels autors
  	LCD_ClearScreen();
   LCD_Print("Autors: ", 8);
   Retard1ms(2000);

   // Els noms dels autors es mouen en paral�lel de dreta
   // a esquerra
   LCD_ClearScreen();
   LCD_Print(Nom1, 33);
   LCD_Address(LINIA2);
   LCD_Print(Nom2, 33);
   for (i = 0; i< 33 ; i++)
   {
   	LCD_Shift(1,0);
      Retard1ms(250);
   }
   Retard1ms(2000);
}



//----------------------------------------------------
// Retorna 0 sii no s'ha tocat el tope dret. NO retorna 1 o TRUE si s'ha tocat.
//----------------------------------------------------
char GetTopeDreta()
{
	return (!(GetP2() & 0x10));
}


//----------------------------------------------------
// Retorna 0 sii no s'ha tocat el tope esquerra. NO retorna 1 o TRUE si s'ha tocat.
//----------------------------------------------------
char GetTopeEsquerra()
{
	return (!(GetP2() & 0x20));
}


//----------------------------------------------------
// Obtenim la lectura dels sensors
//----------------------------------------------------
char GetSensors()
{
	return GetP2() & (SENSORDRET + SENSORESQUERRA);
}



//----------------------------------------------------
// MAIN
//----------------------------------------------------
void main()
{
	BYTE Tecla;						// Tecla llegida de PT
   BYTE UltimaTecla;
	unsigned char Sensors;		// Aqu� hi haur� lo llegit dels sensors
	char GirantRevesDreta;		// En el cas que no poguem girar m�s a la Dreta
	char GirantRevesEsquerra;	// En el cas que no poguem girar m�s a l'Esquerra


	IniPorts();	//config. ports
	IniTimer0();	//config. temporitzadors
   IniTimer1();
   LCD_Init();
   LCD_Screen(1,0,0);		// Apaguem cursor

	Engegat = 0;		// El motor comen�a parat. En teoria no cal.
   Buscar = 0;
	Direccio = ESQUERRA;

   // Saludo inicial
	LCD_ClearScreen();
   LCD_Print("Hola!", 5);
   Retard1ms(1000);
   LCD_ClearScreen();

   // Comencem estant parat
   LCD_ClearScreen();
	LCD_Print("Parat   ", 8);

	//fem un lla� infinit de control
	for(;;){
		Tecla = (char) ~GetPT();

      // Parem el motor si s'ha alliberat alguna tecla de gir o hem deixat
      // de buscar
		if ((UltimaTecla == TECLA_E || UltimaTecla == TECLA_H || Buscar == 1) &&
	      (Tecla != TECLA_E && Tecla != TECLA_H && Buscar == 0))
      {
      	Engegat = 0;
		   LCD_ClearScreen();
		   LCD_Print("Parat   ", 8);
      }

      switch(Tecla)
      {
      	case TECLA_A:							// Parem de buscar - Mode Manual
         	if (UltimaTecla != TECLA_A)
            {
		         Buscar = 0;
		         Engegat = 0;			// No cal
					GirantRevesEsquerra = FALSE;
					GirantRevesDreta = FALSE;
				   LCD_ClearScreen();
				   LCD_Print("Parat   ", 8);
            }
            break;
         case TECLA_B:							// Comencem a buscar - Mode Auto
	      	if (UltimaTecla != TECLA_A)
            {
			   	Buscar = 1;
               // Presentaci� del Mode Auto
				   LCD_ClearScreen();
				   LCD_Print("ModeAuto", 8);
               Retard1ms(1000);
               // Mostrem que busquem
				   LCD_ClearScreen();
				   LCD_Print("Buscant ", 8);
            }
            break;

         // =============================
         case TECLA_E:							// Girem cap a la Dreta
         	if (Buscar == 0)	// Nom�s si no busquem
	         {
					if (GetTopeDreta())
               {
                  // Nom�s mostrem que estem al tope si no hem alliberat la
                  // tecla o l'acabem d'apretar
                  if(Engegat == 1 || UltimaTecla != TECLA_E)
                  {
		              	LCD_ClearScreen();
	                  LCD_Print("TD      ", 8);
               	}
	              	Engegat = 0;
            	}
	            else
               {
                  // Nom�s mostrem que estem al tope si acabem d'apretar la
                  // tecla
                  if(UltimaTecla != TECLA_E)
                  {
		              	LCD_ClearScreen();
	                  LCD_Print("GD      ", 8);
               	}
	              	Engegat = 1;
               }
		        	Direccio = DRETA;
            }
            break;

         // =============================
         case TECLA_H:                    // Girem cap a la Dreta
         	if (Buscar == 0)	// Nom�s si no busquem
         	{
					if (GetTopeEsquerra())
               {
                  // Nom�s mostrem que estem al tope si no hem alliberat la
                  // tecla o l'acabem d'apretar
                  if(Engegat == 1 || UltimaTecla != TECLA_H)
                  {
		              	LCD_ClearScreen();
	                  LCD_Print("TE      ", 8);
               	}
               	Engegat = 0;
               }
               else
               {
                  // Nom�s mostrem que estem al tope si acabem d'apretar la
                  // tecla
                  if(UltimaTecla != TECLA_H)
                  {
		              	LCD_ClearScreen();
	                  LCD_Print("GE      ", 8);
               	}
               	Engegat = 1;
               }
	         	Direccio = ESQUERRA;
            }
            break;

         // =============================
         case TECLA_D:							// About: Mostrem els autors
         	if (Buscar == 0)
            {
            	MostrarAboutLCD();
              	LCD_ClearScreen();
				   LCD_Print("Parat   ", 8);
            }

         	break;
      }


      // Obtenim l'estat dels sensors
		Sensors = GetSensors();
		if (Sensors == SENSORDRET + SENSORESQUERRA && Buscar == 1)
		{
			// Hem trobat el llum. Hem d'estar parats.
         Engegat = 0;
			GirantRevesEsquerra = FALSE;
			GirantRevesDreta = FALSE;
         LCD_Address(LINIA2);
		   LCD_Print("Trobat! ", 8);
		}
      else if (Buscar == 1)		// Si no hem trobat el llum i hem de buscar-lo
		{
			switch(Sensors)
			{
				case (SENSORDRET + SENSORESQUERRA):
					// No hauria de passar
               // Aquest cas es cobreix just despr�s de mirar l'estat dels Sensors
					break;

	         // =============================
				case SENSORDRET:
		         LCD_Address(LINIA2);
		   		LCD_Print("VD-", 3);
#ifndef VIGILAR_ENGANYS
					if (GetTopeDreta())
               {
               	Engegat = 0;
		   			LCD_Print("TD   ", 5);
               }
               else
               {
               	Engegat = 1;
		   			LCD_Print("GD   ", 5);
               }
               {		// Per iniciar la clau del gir normal
#endif
#ifdef VIGILAR_ENGANYS
					Engegat = 1;
					GirantRevesEsquerra = FALSE;
					if (GetTopeDreta())
						GirantRevesDreta = TRUE;
					if (GirantRevesDreta == TRUE)
						if (GetTopeEsquerra())		// En cas que ens enganyin
						{
							GirantRevesDreta = FALSE;
							Direccio = DRETA;
                    	LCD_Print("GD   ", 5);
						} else
                  {
							Direccio = ESQUERRA;
                    	LCD_Print("EN-GE", 5);
                  }
					else
               {
						LCD_Print("GD   ", 5);
#endif
						// Gir normal
						Direccio = DRETA;
					}

					break;

	         // =============================
				case SENSORESQUERRA:
		         LCD_Address(LINIA2);
		   		LCD_Print("VE-", 3);
#ifndef VIGILAR_ENGANYS
					if (GetTopeEsquerra())
               {
               	Engegat = 0;
		   			LCD_Print("TE   ", 5);
               }
               else
               {
               	Engegat = 1;
		   			LCD_Print("GE   ", 5);
					}
               {		// Per iniciar la clau del gir normal
#endif
#ifdef VIGILAR_ENGANYS
					Engegat = 1;
					GirantRevesDreta = FALSE;
					if (GetTopeEsquerra())
						GirantRevesEsquerra = TRUE;
					if (GirantRevesEsquerra == TRUE)
						if (GetTopeDreta())			// En cas que ens enganyin
						{
							GirantRevesEsquerra = FALSE;
							Direccio = ESQUERRA;
                    	LCD_Print("GE   ", 5);
						} else
                  {
							Direccio = DRETA;
                    	LCD_Print("EN-GD", 5);
                  }
					else
               {
						LCD_Print("GE   ", 5);
#endif
						// Gir normal
						Direccio = ESQUERRA;
					}
					break;

	         // =============================
				case 0:								// No veiem el llum
		         LCD_Address(LINIA2);
		   		LCD_Print("NV-", 3);
		      	Engegat = 1;
#ifdef VIGILAR_ENGANYS
					// Si estem vigilant si ens enganyen, cal cobrir el cas en qu�
               // durant uns instants tenim el llum a l'esquena, i continuar
               // girant en la direcci� que toca.
					if (GirantRevesDreta == TRUE)
						if (GetTopeEsquerra())		// En cas que ens enganyin
						{
							GirantRevesDreta = FALSE;
							Direccio = DRETA;
				   		LCD_Print("GD   ", 5);
						} else
                  {
							Direccio = ESQUERRA;
				   		LCD_Print("EN-GE", 5);
               	}
					else if (GirantRevesEsquerra == TRUE)
						if (GetTopeDreta())			// En cas que ens enganyin
						{
							GirantRevesEsquerra = FALSE;
							Direccio = ESQUERRA;
				   		LCD_Print("GE   ", 5);
						} else
                  {
							Direccio = DRETA;
				   		LCD_Print("EN-GD", 5);
                  }
					else
#endif
						// Pululem: Nomes canviem de direccio si arribem al tope.
						if (GetTopeEsquerra())
                  {
							Direccio = DRETA;
				   		LCD_Print("GD   ", 5);
                  }
						else if (GetTopeDreta())
                  {
							Direccio = ESQUERRA;
				   		LCD_Print("GE   ", 5);
                  }
                  else
                  switch(Direccio)
                  {
                  	case DRETA:
                     	break;
					   		LCD_Print("GD   ", 5);
                     case ESQUERRA:
					   		LCD_Print("GE   ", 5);
                     	break;
                  }


					break;
			}
		}
      UltimaTecla = Tecla;
	}	//fi del lla� for
}



