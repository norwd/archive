1. Selecting 2- or 3- Button Mouse Mode

If the mouse you purchased has three buttons and a mode switch (on the bottom of the
mouse), please follow these instructions.

      To configure the mouse as a Microsoft Mouse (2-button), move the switch to the
      position marked Microsoft.
      To configure the Mouse as a Mouse System Mouse (3-button), move the switch to the
      position marked Mouse System.

      Connect the mouse to the serial port (COM port) and turn on the computer. Now the
      hardware installation is completed. Please proceed to section 3. 

If the mouse you purchased has three buttons but does not have a mode switch (on the
bottom of the mouse), please follow these instructions.

      To configure the mouse as a Microsoft Mouse (2-button), connect the mouse to the
      serial port (COM port) and turn on your computer. The mouse will automatically
      configure itself as a Microsoft Mouse.
      To configure the mouse as a Mouse System Mouse (3-button), connect the mouse to
      the serial port (COM port). Then press the left button during booting your
      computer and release it afterwards. The mouse will configure itself as a Mouse
      System Mouse.

      Now the hardware installation is completed. Please proceed to section 3.


2. The Serial-PS/2 Mouse

If the mouse you purchased has two buttons and comes with a mini-DIN-6 to DB-9 adapter,
please follow these instructions.

      To configure the serial-PS/2 mouse as a PS/2 mouse, connect the mouse to the
      mouse port (Pointing Device Port, PDP) and turn on the computer. The mouse will
      automatically emulate a PS/2 mouse.

      To configure the serial-PS/2 mouse as a serial mouse (2-button), connect the
      mini-DIN-6 to DB-9 adapter to the connector at the end of the cable and plug it
      into the serial port (COM port) of your computer. The mouse will automatically
      emulate a Microsoft serial mouse.

      Please proceed to section 3.


3. Mouse Software Installation

To install the mouse software into your system, follow these instructions.

1) Insert the mouse driver diskette in drive A:
2) At the DOS prompt, type

                A:INSTALL

   Instructions on the screen will tell you how to proceed.
3) The install program will ask for your permission to modify your AUTOEXEC.BAT file. 
   By confirming this the driver will be installed automatically during booting up your
   computer.

*** IMPORTANT ***
"Mouse software installation is completed" does not mean that the mouse driver has been
loaded. You have to execute the mouse driver or reboot your system after the
installation.

4. Executing the Mouse Driver

There are two ways of loading the mouse driver.

1) Locate the directory that includes the IMOUSE.COM. (e.g. C:\MOUSE). Now type:

                C:\MOUSE\IMOUSE

2) Including IMOUSE.SYS as a device driver in your CONFIG.SYS file with a text editor:

                DEVICE=C:\MOUSE\IMOUSE.SYS (specify full path !)


5. Mouse Driver Command-Line Options

Command-line options are added in the mouse driver by including a "/" followed by the
options. Some of the options can be combined as long as each is separated by a "/". For
list of the command-line options, at the DOS prompt type:

                C:\MOUSE\IMOUSE /?

It will call up an ON-LINE HELP as the following:

Command-line options available at any time:
  /s# (5-100)           Sensitivity (horizontal & vertical)
  /p# (1,2,3,4)         Ballistic profile
  off                   Remove mouse driver from memory
  /kp#s# (1,2,3)        Primary, secondary button selection
  /k[c]                 Disable [enable] click-lock
  /l[d e f i            Language [German Spanish French Italian
     nl]                Dutch] (default english)
  /n# (0-10)            Cursor display delay
  /ps[s m l]            Pointer size (small, medium, large)
  /pc[n r t]            Pointer "color" (normal, reverse, transparent)
  /IRQ# (2-5, 10-15)    Specify serial port IRQ number
  /?                    List command-line option

Command-line options available only when the driver is first installed:
  /z                    PS/2 mouse
  /c# (1,2,3,4)         Serial mouse (COM 1, COM 2, etc.)
  /mi                   Microsoft-compatible serial
  /mo                   Mouse Systems-compatible serial
  /e                    Install in Expanded Memory
  /u                    Install in Upper Memory Block (UMB)
  /hi                   Install in High Memory Area (HMA)

For removing the mouse driver from memory, at the DOS prompt type:

                C:\MOUSE\IMOUSE OFF


6. Mouse Driver Initial Setting

The mouse driver provides a MOUSE.INI file for the initial setting. The MOUSE.INI
contains many settings for the mouse driver included in, but not limited to, the
command-line switches. The file is specially useful if you want to keep some features
as default values. It saves the trouble of typing the command-line options every time
you install the IMOUSE.COM driver. However, the IMOUSE.SYS driver cannot read the
MOUSE.INI file. The settings in the MOUSE.INI are read only by the IMOUSE.COM driver
when it is loaded into memory. Whenever you change any setting in the MOUSE.INI file,
it becomes the default setting. You can always use command-line switches to override
the settings in MOUSE.INI if you want to make a temporary change.
7. Control Panel

In addition to the mouse driver, you can control your mouse with the control panel
program - CPANEL.EXE. It lets you adjust your mouse parameters dynamically. This means
that you can modify the way your mouse operates while you are running your application.
At the DOS prompt, type:

                C:\MOUSE\CPANEL

Now the control panel program has been executed and resident in your memory. Whenever
you want to call it up, press SHIFT key and mouse primary button at the same time. The
control panel will show up. Sensitivity, acceleration and button definitions can be
modified.
Removing the control panel happens by typing: 

                C:\MOUSE\CPANEL OFF


8. Testing the Mouse

1) Insert your mouse driver disk into drive A.
2) At the DOS prompt,type the following command:
   A:\TEST
   A screen will appear.
3) A small pointer(shaped like a diamond in a box) will appear in the middle of the  
   screen.The pointer's movement will correspond to the mouse movement.
4) In the middle of the screen you will see three rectangular boxes. The bottom box  
   shows the coordinates of the pointer's position on the screen. By moving the      
   mouse, the -x and -y axis values will change. Now press each of the mouse buttons. 
   The other rectangular boxes should darken to indicate which mouse button is pressed.
5) To exit this program, move the cursor to the quit box and press the left mouse    
   button, or press 'q' on the keyboard.

9. Cursor Enhancement Utility

When using Windows, you will find that the cursor is very hard to see when
it moves across the screen. This utility reverses the color of the cursor
making it easier to see. This utility supports both EGA and VGA LCD
displays.

1) EGA LCD Display
 Please type these command:

  REN C:\WINDOWS\SYSTEM\EGA.DRV EGA1.DRV
  [ENTER]
  COPY X:EGA.DRV C:\WINDOWS\SYSTEM
  [ENTER]

2) VGA LCD Display
 Please type these command:

  REN C:\WINDOWS\SYSTEM\VGA.DRV VGA1.DRV
  [ENTER]
  COPY X:VGA.DRV C:\WINDOWS\SYSTEM
  [ENTER]

 NOTE: (1) Where "X" means which driver you put the driver disk in.
       (2) Above examples assume the path name is C:\WINDOWS, if it isn't,
           change it with your path name.

Now you can start your Windows and you will see a Black cursor on your LCD
screen.
