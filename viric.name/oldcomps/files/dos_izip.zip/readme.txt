
                           README FILE
                         January 12, 1998
                 Jaz Tools Software, Version 5.51
     
     Contents
     Section # Topic
          1    Using the Jaz "tools" Disk
          2    Using the Guest Program
          3    Software Installation Troubleshooting
          4    Electronic Manuals
          5    Installing Jaz Support on DOS-Only Systems
                    Iomega Driver for DOS
                    Jaz Tools under DOS
          6    Cautions
                    Microsoft Disk Copy Utilities
                    FDISK
                    32-bit Access
                    Windows Format Utility
                    Microsoft Backup
                    Compression
                    Installing Applications to the Jaz Drive
                    Findit for Windows requires version 3.11.
          7    Setting up a Jaz Boot Disk
                    System Requirements for Booting
                    Jaz Boot Drive Options
                    Setting Up the Jaz Drive as the Primary Boot
                         Device
                    Using the Jaz Drive as a Backup Boot Device


          
     _________________________________________________________
     Section 1
     Using the Jaz "tools" Disk
     
     The Jaz "tools" disk included with your Jaz drive is a
     special dual-format disk which contains Jaz Tools software
     for BOTH Windows/DOS and Macintosh systems.  Before you can
     write any files to the disk, the disk format must be set as
     EITHER Windows/DOS (IBM-compatible PC) or Macintosh (which
     allows you to store your files safely but eliminates the
     Tools software files stored under the other format type). 
     Running the software Setup program under either Windows 95
     or Windows 3.1 automatically sets the "tools" disk format to
     Windows/DOS and reclaims the Macintosh portion of the disk
     for use on PC systems.  Similarly, running the Jaz Install
     program for Macintosh, sets the "tools" disk format to
     Macintosh and erases the PC portion of the disk.  If you are
     installing Jaz software support on a DOS-only system, you
     need to run the Reclaim program from the DOSSTUFF directory
     on the "tools" disk to set the disk format and unlock the
     disk.
     
     If you use your Jaz drive on both PC and Macintosh systems
     and want to install Jaz Tools on both system types, you need
     to purchase an additional "tools" disk for installing Jaz
     Tools on your second system.  (See your Jaz Accessory Guide
     for ordering information.)
     
     NOTE:  The Jaz "tools" disk can be used to reinstall Jaz
     Tools software on the SAME system type (PC or Macintosh) as
     the initial installation.  It is important to keep the
     installation files on the "tools" disk in case you ever need
     to reinstall your Jaz Tools software.  (For a PC system, the
     installation files are located under W95Stuff, W31Stuff,
     WNTStuff, and DOSStuff.)  If you need more disk space, you
     may choose to delete some of the Jaz Tools additions.

     
     
     _________________________________________________________
     Section 2
     Using the Guest Program
     
     The Guest program allows you to use a portable Jaz drive on
     another computer without having to permanently install
     either an Iomega driver or Jaz Tools software. 

     There are versions of Guest for Windows 95, Windows 3.1/DOS
     and Macintosh systems:  

       *  For Windows 95, run Guest95 from the Windows/DOS
          Install disk.  If you encounter any problems, see "Help
          for Guest95" on the Install disk.

       *  For Windows 3.1/DOS systems, run GUEST.EXE from the
          Windows/DOS Install disk.  Refer to the GUESTHLP.TXT
          file on the Install disk for additional information on
          using GUEST.EXE with IBM-compatible PC's. 
     
       *  For information on using Guest on Macintosh systems,
          refer to the GUESTHLP.TXT file on the Windows/DOS
          Install disk.
     
     NOTE:  On Windows 3.1, DOS, or Macintosh systems, running
     the Guest program provides a temporary driver installation
     that is removed when the computer is shut down or restarted. 
     Running Guest95 permanently installs the drivers needed to
     support Iomega hardware under Windows 95.
     
     
     
     _________________________________________________________
     Section 3
     Software Installation Troubleshooting
     
     Refer to the MANUAL.EXE file on the Windows/DOS Install disk
     for software troubleshooting information on computers
     running Windows 95, Windows 3.1, and DOS.  Section 4 in this
     Readme file contains detailed instructions on accessing
     MANUAL.EXE.

     Note for users of Adaptec EZ-SCSI:
     For information on using Iomega software and Adaptec EZ-SCSI
     on the same system, refer to "Special Information for Users
     of Adaptec EZ-SCSI" in Appendix A of MANUAL.EXE.
     
     
     
     _________________________________________________________
     Section 4
     Electronic Manuals
     
     The Iomega software package for Windows/DOS includes two
     electronic manuals:

      *   The "Iomega Installation Manual" (MANUAL.EXE) which
          contains complete installation and problem-solving
          information for Iomega software under Windows 95,
          Windows 3.1, and DOS.

      *   The "User's Reference Manual" (REFMAN.EXE) which
          contains reference information on Iomega SCSI software,
          including the Iomega Driver, configuration program, and
          Iomega SCSI Utilities.

     To access the Installation Manual, insert the Windows/DOS
     "Install" disk in an appropriate drive (floppy or CD-ROM),
     go to the DOS prompt, and type:
     
               A: <Enter> (or D: where D is your CD-ROM drive)
               MANUAL <Enter>
     
     You can also run the Installation Manual from the Windows
     File Manager by selecting drive A: (or D: where D is your
     CD-ROM drive) and double-clicking on MANUAL.EXE.  Under
     Windows 95, you can access the Installation Manual by
     double-clicking on the floppy drive in My Computer and then
     double-clicking on the "Manual" icon.
     

     The User's Reference Manual is located in the DOSSTUFF
     directory on the Jaz "tools" disk and installed with the
     Iomega SCSI software package.  Use the following procedure
     if you want to access the reference manual before installing
     your software:

      1.  Insert the "Install" disk (floppy or CD) for
          Windows/DOS into the appropriate computer drive and the
          "tools" disk into the Jaz drive.

      2.  Go to the DOS prompt and type:

               a:guest.exe <Enter> (Install floppy in drive A)

                         or
    
               d:guest.exe <Enter> (Install CD in drive D)

      3.  Note the drive letter Guest assigns to your Jaz drive
          and use it in place of "e:" in the following command
          line:

               e:\dosstuff\refman <Enter>


     If you install Iomega SCSI software using the INSTALL
     program, you can access the User's Reference manual from the
     C:\IOMEGA directory after the software installation is
     complete.  Go to the DOS prompt and type:

                    c: <Enter>
                    cd \iomega <Enter>
                    refman <Enter>



     _________________________________________________________
     Section 5
     Installing Jaz Support on DOS-Only Systems
     
     Many of the application programs included in the Jaz Tools
     software package require Windows 3.1 or Windows 95.  If you
     do not have Windows on your computer, you can still use the
     Jaz drive, but you will not be able to use the Jaz Tools
     software that requires Windows.  This section describes the
     software support for Jaz drives available for DOS systems
     that do not have Windows.

     
     ______________________________
     Section 5.1
     Iomega Driver for DOS
     
     Running the INSTALL program from the DOSSTUFF directory on
     the Jaz "tools" disk installs Iomega SCSI software to
     support your Jaz drive.  The Iomega SCSI Driver installs as
     a device (SCSIDRVR.SYS) in the computer's CONFIG.SYS file, 
     and because of the way DOS handles drive letter assignments,
     this can shift your existing drive letters.
     
     Iomega software for Jaz includes a TSR version of the Driver
     (GUEST.EXE) which will not cause drive letter shifts when it
     is installed.  If you prefer using the TSR version of the
     Iomega Driver (GUEST.EXE), you can manually install it in
     your AUTOEXEC.BAT file.  Refer to the electronic
     Installation Manual (MANUAL.EXE) for manual installation
     instructions.  MANUAL.EXE also contains information on
     assigning specific drive letters with GUEST.EXE.  (See
     Section 4 in this file for detailed instructions on
     accessing the electronic manuals.)
     
     
     ______________________________
     Section 5.2
     Jaz Tools under DOS
     
     Iomega SCSI software includes a set of utilities that run
     under DOS.  You can use these utilities to set software
     protection options on your Jaz disks, copy data to or from
     Jaz disks, format Jaz disks, or lock the Jaz drive so that
     you can install software to a Jaz disk.
     
     You can run the SCSI Utilities in an easy-to-use menu mode
     or from the DOS command line.  To start the Utilities in
     menu mode, go to the DOS prompt for drive C: (the drive
     where your Iomega SCSI software is installed) and type:
     
                    cd \IOMEGA <Enter>
                    SCSIUTIL <Enter>
     
     If you need help running the Utilities, press <F1> anywhere
     in the Utilities.  Complete reference information on the
     Iomega SCSI Utilities is contained in the electronic "User's
     Reference Manual" (REFMAN.EXE).  (See Section 4 in this file
     for information on accessing the electronic manuals.)

     

     _________________________________________________________
     Section 6
     Cautions and Technical Notes

     
     ______________________________
     Section 6.1
     Microsoft Disk Copy Utilities
     
     CAUTION! 
     Do NOT use DISKCOPY.EXE or the Windows 95 right mouse
     CopyDisk utility with your Jaz drive.  These utilities were
     designed for use with floppy drives and do not work
     correctly with other removable drives.  Use an Iomega disk
     copying utility to copy disks (either Copy Machine or Iomega
     SCSI Disk Copy).


     ______________________________
     Section 6.2
     FDISK

     CAUTION! 
     Do not use FDISK on any removable disk.  FDISK is designed
     for partitioning fixed disks.  Partitioning any type of
     removable media can lead to unexpected results.


     ______________________________
     Section 6.3
     32-bit Access

     If you are using Windows 3.11 or Windows for Workgroups and
     want to use Copy Machine, make sure that 32-bit disk and
     file access is turned off. (This option is available when
     changing virtual memory options under "386 Enhanced" in the
     Windows Control Panel.)

     NOTE: Windows 3.1 does not support 32-bit access for
     removable disks drives. If 32-bit access is not turned off,
     the hard drive will NOT appear in the Copy Machine window.

     
     ______________________________
     Section 6.4
     Windows Format Utility

     If you are using Windows 3.1, do not use the format utility
     available in Windows File Manager to format Jaz disks.  Use
     an Iomega format utility (either Iomega SCSI Format or
     Format in Iomega Tools).

     
     ______________________________
     Section 6.5
     Microsoft Backup

     Microsoft Backup does not support removable disk drives
     other than floppy drives.  You can use Copy Machine to copy
     files on your hard disk to the Jaz drive, or you can use the
     Windows File Manager to drag-and-drop files you want to back
     up to Jaz disks.

     
     ______________________________
     Section 6.6
     Compression
     
     CAUTION! 
     If you are using a compression utility on a removable disk
     (for example, a Jaz disk), you should make that disk
     nonremovable (or lock the disk in the drive) whenever the
     compressed volume is mounted.  Removing a disk while the
     compressed volume is mounted could result in lost data.  To
     remove the disk, first unmount the compressed volume, then
     unlock the drive.  Refer to the electronic "User's Reference
     Manual" (REFMAN.EXE) for detailed information on locking and
     unlocking drives.
     
     CAUTION! 
     Do not use any disk compression software to compress
     removable boot disks.


     Iomega SCSI Utilities with Stacker 4.0
     
     When using Stacker 4.0 and Iomega SCSI, mounted, stacked
     drives will not appear on the graphical user interface
     screen for the Iomega SCSI Utilities.  In order to use an
     Iomega SCSI utility on a stacked drive, you must first
     unmount the drive.
     
          
     ______________________________
     Section 6.7
     Installing Applications to the Jaz Drive

     Certain applications and games will install only to a fixed
     disk.  To install these programs to the Jaz drive, use the
     Iomega Tools "Make Nonremovable" or "Lock" utility to make
     the Jaz drive appear as a hard drive to the system.  After
     the software installation is complete, use "Make Removable"
     or "Unlock" to restore disk removability.

     ______________________________
     Section 6.8
     Findit for Windows requires version 3.11.

     Findit will not work properly under Windows 3.0 & 3.1.
     During catalog of a drive the system may stop responding.
     The solution is to upgrade to Windows 3.11.


     _____________________________
     Section 7
     Setting up a Jaz Boot Disk

     
     _____________________________
     Section 7.1         
     System Requirements for Booting 
     You can boot your computer from a Jaz disk if your system 
     meets the following conditions:

         The computer does not have an IDE hard drive installed
          as drive C.  (You cannot boot from a SCSI drive if an
          IDE drive is set up as drive C on the system unless the
          IDE drive is disabled in the system CMOS.)

         The Jaz drive is connected to a bootable host adapter
          (ROM enabled).  Check the adapter documentation for
          information on necessary switch or jumper settings.

         You have a compatible version of DOS, Windows, or
          Windows 95.


     _____________________________
     Section 7.2
     Jaz Boot Drive Options
     You can use the Jaz drive as the primary (only) boot device 
     for the computer or as a secondary (backup) boot device:

         Using the Jaz drive as the primary (only) boot device: 
          This procedure assumes that the computer does not have 
          a C drive and currently boots from a floppy disk.

         Using the Jaz drive as a secondary (backup) boot
          device: This procedure assumes that the computer
          currently boots from a fixed SCSI hard drive.


     _____________________________
     Section 7.3
     Setting Up the Jaz Drive as the Primary Boot Device

     If the computer does not currently have a hard drive, you
     can set up the Jaz "tools" disk to boot the system.  Note
     that the procedure in this section assumes that the computer
     does not have a C drive and currently boots from a floppy
     disk.  If you have access to a computer that has a hard
     drive, it is recommended that you use that computer to set
     up your Jaz boot disk (see the procedure in Section 7.4.1
     for detailed instructions on setting up a Jaz boot disk);
     this will allow you to avoid having to use the "tools" disk
     as your boot disk.

      1.  Make sure your Jaz drive is connected to a bootable
          host adapter and that the ROM BIOS on the adapter is
          correctly enabled.  (See the adapter documentation for
          specific instructions.)

      2.  Set the SCSI ID on the Jaz drive to 0.  (Some bootable
          SCSI adapters will only assign drive letter C to the
          device at SCSI ID 0, and DOS permits booting only from
          drives A and C.)

      3.  Turn on your Jaz drive and boot the computer from a
          floppy disk.

      4.  After the computer boots (A:> will appear on the
          screen), remove the boot floppy and insert the
          Windows/DOS Install disk that came with your Jaz drive.

      5.  Type A:GUEST (or D:GUEST where D is your CD-ROM drive)
          and press Enter.  This will load the Guest driver to
          provide access to the Jaz drive.  (Guest should assign
          drive letter C: to the Jaz drive.)

      6.  Insert the Jaz "tools" disk into the Jaz drive and run
          RECLAIM.EXE from the DOSSTUFF directory on the "tools"
          disk.  The Reclaim utility sets the DOS format on the
          "tools" disk, reclaims the Mac-formatted portion of the
          disk for use by the PC, and unprotects the disk so you
          can install to it.

      7.  Remove the "Install" disk (if using a floppy install
          diskette) and reinsert your boot floppy.  Use the DOS
          SYS command to make the Jaz "tools" disk bootable.  To
          use the DOS SYS command, type A:SYS C: and press Enter. 
          (This will work only if your boot floppy contains a
          compatible version of MS-DOS.)

      8.  Remove the floppy boot disk and reboot the computer
          from the "tools" disk.

      9.  Install the operating system you plan to use (Windows
          95, DOS/Windows 3.1, or DOS only) to drive C: (the Jaz
          "tools" disk).

          IMPORTANT: Do NOT remove the "tools" disk from the
          drive until you have installed Iomega software as
          described in the next step.

     10.  Install the Iomega software package needed for your
          system as follows:

          Windows 95 Users:
          Run Setup from the W95STUFF directory on the "tools"
          disk to install Tools 95 software to the "tools" boot
          disk.  Note that Windows 95 will operate only in MS-DOS
          compatibility mode (Real mode) when the system is
          booted from a removable drive.  This is a Windows 95
          limitation for using a removable boot disk and is not
          affected by using Iomega Tools to make the Jaz disk
          nonremovable.

          DOS/Windows 3.1 Users:
          Run the INSTALL program from the DOSSTUFF directory on
          the "tools" disk and select the "tools" disk as the
          target for installation.  After completing the Iomega
          SCSI installation, load Windows and run SETUP.EXE from
          the W31STUFF directory on the "tools" disk to install
          Jaz Tools software for Windows.  Make sure the target
          of installation is the "tools" disk.  When the software
          installation is complete, open the AUTOEXEC.BAT file on
          the "tools" disk and add the following line:

                    C:\IOMEGA\SCSIUTIL Lock c:         

          This will make the Jaz boot disk appear as a fixed
          disk, which is preferred for running Windows 3.1 and
          required for installing and/or running some Windows 3.1
          applications.

          DOS Only Users: 
          Run the INSTALL program from the DOSSTUFF directory on
          the "tools" disk and select the "tools" disk as the
          target for installation.

     11.  Install any application programs you want to be able to
          run from the Jaz boot disk.

     12.  To boot the system after the computer has been turned
          off, turn on power to the Jaz drive and insert the
          "tools" boot disk; then turn on the computer.
     

     _____________________________
     Section 7.4
     Using the Jaz Drive as a Backup Boot Device

     If your computer is currently booting from a fixed SCSI hard
     drive, you can easily create a backup Jaz boot disk.  In
     case of some disaster to the primary boot drive, you can
     then boot from the Jaz disk and use it to restore the fixed
     SCSI disk.  The first procedure in this section describes
     how to create a bootable Jaz disk.  The second procedure
     describes how to set up the Jaz drive to boot the computer.


     _____________________________
     Section 7.4.1
     Creating a Jaz Backup Boot Disk

     This procedure assumes that the computer is currently
     booting from a SCSI hard drive and the operating system and
     appropriate Iomega software have already been installed on
     the primary boot drive. 

      1.  Prepare a blank Jaz disk using the Iomega Format tool
          with the "Copy System" option turned on.  This is the
          ideal way to place the basic system files on the disk.

          CAUTION!
          Do NOT format your Jaz "tools" disk as this will
          destroy your Iomega software installation files.

      2.  Install your current operating system (Windows 95,
          DOS/Windows 3.1, or DOS only) to the Jaz boot disk.

      3.  Back up your primary boot disk (C:) to the Jaz boot
          disk as follows:

          Windows 95 Users:
          RIGHT click on the Jaz drive icon in My Computer and
          select Copy Machine.  Use "Two Drive Copy" to copy C:
          to your Jaz drive.  Be sure to select "Don't Erase"
          files on the target disk before starting the copy.

          Windows 3.1 Users:
          Double click on the Copy Machine icon in your Iomega
          Jaz Tools group.  Use "Two Drive Copy" to copy C: to
          your Jaz drive.  Be sure to select "Don't Erase" files
          on the target disk before starting the copy.

          DOS Only Users:
          Use the Iomega SCSI Disk Copy Utility to copy all files
          on drive C: to the Jaz drive (D: in the following
          example).  Go to the DOS prompt for the IOMEGA
          directory on drive C: and run the command line:

                    SCSIUTIL Copy C: D: /A /V

          IMPORTANT: Use the drive letter for your Jaz drive in
          place of D: when using the Disk Copy command line.
          
          You can also run the Iomega SCSI Utilities in menu mode
          to carry out the copy.  Make sure you select the Append
          option before starting the copy.

     BACKUP NOTE for All Users:
     Repeat the appropriate procedure described in step 3
     regularly to keep your Jaz backup boot disk current.

     
     _____________________________
     Section 7.4.2
     Using the Jaz Boot Disk to Restore the Primary Boot Drive
     
     In case of disaster to your primary SCSI boot drive, use the 
     following procedure to boot the computer from your Jaz 
     backup boot disk and restore the fixed SCSI hard disk:

      1.  Make sure your Jaz drive is connected to a bootable
          host adapter and that the ROM BIOS on the adapter is
          correctly enabled.  (See the adapter documentation for
          specific instructions.)

          NOTE: If the fixed SCSI hard disk is connected to a
          different adapter than the Jaz drive, disable the ROM
          on the other adapter.

      2.  Set the SCSI ID on the Jaz drive to 0.  (Some bootable
          SCSI adapters will only assign drive letter C to the
          device at SCSI ID 0, and DOS permits booting only from
          drives A and C.)

          NOTE: If the fixed SCSI hard disk is connected to the
          same adapter as the Jaz drive, you must also change the
          SCSI ID on the fixed disk so that it is not 0.

      3.  Turn on power to the Jaz drive and insert the Jaz
          backup boot disk; then turn on the computer.

      4.  Reformat the fixed SCSI hard disk using your operating
          system's standard format procedure.  Be sure you select
          the option to copy the system files or make the disk
          bootable.

      5.  Restore files from your Jaz boot disk (C:) to the fixed
          SCSI hard disk as follows:

          Windows 95 Users:
          RIGHT click on the Jaz drive icon in My Computer and
          select Copy Machine.  Use "Two Drive Copy" to copy C:
          (your Jaz drive) to the fixed SCSI hard drive.  Be sure
          to select "Don't Erase" files on the target disk before
          starting the copy.

          Windows 3.1 Users:
          Double click on the Copy Machine icon in your Iomega
          Jaz Tools group.  Use "Two Drive Copy" to copy C: (your
          Jaz drive) to the fixed SCSI hard drive.  Be sure to
          select "Don't Erase" files on the target disk before
          starting the copy.

          DOS Only Users:
          Use the Iomega SCSI Disk Copy Utility to copy all files
          on drive C: (the Jaz drive) to the fixed SCSI hard
          drive (D: in the following example).  Go to the DOS
          prompt for the IOMEGA directory on drive C: and run the
          command line:

                    SCSIUTIL Copy C: D: /A /V

          IMPORTANT: Use the drive letter for your fixed SCSI
          hard drive in place of D: when using the Disk Copy
          command line.
          
          You can also run the Iomega SCSI Utilities in menu mode
          to carry out the copy.  Make sure you select the Append
          option before starting the copy.

      6.  Shut down the system and turn off power to the
          computer.  Restore your adapter ROM settings and disk
          drive SCSI ID settings to the configuration needed to
          boot from the fixed SCSI hard disk.
