
             NetWare Lite v1.1 Utility for Windows (11/10/92)

If you use Windows 3.1 in Standard mode, load TBMI2.COM after loading
SERVER.EXE and CLIENT.EXE. Modify your STARTNET.BAT so TBMI2.COM loads
after SERVER.EXE and CLIENT.EXE. This is different from the instructions in
NetWare Lite v1.1 documentation.

If you load TBMI2.COM before SERVER.EXE and CLIENT.EXE, you may experience
print corruption problems when running Windows 3.1 in Standard mode.

If you use Windows 3.0 in Standard mode, load TBMI.COM after loading
SERVER.EXE and CLIENT.EXE. Modify your STARTNET.BAT so that TBMI.COM loads
after SERVER.EXE and CLIENT.EXE.

If you get "FILE OPEN ERROR" when setting up the "NetWare Lite v1.1 Utility
for Windows," make sure that TASKID.COM, TBMI.COM, TBMI2.COM, and VIPX.386
are in your NWLITE directory. If the files have been removed from your
NWLITE directory, install NetWare Lite v1.1 again (the files will be
installed in the NWLITE directory), then run the NetWare Lite v1.1 Utility
for Windows SETUP.

The "Message" window "Use Time Out" option doesn't work when you are in
Windows. However, it does work when you are in DOS. When you receive a
message while in Windows, the "Message" window remains on your screen until
you remove it. The message won't automatically clear after the time
specified in the "Message Time Out" field has elapsed.

If the SETUP program is run more than once on a computer, the message to
exit and restart Windows may not appear. After running SETUP, exit and
restart Windows to ensure that all the drivers are loaded.

The network printer "Add Users with Non-default Rights" dialog help button
displays the "[Network Directory, Add] Non-default User Access Rights
Help." Use the online manual's "Add a User to the Network Printer's Non-
default User Access Rights List" and "Non-default Access Rights" entries to
display the online information.

The network printer "Non-default Access Rights:USER" dialog help button
displays the "[Network directory] Non-default Access Rights:USER Help." Use
the online manual's "View or Change a Network Printer's Non-default User
Access Rights List" and "Non-default Access Rights: USER" entries to
display the information.

The network printer "Create Setup String" dialog help button displays the
"Setup String: STRING_NAME Help." Use the online manual's "Change a Network
Printer's Setup," "Information: NETWORK_PRINTER," Setup Strings for
NETWORK_PRINTER on SERVER," and "Create Setup Strings" entries to display
the information.

The "Print Job Flags" dialog help button displays the "Connection
Information: LPT# Help." Use the online manual's "Modify a Print Job Sent
to a Network Printer" and "Print Job Flags" entries to display the
information.