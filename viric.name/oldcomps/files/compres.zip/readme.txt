BOA Constrictor Archiver v0.58b
-------------------------------

Copyright (c) 1997, 1998 Ian Sutton.  All Rights Reserved - so don't mess
with it baby!



License
-------

   1. This program is distributed without any warranty - without even
   the implied warranty of merchantability or fitness for a particular
   purpose.  In other words, I am not liable for any damage that occurs
   through the use or misuse of this program.  You use it at your own
   risk.

   2. You may freely distribute this program provided that: a) all files
   are distributed, and b) no charge is made.

   If you disagree with the above please delete BOA.



System Requirements
-------------------

   BOA requires a 386 computer or better, with 8Mb for the default
   compression mode, and 2Mb for the minimum mode.



Command line usage
------------------

   Usage: boa [command] [options] arcname.boa [files...]

 Commands

   -a	      Add files to a a new archive, or an existing one (FLEXIBLE
	      only).  This is the default command and may be omitted.

   -x	      Extract files with pathnames.

   -e	      Extract files without pathnames.

   -v	      View archive contents.

   -d	      Delete files from archive.  FLEXIBLE archives only.

   -t	      Perform integrity testing on files.  This will check the
	      archive for CRC errors.  If an error is found, it means that
	      the archive is corrupt.  There is currently no way to repair
	      a broken archive.



   If you are adding files (-a), then you have additional options.

   -s	      Use SOLID archiving.  This option takes advantage of
	      redundancy across files.	Compression ratios can be very
	      much improved, especially when compressing many similar
	      small files.

   -r	      Recurse into subdirectories.  This option will make BOA
	      also look through directories in the specified paths for
	      files to add.

   -p<0,r,s>  Store no paths, recursed paths (see previous option), or
	      both specified and recursed paths.

   -m<x>      Use 'x' megabytes of extended memory.  More memory means
	      better compression in most cases, but be aware that the
	      same amount of memory will be needed on decompresssion.

   -X<file>   Exclude specified file.

   -S	      Include hidden/system files.



Miscellaneous
-------------

   Ctrl-Break quits the program at any stage.

   The default extension for archives is ".b58".  This is to
   avoid confusion with future versions which will be incompatible.
   When v1.00 is released, all versions from that date will be backwards
   compatible and the extension will be "boa".



The Future
----------

   Work on this program is ongoing.  Future additions should include:

   * better compression in some cases - I'm not really happy with the
     way some binary files are compressed.
   * multimedia compression - I will deep six the custom compression modes
     (currently on WAV, BMP, 669 files) in favour of an adaptive method.
   * a superfast compression mode
   * support for file attributes
   * no more flexible/solid modes - all archives will be solid with
     variable blocksizes.  Don't worry, they will be updateable!
   * other stuff...

   It will be available... soon.  Please don't bug me about finishing it!



Acknowledgements
----------------

   Thanks to:

   Malcolm Taylor (author of RKIVE) - for interesting discussions.

   Szymon Grabowski - for multimedia coding ideas.

   Charles Bloom (author of PPMZ) - which provided a few ideas.

   Mark Nelson - for articles which got me hooked on compression.

   Jeff Gilchrist (Archive Comparison Test) - for putting up with everybody
   mailing him about this program while it was unavailable.

   Everybody who mailed me - for encouragement.


Contact info
------------

   Send comments to:

   isutton@idirect.com

   4/2/98
   Ian Sutton

