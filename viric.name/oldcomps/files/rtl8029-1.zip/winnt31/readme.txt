About the winnt31.exe
=====================

Usage:

      Execute winnt31.exe,which is a self-extractor file,to get the NT3.1's
drivers including the following three files ep325.sys, ndis.sys and
oemsetup.inf .
