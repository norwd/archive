About the nw311.exe
===================

Usage:

      Execute nw311.exe,which is a self-extractor file,to get the NetWare 3.11
drivers including the following six files.

     File Name       File Size (Bytes)
     ---------------------------------
     MSM31X.NLM           21,303
     LSLENH.NLM           11,641
     MONITOR.NLM         117,775
     PATCHMAN.NLM          9,632
     ETHERTSM.NLM          9,246
     EP325.LAN             8,271
     ---------------------------------
