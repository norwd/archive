package jdict;

import javax.microedition.lcdui.*;

public class ShowText
	implements CommandListener
{
	private Form myform;
	private Command cmd_malantauxen;
	
	private Form last;

	private String text;


	public ShowText(String _text, Form _last)
	{
		text = _text;
		last = _last;
		show();
	}

	public void show()
	{
		myform = new Form(T.t("Informo"));

        StringItem sitem = new StringItem(null, text);
        myform.append(sitem);

		/* Commands */
		cmd_malantauxen = new Command("Malantaŭen", Command.BACK, 0);
		myform.addCommand(cmd_malantauxen);
		myform.setCommandListener(this);
		Main.display.setCurrent(myform);
	}

	public void commandAction(Command c, Displayable d)
	{
		if (c == cmd_malantauxen)
		{
            Main.display.setCurrent(last);
		}
	}
}
