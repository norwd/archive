package jdict;

import javax.microedition.lcdui.*;
import java.io.*;
import java.util.Enumeration;

public class Config
	implements CommandListener
{
	private Form myform;
	private Command cmd_konservi;
	private Command cmd_malantauxen;
	private ChoiceGroup lingvoj;
    private Form last;
    private AskWord from_screen;



    public Config(AskWord _from_screen, Form _last)
    {
        last = _last;
        from_screen = _from_screen;
        show();
    }

    public void show()
    {
		myform = new Form(T.t("Agordoj"));

        lingvoj = new ChoiceGroup(T.t("Lingvo"), ChoiceGroup.EXCLUSIVE);

        String chosen_lang = T.get_chosen_language();
        for (Enumeration e = T.get_languages(); e.hasMoreElements(); )
        {
            String lingvo = (String) e.nextElement();
            int index;
            
            index = lingvoj.append(lingvo, null);
            if (lingvo.equals(chosen_lang))
                lingvoj.setSelectedIndex(index, true);
        }
        myform.append(lingvoj);

		cmd_konservi = new Command(T.t("Konservi"), Command.OK, 0);
		myform.addCommand(cmd_konservi);
		/* Commands */
		cmd_malantauxen = new Command(T.t("Malantaŭen"), Command.BACK, 4);
		myform.addCommand(cmd_malantauxen);

		myform.setCommandListener(this);
		Main.display.setCurrent(myform);
    }

	public void commandAction(Command c, Displayable d)
	{
        if (c == cmd_konservi)
        {
            T.set_language(lingvoj.getString(lingvoj.getSelectedIndex()));
            from_screen.show();
        }
        else if (c == cmd_malantauxen)
        {
            Main.display.setCurrent(last);
        }
	}
}
