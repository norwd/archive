package jdict;

import javax.microedition.lcdui.*;
import java.util.Vector;

public class SearchThread extends Thread
{
    private Displayable _last;
    private String _vortaro;
    private String _word;
    DictIndex _index;

    public SearchThread(String word, String vortaro,
            DictIndex index, Displayable last)
    {
        _word = word;
        _vortaro = vortaro;
        _last = last;
        _index = index;
    }

    public void run()
    {
        System.out.println("SearchThread serĉante: " + _word);

        Vector results;
        /* Search the word */
        results = _index.BinarySearchDefinition(_word);

        ResultList resultslist = new ResultList(results, _vortaro, _last);
    }
}
