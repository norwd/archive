package jdict;


public class Vorto
{
    int _pos;
    int _length;
    String _vorto;

    public Vorto(String vorto, int pos, int length)
    {
        _pos = pos;
        _vorto = vorto;
        _length = length;
    }

    public int getLength()
    {
        return _length;
    }

    public int getPos()
    {
        return _pos;
    }

    public String getString()
    {
        return _vorto;
    }
}
