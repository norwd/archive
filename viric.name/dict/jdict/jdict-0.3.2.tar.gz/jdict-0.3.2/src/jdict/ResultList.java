package jdict;

import javax.microedition.lcdui.*;
import java.util.Vector;

public class ResultList
	implements CommandListener
{
	private List mylist;
	private Command cmd_malantauxen;
    Vector _list;
    private Displayable _last;
    private DictDefs defs;

    public ResultList(Vector list, String vortarnomo, Displayable last)
    {
        _list = list;
        _last = last;

        defs = new DictDefs(vortarnomo);
        show();
    }

	public void show()
	{
		mylist = new List(T.t("Rezultoj") + ": " +
                new Integer(_list.size()).toString(), List.IMPLICIT);

		/* Commands */
		cmd_malantauxen = new Command(T.t("Malantaŭen"), Command.BACK, 0);
		mylist.addCommand(cmd_malantauxen);

        for(int i = 0; i < _list.size(); ++i)
        {
            Vorto v = (Vorto) _list.elementAt(i);

            mylist.append(v.getString(), null);
        }

        /*
        StringItem item = new StringItem(T.t("Entute:"),
                new Integer(myresults.size()).toString());
        mylist.append(item);
        */

		mylist.setCommandListener(this);
		Main.display.setCurrent(mylist);
	}

	public void commandAction(Command c, Displayable d)
	{
        if (c == cmd_malantauxen)
        {
            Main.display.setCurrent(_last);
        } else if (c == List.SELECT_COMMAND)
        {
            Vorto v = (Vorto) _list.elementAt(mylist.getSelectedIndex());
            String def = defs.getDefinition(v.getPos(), v.getLength());
            Result r = new Result(v.getString(), def, mylist);
        }
	}
}
