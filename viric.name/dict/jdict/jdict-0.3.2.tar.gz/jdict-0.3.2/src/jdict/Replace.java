package jdict;

public class Replace
{
	public static String replace_sub(String original, String from, String to)
	{
        String result = "";
        int lastcopy = 0;
        int index = 0;
        int change;

        while ( (change = original.indexOf(from, index)) != -1)
        {
            String part = original.substring(lastcopy, change);
            result += part + to;
            lastcopy = change + from.length();
            index = lastcopy;
        }

        result += original.substring(lastcopy, original.length());
        return result;
	}

    public static String IksojAlCxapeloj(String original)
    {
        String result = original;
        result = replace_sub(result, "cx", "ĉ");
        result = replace_sub(result, "gx", "ĝ");
        result = replace_sub(result, "hx", "ĥ");
        result = replace_sub(result, "jx", "ĵ");
        result = replace_sub(result, "sx", "ŝ");
        result = replace_sub(result, "ux", "ŭ");
        result = replace_sub(result, "Cx", "Ĉ");
        result = replace_sub(result, "Gx", "Ĝ");
        result = replace_sub(result, "Hx", "Ĥ");
        result = replace_sub(result, "Jx", "Ĵ");
        result = replace_sub(result, "Sx", "Ŝ");
        result = replace_sub(result, "Ux", "Ŭ");
        return result;
    }

    public static String AsciiAlRusa(String original)
    {
        String result = original;

        result = replace_sub(result, "ju", "ю");
        result = replace_sub(result, "ja", "я");
        result = replace_sub(result, "jo", "ё");
        result = replace_sub(result, "wq", "щ");

        result = replace_sub(result, "a", "а");
        result = replace_sub(result, "b", "б");
        result = replace_sub(result, "v", "в");
        result = replace_sub(result, "g", "г");
        result = replace_sub(result, "d", "д");
        result = replace_sub(result, "e", "е");
        result = replace_sub(result, "x", "ж");
        result = replace_sub(result, "z", "з");
        result = replace_sub(result, "i", "и");
        result = replace_sub(result, "j", "й");
        result = replace_sub(result, "k", "к");
        result = replace_sub(result, "l", "л");
        result = replace_sub(result, "m", "м");
        result = replace_sub(result, "n", "н");
        result = replace_sub(result, "o", "о");
        result = replace_sub(result, "p", "п");
        result = replace_sub(result, "r", "р");
        result = replace_sub(result, "s", "с");
        result = replace_sub(result, "t", "т");
        result = replace_sub(result, "u", "у");
        result = replace_sub(result, "f", "ф");
        result = replace_sub(result, "h", "х");
        result = replace_sub(result, "c", "ц");
        result = replace_sub(result, "q", "q");
        result = replace_sub(result, "w", "ш");
        result = replace_sub(result, "\"", "ъ");
        result = replace_sub(result, "y", "ы");
        result = replace_sub(result, "'", "ь");
        result = replace_sub(result, "/e", "э");

        return result;
    }
}
