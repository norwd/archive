package jdict;

import javax.microedition.lcdui.*;

public class Result
	implements CommandListener
{
	private Displayable _last;
	private Form myform;
	private String _title;
	private String _text;
	private Command cmd_malantauxen;

	
	public Result(String title, String text, Displayable last )
	{
        _title = title;
        _last = last;
        _text = text;
		show();
	}

	public void show()
	{
		myform = new Form(_title);

		/* Commands */
		cmd_malantauxen = new Command(T.t("Malantaŭen"), Command.BACK, 0);
		myform.addCommand(cmd_malantauxen);

        StringItem item = new StringItem(null, _text);
        myform.append(item);

        /*
        StringItem item = new StringItem(T.t("Entute:"),
                new Integer(myresults.size()).toString());
        myform.append(item);
        */

		myform.setCommandListener(this);
		Main.display.setCurrent(myform);
	}

	public void commandAction(Command c, Displayable d)
	{
        if (c == cmd_malantauxen)
        {
            Main.display.setCurrent(_last);
        }
	}
}
