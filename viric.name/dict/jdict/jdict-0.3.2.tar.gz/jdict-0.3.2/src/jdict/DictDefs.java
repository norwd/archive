package jdict;

import java.io.*;
import java.util.Vector;

public class DictDefs
{
    BlockFile defs;

    String defs_basename;

    public DictDefs(String dictname)
    {
        defs_basename = "/dicts/x-" + dictname + ".dict";
        defs = new BlockFile(defs_basename);
    }

    public String getDefinition(int offset, int length)
    {
        byte text[] = new byte[length];

        try {
            defs.seekFromStart(offset);
            defs.read(text, 0, length);
        } catch (IOException e)
        {
            return null;
        }

        System.out.println("Definition: " + new String(text));

        String result;
        try {
            result = new String(text, 0, text.length, "UTF-8");
        } catch (UnsupportedEncodingException e)
        {
            System.out.println("Unsupported encoding.");
            return null;
        }

        return result;
    }
}
