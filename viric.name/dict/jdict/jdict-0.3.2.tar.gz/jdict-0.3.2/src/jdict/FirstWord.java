package jdict;

public class FirstWord
{
    int _pos;
    String _vorto;

    public FirstWord(String vorto, int pos)
    {
        _pos = pos;
        _vorto = vorto;
    }

    public int getPos()
    {
        return _pos;
    }

    public String getString()
    {
        return _vorto;
    }
}

