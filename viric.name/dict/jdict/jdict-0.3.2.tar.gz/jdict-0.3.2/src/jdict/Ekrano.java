package jdict;

public interface Ekrano
{
	public void show();
}
