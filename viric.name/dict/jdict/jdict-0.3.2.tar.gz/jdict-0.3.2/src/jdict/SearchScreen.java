package jdict;

import javax.microedition.lcdui.*;

public class SearchScreen
{
    public String _vorto;
    public SearchScreen(String vorto)
    {
        _vorto = vorto;
        show();
    }

    public void show()
    {
        Form myform = new Form(T.t("Serĉante..."));

        StringItem item = new StringItem(T.t("Vorto:"), _vorto);
        myform.append(item);

		Main.display.setCurrent(myform);
    }
}
