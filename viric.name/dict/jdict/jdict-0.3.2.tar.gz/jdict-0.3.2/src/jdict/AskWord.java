package jdict;

import javax.microedition.lcdui.*;
import java.util.Vector;
import java.io.*;

public class AskWord
	implements CommandListener
{
	private Form myform;
	private Command cmd_eliri;
	private Command cmd_sercxi;
	private Command cmd_montri;
	private Command cmd_pri;
	private Command cmd_vortarinformo;
	private Command cmd_agordoj;
    private TextField word;
    private ChoiceGroup translit;
    private String translit_neniu;
    private String translit_iksa;
    private String translit_rusa;
    private StringItem showSearch;
    private String vortaro;
    private DictIndex index;
	
	public AskWord()
	{
        get_vortaro();

        index = new DictIndex(vortaro);

		show();
	}

	public void get_vortaro()
    {
        InputStream vfile = getClass().getResourceAsStream("/dicts/VORTARO");
        if (vfile == null)
        {
            vortaro = "ERROR";
            return;
        }
        /* 50 bytes maximum for vortaro nomo */
        byte array[] = new byte[50];
        int total;
        try {
            total = vfile.read(array, 0, 50);
        } catch (IOException e)
        {
            System.out.println("Cannot open VORTARO file. Going to ERROR B.");
            vortaro = "ERROR";
            return;
        }
        /* This will have '\n' */
        vortaro = new String(array, 0, total - 1 /* - \n */);
    }

	public void show()
	{
        translit_neniu = T.t("Neniu");
        translit_iksa = T.t("Iksa sistemo");
        translit_rusa = T.t("ASCII-rusa");

		myform = new Form(vortaro);

        word = new TextField(T.t("Vorto:"), "", 20, TextField.ANY);
        myform.append(word);

        translit = new ChoiceGroup(T.t("Transliterigo"), ChoiceGroup.EXCLUSIVE);

        String tselected = Mem.getVariable("Transliterigo");
        int lindex;
        lindex = translit.append(translit_neniu, null);
        if (tselected != null && tselected.equals(translit_neniu))
            translit.setSelectedIndex(lindex, true);
        lindex = translit.append(translit_iksa, null);
        if (tselected != null && tselected.equals(translit_iksa))
            translit.setSelectedIndex(lindex, true);
        translit.append(translit_rusa, null);
        if (tselected != null && tselected.equals(translit_rusa))
            translit.setSelectedIndex(lindex, true);
        if (tselected == null)
            translit.setSelectedIndex(0, true);
        myform.append(translit);

        /* DEBUG */
        showSearch = new StringItem(T.t("Serĉonte:"), "");
        myform.append(showSearch);

		cmd_sercxi = new Command(T.t("Serĉi"), Command.OK, 0);
		myform.addCommand(cmd_sercxi);
		/* Commands */
		cmd_montri = new Command(T.t("Montri"), Command.HELP, 1);
		myform.addCommand(cmd_montri);
		/* Commands */
		cmd_pri = new Command(T.t("Pri ĉi tio"), Command.HELP, 2);
		myform.addCommand(cmd_pri);
		/* Commands */
		cmd_vortarinformo = new Command(T.t("Vortarinformo"), Command.HELP, 3);
		myform.addCommand(cmd_vortarinformo);
		/* Commands */
		cmd_agordoj = new Command(T.t("Agordoj"), Command.HELP, 3);
		myform.addCommand(cmd_agordoj);
		/* Commands */
		cmd_eliri = new Command(T.t("Eliri"), Command.BACK, 4);
		myform.addCommand(cmd_eliri);

		myform.setCommandListener(this);
		Main.display.setCurrent(myform);
	}

    private String transliterate(String from)
    {
        String out = from;
        if (translit.getString(translit.getSelectedIndex())
                .equals(translit_iksa))
            out = Replace.IksojAlCxapeloj(from);
        else if (translit.getString(translit.getSelectedIndex())
                .equals(translit_rusa))
            out = Replace.AsciiAlRusa(from);

        return out;
    }

	public void commandAction(Command c, Displayable d)
	{
        if (c == cmd_sercxi)
        {
            String toSearch = word.getString();
            toSearch = transliterate(toSearch);

            showSearch.setText(toSearch);
            SearchThread t = new SearchThread(toSearch, vortaro, index, myform);

            SearchScreen s = new SearchScreen(toSearch);
            t.start();
        }
        else if (c == cmd_eliri)
        {
            String tselected = translit.getString(translit.getSelectedIndex());
            Mem.setVariable("Transliterigo", tselected);
            Main.main.quit();
        }
        else if (c == cmd_montri)
        {
            String toSearch = word.getString();
            toSearch = transliterate(toSearch);

            showSearch.setText(toSearch);
        }
        else if (c == cmd_pri)
        {
            ShowText text = new ShowText(
                    /* Versio */
                    "JDict v0.3.2 - Vortara programo laŭ stilo dictd " +
                    "(http://www.dict.org)\n" +
                    "Kopirajto (C) 2007 Lluís Batlle i Rossell\n" +
                    "Tiun ĉi programon mi distribuas laŭ permesilo " +
                    "GPL versio 2 aŭ posta. Vidu la fontokodon por " +
                    "pliaj detaloj.\n" +
                    "Plia informo, pluaj elŝutoj: " +
                    "http://vicerveza.homeunix.net/~viric/dict/jdict"
                    , myform);
        }
        else if (c == cmd_vortarinformo)
        {
            Vector results;
            String text = "";
            DictDefs defs = new DictDefs(vortaro);

            /* Already at start */
            results = index.BinarySearchDefinition("00databaseinfo");
            if (results.size() > 0)
            {
                Vorto w = (Vorto) results.elementAt(0);
                String def = defs.getDefinition(w.getPos(), w.getLength());
                text += "Database Info:\n" + def + "\n";
            }

            results = index.BinarySearchDefinition("00databaseshort");
            if (results.size() > 0)
            {
                Vorto w = (Vorto) results.elementAt(0);
                String def = defs.getDefinition(w.getPos(), w.getLength());
                text += "Database Short:\n" + def + "\n";
            }

            results = index.BinarySearchDefinition("00databaseurl");
            if (results.size() > 0)
            {
                Vorto w = (Vorto) results.elementAt(0);
                String def = defs.getDefinition(w.getPos(), w.getLength());
                text += "Database URL:\n" + def + "\n";
            }

            ShowText textwin = new ShowText(text, myform);
        }
        else if (c == cmd_agordoj)
        {
            /* This opens a new form */
            Config config = new Config(this, myform);
        }
	}
}
