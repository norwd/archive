package jdict;

import java.io.*;
import javax.microedition.rms.*;
import javax.microedition.lcdui.*;
import javax.microedition.midlet.MIDlet;

public class Main
	extends MIDlet
{
	/* Maximum 128 */
	public static Display display;
    private AskWord askword;
	public static Main main;

	public Main() {
		display = Display.getDisplay(this);

        main = this;
	}
    static public void showMem()
    {
        Runtime r = Runtime.getRuntime();
        long freemem = r.freeMemory();

        System.out.println("Free Memory: " + new Long(freemem).toString());
    }

    protected void loadSettings()
    {
        String val = Mem.getVariable("Lingvo");
        if (val != null)
            T.set_language(val);
    }

    protected void saveSettings()
    {
        String old =  Mem.getVariable("Lingvo");
        String language = T.get_chosen_language();

        if (old == null || ! language.equals(old))
        {
            Mem.setVariable("Lingvo", language);
        }
    }

	protected void startApp()
	{
        T.init();
        loadSettings();
        askword = new AskWord();
	}

	protected void destroyApp(boolean c)
	{
		askword = null;
	}

	protected void pauseApp()
	{
	}

	public void quit()
	{
        saveSettings();
		destroyApp(true);
		notifyDestroyed();
	}
}
