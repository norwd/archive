package jdict;

import java.io.*;
import javax.microedition.rms.*;

public class Mem
{
    public static String getVariable(String var)
    {
        RecordStore r;
        byte tmp[];
        try {
            r = RecordStore.openRecordStore(var, false);
            tmp = r.getRecord(1);
            r.closeRecordStore();
        } catch (Exception e)
        {
            System.out.println("loadSettings() Recordstore Exception: " + e.toString());
            return null;
        }

        String out;
        try {
            out = new String(tmp, 0, tmp.length, "utf-8");
        } catch (UnsupportedEncodingException e)
        {
            return null;
        }
        return out;
    }

    public static void setVariable(String var, String val)
    {
        RecordStore r;
        try {
            r = RecordStore.openRecordStore(var, true);
        } catch (Exception e)
        {
            System.out.println("saveSettings() Recordstore Exception: " + e.toString());
            return;
        }

        byte tmp[];

        try {
            tmp = val.getBytes("utf-8");
        } catch (Exception e)
        {
            System.out.println("Recordstore/Encoding Exception: " + e.toString());
            return;
        }

        try {
            r.setRecord(1, tmp, 0, tmp.length);
            r.closeRecordStore();
        } catch (Exception e)
        {
            try {
                r.addRecord(tmp, 0, tmp.length);
                r.closeRecordStore();
            } catch (Exception f)
            {
                System.out.println("Recordstore addRecord Exception: " + f.toString());
            }
        }
    }
}
