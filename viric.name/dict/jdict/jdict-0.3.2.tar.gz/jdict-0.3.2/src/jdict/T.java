package jdict;

import java.util.Hashtable;
import java.util.Enumeration;

public class T
{
    static Hashtable languages;
    static Hashtable chosen_language;
    static String chosen_language_name;

    public static void init()
    {
        languages = new Hashtable();

        /* Eo */
        Hashtable eo = new Hashtable();
        languages.put("eo", eo);
        eo.put("Vorto:", "Vorto:");
        eo.put("Transliterigo", "Transliterigo");
        eo.put("Neniu", "Neniu");
        eo.put("Iksa sistemo", "Iksa sistemo");
        eo.put("ASCII-rusa", "ASCII-rusa");
        eo.put("Serĉonte:", "Serĉonte:");
        eo.put("Serĉi", "Serĉi");
        eo.put("Montri", "Montri");
        eo.put("Pri ĉi tio", "Pri ĉi tio");
        eo.put("Vortarinformo", "Vortarinformo");
        eo.put("Eliri", "Eliri");
        eo.put("Lingvo", "Lingvo");
        eo.put("Rezultoj", "Rezultoj");
        eo.put("Rezulto:", "Rezulto:");
        eo.put("Entute:", "Entute:");
        eo.put("Malantaŭen", "Malantaŭen");
        eo.put("Agordoj", "Agordoj");
        eo.put("Informo", "Informo");
        eo.put("Konservi", "Konservi");
        eo.put("Serĉante...", "Serĉante...");
        /* Eo iksa */
        Hashtable eox = new Hashtable();
        languages.put("eox", eox);
        eox.put("Vorto:", "Vorto:");
        eox.put("Transliterigo", "Transliterigo");
        eox.put("Neniu", "Neniu");
        eox.put("Iksa sistemo", "Iksa sistemo");
        eox.put("ASCII-rusa", "ASCII-rusa");
        eox.put("Serĉonte:", "Sercxonte:");
        eox.put("Serĉi", "Sercxi");
        eox.put("Montri", "Montri");
        eox.put("Pri ĉi tio", "Pri cxi tio");
        eox.put("Vortarinformo", "Vortarinformo");
        eox.put("Eliri", "Eliri");
        eox.put("Lingvo", "Lingvo");
        eox.put("Rezultoj", "Rezultoj");
        eox.put("Rezulto:", "Rezulto:");
        eox.put("Entute:", "Entute:");
        eox.put("Malantaŭen", "Malantauxen");
        eox.put("Agordoj", "Agordoj");
        eox.put("Informo", "Informo");
        eox.put("Konservi", "Konservi");
        eox.put("Serĉante...", "Sercxante...");
        /* Ca */
        Hashtable ca = new Hashtable();
        languages.put("ca", ca);
        ca.put("Vorto:", "Paraula:");
        ca.put("Transliterigo", "Transliteració");
        ca.put("Neniu", "Cap");
        ca.put("Iksa sistemo", "Sistema X");
        ca.put("ASCII-rusa", "ASCII-Rus");
        ca.put("Serĉonte:", "Es cercarà:");
        ca.put("Serĉi", "Cercar");
        ca.put("Montri", "Mostrar");
        ca.put("Pri ĉi tio", "Sobre això");
        ca.put("Vortarinformo", "Sobre el diccionari");
        ca.put("Eliri", "Sortir");
        ca.put("Lingvo", "Idioma");
        ca.put("Rezultoj", "Resultats");
        ca.put("Rezulto:", "Resultat:");
        ca.put("Entute:", "Total:");
        ca.put("Malantaŭen", "Enrera");
        ca.put("Agordoj", "Configuració");
        ca.put("Informo", "Informació");
        ca.put("Konservi", "Guardar");
        ca.put("Serĉante...", "Cercant...");
        /* Ru */
        Hashtable ru = new Hashtable();
        languages.put("ru", ru);
        ru.put("Vorto:", "Слово:");
        ru.put("Transliterigo", "Транслитерация");
        ru.put("Neniu", "Никакой");
        ru.put("Iksa sistemo", "X-система");
        ru.put("ASCII-rusa", "ASCII-Русский");
        ru.put("Serĉonte:", "Поиск:");
        ru.put("Serĉi", "Искать");
        ru.put("Montri", "Показать");
        ru.put("Pri ĉi tio", "О программе");
        ru.put("Vortarinformo", "О словаре");
        ru.put("Eliri", "Выйти");
        ru.put("Lingvo", "Язык");
        ru.put("Rezultoj", "Результаты");
        ru.put("Rezulto:", "Результат:");
        ru.put("Entute:", "Всего:");
        ru.put("Malantaŭen", "Назад");
        ru.put("Agordoj", "Настойки");
        ru.put("Informo", "Информация");
        ru.put("Konservi", "Сохранить");
        ru.put("Serĉante...", "Ищу...");

        /* default */
        set_language("eo");
    }

    public static void set_language(String name)
    {
        System.out.println("Choosing language: " + name);
        chosen_language = (Hashtable) languages.get(name);
        if (chosen_language == null)
            System.out.println("Language " + name + " not found.");
        chosen_language_name = name;
    }

    public static String t(String from)
    {
        String out;

        if (chosen_language == null)
        {
            System.out.println("Language not chosen for string " + from);
            return from;
        }
        
        out = (String) chosen_language.get(from);
        if (out == null)
        {
            System.out.println("Language string not found for " + from);
            return from;
        }
        /* System.out.println("Asked string '" + from + "', giving '" + out + "'");*/
        return out;
    }

    public static Enumeration get_languages()
    {
        return languages.keys();
    }

    public static String get_chosen_language()
    {
        return chosen_language_name;
    }
}
