import os.path
import glob
import pygame
import random
import exceptions

class ExitToSelect(exceptions.Exception):
        def __init__(self):
                return
class Win(exceptions.Exception):
        def __init__(self):
                return
            
TIMEREVENT = pygame.USEREVENT + 1
DOUBLE_SIZE = True
FPS = 20

LEV_WIDTH = 18
LEV_HEIGHT = 12

def _load_graphic(graphic):
    return pygame.image.load(os.path.join("graphics",
                                          graphic))
def load_graphic_1x(graphic):
    return pygame.Surface.convert_alpha(_load_graphic(graphic))

def load_graphic_2x(graphic):
    gr = _load_graphic(graphic)
    return pygame.Surface.convert_alpha(pygame.transform.scale(gr,
                                                               (gr.get_width() * 2,
                                                                gr.get_height() * 2)))

def load_graphic_full(graphic):
    return pygame.Surface.convert_alpha(pygame.transform.scale(_load_graphic(graphic), (SCREEN_WIDTH,SCREEN_HEIGHT)))

def fit_on_screen(s):
    return pygame.Surface.convert(pygame.transform.scale(s, (SCREEN_WIDTH,SCREEN_HEIGHT)))

GLOBAL_OFF_Y = 64
CELL_SIZE = 64
SCREEN_WIDTH = 1200
SCREEN_HEIGHT = 825
ZEBRA_HEIGHT = 86
EDITOR_X = 100
EDITOR_Y = 100
SENSE_LEFT_OFF = 96
OBJECT_LEFT_OFF = 184
ACTION_LEFT_OFF = 425
PROG_TOP_OFF = 30
OTHER_TOP_OFF = 305
ARROW_LEFT = 12
ARROW_WIDTH = 46
ARROW_HEIGHT = 50
ARROW_VSPACE = 190
ZEBRA_X = 74
ZEBRA_Y = 17
SCREENSHOT_WIDTH = 384
SCREENSHOT_HEIGHT = 213
SCREENSHOT_X = 386
SCREENSHOT_Y = 103
HORIZ_ARROW_TOP = 188
LEFT_ARROW_X = 285
RIGHT_ARROW_X = 822
BACKGROUND_NAMES = [ "savannah", "winter", "beach" ]

if DOUBLE_SIZE:
    load_graphic = load_graphic_2x
else:
    load_graphic = load_graphic_1x
    GLOBALL_OFF_Y /= 2
    CELL_SIZE /= 2
    SCREEN_WIDTH /= 2
    SCREEN_HEIGHT /= 2
    ZEBRA_HEIGHT /= 2
    EDITOR_X /= 2
    EDITOR_Y /= 2
    SENSE_LEFT_OFF /= 2
    OBJECT_LEFT_OFF /= 2
    ACTION_LEFT_OFF /= 2
    PROG_TOP_OFF /= 2
    OTHER_TOP_OFF /= 2
    ARROW_LEFT /= 2
    ARROW_WIDTH /= 2
    ARROW_HEIGHT /= 2
    ARROW_VSPACE /= 2
    ZEBRA_X /= 2
    ZEBRA_Y /= 2
    SCREENSHOT_WIDTH /= 2
    SCREENSHOT_HEIGHT /= 2
    SCREENSHOT_X /= 2
    SCREENSHOT_Y /= 2
    HORIZ_ARROW_TOP /= 2
    LEFT_ARROW_X /= 2
    RIGHT_ARROW_X /= 2


HALF_SIZE = CELL_SIZE / 2
GOPLAY_X = CELL_SIZE * 6
EXIT_X = SCREEN_WIDTH - CELL_SIZE
GOPLAY_WIDTH = CELL_SIZE * 8
GOPLAYRECT = pygame.Rect(GOPLAY_X, 0, GOPLAY_WIDTH, CELL_SIZE)
EXITRECT = pygame.Rect(EXIT_X, 0, CELL_SIZE, CELL_SIZE)

SENSE_LEFT = EDITOR_X + SENSE_LEFT_OFF
OBJECT_LEFT = EDITOR_X + OBJECT_LEFT_OFF
ACTION_LEFT = EDITOR_X + ACTION_LEFT_OFF
PROG_TOP = EDITOR_Y + PROG_TOP_OFF
OTHER_TOP= EDITOR_Y + OTHER_TOP_OFF

object_index = {
    "blank": 0,
    "robot": 1,
    "wall": 2,
    "air": 3,
    "kitten": 4,
    }

MOTIVATION_LEFT = 0
MOTIVATION_RIGHT = 1
MOTIVATION_STILL = 2
MOTIVATION_DRILL = 3

ATTACHMENT_NONE = 0
ATTACHMENT_BALLOON = 1
ATTACHMENT_MAGNET = 2


def flip(graphic):
    return pygame.Surface.convert_alpha(pygame.transform.flip(graphic, True, False))

def load_graphics():
    global animations, icons, tiles, editor_frame, attachment_names, familiars, gobutton, checkmark_graphic, levselect

    levselect = load_graphic_full("level-choose.png") 

    editor_frame = load_graphic("brain_window.png")
    gobutton = [[load_graphic("goplay_clicktoedit.png"),load_graphic("goplay_clicktoedit_hover.png")],
                [load_graphic("goplay_clicktogo.png"),load_graphic("goplay_clicktogo_hover.png")],
                [load_graphic("quitbutton.png"),load_graphic("quitbutton_hover.png")],
		[load_graphic("backbutton.png"),load_graphic("backbutton_hover.png")]]

    checkmark_graphic = load_graphic("checkmark.png")

    icons = {
        "zebra":
        [load_graphic("zebra_even.png"),
         load_graphic("zebra_odd.png")],
        "sense":
        [load_graphic("sense_touch.png"),
         load_graphic("sense_feet.png"),
         load_graphic("sense_head.png")],
        "object":
        [load_graphic("object_blank.png"),
         load_graphic("object_robot.png"),
         load_graphic("object_floor.png"),
         load_graphic("object_sky.png")],
        "action":
        [load_graphic("action_blank.png"),
         load_graphic("action_none.png"),
         load_graphic("action_left.png"),
         load_graphic("action_right.png"),
         load_graphic("action_stop.png"),
         load_graphic("action_turnaround.png"),
         load_graphic("action_balloon.png"),
         load_graphic("action_magnet.png"),
         load_graphic("action_drill.png")],
        "motivation":
        [load_graphic("motivation_left.png"),
         load_graphic("motivation_right.png"),
         load_graphic("motivation_stop.png"),
         load_graphic("motivation_drill.png")],
        "attachment":
        [load_graphic("attachment_none.png"),
         load_graphic("attachment_balloon.png"),
         load_graphic("attachment_magnet.png")],
        "arrowup":
        [load_graphic("scrollarrow_up_disabled.png"),
         load_graphic("scrollarrow_up_active.png")],
        "arrowdown":
        [load_graphic("scrollarrow_down_disabled.png"),
         load_graphic("scrollarrow_down_active.png")],
        "arrowleft":
        [load_graphic("scrollarrow_left_disabled.png"),
         load_graphic("scrollarrow_left_active.png")],
        "arrowright":
        [load_graphic("scrollarrow_right_disabled.png"),
         load_graphic("scrollarrow_right_active.png")],
        }
    
    animations = {
        "standing":
            [load_graphic("robot_right1.png")],
        "walkingright":
            [load_graphic("robot_right1.png"),
             load_graphic("robot_right2.png")],
        "falling":
            [load_graphic("robot_falling_right.png"),
             load_graphic("robot_falling_right2.png")],
        "kitten":
            [load_graphic("kitten.png")],
        "drilling":
            [load_graphic("robot_drilling1.png"),
             load_graphic("robot_drilling2.png"),
             load_graphic("robot_drilling3.png"),
             load_graphic("robot_drilling4.png")],
        "winning":
        [load_graphic("robot_finds_kitten2.png"),
         load_graphic("robot_finds_kitten2.png"),
         load_graphic("robot_finds_kitten2.png"),
         load_graphic("robot_finds_kitten2.png"),
         load_graphic("robot_finds_kitten2.png"),
         load_graphic("robot_finds_kitten3.png"),
         load_graphic("robot_finds_kitten4.png"),
         load_graphic("robot_finds_kitten5.png"),
         load_graphic("robot_finds_kitten6.png"),
         load_graphic("robot_finds_kitten7.png")],
        "pizza":
            [load_graphic("pizza.png")]
        }
    
    animations["walkingleft"] = map(flip, animations["walkingright"])

    attachment_names = [ None, "balloon", "magnet" ]

    familiars = {
        "balloon":
            {
            "walkingright":
                [load_graphic("familiar_balloonright1.png"),
                 load_graphic("familiar_balloonright2.png")],
            "falling":
                [load_graphic("familiar_balloonfalling.png")]
            },
        "magnet":
            {
            "walkingright":
                [load_graphic("familiar_magnet.png")]
            }
        }

    familiars["balloon"]["walkingleft"] = \
        map(flip, familiars["balloon"]["walkingright"])

    familiars["magnet"]["walkingleft"] = \
        map(flip, familiars["magnet"]["walkingright"])


    tiles = [None,
             load_graphic("block.png"),
             load_graphic("iceblock.png"),
             load_graphic("magnet.png"),
             load_graphic("steel.png")]

class Agent:
    def __init__(self, animstate, x, y, w, h):
        if not DOUBLE_SIZE:
            x = x / 2
            y = y / 2
        self.initx = x
        self.inity = y
        self.initstate = animstate
        self.rect = pygame.Rect(x, y, w, h)
        self.dx = 0
        self.dy = 0
        self.animstate = animstate
        self.bumped = None
        self.old_bumped = None
        self.supported = None
        self.old_supported = None
        self.concussed = None
        self.old_concussed = None
        self.air = False
        self.old_air = False

        self.p_mot = 0
        self.p_att = 0
        self.att = 0
        self.mot = 0
        
    def blit(self, time, scr=None):
        if (scr == None):
            scr = screen
        astate = self.animstate
        anim = animations[astate]

        scr.blit(anim[time % len(anim)], (self.rect.x, self.rect.y + GLOBAL_OFF_Y))

        attachment = attachment_names[self.att]
        if attachment:
            fstate = astate
            if fstate == "standing":
                fstate = "walkingright"
            elif fstate == "drilling":
                fstate = "falling"
            if attachment == "magnet" and fstate == "falling":
                fstate = "walkingright"
            f_anim = familiars[attachment][fstate]
            f_frame = f_anim[time % len(f_anim)]
            scr.blit(f_frame, (self.rect.x + CELL_SIZE / 32, 
                                  self.rect.y - f_frame.get_height() + CELL_SIZE / 3 + GLOBAL_OFF_Y))

#        scr.fill((255,255,255), pygame.Rect(self.rect.x / CELL_SIZE * CELL_SIZE,
#                                               (self.rect.y + self.rect.h - 1) / CELL_SIZE * CELL_SIZE,
#                                               CELL_SIZE, CELL_SIZE))
#        scr.fill((255, 0, 0), pygame.Rect((self.rect.x / CELL_SIZE + 1) * CELL_SIZE,
#                                             (self.rect.y + self.rect.h - 1) / CELL_SIZE * CELL_SIZE,
#                                             CELL_SIZE, CELL_SIZE))


    def intendx(self, dx):
        global lev
        r = self.rect
        nr = r.move(dx, 0)
        
        for other in lev.robots:
            if (nr.colliderect(other.rect)):
                if self == other:
                    continue
                if isinstance(other, Kitten):
                    self.animstate = "standing"
                    return ("kitten", 0)
                elif isinstance(other, Robot):
                    return ("robot", 0)
        if (dx > 0):
            lx = (r.x + dx + r.w) / CELL_SIZE
            ly = (r.y) / CELL_SIZE
            ly2 = (r.y + r.h / 2 - 1)  / CELL_SIZE
            ly3 = (r.y + r.h - 1)  / CELL_SIZE
            
            cell1 = lev.get((lx, ly))
            cell2 = lev.get((lx, ly2))
            cell3 = lev.get((lx, ly3))
            
            if cell1 or cell2 or cell3:
                hitx = r.x + r.w + dx
                tx = (hitx / CELL_SIZE) * CELL_SIZE
                danger = (hitx - tx)
                #print (r.x, r.w, dx, hitx, tx, danger, dx - danger)
                return ("wall", dx - danger)
        elif (dx < 0):
            lx = (r.x + dx) / CELL_SIZE
            ly = (r.y) / CELL_SIZE
            ly2 = (r.y + r.h / 2 - 1)  / CELL_SIZE
            ly3 = (r.y + r.h - 1)  / CELL_SIZE
            
            cell1 = lev.get((lx, ly))
            cell2 = lev.get((lx, ly2))
            cell3 = lev.get((lx, ly3))
            
            if cell1 or cell2 or cell3:
                hitx = r.x + dx
                tx = (hitx / CELL_SIZE) * CELL_SIZE 
                danger = CELL_SIZE - (hitx - tx)
                #print (r.x, r.w, dx, hitx, tx, danger, dx + danger)
                return ("wall", dx + danger)
        return (None, 0)
    
    def intendy(self, dy):
        global lev
        r = self.rect
        nr = r.move(0, dy)
        
        for other in lev.robots:
            if (nr.colliderect(other.rect)):
                if self == other:
                    continue
                if isinstance(other, Kitten):
                    self.animstate = "standing"
                    return ("kitten", 0)
                elif isinstance(other, Robot):
                    return ("robot", 0)
                
        if (dy > 0):
            bottom = r.y + r.h
            lx = r.x / CELL_SIZE
            lx2 = (r.x + r.w - 1) / CELL_SIZE
            ly = (bottom + dy) / CELL_SIZE

            cell1 = lev.get((lx, ly))
            cell2 = lev.get((lx2, ly))
            if cell1 or cell2:
                hity = r.y + r.h + dy
                ty = (hity / CELL_SIZE) * CELL_SIZE
                danger = (hity - ty)
                return ("wall", dy - danger)

        elif (dy < 0):
            lx = r.x / CELL_SIZE
            lx2 = (r.x + r.w - 1) / CELL_SIZE
            ly = (r.y + dy) / CELL_SIZE

            cell1 = lev.get((lx, ly))
            cell2 = lev.get((lx2, ly))
            if cell1 or cell2:
                hity = r.y + dy
                ty = ly * CELL_SIZE
                danger = CELL_SIZE - (hity - ty)
                return ("wall", dy + danger)

        return (None, 0)

    def has_balloon(self):
        return attachment_names[self.att] == "balloon"

    def has_magnet(self):
        return attachment_names[self.att] == "magnet"

    def magnet_above(self):
        r = self.rect
        tx = (r.x + CELL_SIZE / 2) / CELL_SIZE
        ty = r.y / CELL_SIZE

        for i in range(ty, -1, -1):
            t = lev.get((tx, i))
            if t == 3:
                return True

        return False

    def do_physics(self):
        self.old_supported = self.supported
        self.old_concussed = self.concussed        
        self.old_bumped = self.bumped
        self.old_air = self.air
        
        r = self.rect
        bottom = r.y + r.h
        lx = r.x / CELL_SIZE
        ly = bottom / CELL_SIZE
        
        # gravity
        self.dy += CELL_SIZE / 32
        if self.has_balloon():
            self.dy -= CELL_SIZE / 64

        if self.has_magnet() and self.magnet_above():
            self.dy -= 3 * CELL_SIZE / 32


        if abs(self.dy) > HALF_SIZE:
            self.dy = HALF_SIZE * (self.dy / abs(self.dy))
            
        p = self.intendx(self.dx)
        (xobstacle, corrx) = p
        
        self.bumped = None
        if (xobstacle):
            if xobstacle == "kitten":
                win(self)
            self.dx = 0
            self.rect.move_ip((corrx, 0))
            self.bumped = xobstacle
        else:
            self.rect.move_ip((self.dx, 0))

        # supported?
        self.supported = None
        # concussed?
        self.concussed = None
        # air?
        self.air = self.dy > 20

        corry = None
        p = self.intendy(self.dy)
        (yobstacle, corry) = p

        #print p, self.rect.y, self.dy
        if (yobstacle):
            if yobstacle == "kitten":
                win(self)
            if self.dy > 0:
                self.supported = yobstacle
            if self.dy < 0:
                self.concussed = yobstacle
            self.dy = 0
            self.rect.move_ip((0,corry))
        else:
            self.rect.move_ip((0,self.dy))


    def do_sense_react(self):
        self.bumped = False

    
class Robot(Agent):
    def __init__(self, animstate, x, y, p_att, p_mot):
        Agent.__init__(self, animstate, x, y, CELL_SIZE, 2 * CELL_SIZE)
        self.program = [[0,1,4], [0,2,4], [0,0,4]]
        self.p_att = p_att
        self.att = p_att
        self.p_mot = p_mot
        self.mot = p_mot
    
    def execute_action(self, a):
        if a == 0:
            pass
        if a == 1:
            self.att = ATTACHMENT_NONE
        if a == 2:
            self.mot = MOTIVATION_LEFT
        if a == 3:
            self.mot = MOTIVATION_RIGHT
        if a == 4:
            self.mot = MOTIVATION_STILL
        if a == 5:
            if self.mot == MOTIVATION_LEFT:
                self.mot = MOTIVATION_RIGHT
            elif self.mot == MOTIVATION_RIGHT:
                self.mot = MOTIVATION_LEFT
        if a == 6:
            self.att = ATTACHMENT_BALLOON
        if a == 7:
            self.att = ATTACHMENT_MAGNET
        if a == 8:
            self.mot = MOTIVATION_DRILL

    def derive_from_mot(self):
        if self.mot == MOTIVATION_RIGHT:
            self.animstate = "walkingright"
            self.dx = CELL_SIZE / 6
        elif self.mot == MOTIVATION_LEFT:
            self.animstate = "walkingleft"
            self.dx = -CELL_SIZE / 6                
        elif self.mot == MOTIVATION_STILL:
            self.animstate = "standing"
            self.dx = 0
        elif self.mot == MOTIVATION_DRILL:
            self.animstate = "drilling"
            self.dx = 0
            self.dy = -10
                

    def do_sense_react(self):
        for p in self.program:
            (s, o, a) = p
            if (s == 0 # touch sensor
                and ((self.bumped
                and object_index[self.bumped] == o
                and not self.old_bumped)
                or (self.air and not self.old_air
                    and o == object_index["air"]))):
                self.execute_action(a)
            if (s == 1 # support sensor
                and ((self.supported
                and object_index[self.supported] == o
                and not self.old_supported)
                or (self.air and not self.old_air
                    and o == object_index["air"]))):
                self.execute_action(a)
            if (s == 2 # head sensor
                and ((self.concussed
                and object_index[self.concussed] == o
                and not self.old_concussed)
                or (self.air and not self.old_air
                    and o == object_index["air"]))):
                self.execute_action(a)
        if self.supported:
            self.derive_from_mot()
            if self.mot == MOTIVATION_DRILL:
                r = self.rect
                tmid = (r.x + r.w / 2) / CELL_SIZE
                tleft = (r.x) / CELL_SIZE
                tright = (r.x + r.w - 1) / CELL_SIZE
                ty = (r.y + r.h) / CELL_SIZE

                tx = None

                if lev.is_breakable((tmid, ty)):
                    tx = tmid
                elif lev.is_breakable((tleft, ty)):
                    tx = tleft
                elif lev.is_breakable((tright, ty)):
                    tx = tright

                if tx is not None:
                    lev.set((tx, ty), 0)
                    lev.draw()

        # if falling, should be drill if drill
        elif self.mot == MOTIVATION_DRILL:
            self.animstate = "drilling"

        else:
            self.animstate = "falling"

class Kitten(Agent):
    def __init__(self, x, y):
        Agent.__init__(self,"kitten", x, y, 1, CELL_SIZE)
        self.program = None
    
class Pizza(Agent):
    def __init__(self, x, y):
        Agent.__init__(self, "pizza", x, y, CELL_SIZE, CELL_SIZE)
        self.program = None

def pickle_robot(r):
    return (r.__class__.__name__, r.rect.x, r.rect.y, r.program, r.p_att, r.p_mot)
def unpickle_robot((c, x, y, program, p_att, p_mot)):
    if c == "Robot":
        r = Robot("standing", x, y, p_att, p_mot)
        r.program = program
        return r
    elif c == "Kitten":
        r = Kitten(x, y)
        return r

def save_level((bg, cells, robots), filename):
    f = open(filename, 'w')
    ls = repr(cells)
    rs = repr(map(pickle_robot, robots))
    s = "(" + str(bg) + ", " + ls + ", " + rs + ")"
    f.write(s)
    f.close()
def load_level(filename):
    f = open(filename, 'r')
    (bg, cells, prerobots) = eval(f.read())
    robots = map(unpickle_robot, prerobots)
    f.close()
    if len(cells) < LEV_WIDTH * LEV_HEIGHT:
            cells.extend([0] * ((LEV_WIDTH * LEV_HEIGHT) - len(cells)))
    return (bg, cells, robots)
def save_imp(filename):
    global lev
    save_level((lev.bg, lev.cells, lev.robots), filename)
def load_imp(filename):
    global lev
    (lev.bg, lev.cells, lev.robots) = load_level(filename)
    lev.load_background()

class Level:
    def __init__(self, w, h):
        self.w = w
        self.cells = [0] * (w * h)
        self.surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))

    def load_background(self):
        b = load_graphic_1x("background_" + BACKGROUND_NAMES[self.bg] + ".png")
        self.bgsurf = fit_on_screen(b)

    def set(self, (x,y), v):
        try:
            self.cells[self.w * y + x] = v
        except IndexError:
            pass

    def get(self, (x,y)):
        cells = self.cells
        i = self.w * y + x
        return_val = None
        if x >= 0 and x < self.w and i >= 0 and i < len(cells):
            return_val = cells[i]

        return return_val

    def is_breakable(self, (x,y)):
        tile = self.get((x,y))
        return tile and (tile == 1 or tile == 2)

    def draw(self):
        if self.bgsurf:
            self.surf.blit(self.bgsurf, (0, 0))
        else:
            self.surf.fill((0,128,255))
        for i in range(len(self.cells)):
            t = tiles[self.cells[i]]
            if t != None:
                self.surf.blit(t, (CELL_SIZE * (i % self.w), CELL_SIZE * (i / self.w) + GLOBAL_OFF_Y))
    def blit(self, scr=None):
        if (scr == None):
            scr = screen
        scr.blit(self.surf, (0, 0))
    def clone(self):
        c = Level(self.w, 0)
        c.cells = self.cells[:]
        c.bgsurf = self.bgsurf
        c.robots = self.robots
        c.bg = self.bg
        return c

    def reset_robots(self):
        for r in self.robots:
            r.rect.x = r.initx
            r.rect.y = r.inity
            r.dx = 0
            r.dy = 0
            r.animstate = r.initstate
            r.mot = r.p_mot
            r.att = r.p_att
            r.bumped = None
            r.old_bumped = None
            r.supported = None
            r.old_supported = None
            r.concussed = None
            r.old_concussed = None
            r.air = False
            r.old_air = False
            if isinstance(r, Robot):
                r.derive_from_mot()

def reinit():
    global lev, orig_lev
    lev = orig_lev.clone()
    lev.draw()
    lev.reset_robots()
    
def init():
    global screen, clock, levels
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    load_graphics()
    pygame.mixer.init()
    levels = glob.glob('levels/*.lev')
    levels.sort()


cat2num = {"sense": 0, "object": 1, "action": 2}

UPARROWRECT = pygame.Rect(EDITOR_X + ARROW_LEFT, PROG_TOP, ARROW_WIDTH, ARROW_HEIGHT)
DOWNARROWRECT = pygame.Rect(EDITOR_X + ARROW_LEFT, PROG_TOP + ARROW_VSPACE, ARROW_WIDTH, ARROW_HEIGHT)
LEFTARROWRECT = pygame.Rect(LEFT_ARROW_X, HORIZ_ARROW_TOP, ARROW_HEIGHT,  ARROW_WIDTH)
RIGHTARROWRECT = pygame.Rect(RIGHT_ARROW_X, HORIZ_ARROW_TOP, ARROW_HEIGHT,  ARROW_WIDTH )
SCREENSHOTRECT = pygame.Rect(SCREENSHOT_X, SCREENSHOT_Y, SCREENSHOT_WIDTH, SCREENSHOT_HEIGHT)

def redraw_brain_edit(r, scroll):
    screen.blit(editor_frame, (EDITOR_X,EDITOR_Y))
    screen.blit(icons["zebra"][scroll % 2], (EDITOR_X + ZEBRA_X, EDITOR_Y + ZEBRA_Y))

    screen.blit(icons["arrowup"][scroll > 0], (UPARROWRECT.x, UPARROWRECT.y))
    screen.blit(icons["arrowdown"][scroll < len(r.program) - 1], (DOWNARROWRECT.x, DOWNARROWRECT.y))

    for i in range(3):
        line = i + scroll
        if line >= len(r.program):
            break
        (s, o, a) = r.program[line]
        screen.blit(icons["sense"][s], (SENSE_LEFT, PROG_TOP + i * ZEBRA_HEIGHT))
        screen.blit(icons["object"][o], (OBJECT_LEFT, PROG_TOP + i * ZEBRA_HEIGHT))
        screen.blit(icons["action"][a], (ACTION_LEFT, PROG_TOP + i * ZEBRA_HEIGHT))
    screen.blit(icons["attachment"][r.p_att], (SENSE_LEFT, OTHER_TOP))
    screen.blit(icons["motivation"][r.p_mot], (OBJECT_LEFT, OTHER_TOP))

def increment(r, cat, row):
    r.program[row][cat2num[cat]] = (r.program[row][cat2num[cat]] + 1) % len(icons[cat])

def brain_edit(r):
    time = 0
    scroll = 0
    
    curtain = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
    curtain.fill((128,128,128))
    curtain.set_alpha(200)
    screen.blit(curtain,(0,0))
    r.blit(0);

    redraw_brain_edit(r, scroll)
    pygame.display.flip()
    
    while True:
        e = pygame.event.wait()
        et = e.type
        if et == pygame.KEYDOWN:
            if e.key == 27 or e.key == 113:
                return
            if e.key == 32:
                return
            if e.key == ord('n'):
                r.program.append(r.program[0])
                redraw_brain_edit(r, scroll)
                pygame.display.flip()
            if e.key == ord('d'):
                r.program.pop()
                redraw_brain_edit(r, scroll)
                pygame.display.flip()

        elif et == pygame.MOUSEBUTTONDOWN:
            
            if not pygame.Rect(EDITOR_X,EDITOR_Y,editor_frame.get_width(),editor_frame.get_height()).collidepoint(e.pos):
                return
            for row in range(3):
                if row + scroll < len(r.program) and row + scroll >= 0:
                    if pygame.Rect(SENSE_LEFT, PROG_TOP + row * ZEBRA_HEIGHT, CELL_SIZE, CELL_SIZE).collidepoint(e.pos):
                        increment(r, "sense", row + scroll)
                    if pygame.Rect(OBJECT_LEFT, PROG_TOP + row * ZEBRA_HEIGHT, CELL_SIZE, CELL_SIZE).collidepoint(e.pos):
                        increment(r, "object", row + scroll)
                    if pygame.Rect(ACTION_LEFT, PROG_TOP + row * ZEBRA_HEIGHT, CELL_SIZE, CELL_SIZE).collidepoint(e.pos):
                        increment(r, "action", row + scroll)
            if pygame.Rect(SENSE_LEFT, OTHER_TOP, CELL_SIZE, CELL_SIZE).collidepoint(e.pos):
                r.p_att = (r.p_att + 1) % len (icons["attachment"])
                r.att = r.p_att
            if pygame.Rect(OBJECT_LEFT, OTHER_TOP, CELL_SIZE, CELL_SIZE).collidepoint(e.pos):
                r.p_mot = (r.p_mot + 1) % len (icons["motivation"])
                r.mot = r.p_mot
            if DOWNARROWRECT.collidepoint(e.pos):
                if scroll < len(r.program) - 1:
                    scroll += 1
            if UPARROWRECT.collidepoint(e.pos):
                if scroll > 0:
                    scroll -= 1

            redraw_brain_edit(r, scroll)
            pygame.display.flip()
                
        elif et == TIMEREVENT:
            time += 1
        elif et == pygame.QUIT:
            exit()

def redraw_all(time):
    global lev
#    screen.fill((128,128,128));
    lev.blit()
    for robo in lev.robots:
        robo.rect.x = robo.initx
        robo.rect.y = robo.inity
        if isinstance(robo, Robot):
            robo.derive_from_mot()
        robo.blit(time)


def rerender_level():
    lev.draw()
    redraw_all(0)
    pygame.display.flip()

def rerender_robots():
    redraw_all(0)
    pygame.display.flip()

def _edit_mode():
    global lev, gobutton
    
    time = 0
    cur_robo = None
    old_cur_robo = None
    reinit()
    redraw_all(0)

    pygame.display.flip()
    drawing = None
    moving = False
    draw_tool = 1
    posx = 0
    posy = 0
    robots = lev.robots
    hover = 0
    hover_exit = 0
    
    while True:
        e = pygame.event.wait()
        et = e.type
        if et == pygame.KEYUP:
            if e.key == ord('m'):
                moving = False
        if et == pygame.KEYDOWN:
            if e.key == 27 or e.key == 113:
                return
            if e.key == 32:
                return
            if e.key == ord ('s'):
                save_imp("levels/saved.lev")
            if e.key >= ord ('0') and e.key < ord ('9'):
                draw_tool = e.key - ord ('0')
            if e.key == ord ('b'):
                robots[draw_tool] = Robot("standing", posx, posy, ATTACHMENT_NONE, MOTIVATION_STILL)
                rerender_robots()
            if e.key == ord ('k'):
                robots[draw_tool] = Kitten(posx, posy)
                rerender_robots()
            if e.key == ord ('m'):
                robots[draw_tool].initx = posx
                robots[draw_tool].inity = posy
                moving = True
                rerender_robots()
            if e.key == ord ('n'):
                robots.append(Robot("standing", posx, posy, ATTACHMENT_NONE, MOTIVATION_STILL))
                rerender_robots()
            if e.key == ord ('d') and len(robots):
                robots.pop()
                rerender_robots()
            if e.key == ord ('.'):
                lev.bg = (lev.bg + 1) % len(BACKGROUND_NAMES)
                lev.load_background()
                rerender_level()
            
        elif et == pygame.MOUSEBUTTONUP:
            drawing = None
        elif et == pygame.MOUSEBUTTONDOWN:
            if e.button == 3:
                    drawing = draw_tool
                    lev.set((e.pos[0] / CELL_SIZE, (e.pos[1] - GLOBAL_OFF_Y) / CELL_SIZE), drawing)
                    rerender_level()
            elif cur_robo:
                    brain_edit(cur_robo)
                    cur_robo = None
            elif GOPLAYRECT.collidepoint(e.pos):
                 return
            elif EXITRECT.collidepoint(e.pos):
                 raise ExitToSelect

        elif et == pygame.MOUSEMOTION:
            (posx, posy) = e.pos
        
            if GOPLAYRECT.collidepoint(e.pos):
                hover = 1
            else:
                hover = 0
            if EXITRECT.collidepoint(e.pos):
                hover_exit = 1
            else:
                hover_exit = 0

            posy -= GLOBAL_OFF_Y
            if moving:
                robots[draw_tool].initx = posx
                robots[draw_tool].inity = posy
                rerender_robots()
            if drawing != None:
                lev.set((e.pos[0] / CELL_SIZE, (e.pos[1] - GLOBAL_OFF_Y) / CELL_SIZE), drawing)
                rerender_level()
            else:
                old_cur_robo = cur_robo
                cur_robo = None
                for r in robots:
                    if (r.rect).move(0,GLOBAL_OFF_Y).collidepoint(e.pos) and r.program is not None:
                        cur_robo = r
                        break            
        elif et == TIMEREVENT:
            time += 1
            screen.blit(gobutton[1][hover], (GOPLAY_X, 0))
            screen.blit(gobutton[2][hover_exit], (EXIT_X, 0))
            if drawing == None and not moving:
                pygame.display.flip()

        elif et == pygame.QUIT:
            exit()

        if old_cur_robo != cur_robo:
            redraw_all(0)
            if cur_robo:
                pygame.draw.rect(screen, (128,255,255), cur_robo.rect.move(0,GLOBAL_OFF_Y), 5)

def edit_mode():
        global lev, orig_lev
        _edit_mode()
        orig_lev = lev.clone()



def win(r):
    global lev
    
    time = 0
    hover_back = 0
    winanim = animations["winning"]
    pygame.mixer.music.load("music/win.mid")
    pygame.mixer.music.play()

    while True:
        e = pygame.event.wait()
        et = e.type
        if et == pygame.KEYDOWN:
            raise Win
        elif et == pygame.MOUSEBUTTONDOWN:
            raise Win
        elif et == pygame.MOUSEMOTION:
            (posx, posy) = e.pos
            if EXITRECT.collidepoint(e.pos):
                hover_back = 1
            else:
                hover_back = 0

        elif et == TIMEREVENT:
            lev.blit()
            time += 1
            if time == len(winanim) * 3:
                time = time - 1
            for robo in lev.robots:
                if robo != r and not isinstance(robo, Kitten):
                    robo.blit(time)
                    
            screen.blit(winanim[time / 3], (r.rect.x - 35, r.rect.y - 64  + GLOBAL_OFF_Y))
	    # XXX hover...
            screen.blit(gobutton[3][hover_back], (EXIT_X, 0))
            pygame.display.flip()

        elif et == pygame.QUIT:
            exit()

def go(levname):
    global lev, orig_lev, gobutton

    hover = 0
    hover_exit = 0
    pygame.mixer.music.load("music/morn2.mid")
    pygame.mixer.music.play(-1)

    lev = Level(LEV_WIDTH, LEV_HEIGHT)
    load_imp(levname)
    lev.reset_robots()
    lev.draw()

    
    orig_lev = lev.clone()
    robots = lev.robots

    time = 0
    pygame.time.set_timer(TIMEREVENT, 1000 / FPS)

    edit_mode()
    
    while True:
        e = pygame.event.wait()
        et = e.type

        if et == pygame.KEYDOWN:
            if e.key == 27 or e.key == 113:
                break
            if e.key == 32:
                edit_mode()
        elif et == pygame.MOUSEBUTTONDOWN:
            if GOPLAYRECT.collidepoint(e.pos):
                edit_mode()
            if EXITRECT.collidepoint(e.pos):
                raise ExitToSelect

        elif et == pygame.MOUSEMOTION:
            if GOPLAYRECT.collidepoint(e.pos):
                hover = 1
            else:
                hover = 0
            if EXITRECT.collidepoint(e.pos):
                hover_exit = 1
            else:
                hover_exit = 0

        elif et == TIMEREVENT:
            lev.blit()
            screen.blit(gobutton[0][hover], (GOPLAY_X, 0))
            screen.blit(gobutton[2][hover_exit], (EXIT_X, 0))


            time += 1
#            for robo in robots:
#                robo.steady()
                
#                robo.update()

            for robo in robots:
                robo.do_physics()
                robo.do_sense_react()

            for robo in robots:
                robo.blit(time)

            pygame.display.flip()

        elif et == pygame.QUIT:
            exit()

def screenshot(levels, i, passed):
    global levselect, icons
    tmp_lev = Level(LEV_WIDTH,LEV_HEIGHT)
    (bg, c,rs) = load_level(levels[i])
    tmp_lev.cells = c
    tmp_lev.bg = bg
    tmp_lev.load_background()
    tmp_lev.draw()
    for r in rs:
        r.blit(0,tmp_lev.surf)

    screen.blit(levselect, (0, 0))
    screen.blit(icons["arrowleft"][1], (LEFTARROWRECT.x, LEFTARROWRECT.y))
    screen.blit(icons["arrowright"][1], (RIGHTARROWRECT.x, RIGHTARROWRECT.y))
        
    screen.blit(pygame.transform.scale(tmp_lev.surf, (SCREENSHOT_WIDTH,SCREENSHOT_HEIGHT)), (SCREENSHOT_X,SCREENSHOT_Y))
    if i in passed:
        screen.blit(checkmark_graphic, (SCREENSHOT_X + SCREENSHOT_WIDTH - 32, SCREENSHOT_Y - 16))
    pygame.display.flip()


def level_select(passed, curlev):
    global levels
    pygame.mixer.music.load("music/proprietarypiano2.mid")
    pygame.mixer.music.play(-1)

    screenshot(levels, curlev, passed)
    
    while True:
        e = pygame.event.wait()
        et = e.type
        if et == pygame.KEYDOWN:
            if e.key == 27 or e.key == 113:
                exit()
            break
        elif et == pygame.MOUSEBUTTONDOWN:
            if (LEFTARROWRECT.collidepoint(e.pos)):
                curlev = (curlev - 1 + len(levels)) % len(levels)
                screenshot(levels, curlev, passed)
            if (RIGHTARROWRECT.collidepoint(e.pos)):
                curlev = (curlev + 1) % len(levels)
                screenshot(levels, curlev, passed)
            if (SCREENSHOTRECT.collidepoint(e.pos)):
                break
        
    return curlev

def title_screen():
    title = load_graphic_full("titlescreen.png")
    screen.blit(title, (0, 0))
    try:
        pygame.mixer.init()
        pygame.mixer.music.load("music/morn2.mid")
        pygame.mixer.music.play(-1)
    except:
        pass
    pygame.display.flip()

    while True:
        e = pygame.event.wait()
        et = e.type
        if et == pygame.KEYDOWN:
            break
        elif et == pygame.MOUSEBUTTONDOWN:
            break

def main():
    passed = {}
    init()
    title_screen()
    levindex = 0
    while True:
        levindex = level_select(passed, levindex)
        try:
            go(levels[levindex])
        except ExitToSelect:
            pass
        except Win:
            passed[levindex] = True


if __name__ == "__main__":
    main()
