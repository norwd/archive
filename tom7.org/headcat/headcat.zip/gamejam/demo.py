import pygame,time
from math import sin,cos,degrees,radians,hypot,pi,atan
from random import choice,randint
from pygame.locals import *

fps = 30

pygame.init()
pygame.mixer.init(22050,16,2,1024)
pygame.display.set_caption("Wave")
pygame.mixer.music.load("shaskell2.mid")
pygame.mixer.music.play()

#pygame.mouse.set_visible(False)
screen=pygame.display.set_mode((1200, 900))
clock = pygame.time.Clock()

#tuberfont=pygame.font.Font("Tuber.ttf",50)
imgs = (pygame.image.load("brazilian.png"), pygame.image.load("brazilian2.png"))

n = 0

def idle(n):
    screen.blit(pygame.transform.rotate(imgs[(n / 10) % len(imgs)], n * 1),(0,0))


colors = ((0,128,0), (0xff,255,0), (0,80,255), (255,255,255))

while True:
    n = n + 1
    e = pygame.event.poll()
    if e.type == pygame.KEYDOWN:
        exit()
    screen.fill((128,128,128))
    idle(n)
#    screen.blit(tuberfont.render("Ola, Mundo!",1,colors[(n / 10) % len(colors)]),(0,300))
    pygame.display.flip()
    clock.tick(fps)

# pygame.time.wait(100);























