#ifndef DEFS
#define DEFS

typedef struct lightmap_s {
	int width;
	int height;
	unsigned char* data;
} lightmap_t;

typedef struct surface_s {
	int widthBlock;
	int heightBlock;
	int miplevel;
	unsigned char* data;
	lightmap_t* lightmap;
} surface_t;





typedef struct lightmap_q2_s {
	int width;
	int height;
	unsigned int* data;
} lightmap_q2_t;

typedef struct surface_q2_s {
	int widthBlock;
	int heightBlock;
	int miplevel;
	unsigned char* data;
	lightmap_q2_t* lightmap;
} surface_q2_t;


#endif
