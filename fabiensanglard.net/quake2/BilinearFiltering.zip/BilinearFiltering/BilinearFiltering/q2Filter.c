#include "tga.h"
#include "defs.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LM_WIDTH 13
#define LM_HEIGHT 15


/*

Tried to export a lightmap to TGA but was losing precision since lightmap in Quake2 are stored at 16bits
but TGA greyscale is 8 bits. So here is an export of a lightmap from Quake2 and an interpolation bilinear filtering based
on short instead of unsigned chars.

*/


unsigned int quake2Lightmap[LM_WIDTH*LM_HEIGHT]  = { 
7584, 6912, 7008, 7296, 8064, 8544, 8832, 9312,10656,11328,11904,12576,13728,
 5952, 5568, 5664, 6048, 6816, 7488, 7968, 8544, 9984,10656,11424,12096,13344,
 4128, 4032, 4032, 4416, 5088, 5952, 6816, 7680, 8640, 9696,10752,11808,12768,
 2496, 2400, 2496, 2880, 3552, 4512, 5760, 6816, 7776, 9024, 9984,11424,12672,
  384,  288,  480,  864, 1632, 2784, 4416, 5664, 7008, 8160, 9408,10944,12384,
   64,   64,   64,   64,  672, 2016, 3648, 5280, 6624, 7872, 9024,10560,12000,
   64,   64,   64,   64,  384, 1728, 3552, 5088, 6336, 7584, 8832,10464,11808,
   64,   64,   64,   64,  864, 2304, 3936, 5280, 6528, 7680, 8544, 9600,11712,
   64,   64,  384, 1056, 1920, 3072, 4608, 5856, 6912, 7584, 8160, 8832,10464,
 1056, 1536, 1920, 2400, 3168, 4320, 5664, 6624, 7104, 7488, 7776, 8256, 8928,
 1920, 2400, 2976, 3552, 4320, 5280, 6528, 7008, 7104, 7104, 7104, 7200, 7776,
 2592, 3168, 3840, 4704, 5568, 6528, 7392, 7392, 7008, 6528, 6240, 6144, 6432,
 3552, 4128, 4896, 5856, 6912, 7872, 8064, 7776, 7104, 6528, 5952, 5568, 5664,
 4512, 5184, 5952, 7008, 7968, 8448, 8544, 8160, 7296, 6432, 5664, 5184, 5376,
 5184, 5952, 6816, 7872, 8352, 8544, 8832, 8256, 7296, 6432, 5760, 5280, 5184, } ;




void Q2_DrawBlockInt(lightmap_q2_t* lightmap,int posX, int posY, unsigned char* dest,int blocksize)
{
	int colorLeft, colorRight ;
	int nextColorLeft, nextColorRight ;
	float diffLeft, diffRight ;
	int i,j;
	int left,right;
	int  diffRightLeft;

	left = colorLeft     = lightmap->data[posX+ posY   *lightmap->width] ;
	nextColorLeft        = lightmap->data[posX+(posY+1)*lightmap->width] ;
	diffLeft = (nextColorLeft - colorLeft)/blocksize;

	right = colorRight     = lightmap->data[posX+1+ posY   *lightmap->width]  ;
	nextColorRight         = lightmap->data[posX+1+(posY+1)*lightmap->width] ;
	diffRight = (nextColorRight - colorRight)/blocksize;

	

	for(i=0 ; i < blocksize ; i++)
	{
		diffRightLeft = (  right - left)/blocksize;
		

		for(j=blocksize-1 ; j >=0  ; j--)
		{
			dest[j] = (left + j * diffRightLeft) >> 8;
		}

		dest += blocksize*(lightmap->width-1);

		left =  colorLeft  + i* diffLeft;
		right = colorRight + i* diffRight;
	}
}

void Q2_BilinearFilter(surface_q2_t* surface)
{
	int blockSize = 16 >> surface->miplevel;
	int i,j;

	surface->data = calloc(surface->widthBlock*surface->heightBlock,blockSize*blockSize);


	//Draw blocks left to right
	for (i =0 ; i < surface->widthBlock ; i++)
	{
		for(j=0 ; j< surface->heightBlock ; j++)
		{
			//DrawBlockFloat(surface->lightmap,i,j,&(surface->data[i*blockSize + j*blockSize*blockSize*surface->widthBlock]),blockSize);
			Q2_DrawBlockInt(surface->lightmap,i,j,&(surface->data[i*blockSize + j*blockSize*blockSize*surface->widthBlock]),blockSize);
		}
	}
}


int main(int argc, char** argv)
{
	surface_q2_t		surface ;
	lightmap_q2_t		lightmap;


	memset(&surface,0,sizeof(surface));
	surface.lightmap = &lightmap;
	surface.miplevel = 0;
	surface.heightBlock = LM_HEIGHT-1;
	surface.widthBlock = LM_WIDTH-1;

	lightmap.width=LM_WIDTH;
	lightmap.height=LM_HEIGHT;
	lightmap.data = quake2Lightmap;


	Q2_BilinearFilter(&surface);
	WriteSurfaceQ2AsTGA("q2.test.surface.mipmap0.tga",&surface);

	surface.miplevel = 1;
	Q2_BilinearFilter(&surface);
	WriteSurfaceQ2AsTGA("q2.test.surface.mipmap1.tga",&surface);

	surface.miplevel = 2;
	Q2_BilinearFilter(&surface);
	WriteSurfaceQ2AsTGA("q2.test.surface.mipmap2.tga",&surface);

	surface.miplevel = 3;
	Q2_BilinearFilter(&surface);
	WriteSurfaceQ2AsTGA("q2.test.surface.mipmap3.tga",&surface);

}