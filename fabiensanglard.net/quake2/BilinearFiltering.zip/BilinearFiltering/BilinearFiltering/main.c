#include "tga.h"
#include "defs.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>




void DrawBlockFloat(lightmap_t* lightmap,int posX, int posY, unsigned char* dest,int blocksize)
{
	unsigned char colorLeft, colorRight ;
	unsigned char nextColorLeft, nextColorRight ;
	float diffLeft, diffRight ;
	int i,j;
	unsigned char left,right;
	float  diffRightLeft;

	left = colorLeft     = lightmap->data[posX+ posY   *lightmap->width];
	nextColorLeft        = lightmap->data[posX+(posY+1)*lightmap->width];
	diffLeft = (nextColorLeft - colorLeft)/(float)blocksize;

	right = colorRight     = lightmap->data[posX+1+ posY   *lightmap->width];
	nextColorRight         = lightmap->data[posX+1+(posY+1)*lightmap->width];
	diffRight = (nextColorRight - colorRight)/(float)blocksize;

	

	for(i=0 ; i < blocksize ; i++)
	{
		diffRightLeft = (right - left)/(float)blocksize;
		

		for(j=0 ; j < blocksize ; j++)
		{
			dest[j] = left + j * diffRightLeft;
		}

		dest += blocksize*(lightmap->width-1);

		left =  colorLeft  + i* diffLeft;
		right = colorRight + i* diffRight;
	}
}

void DrawBlockInt(lightmap_t* lightmap,int posX, int posY, unsigned char* dest,int blocksize)
{
	int colorLeft, colorRight ;
	int nextColorLeft, nextColorRight ;
	float diffLeft, diffRight ;
	int i,j;
	int left,right;
	int  diffRightLeft;

	left = colorLeft     = lightmap->data[posX+ posY   *lightmap->width] << 8;
	nextColorLeft        = lightmap->data[posX+(posY+1)*lightmap->width] << 8;
	diffLeft = (nextColorLeft - colorLeft)/blocksize;

	right = colorRight     = lightmap->data[posX+1+ posY   *lightmap->width] << 8 ;
	nextColorRight         = lightmap->data[posX+1+(posY+1)*lightmap->width] << 8;
	diffRight = (nextColorRight - colorRight)/blocksize;

	

	for(i=0 ; i < blocksize ; i++)
	{
		diffRightLeft = (left - right)/blocksize;
		

		for(j=blocksize-1 ; j >=0  ; j--)
		{
			dest[j] = (left + j * diffRightLeft) >> 8;
		}

		dest += blocksize*(lightmap->width-1);

		left =  colorLeft  + i* diffLeft;
		right = colorRight + i* diffRight;
	}
}

void BilinearFilter(surface_t* surface)
{
	int blockSize = 16 >> surface->miplevel;
	int i,j;

	surface->data = calloc(surface->widthBlock*surface->heightBlock,blockSize*blockSize);


	//Draw blocks left to right
	for (i =0 ; i < surface->widthBlock ; i++)
	{
		for(j=0 ; j< surface->heightBlock ; j++)
		{
			//DrawBlockFloat(surface->lightmap,i,j,&(surface->data[i*blockSize + j*blockSize*blockSize*surface->widthBlock]),blockSize);
			DrawBlockInt(surface->lightmap,i,j,&(surface->data[i*blockSize + j*blockSize*blockSize*surface->widthBlock]),blockSize);
		}
	}
}

int ReadTGA(lightmap_t* lightmap, char* path)
{
	FILE *file;
	unsigned char type[4];
	unsigned char info[6];
	int byteCount;
	long imageSize;

    file = fopen(path, "rb");

    if (!file)
		return 0;

	fread (&type, sizeof (char), 3, file);
	fseek (file, 12, SEEK_SET);
	fread (&info, sizeof (char), 6, file);

	//image type either 2 (color) or 3 (greyscale)
	if (type[1] != 0 || (type[2] != 2 && type[2] != 3))
	{
		fclose(file);
		return 0;
	}

	lightmap->width = info[0] + info[1] * 256;
	lightmap->height = info[2] + info[3] * 256;
	byteCount = info[4] / 8;

	/*
	if (byteCount != 3 && byteCount != 4) {
		fclose(file);
		return 0;
	}
*/
	imageSize = lightmap->width * lightmap->height * byteCount;

	//allocate memory for image data
	lightmap->data = malloc(imageSize);

	//read in image data
	fread(lightmap->data, sizeof(unsigned char), imageSize, file);

	//close file
	fclose(file);

	return 1;
}

int main2(int argc,char** argv)
{
	lightmap_t    lightmap;
	surface_t surface ;
	int i,j;

	if (argc < 2)
	{
		printf("Usage %s <lightmap.tga>\n",argv[0]);
		return;
	}

	ReadTGA(&lightmap,argv[1]);

	for(i=0 ; i < lightmap.height ; i++)
	{
		for(j=0 ; j < lightmap.width ; j++)
			printf("%d  ",lightmap.data[i*lightmap.width+j] << 8);
		printf("\n");
	}
	memset(&surface,0,sizeof(surface));
	surface.lightmap = &lightmap;
	surface.miplevel = 0;
	surface.heightBlock = lightmap.height-1;
	surface.widthBlock = lightmap.width-1;
	BilinearFilter(&surface);
	WriteSurfaceAsTGA("test.surface.mipmap0.tga",&surface);

	surface.miplevel = 1;
	BilinearFilter(&surface);
	WriteSurfaceAsTGA("test.surface.mipmap1.tga",&surface);
    
	surface.miplevel = 2;
	BilinearFilter(&surface);
	WriteSurfaceAsTGA("test.surface.mipmap2.tga",&surface);
    
	surface.miplevel = 3;
	BilinearFilter(&surface);
	WriteSurfaceAsTGA("test.surface.mipmap3.tga",&surface);
    
}