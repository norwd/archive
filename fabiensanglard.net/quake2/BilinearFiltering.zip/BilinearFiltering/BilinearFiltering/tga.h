#ifndef TGA
#define TGA

#include "defs.h"

void WriteLightMapAsTGA(char* path, lightmap_t* lightmap);
void WriteSurfaceAsTGA(char* path, surface_t* lightmap);
void WriteSurfaceQ2AsTGA(char* path, surface_q2_t* lightmap);
#endif