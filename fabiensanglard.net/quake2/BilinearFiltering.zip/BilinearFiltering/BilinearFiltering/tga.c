#include "tga.h"
#include "defs.h"
#include <stdio.h>
#include <string.h>

void WriteLightMapAsTGA(char* path, lightmap_t* lightmap)
{
	char header[18];
	FILE* file;

    memset (header, 0, 18);
	header[2] = 3;		// uncompressed grayscale
	header[12] = lightmap->width&255;
	header[13] = lightmap->width>>8;
	header[14] = lightmap->height&255;
	header[15] = lightmap->height>>8;
	header[16] = 8;	// pixel size



	file = fopen(path,"wb");
	fwrite(&header,sizeof(header),1,file);
	fwrite(lightmap->data,lightmap->height*lightmap->width,1,file);
	fclose(file);
}


void WriteSurfaceAsTGA(char* path, surface_t* surface)
{
	char header[18];
	FILE* file;

	int blockSize = 16 >> surface->miplevel;
	int tgaWidth = surface->widthBlock * blockSize;
	int tgaHeight = surface->heightBlock * blockSize;

    memset (header, 0, 18);
	header[2] = 3;		// uncompressed grayscale
	header[12] = tgaWidth&255;
	header[13] = tgaWidth>>8;
	header[14] = tgaHeight&255;
	header[15] = tgaHeight>>8;
	header[16] = 8;	// pixel size



	file = fopen(path,"wb");
	fwrite(&header,sizeof(header),1,file);
	fwrite(surface->data,tgaHeight*tgaWidth,1,file);
	fclose(file);
}


void WriteSurfaceQ2AsTGA(char* path, surface_q2_t* q2_surface)
{
	surface_t surface;

	surface.widthBlock = q2_surface->widthBlock;
	surface.heightBlock= q2_surface->heightBlock;
	surface.miplevel = q2_surface->miplevel;
	surface.data = q2_surface->data;

	WriteSurfaceAsTGA(path,&surface);

}