#include "TRDecreaseDensity.h"
#include "Engine.h"
#include "Timer.h"

CTRDecreaseDensity::CTRDecreaseDensity(void)
{
}

CTRDecreaseDensity::~CTRDecreaseDensity(void)
{
}

void CTRDecreaseDensity::keyPressed()
{
	Engine::engine->uniformDensity -= 0.1f * Timer::tick / (float)1000;
	printf("Engine::engine->uniformDensity=%f\n",Engine::engine->uniformDensity);
}

