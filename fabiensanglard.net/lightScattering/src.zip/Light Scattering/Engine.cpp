#include "Frustrum.h"
#include "Engine.h"

#include "Timer.h"
#include "includes.h"
#include "main.h"
#include "WaveObject.h"

// key listeners
#include "FovyExpander.h"
#include "FovyReducer.h"
#include "CTRwitchCamera.h"



#include "glex_impl.h"
#include "glInfo.h"
#include "ShaderLoader.h"
#include "TRIncreaseExposure.h"
#include "TRDecreaseExposure.h"
#include "TRIncreaseDecay.h"
#include "TRDecreaseDecay.h"
#include "TRIncreaseWeight.h"
#include "TRDecreaseWeight.h"
#include "TRIncreaseDensity.h"
#include "TRDecreaseDensity.h"
#include "Pause.h"




#define OFF_SCREEN_RENDER_RATIO 2

Engine* Engine::engine ;

Engine::Engine()
{
	fboId = 0;
	fboTextureId=0;

	engine = this;

	shaderSupported = false;

	

    glInfoObject.getInfo();
	//glInfoObject.printSelf();
	initExtensions();		// Using VBO and Shaders

	light = new Light();

	if (fboSupported)
		generateFBO();

	//fboUsed = false;
	if (!fboUsed)
		createScreenCopyTexture();

	if (shaderSupported)
	{
		ShaderLoader loader;
 	//	GLhandleARB vertexShader = loader.loadShader("vert_lightScattering.glsl",GL_VERTEX_SHADER);
	//	GLhandleARB fragmentShader = loader.loadShader("frag_lightScattering2.glsl",GL_FRAGMENT_SHADER);

		GLhandleARB vertexShader = loader.loadShader("vert_simpleTexture.glsl",GL_VERTEX_SHADER);
		GLhandleARB fragmentShader = loader.loadShader("frag_simpleTexture.glsl",GL_FRAGMENT_SHADER);

		shader = glCreateProgramObjectARB();
			
	//	printf("Light scattering shaders program id=%d, vShader=%d, fShader=%d\n",shader,vertexShader,fragmentShader);

		glAttachObjectARB(shader,vertexShader);
		glAttachObjectARB(shader,fragmentShader);
		
		glLinkProgramARB(shader);
		
		glUseProgramObjectARB(shader);

		uniformExposure = 0.0034f;
		uniformDecay = 1.0f;
		uniformDensity = 0.84f;
		uniformWeight = 5.65f;	
		
		glsl_loc_light = glGetUniformLocationARB(shader,"lightPositionOnScreen");
		glUniform2fARB(glsl_loc_light,uniformLightX,uniformLightY);

		glsl_loc_exposure = glGetUniformLocationARB(shader,"exposure");
		glUniform1fARB(glsl_loc_exposure,uniformExposure);
		
		glsl_loc_decay = glGetUniformLocationARB(shader,"decay");
		glUniform1fARB(glsl_loc_decay,uniformDecay);

		glsl_loc_density = glGetUniformLocationARB(shader,"density");
		glUniform1fARB(glsl_loc_density,uniformDensity);

		glsl_loc_weight = glGetUniformLocationARB(shader,"weight");
		glUniform1fARB(glsl_loc_weight,uniformWeight);

		glsl_loc_myTexture = glGetUniformLocationARB(shader,"myTexture");
		glUniform1iARB(glsl_loc_myTexture,screenCopyTextureId);

//		printf("glsl_loc_light=%d\n",glsl_loc_light);
//		printf("glsl_loc_exposure=%d\n",glsl_loc_exposure);
//		printf("glsl_loc_decay=%d\n",glsl_loc_decay);
//		printf("glsl_loc_density=%d\n",glsl_loc_density);
//		printf("glsl_loc_weight=%d\n",glsl_loc_weight);
//		printf("glsl_loc_light=%d\n",glsl_loc_light);
//		printf("glsl_loc_myTexture=%d\n",glsl_loc_myTexture);
	}



	gameOn = 1;

	
	drawThirdPerson = false;
	Timer::paused = false;
	


	

	
	this->tenso = new WaveObject(1, Vertex(0,0,0));
	//this->tenso->load("CUBE.OBJ");
	this->tenso->load("TENSO.OBJ");
	//this->tenso->load("dragon_Scene.obj");
	//this->tenso->load("audi_tt_et_toit_Scene.obj");
	this->tenso->buildBsp();

	ikal  = new WaveObject(3.8f,Vertex(0,0,10));//new WaveObject(2.8f, Vertex(-500,0,-500));
	this->ikal->load("IKAL.OBJ");
	ikal->position = Vertex(-30,70,-3000);

	this->sky1 = new WaveObject(1, Vertex(0,0,0));
	this->sky1->load("SKY1.OBJ");
	this->sky2 = new WaveObject(1, Vertex(0,0,0));
	this->sky2->load("SKY2.OBJ");

	Vertex camera1Position = Vertex(-10,00,60); //560
	Vertex camera1LookAt = Vertex(-1000,600,-2000);
	firstPerson = new Camera(renderWidth,renderHeight,camera1Position,camera1LookAt, 10 ,100000);

	
	
	Vertex camera2Position = Vertex(1000,1000,0);//-30,-30,50);
	Vertex camera2LookAt = Vertex(-46,184,1-1086);
	observer = new Camera(renderWidth,renderHeight,camera2Position,camera2LookAt,0.1f,100000);

	keyboard.addListener(SDLK_DELETE,new FovyExpander());
	keyboard.addListener(SDLK_INSERT,new FovyReducer());

	keyboard.addListener(SDLK_w,new CTRIncreaseExposure());
	keyboard.addListener(SDLK_s,new CTRDecreaseExposure());
	keyboard.addListener(SDLK_e,new CTRIncreaseDecay());
	keyboard.addListener(SDLK_d,new CTRDecreaseDecay());
	keyboard.addListener(SDLK_r,new CTRIncreaseWeight());
	keyboard.addListener(SDLK_f,new CTRDecreaseWeight());
	keyboard.addListener(SDLK_t,new CTRIncreaseDensity());
	keyboard.addListener(SDLK_g,new CTRDecreaseDensity());
	keyboard.addListener(SDLK_SPACE,new Pause());

}


///////////////////////////////////////////////////////////////////////////////
// write 2d text using GLUT
// The projection matrix must be set to orthogonal before call this function.
///////////////////////////////////////////////////////////////////////////////
void drawString(const char *str, int x, int y)
{
	static const float color[4] = {1, 1, 1, 1};	
    glColor4fv(color);          // set text color
    glRasterPos2i(x, y);        // place text position

    // loop all characters in the string
    while(*str)
    {
        glutBitmapCharacter(GLUT_BITMAP_8_BY_13, *str);
        ++str;
    }
}

void Engine::getLightScreenCoor()
{
	double modelView[16];
    double projection[16];
    GLint viewport[4];
    double depthRange[2];

	glGetDoublev(GL_MODELVIEW_MATRIX, modelView);
    glGetDoublev(GL_PROJECTION_MATRIX, projection);
    glGetIntegerv(GL_VIEWPORT, viewport);
    glGetDoublev(GL_DEPTH_RANGE, depthRange);

	GLdouble winX=0;
	GLdouble winY=0;
	GLdouble winZ=0;

	gluProject(	light->lightPosition[0],
				light->lightPosition[1],
				light->lightPosition[2],
				modelView,
				projection,
				viewport,
				&winX,
				&winY,
				&winZ);
	
	
	uniformLightX = winX/((float)renderWidth/OFF_SCREEN_RENDER_RATIO);
	uniformLightY = winY/((float)renderHeight/OFF_SCREEN_RENDER_RATIO) ;

	//printf("Light position zz xo=%f, yo=%f, x=%f, y=%f\n",winX,winY,uniformLightX,uniformLightY);

	/*

		 // Get the matrices and viewport
    double modelView[16];
    double projection[16];
    double viewport[4];
    double depthRange[2];

    glGetDoublev(GL_MODELVIEW_MATRIX, modelView);
    glGetDoublev(GL_PROJECTION_MATRIX, projection);
    glGetDoublev(GL_VIEWPORT, viewport);
    glGetDoublev(GL_DEPTH_RANGE, depthRange);

    // Compose the matrices into a single row-major transformation
    Vector4 T[4];
    int r, c, i;
    for (r = 0; r < 4; ++r) {
        for (c = 0; c < 4; ++c) {
            T[r][c] = 0;
            for (i = 0; i < 4; ++i) {
                // OpenGL matrices are column major
                T[r][c] += projection[r + i * 4] * modelView[i + c * 4];
            }
        }
    }

    // Transform the vertex
    Vector4 result;
    for (r = 0; r < 4; ++r) {
        result[r] = T[r].dot(v);
    }

    // Homogeneous divide
    const double rhw = 1 / result.w;

    return Vector4(
        (1 + result.x * rhw) * viewport[2] / 2 + viewport[0],
        (1 - result.y * rhw) * viewport[3] / 2 + viewport[1],
        (result.z * rhw) * (depthRange[1] - depthRange[0]) + depthRange[0],
        rhw);
} 


	*/

	
}


char* fps = (char*)malloc(10 * sizeof(char));
char* polyCount = (char*)malloc(30 * sizeof(char));
char* s_textSwitchs = (char*)malloc(30 * sizeof(char));
char* s_extensions = (char*)malloc(40 * sizeof(char));


float positionz=0;
void Engine::render()
{
	//fflush(stdout);
	//cout << "salut" << std::endl;
	//printf("\nStarting rendition-----------------------------\n");

	polygonRendered = 0;
	textureSwitchs = 0;

	
   
	if (drawThirdPerson)
		observer->setupPerspective();
	else
		 firstPerson->setupPerspective();
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
	if (drawThirdPerson)
		observer->apply();
   else
	   firstPerson->apply();
	 

	// If there is a FBO, rendering to offscreen buffer via FrameBuffer
    if (fboUsed)
		glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, fboId);


	glClear ( GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT );
	

	glColor4f(1,1,1,1);
	

	  

	glViewport(0,0,renderWidth/OFF_SCREEN_RENDER_RATIO,renderHeight/OFF_SCREEN_RENDER_RATIO);
	glDisable(GL_TEXTURE_2D);
		glPushMatrix();
			glTranslatef(light->lightPosition[0],light->lightPosition[1],light->lightPosition[2]);
			light->render();
		glPopMatrix();
		getLightScreenCoor();
	
	
	// Draw occuding source black with light
				glUseProgramObjectARB(0);

				
				glEnable(GL_TEXTURE_2D);
				glColor4f(0,0,0,1);
				glPushMatrix();
					tenso->render();
			    glPopMatrix();

			   glPushMatrix();
					glTranslatef(ikal->position.x,ikal->position.y,ikal->position.z);
					glRotatef(180,0,1,0);
					glRotatef(ikal->eulerRotation.z,0,0,1);
					ikal->render();
			   glPopMatrix();
			   // Make sky a bit more visible
			   //glColor4f(0.19f,0.19f,0.19f,1);
			   //sky1->render();
			  // glPushMatrix();
			//		glRotatef(180,1,0,0);
			//		sky1->render();
			//	glPopMatrix();

	
			// Save screen or Switch to normal rendering
			if (fboUsed)
				glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
			else
				copyFrameBufferToTexture();

	glViewport(0,0,renderWidth,renderHeight);
	glEnable(GL_TEXTURE_2D);
	
	
	// Render the scene with no light scattering
			
	
	glClear (GL_COLOR_BUFFER_BIT  | GL_DEPTH_BUFFER_BIT);
	
			glColor4f(1,1,1,1);
			glPushMatrix();
				tenso->render();
		   glPopMatrix();

		   glPushMatrix();
				glTranslatef(ikal->position.x,ikal->position.y,ikal->position.z);
				glRotatef(180,0,1,0);
				glRotatef(ikal->eulerRotation.z,0,0,1);
				ikal->render();
			glPopMatrix();
		  
		   //sky1->render();
		   glPushMatrix();
				glRotatef(180,1,0,0);
				sky1->render();
			glPopMatrix();
	
	//glDisable(GL_BLEND);


	// Paint the light scaterring effect
	
			glMatrixMode(GL_PROJECTION);
			glLoadIdentity();
			glOrtho( -renderWidth/2,renderWidth/2, -renderHeight/2, renderHeight/2, 000, 50000.0 );
			glMatrixMode(GL_MODELVIEW);
			glLoadIdentity();
			glClear (GL_DEPTH_BUFFER_BIT );
	//		glViewport(0,0,renderWidth,renderHeight);
		//	glViewport(0,0,renderWidth/2,renderHeight/2);

			

			glActiveTextureARB(GL_TEXTURE0_ARB);
			if (!fboUsed)
				glBindTexture(GL_TEXTURE_2D, screenCopyTextureId);
			else
				glBindTexture(GL_TEXTURE_2D, fboTextureId);
			


			glUseProgramObjectARB(shader);
			glUniform2fARB(glsl_loc_light,uniformLightX,uniformLightY);
			glUniform1fARB(glsl_loc_exposure,uniformExposure);
			glUniform1fARB(glsl_loc_decay,uniformDecay);
			glUniform1fARB(glsl_loc_density,uniformDensity);
			glUniform1fARB(glsl_loc_weight,uniformWeight);
			glUniform1iARB(glsl_loc_myTexture,0);

				//glDisable(GL_DEPTH_TEST);
				//glDisable(GL_ALPHA_TEST);
			glEnable(GL_TEXTURE_2D);
			//glColor4f(1,1,1,1);
			glEnable(GL_BLEND);
			
			glBlendFunc(GL_SRC_ALPHA, GL_ONE);
			//glTexEnvi (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);

			 glBegin(GL_QUADS);
					 glTexCoord2f(0,0);
					 glVertex2f(-renderWidth/2,-renderHeight/2);

					glTexCoord2f(1,0);
					glVertex2f(renderWidth/2,-renderHeight/2);

					glTexCoord2f(1,1);
					glVertex2f(renderWidth/2,renderHeight/2);

					glTexCoord2f(0,1);
					glVertex2f(-renderWidth/2,renderHeight/2);	
			glEnd();

			
			//}
			//	glViewport(0,0,renderWidth,renderHeight);
	glUseProgramObjectARB(0);

	// DRAWING TEXT
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho( -renderWidth/2,renderWidth/2, -renderHeight/2, renderHeight/2, 00.1f, 600.0f );
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glTranslated(0,0,-500);

	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	//glClear ( GL_DEPTH_BUFFER_BIT );
	glDisable(GL_BLEND);
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_DEPTH_TEST);
	
	sprintf(fps,"fps: %.0f",Timer::fps );    
	sprintf(polyCount,"polygones rendered: %d",polygonRendered );    
	sprintf(s_textSwitchs,"textures switches: %d",textureSwitchs );      
    drawString(fps,renderWidth/2-250,-renderHeight/2+60);
	drawString(polyCount,renderWidth/2-250,-renderHeight/2+40);
	
	drawString(s_textSwitchs,renderWidth/2-250,-renderHeight/2+20);
	//drawString(s_extensions,-renderWidth/2+10,renderHeight/2-80);

	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glEnable(GL_DEPTH_TEST);
   // END DRAWING TEXT


	//printf("\nFinishing rendition-----------------------------\n");
}


void Engine::update()
{
	Timer::update();
	
	SDL_PumpEvents();

	SDL_Event event;
	// Check for events 

	static int oldMouseX;
	static int oldMouseY;

	while ( SDL_PollEvent (&event) ) {
		switch (event.type) {
			case SDL_QUIT:	gameOn = 0;	break;
			case SDL_MOUSEMOTION: 
								if (event.button.button == SDL_BUTTON_LEFT)
								{
									firstPerson->updateMouse(oldMouseX-event.button.x,oldMouseY-event.button.y);
									
								}
								oldMouseX = event.button.x;
								oldMouseY = event.button.y;
							
								break;
			default:		    break;
		}
	}

	Uint8 * tKeys = SDL_GetKeyState(NULL);
	readSystemEntries(tKeys);	

	keyboard.update(tKeys);

	// Update camera according to keys
	firstPerson->update(tKeys);
	
	//observer->lookAt = firstPerson->position;

	
	
	ikal->position.z += Timer::tick /5.0f;
	ikal->position.x -= Timer::tick /220.0f;
	ikal->eulerRotation.z += Timer::tick /10.0f;

	firstPerson->position.z += Timer::tick /20.0f;
	//firstPerson->position.x -= Timer::tick /200.0f;
	firstPerson->frustrum->update();
 }





void Engine::run ()
{
	
	

    while (gameOn ) 
	{
		update();
		render ();
		
        SDL_GL_SwapBuffers ();
	}
}

void Engine::readSystemEntries(Uint8 * tKeys)
{
	if (tKeys[SDLK_ESCAPE] || tKeys[SDLK_q]) 
			gameOn = false;
	
	//if (tKeys[SDLK_SLASH])
	//	Timer::paused = true;

	//if (Timer::paused && !tKeys[SDLK_SLASH])
	//	Timer::paused = false;
}


void Engine::createScreenCopyTexture()
{
	int width = renderWidth;
	int height = renderHeight;
	

	char* emptyData = (char*)malloc(width * height * 3 * sizeof(char));
		  memset(emptyData,0,width * height * 3 * sizeof(char));

	glActiveTextureARB(GL_TEXTURE0);
	glGenTextures(1, &screenCopyTextureId);
	glBindTexture(GL_TEXTURE_2D, screenCopyTextureId); // Binding of texture name 
	glTexImage2D( GL_TEXTURE_2D, 0, GL_RGB, width,height, 0, GL_RGB,GL_UNSIGNED_BYTE,emptyData); // Texture specification 
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); // We will use linear      interpolation for magnification filter 
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); // We will use linear      interpolation for minifying filter 

	free(emptyData);

	//printf("Offscreen texture id=%d\n",screenCopyTextureId);
}

void Engine::copyFrameBufferToTexture()
{
	glBindTexture(GL_TEXTURE_2D,screenCopyTextureId);
	glCopyTexSubImage2D(GL_TEXTURE_2D,0,0,0,0,0,renderWidth,renderHeight);
}


void Engine::generateFBO()
{
	int offScreenWidth = renderWidth/OFF_SCREEN_RENDER_RATIO;
	int offScreenHeight = renderHeight/OFF_SCREEN_RENDER_RATIO;



	glGenTextures(1, &fboTextureId);
	glBindTexture(GL_TEXTURE_2D, fboTextureId);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	//glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	//glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE); // automatic mipmap
	//glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, TEXTURE_WIDTH, TEXTURE_HEIGHT, 0, GL_RGBA, GL_UNSIGNED_BYTE, 0);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, offScreenWidth, offScreenHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, 0);
	glBindTexture(GL_TEXTURE_2D, 0);

	// create a renderbuffer object to store depth info
	GLuint rboId;
	glGenRenderbuffersEXT(1, &rboId);
	glBindRenderbufferEXT(GL_RENDERBUFFER_EXT, rboId);
	//glRenderbufferStorageEXT(GL_RENDERBUFFER_EXT, GL_DEPTH_COMPONENT,TEXTURE_WIDTH, TEXTURE_HEIGHT);
	glRenderbufferStorageEXT(GL_RENDERBUFFER_EXT, GL_DEPTH_COMPONENT,offScreenWidth, offScreenHeight);
	glBindRenderbufferEXT(GL_RENDERBUFFER_EXT, 0);

	// create a framebuffer object
	glGenFramebuffersEXT(1, &fboId);
	glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, fboId);

	// attach the texture to FBO color attachment point
	glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT, GL_COLOR_ATTACHMENT0_EXT,GL_TEXTURE_2D, fboTextureId, 0);
	// attach the renderbuffer to depth attachment point
	glFramebufferRenderbufferEXT(GL_FRAMEBUFFER_EXT, GL_DEPTH_ATTACHMENT_EXT,GL_RENDERBUFFER_EXT, rboId);

	// check FBO status
	GLenum status = glCheckFramebufferStatusEXT(GL_FRAMEBUFFER_EXT);
	if(status != GL_FRAMEBUFFER_COMPLETE_EXT)
	{
		fboUsed = false;
		printf("GL_FRAMEBUFFER_COMPLETE_EXT failed, CANNOT use FBO\n");
	}
	else
	{
		fboUsed = true;
		//printf("GL_FRAMEBUFFER_COMPLETE_EXT OK, using FBO\n");
	//	printf("fbo offScreenWidth =%d\n",offScreenWidth);
	//	printf("fbo offScreenHeight =%d\n",offScreenHeight);
	//	printf("fbo texture id=%d\n",fboTextureId);
	//	printf("fbo id=%d\n",fboId);
	//	printf("fbo's rbo id=%d\n",rboId);
	}
	// switch back to window-system-provided framebuffer
	glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);



	
}

