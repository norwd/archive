#pragma once
#include "keyboardkeyhander.h"

class FovyExpander : public KeyboardKeyHander
{
public:
	FovyExpander(void);
	~FovyExpander(void);

	virtual void onKeyPressed() ;

};
