#pragma once

#include "3DDefinitions.h"
#include "includes.h"

class Light
{
public:
	Light(void);
	~Light(void);

	void apply(void);
	void render(void);
	void update(void);

	GLfloat lightPosition[4];

	GLfloat diffuseProperty[3];
	GLfloat ambiantProperty[4];
	GLfloat speculaProperty[4];

	GLfloat materialDiffuseProp[4];

	GLuint dList;

};
