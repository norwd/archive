#include "FovyReducer.h"
#include "Frustrum.h"
#include "Engine.h"


FovyReducer::FovyReducer(void){}

FovyReducer::~FovyReducer(void){}

void FovyReducer::onKeyPressed()
{
	Engine::engine->firstPerson->fovy--;
	Engine::engine->firstPerson->frustrum->update();
}

