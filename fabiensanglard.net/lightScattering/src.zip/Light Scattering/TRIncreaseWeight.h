#pragma once
#include "keyboardkeyhander.h"

class CTRIncreaseWeight :
	public KeyboardKeyHander
{
public:
	CTRIncreaseWeight(void);
	~CTRIncreaseWeight(void);
	virtual void keyPressed() ;
};
