#include "FovyExpander.h"
#include "Frustrum.h"
#include "Engine.h"


FovyExpander::FovyExpander(void){}
FovyExpander::~FovyExpander(void){}

void FovyExpander::onKeyPressed()
{
	Engine::engine->firstPerson->fovy++;
	Engine::engine->firstPerson->frustrum->update();
}

