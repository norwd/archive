#pragma once
#include "keyboardkeyhander.h"

class CTRDecreaseWeight :
	public KeyboardKeyHander
{
public:
	CTRDecreaseWeight(void);
	~CTRDecreaseWeight(void);
	virtual void keyPressed() ;
};
