#include "TRIncreaseDensity.h"
#include "Engine.h"
#include "Timer.h"

CTRIncreaseDensity::CTRIncreaseDensity(void)
{
}

CTRIncreaseDensity::~CTRIncreaseDensity(void)
{
}

void CTRIncreaseDensity::keyPressed()
{
	Engine::engine->uniformDensity += 0.1f * Timer::tick / (float)1000;
	printf("Engine::engine->uniformDensity=%f\n",Engine::engine->uniformDensity);
}
