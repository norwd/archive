#pragma once
#include "keyboardkeyhander.h"

class FovyReducer :public KeyboardKeyHander
{
public:
	FovyReducer(void);
	~FovyReducer(void);


	virtual void onKeyPressed() ;

};
