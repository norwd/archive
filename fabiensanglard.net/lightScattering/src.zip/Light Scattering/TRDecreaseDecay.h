#pragma once
#include "keyboardkeyhander.h"

class CTRDecreaseDecay :
	public KeyboardKeyHander
{
public:
	CTRDecreaseDecay(void);
	~CTRDecreaseDecay(void);

	virtual void keyPressed() ;
};
