#pragma once
#include "keyboardkeyhander.h"

class CTRIncreaseExposure : public KeyboardKeyHander
{
public:
	CTRIncreaseExposure(void);
	~CTRIncreaseExposure(void);

	virtual void keyPressed() ;
};
