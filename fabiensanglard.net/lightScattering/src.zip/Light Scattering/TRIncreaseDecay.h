#pragma once
#include "keyboardkeyhander.h"

class CTRIncreaseDecay :
	public KeyboardKeyHander
{
public:
	CTRIncreaseDecay(void);
	~CTRIncreaseDecay(void);

	virtual void keyPressed() ;
};
