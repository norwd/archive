#ifndef CAMERA

#define CAMERA 1

#include "3DDefinitions.h"
#include "SDL.h"

class Frustrum;



class Camera
{
	public:

		Camera(int renderWith, int renderHeight, Vertex& positionIn, Vertex& lookAtIn, float nearZ, float farZ);
		~Camera();
		
		void setupPerspective();

		void apply();
		void update(Uint8 * tKeys);
		void updateMouse(int deltax,int deltay);
		void render();
		void print();

		Vertex position;
		Vertex lookAt;

		Vertex upVector ;

		// Frustrum definition
		float fovy;
		float aspect;
		float zNear;
		float zFar;

		void updateFrustrum();
		Frustrum* frustrum;
} ;

#endif
