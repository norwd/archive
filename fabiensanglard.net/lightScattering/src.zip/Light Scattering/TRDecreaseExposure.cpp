#include "TRDecreaseExposure.h"
#include "Engine.h"
#include "Timer.h"

CTRDecreaseExposure::CTRDecreaseExposure(void)
{
}

CTRDecreaseExposure::~CTRDecreaseExposure(void)
{
}

void CTRDecreaseExposure::keyPressed()
{
	Engine::engine->uniformExposure -= 0.1f * Timer::tick / (float)1000;
	printf("Engine::engine->uniformExposure=%f\n",Engine::engine->uniformExposure);
}

