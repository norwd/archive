#include <string>
#include <vector>
#include <fstream>
#include <iostream>
#include <iomanip>
#include "math.h"
#include <algorithm>
using namespace std;



#include <GLUT/glut.h>

#ifdef _WIN32
//string WaveObject::pathContext = string("D:\\home\\c++ ressources\\");
#define RESSOURCE_PATH  ".\\ressources\\"
#else
#define RESSOURCE_PATH  "bsp.app/Contents/Resources/"
#endif