#include "Camera.h"
#include "includes.h"
#include "Timer.h"
#include "Frustrum.h"

Camera::Camera(int renderWith, int renderHeight,Vertex& positionIn, Vertex& lookAtIn, float zNearIn, float aFarin)
{
	position.x = positionIn.x;
	position.y = positionIn.y;
	position.z = positionIn.z;

	lookAt.x=lookAtIn.x;
	lookAt.y=lookAtIn.y;
	lookAt.z=lookAtIn.z;

	upVector = Vertex(0,1,0);

	fovy = 55;
	aspect = (float)renderWith/renderHeight;
	zNear = zNearIn;
	zFar = aFarin;

	frustrum = new Frustrum(this);
	frustrum->update();
}
Camera::~Camera() {}

void Camera::updateFrustrum()
{
	frustrum->update();
}

void Camera::apply()
{
	gluLookAt(position.x,position.y,position.z,lookAt.x,lookAt.y,lookAt.z,upVector.x,upVector.y,upVector.z);

}
void Camera::update(Uint8 * tKeys)
{
	if (tKeys[SDLK_UP])
	{
		Vertex direction = lookAt - position;
		direction.normalize();
		position =  position + (direction * 0.1f * Timer::tick);
		lookAt = lookAt + (direction * 0.1f * Timer::tick);

		frustrum->update();

		print();
	}	

	if (tKeys[SDLK_DOWN])
	{
		Vertex direction = lookAt - position;
		direction.normalize();
		position =  position - (direction * 0.1f * Timer::tick);
		lookAt = lookAt - (direction * 0.1f * Timer::tick);

		frustrum->update();
		print();
	}	

	if (tKeys[SDLK_LEFT])
	{
		Vertex direction = lookAt - position;
		direction.normalize();
		direction.rotateY(90);
		position =  position - (direction * 0.1f * (Timer::tick));
		lookAt = lookAt - (direction *0.1f *  Timer::tick);

		frustrum->update();
		print();
	}

	if (tKeys[SDLK_RIGHT])
	{
		Vertex direction = lookAt - position;
		direction.normalize();
		direction.rotateY(-90);
		position =  position - (direction * 0.1f * (Timer::tick));
		lookAt = lookAt - (direction * 0.1f * Timer::tick);

		frustrum->update();
		print();
	}
}

int leftButtonClicked = 0;

void Camera::updateMouse(int deltax,int deltay)
{
	if (deltax == 0 && deltay==0)
		return;

	lookAt.rotateY(-deltax);

	if (lookAt.x < 0)
		deltay=-deltay;
	lookAt.rotateX(-deltay);
	frustrum->update();
}

void Camera::render()
{
	glColor4f(0,0,1,0.7f);
	glDisable(GL_TEXTURE_2D);
	//glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	
	// Near
	glBegin(GL_QUADS);
		glVertex3f(frustrum->viewingVolume[NBR].x,
				   frustrum->viewingVolume[NBR].y,
				   frustrum->viewingVolume[NBR].z);

		glVertex3f(frustrum->viewingVolume[NTR].x,
				   frustrum->viewingVolume[NTR].y,
				   frustrum->viewingVolume[NTR].z);

		glVertex3f(frustrum->viewingVolume[NTL].x,
				   frustrum->viewingVolume[NTL].y,
				   frustrum->viewingVolume[NTL].z);

		glVertex3f(frustrum->viewingVolume[NBL].x,
				   frustrum->viewingVolume[NBL].y,
				   frustrum->viewingVolume[NBL].z);
	glEnd();

	//Far
	glBegin(GL_QUADS);
		glVertex3f(frustrum->viewingVolume[FBR].x,
				   frustrum->viewingVolume[FBR].y,
				   frustrum->viewingVolume[FBR].z);

		glVertex3f(frustrum->viewingVolume[FTR].x,
				   frustrum->viewingVolume[FTR].y,
				   frustrum->viewingVolume[FTR].z);

		glVertex3f(frustrum->viewingVolume[FTL].x,
				   frustrum->viewingVolume[FTL].y,
				   frustrum->viewingVolume[FTL].z);

		glVertex3f(frustrum->viewingVolume[FBL].x,
				   frustrum->viewingVolume[FBL].y,
				   frustrum->viewingVolume[FBL].z);
	glEnd();



	// Right

glBegin(GL_QUADS);
		glVertex3f(frustrum->viewingVolume[FBR].x,
				   frustrum->viewingVolume[FBR].y,
				   frustrum->viewingVolume[FBR].z);

		glVertex3f(frustrum->viewingVolume[FTR].x,
				   frustrum->viewingVolume[FTR].y,
				   frustrum->viewingVolume[FTR].z);

		glVertex3f(frustrum->viewingVolume[NTR].x,
				   frustrum->viewingVolume[NTR].y,
				   frustrum->viewingVolume[NTR].z);

		glVertex3f(frustrum->viewingVolume[NBR].x,
				   frustrum->viewingVolume[NBR].y,
				   frustrum->viewingVolume[NBR].z);

glEnd();

	//Left
glBegin(GL_QUADS);
		glVertex3f(frustrum->viewingVolume[FBL].x,
				   frustrum->viewingVolume[FBL].y,
				   frustrum->viewingVolume[FBL].z);

		glVertex3f(frustrum->viewingVolume[FTL].x,
				   frustrum->viewingVolume[FTL].y,
				   frustrum->viewingVolume[FTL].z);

		glVertex3f(frustrum->viewingVolume[NTL].x,
				   frustrum->viewingVolume[NTL].y,
				   frustrum->viewingVolume[NTL].z);

		glVertex3f(frustrum->viewingVolume[NBL].x,
				   frustrum->viewingVolume[NBL].y,
				   frustrum->viewingVolume[NBL].z);

glEnd();

// Top
glBegin(GL_QUADS);
		glVertex3f(frustrum->viewingVolume[FTL].x,
				   frustrum->viewingVolume[FTL].y,
				   frustrum->viewingVolume[FTL].z);

		glVertex3f(frustrum->viewingVolume[FTR].x,
				   frustrum->viewingVolume[FTR].y,
				   frustrum->viewingVolume[FTR].z);

		glVertex3f(frustrum->viewingVolume[NTR].x,
				   frustrum->viewingVolume[NTR].y,
				   frustrum->viewingVolume[NTR].z);

		glVertex3f(frustrum->viewingVolume[NTL].x,
				   frustrum->viewingVolume[NTL].y,
				   frustrum->viewingVolume[NTL].z);

glEnd();

// Bottom
glBegin(GL_QUADS);
		glVertex3f(frustrum->viewingVolume[FBL].x,
				   frustrum->viewingVolume[FBL].y,
				   frustrum->viewingVolume[FBL].z);

		glVertex3f(frustrum->viewingVolume[FBR].x,
				   frustrum->viewingVolume[FBR].y,
				   frustrum->viewingVolume[FBR].z);

		glVertex3f(frustrum->viewingVolume[NBR].x,
				   frustrum->viewingVolume[NBR].y,
				   frustrum->viewingVolume[NBR].z);

		glVertex3f(frustrum->viewingVolume[NBL].x,
				   frustrum->viewingVolume[NBL].y,
				   frustrum->viewingVolume[NBL].z);

glEnd();

	//glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_TEXTURE_2D);
	glColor3f(1,1,1);
}


void Camera::setupPerspective()
{
	glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
	gluPerspective(fovy,aspect,zNear,zFar);
}


void Camera::print()
{
	//printf("Camera position: x=%f,y=%f,z=%f : lookat: x=%f,y=%f,z=%f\n",position.x,position.y,position.z,lookAt.x,lookAt.y,lookAt.z);
}
