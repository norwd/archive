#include "TRDecreaseWeight.h"
#include "Engine.h"
#include "Timer.h"

CTRDecreaseWeight::CTRDecreaseWeight(void)
{
}

CTRDecreaseWeight::~CTRDecreaseWeight(void)
{
}

void CTRDecreaseWeight::keyPressed()
{
	Engine::engine->uniformWeight -= 0.1f * Timer::tick / (float)1000;
	printf("Engine::engine->uniformWeight=%f\n",Engine::engine->uniformWeight);
}
