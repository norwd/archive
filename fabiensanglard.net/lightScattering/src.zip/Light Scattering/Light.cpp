#include "Light.h"
#include "includes.h"

Light::Light(void)
{
	lightPosition[0] = -500.0f; //x 
	lightPosition[1] = 500.0f; //y 
	lightPosition[2] = 0.0f; //z 
	lightPosition[3] = 1.0f; //w 
	
	
	diffuseProperty[0] = 1.0f ; //y
	diffuseProperty[1] = 1.0f ; //y
	diffuseProperty[2] = 1.0f ; //z
	

	materialDiffuseProp[0] = 1.0f;//x
	materialDiffuseProp[1] = 1.0f;//y
	materialDiffuseProp[2] = 1.0f;//z
	materialDiffuseProp[3] = 1.0f;//q

	dList = glGenLists(1);
	glNewList(dList,GL_COMPILE);

		glColor4f(diffuseProperty[0],diffuseProperty[1],diffuseProperty[2],1);
		glutSolidSphere(45,40,40);

	// endList
	glEndList();
}

Light::~Light(void)
{
	

}


void Light::apply(void)
{

	//glLightfv (GL_LIGHT0, GL_DIFFUSE, diffuseProperty); 
	//glMaterialfv(GL_FRONT, GL_DIFFUSE, materialDiffuseProp );
	//glLightfv(GL_LIGHT0, GL_POSITION, lightPosition);
}

void Light::render()
{
	glCallList(dList);
	
}