#pragma once
#include "keyboardkeyhander.h"

class CTRDecreaseDensity :
	public KeyboardKeyHander
{
public:
	CTRDecreaseDensity(void);
	~CTRDecreaseDensity(void);
	virtual void keyPressed() ;
};
