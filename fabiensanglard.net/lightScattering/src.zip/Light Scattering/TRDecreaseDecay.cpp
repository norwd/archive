#include "TRDecreaseDecay.h"
#include "Engine.h"
#include "Timer.h"

CTRDecreaseDecay::CTRDecreaseDecay(void)
{
}

CTRDecreaseDecay::~CTRDecreaseDecay(void)
{
}

void CTRDecreaseDecay::keyPressed()
{
	Engine::engine->uniformDecay -= 0.1f * Timer::tick / (float)1000;
	printf("Engine::engine->uniformDecay=%f\n",Engine::engine->uniformDecay);
}

