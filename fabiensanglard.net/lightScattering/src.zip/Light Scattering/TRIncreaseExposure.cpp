#include "TRIncreaseExposure.h"
#include "Engine.h"
#include "Timer.h"

CTRIncreaseExposure::CTRIncreaseExposure(void)
{
}

CTRIncreaseExposure::~CTRIncreaseExposure(void)
{
}


void CTRIncreaseExposure::keyPressed()
{
	Engine::engine->uniformExposure += 0.1f * Timer::tick / (float)1000;
	printf("Engine::engine->uniformExposure=%f\n",Engine::engine->uniformExposure);
}
