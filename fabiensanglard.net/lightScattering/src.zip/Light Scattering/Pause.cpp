#include "Pause.h"
#include "Timer.h"

Pause::Pause(void)
{
}

Pause::~Pause(void)
{
}

void Pause::onKeyPressed()
{


		Timer::paused = !Timer::paused;
	
	
}
