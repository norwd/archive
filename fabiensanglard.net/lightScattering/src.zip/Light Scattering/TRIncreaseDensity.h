#pragma once
#include "keyboardkeyhander.h"

class CTRIncreaseDensity :
	public KeyboardKeyHander
{
public:
	CTRIncreaseDensity(void);
	~CTRIncreaseDensity(void);
	virtual void keyPressed() ;
};
