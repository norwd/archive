#include "TRIncreaseDecay.h"
#include "Engine.h"
#include "Timer.h"

CTRIncreaseDecay::CTRIncreaseDecay(void)
{
}

CTRIncreaseDecay::~CTRIncreaseDecay(void)
{
}

void CTRIncreaseDecay::keyPressed()
{
	Engine::engine->uniformDecay += 0.1f * Timer::tick / (float)1000;
	printf("Engine::engine->uniformDecay=%f\n",Engine::engine->uniformDecay);
}