#pragma once

#include "SDL.h"
#include "Camera.h"
#include "WaveObject.h"
#include "KeyBoardListener.h"
#include "glex_impl.h"
#include "glInfo.h"
#include "Light.h"


#define SHADER_LIGHT_SCATTERING 0

class Engine
{
	public:

		Engine();
		
		void mainLoop ();
		void render();
		void run();
		
		static Engine* engine ;

		Camera* firstPerson;
		Camera* observer;

		Light* light;

		bool drawThirdPerson;

		int polygonRendered;
		int textureSwitchs;

		glInfo glInfoObject;

		bool shaderSupported;
		GLhandleARB shader;

		// FBO flags
		bool fboSupported;
		bool fboUsed;

		float uniformLightX ;
		float uniformLightY ;
		float uniformExposure;
		float uniformDecay;
		float uniformDensity;
		float uniformWeight;
		GLuint fboId;

	private:
		
		short gameOn ;
		void update();
		void readSystemEntries(Uint8 * tKeys);

		WaveObject* tenso;
		WaveObject* sky1;
		WaveObject* sky2;
		WaveObject* ikal;

		KeyBoardListener keyboard ;

		void getLightScreenCoor();

		unsigned int glsl_loc_light;
		unsigned int glsl_loc_exposure;
		unsigned int glsl_loc_decay;
		unsigned int glsl_loc_density;
		unsigned int glsl_loc_weight;
		unsigned int glsl_loc_myTexture;


		// OldSchool offScreen
		void createScreenCopyTexture();
		GLuint screenCopyTextureId;
		void copyFrameBufferToTexture();

		// FBO
		void generateFBO();
		GLuint fboTextureId;
} ;