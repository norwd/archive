#pragma once
#include "keyboardkeyhander.h"

class CTRDecreaseExposure :
	public KeyboardKeyHander
{
public:
	CTRDecreaseExposure(void);
	~CTRDecreaseExposure(void);

	virtual void keyPressed() ;
};
