<?php footnote_gen_references(); ?>
 <hr>
 <center>*