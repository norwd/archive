#include "Entity.h"

Entity::Entity(void)
{
}

Entity::~Entity(void)
{
}
