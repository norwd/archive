#include <string>
#include <vector>
#include <fstream>
#include <iostream>
#include <iomanip>
#include "math.h"
#include <algorithm>
#include <map>
using namespace std;



#include <GLUT/glut.h>

#ifdef _WIN32
//string WaveObject::pathContext = string("D:\\home\\c++ ressources\\");
#define RESSOURCE_PATH  ".\\shaders\\"
#else
#define RESSOURCE_PATH  "./"
#endif


