#include "CreatureShader.h"


CreatureShader::CreatureShader(char* vertexShader, char* fragmentShader) : ShadowShader(vertexShader,fragmentShader)
{
	shadowMapUniform = glGetUniformLocationARB(shaderId,"ShadowMap");
	shadowMapBackUniform = glGetUniformLocationARB(shaderId,"BackShadowMap");

	diffuseTextureUniform = glGetUniformLocationARB(shaderId,"diffuseTexture");
	specularTextureUniform = glGetUniformLocationARB(shaderId,"specularTexture");
	normalTextureUniform = glGetUniformLocationARB(shaderId,"normalTexture");

	tangentLoc = glGetAttribLocationARB(shaderId, "tangent");
	printf("tangentLoc = %d\n",tangentLoc);

	printf("shadowMapUniform = %d\n",shadowMapUniform);

	printf("shadowMapBackUniform = %d\n",shadowMapBackUniform);

	printf("diffuseTextureUniform = %d\n",diffuseTextureUniform);

	printf("specularTextureUniform = %d\n",specularTextureUniform);

	printf("normalTextureUniform = %d\n",normalTextureUniform);

}

CreatureShader::~CreatureShader(void)
{
}

void CreatureShader::enable()
{
	ShadowShader::enable();
	
	glUniform1iARB(diffuseTextureUniform,1);
	glUniform1iARB(specularTextureUniform,2);
	glUniform1iARB(normalTextureUniform,3);
	glUniform1iARB(shadowMapUniform,0);
	glUniform1iARB(shadowMapBackUniform,7);
	glEnableVertexAttribArrayARB (tangentLoc);
}


void CreatureShader::setCurrentModel(md5Object* object)
{
	
	
	//glVertexAttribPointerARB (tangentLoc, 
	//							3, 
	//							GL_FLOAT, 
	//							GL_FALSE,
	//							0, 
	//							object->tangentArraySkin[(int)object->animCursor]);
								
}

