#pragma once
#include "ShadowShader.h"

class EnvShader : public ShadowShader
{
public:
	EnvShader(const char* vertexShader, const char* fragmentShader);
	~EnvShader(void);
	virtual void enable();
	//virtual void bindUniformsAndAttribute(void);
};
