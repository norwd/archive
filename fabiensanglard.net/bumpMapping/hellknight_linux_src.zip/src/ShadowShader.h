#pragma once
#include "ShaderProgram.h"
#include "float2.h"

class ShadowShader : public ShaderProgram
{
public:
	ShadowShader(const char* vertexShader, const char* fragmentShader);
	virtual void enable();
	~ShadowShader(void);

	GLint textureUnitUniform;
	float2 textureUnit;
};
