#include "ParserMTLD.h"
#include "WaveObject.h"

ParserMTLD::ParserMTLD(WaveObject* object)
{
	this->object = object;
}

void ParserMTLD::parse(vector<string>& line)
{
	
}

