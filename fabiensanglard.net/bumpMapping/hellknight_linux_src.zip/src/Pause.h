#pragma once
#include "KeyboardKeyHander.h"

class Pause :
	public KeyboardKeyHander
{
public:
	Pause(void);
	~Pause(void);

	void onKeyPressed();
};
