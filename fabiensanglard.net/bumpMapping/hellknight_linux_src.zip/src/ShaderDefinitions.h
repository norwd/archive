#define CREATURE_VERTEX_SHADER "creature_vertexShader_shadow.glsl"
#define CREATURE_FRAGMENT_SHADER "creature_fragmentShader_shadow.glsl"

#define ENV_VERTEX_SHADER "env_vertexShader_shadow.glsl"
#define ENV_FRAGMENT_SHADER "env_fragmentShader_shadow.glsl"

#define LIGHT_SCATTERING_VERTEX_SHADER "lightScattering_vertexShader.glsl"
#define LIGHT_SCATTERING_FRAGMENT_SHADER "lightScattering_fragmentShader.glsl"
