#include "CTRwitchCamera.h"
#include "Engine.h"

CRTSwitchCamera::CRTSwitchCamera(void){}

CRTSwitchCamera::~CRTSwitchCamera(void){}


void CRTSwitchCamera::onKeyPressed() 
{
	//Engine::engine->switchCamera();
}

