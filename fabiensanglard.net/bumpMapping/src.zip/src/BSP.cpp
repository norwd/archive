#include "BSP.h"

BSP::BSP(void)
{
	front = NULL;
	back = NULL;
}

BSP::~BSP(void)
{
}
