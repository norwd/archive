package renderer.modelers;

import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.image.PixelGrabber;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.swing.JFrame;

import com.sun.corba.se.impl.naming.cosnaming.InterOperableNamingImpl;

import renderer.Modeler;
import renderer.Renderer;

public class FreeInterpolatedTunnel implements Modeler, MouseMotionListener, KeyListener
{	
	private Renderer renderer;
	
	private static int texture[] ;
	private static  final int TEXTUREWIDTH = 256;
	private static  final int TEXTUREHEIGHT = 256;
	
	private static Coordinate offSetsXY[] ;
	
	private Vector[] visPlan; 
	
	private int camHeight ; 
	private int camWidth ;

	
	
	private static Vector Origin = new Vector(0,0,-256);
	
	
	private static final float RADIUS = 1024;
	private static final float SQUARE_RADIUS = RADIUS * RADIUS;
	
	// This is done for testing, please remove that shit
	InputStreamReader isr = new InputStreamReader ( System.in );
	BufferedReader br = new BufferedReader ( isr );

	private int textureXCoordinate;

	private int textureYCoordinate;
	
	private static Image textureImage ;
	
	public FreeInterpolatedTunnel(Renderer renderer)
	{
	
		offSetsXY = new Coordinate[Renderer.renderedWidth * Renderer.renderedHeight];
		
		// This block of code grabs the texture and loads it in an array for later use..
		texture = new int[TEXTUREHEIGHT * TEXTUREHEIGHT];
		textureImage = renderer.getImage(renderer.getCodeBase(), "tex48.jpg");
		PixelGrabber pixelgrabber = new PixelGrabber(textureImage, 0, 0, TEXTUREWIDTH, TEXTUREHEIGHT, texture, 0, TEXTUREWIDTH);
        try
        {
            pixelgrabber.grabPixels();
        }
        catch(InterruptedException interruptedexception) 
       	{//Won't happen
       	}
        
		
        
        // The renderer is in charge of:
        //	- Display the raster
        // 	- Calculate the frame rate
		this.renderer = renderer;
		
		this.camHeight = Renderer.renderedHeight;
		this.camWidth = Renderer.renderedWidth;
		
		// The visPlan is the camera plan.
		this.visPlan = new Vector[camWidth*this.camHeight];
		
		// Initialization for all direction vectors
		for (int y = 0 ; y < this.camHeight ; y++)
			for (int x = 0 ; x < this.camWidth ; x++)
			{
				visPlan[x+y*camWidth] = new Vector(x - this.camWidth/2 , y - this.camHeight/2 ,-512);
				normalize(visPlan[x+y*camWidth]);
				offSetsXY[x + y * camWidth] = new Coordinate();
			}
		renderer.addMouseMotionListener(this);
		renderer.addKeyListener(this);
	}
	
	
	// Those 3 variables are here to precalculate sin and cos value.
	// This spares some CPU ressources.
	private final static double anglex = Math.PI  / 300 ;
	private final static double sinAngle =  Math.sin(anglex);
	private final static double cosAngle =  Math.cos(anglex);
	
	
	private void defalutrotate(Vector vector) {
		// Z axis
		float savecValue =vector.x; 
		vector.x = (float) (vector.x * cosAngle - vector.y * sinAngle);
		vector.y = (float) (savecValue * sinAngle + vector.y * cosAngle) ;
		
		// Y Azis
		savecValue =vector.x; 
		vector.x = (float) (vector.x * cosAngle + vector.z * sinAngle ); 
		vector.z = (float) (savecValue * -sinAngle + vector.z * cosAngle );
		
		// X Azis
		savecValue = vector.y ; 
		//vector.y = (float) (vector.y * cosAngle + vector.z * sinAngle);
		//vector.z = (float) (savecValue * -sinAngle + vector.z * cosAngle);
			
	}

	public static void normalize(Vector vector)
	{
		double length = Math.sqrt( vector.x * vector.x + vector.y * vector.y + vector.z * vector.z );
		vector.x /= length;
		vector.y /= length;
		vector.z /= length;
	}
	
	float p1;
	float p2;

	public void drawOffScreen() 
	{			
		int cursor=0;
		float stepX = 0;
		float stepY = 0;
		float pathX = 0;
		float pathY = 0;

		Origin.z += 50;
		
		for (int y = 0  ; y< camHeight ; y +=8,cursor+= 7*camWidth)
		{
			for (int x = 0 ; x < camWidth; x++,cursor++)
			{
				drawPixelAndpopulateOffSet(x,y,cursor);
				
				if ( y > 7 )
				{
					point2 = offSetsXY[cursor];
					point1 = offSetsXY[cursor- 8 * camWidth];
					
					stepX = (point2.x - point1.x) / 8F ;
					stepY = (point2.y - point1.y) / 8F ;
					
					pathX=0;
					pathY=0;
										
					for (int i = 1 ; i < 8 ; i++ )
					{
						pathX += stepX;
						pathY += stepY;
						int offSet = (int)(point1.x + pathX) % TEXTUREWIDTH ;
						offSet += ((int)((point1.y + pathY) % TEXTUREHEIGHT) * TEXTUREWIDTH) ;
						renderer.offScreenRaster[cursor - 8 * camWidth+i*camWidth] = texture[offSet];	
					}
					
				}
			}
		}
	}







	public void mouseDragged(MouseEvent arg0) {
	}

	public void mouseMoved(MouseEvent arg0) {
	}
	
	private static float a ;
	private static float b ;
	private static float c ;
	private static float delta;
	private static float t;
	private static Vector direction = null;
	private static Vector intersection = new Vector(0,0,0);
	
	private void drawPixelAndpopulateOffSet(int x, int y, int cursor)
	{
		direction = (Vector)visPlan[cursor];
		
		defalutrotate(direction); // Rotate the vector to change the direction to which this pixel is looking

		
		a = direction.x*direction.x + direction.y * direction.y;
		b = 2*(Origin.x*direction.x + Origin.y*direction.y); 
		c =  Origin.x * Origin.x + Origin.y *Origin.y  -(SQUARE_RADIUS); 

		delta =  (b*b) - (4*a*c);  
		
		t = (float)(-b - Math.sqrt(delta))/(2*a);
		

		intersection.x = direction.x * t;
		intersection.y = direction.y * t;
		intersection.z = direction.z * t;

		point1 = offSetsXY[cursor];
		
		textureYCoordinate =  (int) Math.abs(intersection.z + Origin.z)/5 ;
		point1.y = textureYCoordinate;
		textureYCoordinate = (textureYCoordinate%TEXTUREHEIGHT) ;
		
		
		textureXCoordinate =  (int) Math.abs(Math.atan2(intersection.y,intersection.x)*256/Math.PI) ;
		point1.x = textureXCoordinate;
		textureXCoordinate =  textureXCoordinate % TEXTUREWIDTH ;
		
		int offset = textureXCoordinate+textureYCoordinate*TEXTUREWIDTH ; 
		
		point1.offSet = offset;
		
		
		renderer.offScreenRaster[cursor] =  texture[offset];
	}
	
	Coordinate point1 = null;
	Coordinate point2 = null;
	
	private void displayOffset(int offS)
	{
		System.out.println("("+offS+")x="+offS%camWidth+",y="+offS/camWidth);
	}
	private void displayOffset(float offS)
	{
		displayOffset((int)offS);
	}




	public void keyTyped(KeyEvent arg0) {
	}




	public void keyPressed(KeyEvent arg0) {
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
	
			e.printStackTrace();
		}
	
		
	}




	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}

