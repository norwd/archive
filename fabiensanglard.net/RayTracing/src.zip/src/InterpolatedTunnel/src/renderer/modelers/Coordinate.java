package renderer.modelers;

public class Coordinate {

	public int x = 0; 
	public int y = 0;
	public int offSet = 0;
}
