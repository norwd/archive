package renderer.modelers;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.PixelGrabber;
import java.io.BufferedReader;
import java.io.InputStreamReader;

import renderer.Modeler;
import renderer.Renderer;

public class FreeTunnel implements Modeler
{	
	private Renderer renderer;
	
	private static int texture[] ;
	private static  final int TEXTUREWIDTH = 256;
	private static  final int TEXTUREHEIGHT = 256;
	
	private Vector[][] visPlan; 
	
	private int camHeight ; 
	private int camWidth ;

	
	
	private static Vector Origin = new Vector(0,0,-128);
	
	
	private static final float RADIUS = 128;
	private static final float SQUARE_RADIUS = RADIUS * RADIUS;
	
	// This is done for testing, please remove that shit
	InputStreamReader isr = new InputStreamReader ( System.in );
	BufferedReader br = new BufferedReader ( isr );

	private int textureXCoordinate;

	private int textureYCoordinate;
	
	public FreeTunnel(Renderer renderer)
	{
		
		// This block of code grabs the texture and loads it in an array for later use..
		texture = new int[TEXTUREHEIGHT * TEXTUREHEIGHT];
		Image textureImage = renderer.getImage(renderer.getCodeBase(), "tex48.jpg");
		PixelGrabber pixelgrabber = new PixelGrabber(textureImage, 0, 0, TEXTUREWIDTH, TEXTUREHEIGHT, texture, 0, TEXTUREWIDTH);
        try
        {
            pixelgrabber.grabPixels();
        }
        catch(InterruptedException interruptedexception) 
        	{//Won't happen
        	}
        
		
        
        // The renderer is in charge of:
        //	- Display the raster
        // 	- Calculate the frame rate
		this.renderer = renderer;
		
		this.camHeight = Renderer.renderedHeight;
		this.camWidth = Renderer.renderedWidth;
		
		// The visPlan is the camera plan.
		this.visPlan = new Vector[camWidth][this.camHeight];
		
		// Initialization for all direction vectors
		for (int y = 0 ; y < this.camHeight ; y++)
			for (int x = 0 ; x < this.camWidth ; x++)
			{
				visPlan[x][y] = new Vector(x - this.camWidth/2 , y - this.camHeight/2 ,-512);
				normalize(visPlan[x][y]);
			}
		
	}
	
	
	// Those 3 variables are here to precalculate sin and cos value.
	// This spares some CPU ressources.
	private final static double anglex = Math.PI  / 300 ;
	private final static double sinAngle =  Math.sin(anglex);
	private final static double cosAngle =  Math.cos(anglex);
	
	
	private void defalutrotate(Vector vector) {
// TODO Fix this nasty bug !!!!!
		
		// Z axis
		float oldX =vector.x; 
		//vector.x = (float) (vector.x * cosAngle - vector.y * sinAngle);
		//vector.y = (float) (oldX * sinAngle + vector.y * cosAngle) ;
		
		// Y Azis
		oldX =vector.x; 
		vector.x = (float) (vector.x * cosAngle + vector.z * sinAngle ); 
		vector.z = (float) (oldX * -sinAngle + vector.z * cosAngle );
		
		// X Azis
		float oldY = vector.y ; 
		vector.y = (float) (vector.y * cosAngle + vector.z * sinAngle);
		vector.z = (float) (oldY * -sinAngle + vector.z * cosAngle);
			
	}
	
	
	

	public static void normalize(Vector vector)
	{
		double length = Math.sqrt( vector.x * vector.x + vector.y * vector.y + vector.z * vector.z );
		vector.x /= length;
		vector.y /= length;
		vector.z /= length;
	}
	
	
	private static float a ;
	private static float b ;
	private static float c ;
	private static float delta;
	private static float t;
	private static Vector direction = null;
	private static Vector intersection = new Vector(0,0,0);

	
	public void drawOffScreen() 
	{
		
		Origin.z -= 7;  // This makes up move forward in the tunnel
		
		for (int y = 0,cursor=0 ; y< this.camHeight ; y++)
		{
			
			
			for (int x = 0 ; x < this.camWidth ; x++)
			{
				
				if (true)
				{
				direction = (Vector)visPlan[x][y];
				
				defalutrotate(direction); // Rotate the vector to change the direction to which this pixel is looking
				
				a = direction.x*direction.x + direction.y * direction.y;
				b = 2*(Origin.x*direction.x + Origin.y*direction.y); 
				c =  Origin.x * Origin.x + Origin.y *Origin.y  -(SQUARE_RADIUS); 
  
				delta =  (b*b) - (4*a*c);  
				
					t = (float)(-b - Math.sqrt(delta))/(2*a);
					

					intersection.x = direction.x * t;
					intersection.y = direction.y * t;
					intersection.z = direction.z * t;
	
					textureYCoordinate =  (int) Math.abs(intersection.z + Origin.z) % TEXTUREHEIGHT; 
					//textureXCoordinate =  (int) Math.abs(intersection.y+intersection.x)  % TEXTUREWIDTH;
					textureXCoordinate =  (int) Math.abs(Math.atan2(intersection.y,intersection.x)*256/Math.PI)  % TEXTUREWIDTH;
					  
					renderer.offScreenRaster[cursor] = texture[textureYCoordinate+textureXCoordinate*TEXTUREWIDTH] ;
					//renderer.offScreenRaster[cursor] = texture[((int)Math.abs((intersection.z+Origin.z) /10D) % TEXTUREHEIGHT) * TEXTUREWIDTH + (int)Math.abs((intersection.x+intersection.y) % TEXTUREWIDTH)] ;
					//renderer.offScreenRaster[cursor] = (int)(intersection.z+Origin.z);
				}	
				cursor++;
			}
			
		}	
	}
}
