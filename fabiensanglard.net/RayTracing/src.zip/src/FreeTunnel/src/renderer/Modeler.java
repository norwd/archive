package renderer;

public interface Modeler {

	
	
	void drawOffScreen();
	
}
