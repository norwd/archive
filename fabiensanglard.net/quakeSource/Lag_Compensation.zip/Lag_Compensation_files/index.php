/* generated javascript */
var skin = 'valve';
var stylepath = '/w/skins';

/* MediaWiki:Common.js */
/* Any JavaScript here will be loaded for all users on every page load. */

/* MediaWiki:Valve.js */
