/**************************************************************
*	
* GBATypes.h : Fichier en-tete contenant la definition des 
*              types des variables
*
* Cree le : 16.08.2001
* Par : Edorul (edorul@free.fr)
*         http://www.ifrance.com/edorul/
*
* Ver. : 0.4.0
* Modifi� le 14.06.2002
*
***************************************************************/

#ifndef GBATYPES_H
#define GBATYPES_H

// Definitions generales
//-----------------------

// declaration propre aux backgrounds anim�s g�n�r�s par Tile Studio
#define TSSEQUENCE_DELTA	1		// nombre � soustraire pour avoir num de la premi�re s�quence = 0 

//Reglage tempo entre Tile Studio et GBATime
#define TEMPO				600

// Types generaux
//----------------

// definitions des types courants de variables
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;

typedef signed char s8;
typedef signed short s16;
typedef signed long s32;

// definitions de types pour les fichiers ".H" 
//   contenant des donn�es binaires
typedef const unsigned char const_u8;
typedef const unsigned short const_u16;

//variables booleennes
typedef unsigned short BOOL;
#define TRUE	1
#define FALSE	0	

//Pour les pointeurs nuls
#define NULL	0

//Definitions pour les registres utilises par 
// les Backgrounds de type Rotation
typedef signed short FIXED8_8;
typedef signed long FIXED20_8;
typedef signed long FIXED16_16;

//Definition d'un point en 2 dimensions
typedef struct Point2D
{
	s32 X;
	s32 Y;
} Point2D;

//Definition d'un point en 3 dimensions
typedef struct Point3D
{
	s32 X;
	s32 Y;
	s32 Z;
} Point3D;

// STRUCTURES pour GBADraw
//-------------------------

// Structure pour l'utilisation des Sequences
#ifndef SEQUENCE_STRUCT
#define SEQUENCE_STRUCT

typedef struct sequence_struct
{
	unsigned short SequenceLength;
	unsigned short *TileNum;
	unsigned char *Duration;
} sequence_struct;

#endif

// Structure pour l'utilisation des Tiles
#ifndef TILE_STRUCT
#define TILE_STRUCT

typedef struct tile_struct
{
	unsigned short PaletteSize;		// Nb de couleurs dans la palette
	unsigned short *PaletteData;	// Pointeur vers le tableau contenant les donnees de la palette
	unsigned short TilesNb;			// Nb de tiles dans ce TileSet
	unsigned short TileWidth;		// largeur Tile en Pixels
	unsigned short TileHeight;		// hauteur Tile en Pixels
	unsigned short Overlap;			// recouvrement suivant Y des Tiles (en pixels) ###non uilise
	unsigned short *TilesData;		// Pointeur vers le tableau contenant les donnees des Tiles
	unsigned short *SPRVidMemLocation;	// emplacement dans la memoire video des tiles
	unsigned short SequencesNb;		// Nombres de sequences pour ce jeu de Tiles
	sequence_struct *Sequences;		// Sequences associ�es au jeu de Tiles
} tile_struct;

#endif

// Structure pour l'utilisation des maps
#ifndef MAP_STRUCT
#define MAP_STRUCT

typedef struct map_struct
{
	tile_struct *Tiles;			// Pointeur vers la structure des Tiles utilisees
	unsigned short MapWidth;	// Largeur de la Map en Tiles
	unsigned short MapHeight;	// Hauteur de la Map en Tiles
	short *MapData;				// Pointeur vers le tableau contenant les donnees de la Map
	unsigned char *Bounds;		// Pointeur vers le tableau contenant les limites de la Map
	unsigned char *MapCode;		// Pointeur vers le tableau contenant les emplacements speciaux
} map_struct;

#endif

// Structure permettant la convertion "Tinytiles" (i.e. Tiles taille = 8x8 pixels) 
//           -> "LargeTiles" (i.e. Tiles taille > � 8x8 pixels)
//  (structure utilis�e en interne seulement)
typedef struct ttol_privatestruct
{
	s16 *TilePos;		// Positions des Tiny Tiles pour recreer les grandes tiles (NEW 0.4.0)
	u16	TWidth;			// largeur des tiles (en pixels)
	u16 THeight;		// hauteur des tiles (en pixels)
} ttol_privatestruct;

// Structure pour les Backgrounds
typedef struct bkg_struct
{
	map_struct *Map;	// Pointeur vers la structure contenant la Map plac�e dans ce Background
	ttol_privatestruct *ConvTiles;		// Positions des Tiny Tiles pour recreer les grandes tiles (NEW 0.4.0)
	u16 Num;			// numero du Background
	u16 *Register;      // pointe vers le registre BGx_CR du Background
//	u16 TileBlock;		// Tile Base Block Number
	u16 *TileData;		// pointe vers la en m�m vid�o contenant les Tiles
//	u16 MapBlock;		// Screen Base Block Number (Map Block)
	u16 *MapData;		// pointe vers la m�m vid�o contenant la Map
	u16 MapWidth;		// Largeur de la Map en Pixels
	u16 MapHeight;		// Hauteur de la Map en Pixels

//	u16 Priority;		// Priorit� du Background (0 affich� dessus, 3 affich� dessous)
//	u16 Mosaic;			// si =1 Mosaic enable
//	u16 NbColors;		// 16 ou 256
	u16 ScreenSize;		// Taille de la carte de 0 � 3 (utilise en interne par DirectGBA)

	s32 Scroll_X;		// valeur absolue du scrolling suivant X
	s32 Scroll_Y;		// valeur absolue du scrolling suivant Y
	s32 Deplct_X;		// valeur relative du deplacement du scrolling suivant X
	s32 Deplct_Y;		// valeur relative du deplacement du scrolling suivant Y
	u16 Bound;			// si =1 empeche Map de sortir de l'ecran

	u16 Angle;			// angle en degres de la rotation du Bkg
	s16 Center_X;		// coordonnee suivant X du centre de la rotation
	s16 Center_Y;		// coordonnee suivant Y du centre de la rotation
	u16 Zoom_X;			// facteur d'agrandissement du Bkg suivant X (>1 agrandit)
	u16 Zoom_Y;			// facteur d'agrandissement du Bkg suivant Y (>1 agrandit)
	u16 ZoomType;		// axe du zoom (AXE_SCREEN -> selon axe ecran, AXE_BKG -> selon axe Background)

	s32 Trans_X;		// Translation suivant X (pour chgt de repere du centre rotation juste pour augmenter rapidite, utilise en interne par DirectGBA)
	s32 Trans_Y;		// Translation suivant Y (pour chgt de repere du centre rotation juste pour augmenter rapidite, utilise en interne par DirectGBA)

	u16 *CurrentFrame;	// num�ros des frames en cours (tableau de dimension �gale au nb de sequences)
	u32 *TimeFrame;		// temps du commencement de ces frames (tableau de dimension �gale au nb de sequences)
} bkg_struct;

// Definitions pour les SPRITES
//------------------------------
typedef struct spriteOAM_struct
{
	u16 Attribute0;
	u16 Attribute1;
	u16 Attribute2;
	u16 Unused;
} spriteOAM_struct;

typedef struct spriteRot_struct
{
	u16 Unused0[3];
	FIXED8_8 PA;
	u16 Unused1[3];
	FIXED8_8 PB;
	u16 Unused2[3];
	FIXED8_8 PC;
	u16 Unused3[3];
	FIXED8_8 PD;
} spriteRot_struct;

// structure pour les sprites
typedef struct sprite_struct
{
	u16 NumSprite;					//numero du sprite dans SpritesOAM[128]
	spriteOAM_struct *SpriteOAM;	//pointe vers zone memoire contenant les attributs du sprite

	u16 NumRot;						//numero de la rotation a utiliser pour le sprite
	spriteRot_struct *SpriteRot;	//pointe vers la rotation utilisee par le sprite

	u32 Properties;					// sauvegarde des proprietes du sprite 
	bkg_struct *Bkg;				//different de NULL si attache a un Bkg (i.e. pour le scrolling & PathFinding)
	u16 Width;						//largeur en pixels
	u16 Height;						//hauteur en pixels

	FIXED16_16 X_Pos;				//X actuel % ecran
	FIXED16_16 Y_Pos;				//Y actuel % ecran
	FIXED16_16 X_Dest;				//X de la destination % ecran
	FIXED16_16 Y_Dest;				//Y de la destination % ecran

	u16 Action;						//type de l'action (ex: 01 = marcher vers droite, 18 = sauter...)
	u16 Type;						//type du sprite (ex:01 = joueur, 03 = ennemi n�1...)
	u32 LastAction;					//temps de la derniere action executee
	u32 NextAction;					//temps ou sera executee la prochaine action

	sequence_struct Animation;		//pointe vers l'animation a utiliser
	u32 TimeFrame;					//temps du commencement de cette frame 
	u16 CurrentFrame;				//frame en cour d'affichage
	s16	Loop;						//Si = LOOP_FWD (ou LOOP_RWD) animation boucle a l'infini, sinon nb de boucles a faire (si <0 animation sens inverse)

	struct sprite_struct *Next;		//sprite suivant dans liste chainee
	struct sprite_struct *Prev;		//sprite precedent dans liste chainee
	void (*Fonction)(struct sprite_struct *self);	//fonction a executer avec ce sprite (peut etre utilise avec NextAction)
} sprite_struct;

//Structure pour les Listes chainees de sprites
//------------------------------------------------
typedef struct spritelist_struct
{
	u16 NbSpr;				//nombre de sprites dans la liste
	sprite_struct *First;	//Premier sprite de la liste
} spritelist_struct;

//Structure pour la recherche de chemin (SearchPath)
//---------------------------------------------------
typedef struct NODE {
    s32 f,h;
    s16 g,tmpg;
    s16 x,y;
    s16 NodeNum;
    struct NODE *Parent;
    struct NODE *Child[8];       // a node may have upto 8+(NULL) children. 
    struct NODE *NextNode;       // for filing purposes 
} NODE;

typedef struct STACK {
    struct NODE *NodePtr;
    struct STACK *NextStackPtr;
} STACK;

#endif
