#ifndef _GRAPHS_H_
#define _GRAPHS_H_

#define	LG_SCREEN	240
#define	HT_SCREEN	150

#define	NB_SCREENS	6

#define CODE_IN_IWRAM __attribute__ ((section(".iwram"),long_call))

extern	s16		num_palette;
extern	u16		luminosite,
				contraste,
				langue,
				*base_palette;
extern	u8		*base_sprites,
				*base_sprites2,
				*current_base_obj,
				*tab_screens[],
				*work_screen;

extern	void	init_graphs();
extern	void	set_screen(u16 num);
extern	void	set_work_screen(u16 num);
extern	void	fill_screen(u16 num, u16 color);
extern	void	copy_screen(u16 src, u16 dst);
extern	void	CODE_IN_IWRAM printat(u16 ntxt, u16 x, u16 y, u8 col);
extern	void	CODE_IN_IWRAM draw_shape(u8 *pt_shape, s32 x, s32 y, u16 scale, u16 color);
extern	void	pause();
extern	void	flip();

#endif
