#include <malloc.h>
#include "gbatypes.h"
#include "interpret.h"
#include "graphs.h"
#include "present.h"

#define TRACE_GFX	0

#include "gbainput.h"
#include "dma.h"
#include "inters.h"
#if PlayModule
#if USE_KRAWALL
#include "krawall.h"
#else
#include "aas.h"
#endif
#endif

u16		*VideoBuffer =		(u16*)0x600a000;
u16		*VideoFrontBuffer =	(u16*)0x6000000;
u16		*VideoBackBuffer =	(u16*)0x600a000;
u16		*Palette =			(u16*)0x5000000;

#define RGB(r,g,b)		((r)+((g)<<5)+((b)<<10)) 
#define DISP_CR			*(u16*)0x4000000
#define BACKBUFFER		0x10

#include "fonte6.c"
#include "tab_texts.c"

u8		*tab_screens[NB_SCREENS]={0,0,0,0,0,0},
		*logic_screen,
		*physic_screen,
		*work_screen;
u16		*base_palette=NULL,
		*tab_incx=NULL;
u8		*base_sprites=NULL,
		*base_sprites2=NULL,
		*current_base_obj;

s16		num_palette,
		cur_palette;

u16		luminosite,
		contraste,
		langue=0,
		new_pal[256];

#if TRACE_GFX
u32		num_shape=0;

void printlog_gfx(char *s,...)
{
	asm volatile("mov r0, %0;"
                 "swi 0xff0000;"
                 : // no ouput
                 : "r" (s)
                 : "r0");
}

void printlog_numgfx(char *s1, u16 val, char *s2)
{
	u16	i;
	u8	txt[5],chr;

	txt[4]=0;
	for (i=0; i<4; i++)
	{
		chr=((val>>(i*4)) & 15);
		if (chr<10)
			txt[3-i]='0'+chr;
		else
			txt[3-i]='A'+chr-10;
	}
	print_gfx(s1);
	print_gfx(txt);
	print_gfx(s2);
}
#else
#define	printlog_gfx(...)
#define	printlog_numgfx(...)
#endif

/*************************************************************************
	Initialisation des �crans
 *************************************************************************/

void init_graphs()
{
	u16	i;
	
	if (tab_screens[0] == 0)
	{
		for (i=0; i<NB_SCREENS; i++)
		{
			tab_screens[i]=(u8 *)malloc(LG_SCREEN*HT_SCREEN);
			if (tab_screens[i]==NULL)
			{
				Palette[0]=0x5555;
				while(1);
			}
		}
	}

	if (tab_incx == NULL)
		tab_incx=(u16 *)malloc(1024*2);

	tab_incx[0]=0x4000;
	for (i=1; i<1024; i++)
		tab_incx[i]=0x4000/i;

	physic_screen=tab_screens[0];
	logic_screen=tab_screens[1];
	work_screen=tab_screens[1];

	num_palette=0;

	DMAFillMemory16(VideoFrontBuffer, (240*160)/2, 0);
	DMAFillMemory16(VideoBackBuffer, (240*160)/2, 0);
}

/*************************************************************************
	Swap ecran physique
 *************************************************************************/

void flip()
{
	u16	nv;

	nv=num_vbl;
	while(nv==num_vbl);

	if (DISP_CR & BACKBUFFER)
	{
		DISP_CR &= ~BACKBUFFER;
		VideoBuffer = VideoBackBuffer;
	}
	else
	{
		DISP_CR |= BACKBUFFER;
		VideoBuffer = VideoFrontBuffer;
	}
}

/*************************************************************************
	Calcul de la palette en fonction de la luminosit� et du contraste
 *************************************************************************/

void calcul_palette(u16 *pal, u16 start, u16 nb_cols)
{
	u16	i,rgb;
	s16	r,g,b;

	for (i=0; i<nb_cols; i++)
	{
		rgb=pal[start+i];
		r=rgb & 31;
		g=(rgb>>5) & 31;
		b=(rgb>>10) & 31;

		r=r+((31-r)*(luminosite-64)/63);
		g=g+((31-g)*(luminosite-64)/63);
		b=b+((31-b)*(luminosite-64)/63);

//		r=(r*luminosite)/32;
//		g=(g*luminosite)/32;
//		b=(b*luminosite)/32;

		r=r+((r-15)*(contraste-64)/63);
		g=g+((g-15)*(contraste-64)/63);
		b=b+((b-15)*(contraste-64)/63);

//		r=r+((contraste*(r-15))/16);
//		g=g+((contraste*(g-15))/16);
//		b=b+((contraste*(b-15))/16);

		if (r < 0)	r=0;
		if (r > 31)	r=31;
		if (g < 0)	g=0;
		if (g > 31)	g=31;
		if (b < 0)	b=0;
		if (b > 31)	b=31;

		new_pal[start+i]=RGB(r,g,b);
	}

	DMACopyCH3(&new_pal[start], &Palette[start], nb_cols, DMA_16NOW);
}

/*************************************************************************
	Gestion de la pause et du reglage de la luminosit� & contraste
 *************************************************************************/

void rebuild_pause(u8 *phys, u16 *pal)
{
	u16	i,j;

	DMACopyCH3(tab_screens[4], tab_screens[5], (LG_SCREEN*HT_SCREEN)/2, DMA_16NOW);

	printat(900,0xffff,10,16);	// "Pause"
	printat(901,0xffff,40,17);	// "Reprendre"
	printat(904,0xffff,60,18);	// "Reglages par defaut"
	printat(902,0xffff,75,19);	// "Luminosit�"
	printat(903,0xffff,100,20);	// "Contraste"

	// Affiche cadres
	for (i=0; i<130; i++)
	{
		work_screen[56+(63*LG_SCREEN)+i]=16;
		work_screen[56+(69*LG_SCREEN)+i]=16;
		work_screen[56+(82*LG_SCREEN)+i]=16;
		work_screen[56+(88*LG_SCREEN)+i]=16;

		work_screen[56+(110*LG_SCREEN)+i]=16;
		work_screen[56+(131*LG_SCREEN)+i]=16;
	}

	for (i=0; i<5; i++)
	{
		work_screen[56+((64+i)*LG_SCREEN)]=16;
		work_screen[56+((64+i)*LG_SCREEN)+129]=16;
		work_screen[56+((83+i)*LG_SCREEN)]=16;
		work_screen[56+((83+i)*LG_SCREEN)+129]=16;

		work_screen[56+((111+i)*LG_SCREEN)]=16;
		work_screen[56+((116+i)*LG_SCREEN)]=16;
		work_screen[56+((121+i)*LG_SCREEN)]=16;
		work_screen[56+((126+i)*LG_SCREEN)]=16;
		work_screen[56+((111+i)*LG_SCREEN)+129]=16;
		work_screen[56+((116+i)*LG_SCREEN)+129]=16;
		work_screen[56+((121+i)*LG_SCREEN)+129]=16;
		work_screen[56+((126+i)*LG_SCREEN)+129]=16;
	}

	for (i=0; i<luminosite; i++)
	{
		for (j=0; j<5; j++)
			work_screen[56+((64+j)*LG_SCREEN)+1+i]=16;
	}

	for (i=0; i<contraste; i++)
	{
		for (j=0; j<5; j++)
			work_screen[56+((83+j)*LG_SCREEN)+1+i]=16;
	}

	for (i=0; i<128; i++)
	{
		for (j=0; j<5; j++)
		{
			work_screen[56+((111+j)*LG_SCREEN)+1+i]=128+(i/4);
			work_screen[56+((116+j)*LG_SCREEN)+1+i]=160+(i/4);
			work_screen[56+((121+j)*LG_SCREEN)+1+i]=192+(i/4);
			work_screen[56+((126+j)*LG_SCREEN)+1+i]=224+(i/4);
		}
	}

	calcul_palette(pal, 0, 16);
	calcul_palette(pal, 128, 128);

	DMACopyCH3(work_screen, phys, (LG_SCREEN*HT_SCREEN)/2, DMA_16NOW);
}

void pause()
{
	u8	*old_workscreen=work_screen,*phys;
	u16	pt=0,nvbl,col=0,last_key=0,tempo=0;
	s16	inc=1;
	u16	pal[256],i;

#if PlayModule
#if USE_KRAWALL
		krapPause(TRUE);
#else
		AAS_MOD_Pause();
		AAS_SFX_Stop(0);
		AAS_SFX_Stop(1);
		AAS_SFX_Stop(2);
		AAS_SFX_Stop(3);
#endif
#endif

	DMACopyCH3(&base_palette[cur_palette*16], pal, 16, DMA_16NOW);

	for (i=16; i<21; i++)
	{
		Palette[i]=0x7fff;
	}

	for (i=0; i<32; i++)
	{
		pal[128+i]=RGB(i,0,0);
		pal[160+i]=RGB(0,i,0);
		pal[192+i]=RGB(0,0,i);
		pal[224+i]=RGB(i,i,i);
	}

	if (DISP_CR & BACKBUFFER)
		phys=(u8 *)(VideoBackBuffer+(5*LG_SCREEN)/2);
	else
		phys=(u8 *)(VideoFrontBuffer+(5*LG_SCREEN)/2);

	DMACopyCH3(phys, tab_screens[4], (LG_SCREEN*HT_SCREEN)/2, DMA_16NOW);
	DMACopyCH3(phys, tab_screens[5], (LG_SCREEN*HT_SCREEN)/2, DMA_16NOW);

	work_screen=tab_screens[5];

	rebuild_pause(phys, pal);

	while(KEY_DOWN(K_START));
	while(1)
	{
		nvbl=num_vbl;
		while(nvbl==num_vbl);

		col+=inc;
		if ((col == 0) || (col == 31))
			inc=-inc;
		
		if ((KEY_DOWN(K_UP) & last_key) && (pt > 0))
		{
			Palette[17+pt]=RGB(31,31,31);
			pt--;
		}
		if ((KEY_DOWN(K_DOWN) & last_key) && (pt < 3))
		{
			Palette[17+pt]=RGB(31,31,31);
			pt++;
		}

		Palette[17+pt]=RGB(col,col,col);

		if ((KEY_DOWN(K_A | K_B) & last_key) && (pt == 0))
			break;

		if ((KEY_DOWN(K_START) & last_key))
			break;

		if ((KEY_DOWN(K_A | K_B) & last_key) && (pt == 1))
		{
			luminosite=70;
			contraste=70;
			
			rebuild_pause(phys, pal);
		}

		if (KEY_DOWN(K_LEFT))
		{
			if ((KEY_DOWN(K_RIGHT) & last_key) || tempo==0)
			{
				if (pt == 2)
				{
					if (luminosite)
						luminosite--;
				}

				if (pt == 3)
				{
					if (contraste)
						contraste--;
				}
				tempo=5;
				
				rebuild_pause(phys, pal);
			}
		}

		if (KEY_DOWN(K_RIGHT))
		{
			if ((KEY_DOWN(K_RIGHT) & last_key) || tempo==0)
			{
				if (pt == 2)
				{
					if (luminosite < 128)
						luminosite++;
				}

				if (pt == 3)
				{
					if (contraste < 128)
						contraste++;
				}
				tempo=5;

				rebuild_pause(phys, pal);
			}
		}

		if (tempo)
			tempo--;

		last_key=~KEY_DOWN(K_ALL);
	}

	save_game();

	while(KEY_DOWN(K_ALL));

	DMACopyCH3(tab_screens[4], work_screen, (LG_SCREEN*HT_SCREEN)/2, DMA_16NOW);

	work_screen=old_workscreen;

#if PlayModule
#if USE_KRAWALL
	krapUnpause();
#else
	AAS_MOD_Resume();
	AAS_SFX_Resume(0);
	AAS_SFX_Resume(1);
	AAS_SFX_Resume(2);
	AAS_SFX_Resume(3);
#endif
#endif
}

/*************************************************************************
	Renvoi un pt sur l'ecran num
 *************************************************************************/

u8 *get_ad_screen(u16 num)
{
	if (num < 4)
		return tab_screens[num];

	if (num == 0xFF)
		return logic_screen;

	if (num == 0xFE)
		return physic_screen;

	return tab_screens[0];
}

/*************************************************************************
	Affiche l'�cran physique
 *************************************************************************/

void set_screen(u16 num)
{
	u16	*src,
		*dst;

	if (num != 0xFE)
	{
		if (num == 0xFF)
		{
			src=(u16 *)logic_screen;
			logic_screen=physic_screen;
			physic_screen=(u8 *)src;
		}
		else
			physic_screen=get_ad_screen(num);
	}

	src=(u16 *)physic_screen;
	dst=VideoBuffer+(5*LG_SCREEN)/2;

	DMACopyCH3(src, dst, (LG_SCREEN*HT_SCREEN)/2, DMA_16NOW);

	flip();

	if (num_palette != -1)
	{
		cur_palette=num_palette;
		calcul_palette(&base_palette[cur_palette*16], 0, 16);
		num_palette=-1;
	}

	if (game_current_part==16001)
	{
		while((tab_vars[255]*4)/3 > num_vbl);
		tab_vars[247]=tab_vars[255];	//num_vbl;
	}
	else
	{
		while(tab_vars[255] > num_vbl);
		tab_vars[247]=num_vbl;
	}
	num_vbl=0;
}

/*************************************************************************
	Change l'�cran de travail
 *************************************************************************/

void set_work_screen(u16 num)
{
	work_screen=get_ad_screen(num);
}

/*************************************************************************
	Rempli l'�cran avec une couleur
 *************************************************************************/

void fill_screen(u16 num, u16 color)
{
	u16	col,
		*scr;

	scr=(u16 *)get_ad_screen(num);
	col=(color<<8)|color;

	DMAFillMemory16(scr, (LG_SCREEN*HT_SCREEN)/2,col);
}

/*************************************************************************
	Copie d'un �cran vers un autre
 *************************************************************************/

void copy_screen(u16 src, u16 dst)
{
	u16	*screen_src,
		*screen_dst;
	u16	nb_lgn;
	s32	decal;

	if (((src & 0x83) < 4) || (src >= 254))
	{
		screen_src=(u16 *)get_ad_screen(src);
		screen_dst=(u16 *)get_ad_screen(dst);

		if (screen_src == screen_dst)
			return;

		DMACopyCH3(screen_src, screen_dst, (LG_SCREEN*HT_SCREEN)/2, DMA_16NOW);
		return;
	}

	screen_src=(u16 *)get_ad_screen((u16)(src & 3));
	screen_dst=(u16 *)get_ad_screen(dst);

	if (screen_src == screen_dst)
		return;

	decal=tab_vars[249];
	if ((decal > 199) || (decal < -199))
		return;

	decal=(decal*3)/4;

	if (decal < 0)
	{
		nb_lgn=HT_SCREEN+decal;
		screen_src+=(LG_SCREEN*-decal)/2;
	}
	else
	{
		nb_lgn=HT_SCREEN-decal;
		screen_dst+=(LG_SCREEN*decal)/2;
	}

	DMACopyCH3(screen_src, screen_dst, (LG_SCREEN*nb_lgn)/2, DMA_16NOW);
}

/*************************************************************************
	Affichage d'un texte
 *************************************************************************/

void CODE_IN_IWRAM printat(u16 ntxt, u16 x, u16 y, u8 col)
{
	const u8	*pt_gfx,
				*pt_txt;
	u8	*scr,
		id_text=0,lettre;
	u16	x2=x;
	u16	i,j;

	while(textes_id[id_text])
	{
		if (textes_id[id_text] == ntxt)
			break;
		id_text++;
	}

	if (textes_id[id_text]==0)
		return;

	if (langue)
		pt_txt=textes[id_text];
	else
		pt_txt=textes_fr[id_text];

	y=(y*3)/4;
	scr=(u8 *)work_screen;

	if (x == 0xffff)
	{
		x=LG_SCREEN/2;
		while(*pt_txt++)
			x-=3;

		scr+=x+(y*LG_SCREEN);

		if (langue)
			pt_txt=textes[id_text];
		else
			pt_txt=textes_fr[id_text];
	}
	else
		scr+=(x*6)+(y*LG_SCREEN);

	while(*pt_txt)
	{
		lettre=*pt_txt++;
		if (lettre=='\n')
		{
			x=x2;
			y+=6;
			scr=(u8 *)work_screen;
			scr+=(x*6)+(y*LG_SCREEN);
			continue;
		}

		if (x>LG_SCREEN-6)
			continue;

		if (y>HT_SCREEN-6)
			continue;

		pt_gfx=&fonte6[(lettre-32)*36];
		for (i=0; i<6; i++)
		{
			for (j=0; j<6; j++)
			{
				if (*pt_gfx++)
					*scr++=col;
				else
					scr++;
			}
			scr+=LG_SCREEN-6;
		}
		scr-=(LG_SCREEN*6)-6;
		x++;
	}
}

void CODE_IN_IWRAM draw_shape(u8 *pt_shape, s32 x, s32 y, u16 scale, u16 color)
{
	u16	id_next;
	s16	nb_obj;
	s32	crdx, crdy;

	printlog_numgfx("Shape ",++num_shape," : ");
	printlog_numgfx("(",(pt_shape-current_base_obj)/2,") : ");
	printlog_numgfx("x=",x," , ");
	printlog_numgfx("y=",y," , ");
	printlog_numgfx("f=",scale," , ");
	printlog_numgfx("c=",color," ");

	if (*pt_shape < 0xC0)
	{
		if ((*pt_shape & 0x3F) != 2)
		{
			printlog_gfx("Erreur\n");
			return; // On ignore
		}

		pt_shape++;

		x -= ((*pt_shape++)*scale)>>6;
		y -= ((*pt_shape++)*scale)>>6;

		nb_obj=*pt_shape++;

		printlog_gfx("type multiple ");
		printlog_numgfx("nbobj=",nb_obj+1,"\n");

		for (; nb_obj>=0; nb_obj--)
		{
			id_next=(*pt_shape++)*256;
			id_next+=*pt_shape++;

			crdx=x+(((*pt_shape++)*scale)>>6);
			crdy=y+(((*pt_shape++)*scale)>>6);

			color=255;
			if (id_next & 0x8000)
			{
				id_next &= 0x7fff;

				color=(*pt_shape++) & 0x7f;
				pt_shape++;
			}

			id_next+=id_next;
			draw_shape(current_base_obj+id_next, crdx, crdy, scale, color);
		}
	}
	else
	{
		u8	*next_pt,
			*last_pt,
			flag;
		s32	x1,
			x2,y2;
		s32	dy,
			cpt1,cpt2,
			incx1,incx2;
		u16	nb_pts,yscr;

		if (color & 0x80)
			color=*pt_shape & 0x3F;

		if (((pt_shape[2]*256)+pt_shape[3]) == 260)
		{
			if (pt_shape[1] == 0)
			{
				printlog_gfx("type pixel\n");

				if ((x < 0) || (x > 319) || (y < 0) || (y > 199))
					return;

				x=(x*3)/4;
				yscr=((y*3)/4)*LG_SCREEN;

				if (color == 16)
					work_screen[(x+yscr)] |= 8;
				else if (color == 17)
					work_screen[(x+yscr)]=(tab_screens[0])[(x+yscr)];
				else
					work_screen[(x+yscr)]=(u8)color;
				return;
			}
		}

		printlog_gfx("type polygon ");

		flag=0;
		if (color == 16)
			flag=1;
		else if (color == 17)
			flag=2;

		pt_shape++;

		// Calcul de la boundbox pour le clip rapide
		x2=x+(((*pt_shape*scale)>>6)/2);
		x=x-(((*pt_shape++*scale)>>6)/2);
		y2=y+(((*pt_shape*scale)>>6)/2);
		y=y-(((*pt_shape++*scale)>>6)/2);

		if ((x > 319) || (x2 < 0) || (y > 199) || (y2 < 0))
		{
			printlog_gfx("\n");
			return;
		}

		if (y < 0)
			yscr=0;
		else
			yscr=(u16)y;

		nb_pts=*pt_shape++;
		last_pt=pt_shape+((nb_pts-1)*2);
		x2=x+(((*pt_shape++)*scale)>>6);
		next_pt=pt_shape+1;
		x1=x+((*last_pt*scale)>>6);

		cpt1 = x1 << 16;
		cpt2 = x2 << 16;

		printlog_numgfx("",nb_pts," pts\n");

		while(1)
		{
			nb_pts-=2;
			if (nb_pts == 0)
				return;

			incx1=((last_pt[-2]*scale)>>6)-((last_pt[0]*scale)>>6);	// Distance xn-x(n-1)
			dy=((last_pt[-1]*scale)>>6)-((last_pt[1]*scale)>>6);	// Distance yn-y(n-1)
			incx1=(incx1*tab_incx[dy])<<2;
			last_pt-=2;

			incx2=((next_pt[0]*scale)>>6)-((next_pt[-2]*scale)>>6);	// Distance x1-x0
			dy=((next_pt[1]*scale)>>6)-((next_pt[-1]*scale)>>6);	// Distance y1-y0
			incx2=(incx2*tab_incx[dy])<<2;
			next_pt+=2;

			cpt1 |= 0x7FFF;
			cpt2 |= 0x8000;

			if (dy == 0)
			{
				cpt1 += incx1;
				cpt2 += incx2;
			}
			else
			{
				for (; dy !=0; --dy)
				{
					if (y >=0)
					{
						x1=cpt1>>16;
						x2=cpt2>>16;

						if (x1 > x2)
						{
							x=x1;
							x1=x2;
							x2=x;
						}	/**/

						if (x1<0)
							x1=0;

						if (x2>319)
							x2=319;

						if ((x1 < 320) && (x2 >- 1))
						{
							x1=(x1*3)/4;
							x2=(x2*3)/4;
							yscr=((y*3)/4)*LG_SCREEN;	/**/

							if (yscr < HT_SCREEN*LG_SCREEN)
							{
								if (flag == 0)
								{
									u8	*pt_scr=&work_screen[yscr+x1];
									s16	lg=(x2-x1)+1;
									u16	col=(color<<8)|color;

									if (x1 & 1)
									{
										*pt_scr++=(u8)color;
										lg--;
									}

									for (; lg>1; lg-=2)
										*((u16 *)pt_scr)++=col;

									if (lg>0)
										*pt_scr++=(u8)color;
								}
								else if (flag == 1)
								{
									u8	*pt_scr=&work_screen[yscr+x1];
									s16	lg=(x2-x1)+1;

									if (x1 & 1)
									{
										*pt_scr++ |= 8;
										lg--;
									}

									for (; lg>1; lg-=2)
										*((u16 *)pt_scr)++ |= 0x0808;

									if (lg>0)
										*pt_scr++ |= 8;
								}
								else
								{
									u8	*pt_scr=&work_screen[yscr+x1],
										*pt_scr2=&(tab_screens[0])[yscr+x1];
									s16	lg=(x2-x1)+1;

									if (x1 & 1)
									{
										*pt_scr++=*pt_scr2++;
										lg--;
									}

									for (; lg>1; lg-=2)
										*((u16 *)pt_scr)++=*((u16 *)pt_scr2)++;

									if (lg>0)
										*pt_scr++=*pt_scr2++;
								}
							}
						}
					}

					cpt1+=incx1;
					cpt2+=incx2;
					y++;
					if (y > 199)
						return;
				}
			}
		}
	}
}
