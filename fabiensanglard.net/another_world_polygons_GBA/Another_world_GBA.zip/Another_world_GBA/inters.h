#ifndef _INTERS_H_
#define _INTERS_H_

#define	PlayModule	1
#define	USE_KRAWALL	0	// 0=AAS / 1=Krawall

extern	volatile u16	num_vbl;

extern	volatile BOOL kramWorkerCall;
extern	volatile BOOL kramPlayCall;

extern	void	init_inters();
extern	s16		myrand(s16 Value);

#endif
