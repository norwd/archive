#ifndef _PROFILER_H_
#define _PROFILER_H_

#define PROFILER	0

#if PROFILER

extern	void profil_init();
extern	void profil_start(u16 rout);
extern	void profil_stop();
extern	void profil_rout(u16 rout);

#else

#define	profil_init(...)
#define	profil_it(...)
#define	profil_start(...)
#define	profil_stop(...)
#define	profil_rout(...)

#endif

#define	PRF_MAINLOOP		0
#define	PRF_INTERPRETEUR	1
#define	PRF_DRAWSHAPE		2
#define	PRF_PRINT			3
#define	PRF_GFX_DIVERS		4

#endif
