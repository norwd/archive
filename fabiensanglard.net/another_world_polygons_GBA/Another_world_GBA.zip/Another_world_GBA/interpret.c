#include <malloc.h>
#include "gbatypes.h"
#include "graphs.h"
#include "present.h"
#include "gbainput.h"
#include "dma.h"
#include "inters.h"
#if PlayModule
#if USE_KRAWALL
#include "krawall.h"
#include "modules.h"
#else
#include "aas.h"
#include "AAS_Data.h"
#endif
#endif
#include "profiler.h"

#define	TRACE_LOG	0

#define	MAX_ENTITY		64
#define	MAX_VARS		256

extern	u8	*filesdata[];
extern	u8	filestype[];
extern	u16 part2;

u16			game_step;

u8			*tab_entity_flags=NULL,
			*tab_entity_frame_flags=NULL;

s16			*tab_vars=NULL;
s16			*tab_entity_frame=NULL,
			*tab_entity_pt=NULL;
u16			*op_stack=NULL,
			*top_op_stack,
			*pt_op_stack;

u16			game_current_part,
			game_part;

u8			*base_opcode;

const	u16	tab_spl_freqs[]={	3326, 3523, 3728, 3950, 4181, 4430, 4697, 4971, 5279, 8893, 5926, 6279,
								6653, 7046, 7457, 7901, 8363, 8860, 9395, 9943, 10559, 11186, 11852,12559,
								13306,14092,14914, 15802,16726,17720,18790, 19886, 22372, 23704, 25118,
								26612, 28184, 29828, 31604	};

#if TRACE_LOG
u8	flag_log;

void print_log(char *s,...)
   {
	if (KEY_DOWN(K_START))
		flag_log=1;
	if (flag_log==0)
		return;

     asm volatile("mov r0, %0;"
                  "swi 0xff0000;"
                  : // no ouput
                  : "r" (s)
                  : "r0");
   }

void print_numlog(char *s1, u16 val, char *s2)
{
	u16	i;
	u8	txt[5],chr;

	txt[4]=0;
	for (i=0; i<4; i++)
	{
		chr=((val>>(i*4)) & 15);
		if (chr<10)
			txt[3-i]='0'+chr;
		else
			txt[3-i]='A'+chr-10;
	}
	print_log(s1);
	print_log(txt);
	print_log(s2);
}
#else
#define	print_log(...)
#define	print_numlog(...)
#endif

void init_interpret(u16 part, u16 part2)
{
	u16	i;

	if (tab_entity_pt==NULL)
		tab_entity_pt=(s16 *)malloc(MAX_ENTITY*2);

	if (tab_entity_frame==NULL)
		tab_entity_frame=(s16 *)malloc(MAX_ENTITY*2);

	if (tab_entity_flags==NULL)
		tab_entity_flags=(u8 *)malloc(MAX_ENTITY);

	if (tab_entity_frame_flags==NULL)
		tab_entity_frame_flags=(u8 *)malloc(MAX_ENTITY);

	if (tab_vars==NULL)
		tab_vars=(s16 *)malloc(MAX_VARS*2);

	if (op_stack==NULL)
		op_stack=(u16 *)malloc(256*2);

	top_op_stack=op_stack;

	for (i=0; i<MAX_ENTITY; i++)
	{
		tab_entity_pt[i]=0;
		tab_entity_frame[i]=0;
		tab_entity_flags[i]=0;
		tab_entity_frame_flags[i]=0;
	}

	for (i=0; i<MAX_VARS; i++)
		tab_vars[i]=0;

	game_part=part;
	game_current_part=0;
	tab_vars[0]=part2;
}

void num_to_str(u8 *txt, u16 val)
{
	u16 p1,p2,p3;

	p1=val/100;
	p2=(val-(p1*100))/10;
	p3=val-(p1*100)-(p2*10);

	txt[0]='0'+p1;
	txt[1]='0'+p2;
	txt[2]='0'+p3;
}

void load_gamepart()
{
	u16	num_file_palettes=0,
		num_file_opcodes=0,
		num_file_sprites=0,
		num_file_sprites2=0,
		i;

	if ((game_part != game_current_part) && (game_part != 0))
	{
		switch(game_part)
		{
			case 16001:	num_file_palettes=23;
						num_file_opcodes=24;
						num_file_sprites=25;
						tab_vars[0]=0;
						part2=0;
						break;

			case 16002:	num_file_palettes=26;
						num_file_opcodes=27;
						num_file_sprites=28;
						break;

			case 16003:	num_file_palettes=29;
						num_file_opcodes=30;
						num_file_sprites=31;
						num_file_sprites2=17;
						break;

			case 16004:	num_file_palettes=32;
						num_file_opcodes=33;
						num_file_sprites=34;
						num_file_sprites2=17;
						break;

			case 16005:	num_file_palettes=35;
						num_file_opcodes=36;
						num_file_sprites=37;
						break;

			case 16006:	num_file_palettes=38;
						num_file_opcodes=39;
						num_file_sprites=40;
						num_file_sprites2=17;
						break;

			case 16007:	num_file_palettes=41;
						num_file_opcodes=42;
						num_file_sprites=43;
						num_file_sprites2=17;
						break;

			case 16008:	num_file_palettes=125;
						num_file_opcodes=126;
						num_file_sprites=127;
						break;

			case 16009:	num_file_palettes=125;
						num_file_opcodes=126;
						num_file_sprites=127;
						break;
		}

#if PlayModule
#if USE_KRAWALL
		krapStop();
#else
		AAS_SFX_Stop(0);
		AAS_SFX_Stop(1);
		AAS_SFX_Stop(2);
		AAS_SFX_Stop(3);
		AAS_MOD_Stop();
#endif
#endif

		tab_vars[60]=myrand(0x4444);	// random
		tab_vars[219]=0;

		base_palette=(u16 *)filesdata[num_file_palettes];
		base_opcode=filesdata[num_file_opcodes];
		base_sprites=filesdata[num_file_sprites];
		base_sprites2=filesdata[17];

		game_current_part=game_part;
		part2=tab_vars[0];
		save_game();

		for (i=0; i<MAX_ENTITY; i++)
		{
			tab_entity_pt[i]=-1;
			tab_entity_frame[i]=-1;
			tab_entity_flags[i]=0;
			tab_entity_frame_flags[i]=0;
		}

		tab_entity_pt[0]=0;

		game_part=0;
	}
}

s16	interpret(u16 index_opc)
{
	u8	opcode;
	s16	val1,val2;
	u16	index;

	while(1)
	{
		print_numlog("",index_opc,": ");

		opcode=base_opcode[index_opc++];

		if (opcode & 0x80)	// aff_shape(num, x, y)
		{
			s16	x=0,y=0,h;

			current_base_obj=base_sprites;

			index=(opcode<<8)|base_opcode[index_opc++];
			index+=index;
			x=base_opcode[index_opc++];
			y=base_opcode[index_opc++];

			h=y-199;
			if (h > 0)
			{
				y=199;
				x+=h;
			}

			print_numlog("aff_shape(",index,", ");
			print_numlog("",x,", ");
			print_numlog("",y,")\n");
			
			profil_rout(PRF_DRAWSHAPE);
			draw_shape(current_base_obj+index, x, y, 64, 255);
			profil_rout(PRF_INTERPRETEUR);
			continue;
		}

		if (opcode & 0x40)	// aff_shape_scale(num, x, y, scale)
		{
			s16	x=0,y=0,scale=0;

			current_base_obj=base_sprites;

			index=base_opcode[index_opc++]<<8;
			index|=base_opcode[index_opc++];
			index+=index;

			print_numlog("aff_shape_zoom(",index,", ");

			x=base_opcode[index_opc++];
			if (opcode & 0x20)
			{
				if (opcode & 0x10)
					x+=256;
				print_numlog("",x,", ");
			}
			else
			{
				if (opcode & 0x10)
				{
					print_numlog("V",x,", ");
					x=tab_vars[x];
				}
				else
				{
					x=(x<<8)|base_opcode[index_opc++];
					print_numlog("",x,", ");
				}
			}

			y=base_opcode[index_opc++];
			if (opcode & 0x8)
			{
				if (opcode & 0x4)
					y+=256;

				print_numlog("",y,", ");
			}
			else
			{
				if (opcode & 0x4)
				{
					print_numlog("V",y,", ");
					y=tab_vars[y];
				}
				else
				{
					y=(y<<8)|base_opcode[index_opc++];
					print_numlog("",y,", ");
				}
			}

			scale=base_opcode[index_opc++];
			if (opcode & 0x2)
			{
				if (opcode & 0x1)
				{
					current_base_obj=base_sprites2;
					index_opc--;
					scale=64;
				}
				print_numlog("",scale,")\n");
			}
			else
			{
				if (opcode & 0x1)
				{
					print_numlog("V",scale,")\n");
					scale=tab_vars[scale];
				}
				else
				{
					index_opc--;
					scale=64;
					print_numlog("",scale,")\n");
				}
			}

			profil_rout(PRF_DRAWSHAPE);
			draw_shape(current_base_obj+index, x, y, scale, 255);
			profil_rout(PRF_INTERPRETEUR);

			continue;
		}

		if (opcode == 0)	// var = val
		{
			val1=base_opcode[index_opc++];
			val2=base_opcode[index_opc++]<<8;
			val2|=base_opcode[index_opc++];
			tab_vars[val1]=val2;

			print_numlog("V",val1," = ");
			print_numlog("",val2,"\n");
		}

		else if (opcode == 1)	// var = var
		{
			val1=base_opcode[index_opc++];
			val2=base_opcode[index_opc++];
			tab_vars[val1]=tab_vars[val2];

			print_numlog("V",val1," = ");
			print_numlog("V",val2,"\n");
		}

		else if (opcode == 2)	// var += var
		{
			val1=base_opcode[index_opc++];
			val2=base_opcode[index_opc++];
			tab_vars[val1]+=tab_vars[val2];

			print_numlog("V",val1," += ");
			print_numlog("V",val2,"\n");
		}

		else if (opcode == 3)	// var += val
		{
			val1=base_opcode[index_opc++];
			val2=base_opcode[index_opc++]<<8;
			val2|=base_opcode[index_opc++];
			tab_vars[val1]+=val2;

			print_numlog("V",val1," += ");
			print_numlog("",val2,"\n");
		}

		else if (opcode == 4)	// jsr
		{
			val1=base_opcode[index_opc++]<<8;
			val1|=base_opcode[index_opc++];
			*pt_op_stack++=index_opc;
			index_opc=(u16)val1;

			print_numlog("jsr ",val1,"\n");
		}

		else if (opcode == 5)	// ret
		{
			index_opc=*--pt_op_stack;
			print_log("ret\n");
		}

		else if (opcode == 6)	// stop
		{
			print_log("stop\n");
			break;
		}

		else if (opcode == 7)	// jmp
		{
			val1=base_opcode[index_opc++]<<8;
			val1|=base_opcode[index_opc++];
			index_opc=(u16)val1;

			print_numlog("jmp ",val1,"\n");
		}

		else if (opcode == 8)	// setentity(num, pc)
		{
			val1=base_opcode[index_opc++];
			val2=base_opcode[index_opc++]<<8;
			val2|=base_opcode[index_opc++];
			tab_entity_frame[val1]=(u16)val2;

			print_numlog("set_entity(",val1,", ");
			print_numlog("",val2,")\n");
		}

		else if (opcode == 9)	// dbf
		{
			print_numlog("dbf V",base_opcode[index_opc],", ");
			print_numlog("",(base_opcode[index_opc+1]<<8)|base_opcode[index_opc+2],"\n");

			if ((--tab_vars[base_opcode[index_opc++]]))
			{
				val1=base_opcode[index_opc++]<<8;
				val1|=base_opcode[index_opc++];
				index_opc=(u16)val1;
			}
			else
				index_opc+=2;
		}

		else if (opcode == 10)	// op cmp
		{
			u8 flag;

			opcode=base_opcode[index_opc++];

			print_numlog("cmp V",base_opcode[index_opc],", ");

			val1=tab_vars[base_opcode[index_opc++]];
			val2=base_opcode[index_opc++];

			if (opcode & 0x80)
			{
				print_numlog("V",val2,", ");
				val2=tab_vars[val2];
			}
			else
			{
				if (opcode & 0x40)
					val2=(s16)((val2<<8)|base_opcode[index_opc++]);
				print_numlog("",val2,", ");
			}

			flag=0;
			switch(opcode & 7)
			{
			case 0:	if (val1 == val2)
						flag=1;
					print_log("eq ");
					break;
			case 1: if (val1 != val2)
						flag=1;
					print_log("ne ");
					break;
			case 2:	if (val1 > val2)
						flag=1;
					print_log("gt ");
					break;
			case 3:	if (val1 >= val2)
						flag=1;
					print_log("ge ");
					break;
			case 4:	if (val1 < val2)
						flag=1;
					print_log("lt ");
					break;
			case 5:	if (val1 <= val2)
						flag=1;
					print_log("le ");
					break;
			}

			val1=base_opcode[index_opc++]<<8;
			val1|=base_opcode[index_opc++];
			if (flag)
				index_opc=(u16)val1;

			print_numlog("",val1,"\n");
		}

		else if (opcode == 11)	// palette(num, flag)
		{
			num_palette=base_opcode[index_opc++];
			index_opc++;	// skip 2eme parametre

			print_numlog("palette(",num_palette,")\n");
		}

		else if (opcode == 12) // entity_flag(num to num, flag)
		{
			s8	flag;

			val1=base_opcode[index_opc++];
			val2=base_opcode[index_opc++] & 63;
			flag=base_opcode[index_opc++];

			print_numlog("entity_flag(",val1," to ");
			print_numlog("",val2,", ");
			print_numlog("",flag,")\n");

			if (flag == 2)
			{
				for (; val1 <= val2; val1++)
					tab_entity_frame[val1]=-2;
			}
			else if (flag < 2)
			{
				for (; val1 <= val2; val1++)
					tab_entity_frame_flags[val1]=flag;
			}
		}

		else if (opcode == 13)	// logic(num)
		{
			print_numlog("set_logic(",base_opcode[index_opc],")\n");

			profil_rout(PRF_GFX_DIVERS);
			set_work_screen(base_opcode[index_opc++]);
			profil_rout(PRF_INTERPRETEUR);
		}

		else if (opcode == 14)	// fill_screen(num, color)
		{
			val1=base_opcode[index_opc++];
			val2=base_opcode[index_opc++];

			print_numlog("fill_screen(",val1,", ");
			print_numlog("",val2,")\n");

			profil_rout(PRF_GFX_DIVERS);
			fill_screen(val1, val2);
			profil_rout(PRF_INTERPRETEUR);
		}

		else if (opcode == 15)	// copy_screen(src, dst)
		{
			val1=base_opcode[index_opc++];
			val2=base_opcode[index_opc++];

			print_numlog("copy_screen(",val1,", ");
			print_numlog("",val2,")\n");

			profil_rout(PRF_GFX_DIVERS);
			copy_screen(val1, val2);
			profil_rout(PRF_INTERPRETEUR);
		}

		else if (opcode == 16)	// aff_screen(num)
		{
			print_numlog("aff_screen(",base_opcode[index_opc],")\n");

			profil_rout(PRF_GFX_DIVERS);
			set_screen(base_opcode[index_opc++]);
			profil_rout(PRF_INTERPRETEUR);
		}

		else if (opcode == 17)	// end
		{
			print_log("end\n");
			index_opc=-1;
			break;
		}

		else if (opcode == 18)	// printat(ntxt, x, y, color)
		{
			u16	x, y;
			u8	col;

			val1=base_opcode[index_opc++]<<8;
			val1|=base_opcode[index_opc++];
			x=base_opcode[index_opc++];
			y=base_opcode[index_opc++];
			col=base_opcode[index_opc++];

			profil_rout(PRF_PRINT);
			printat(val1,x,y,col);
			profil_rout(PRF_INTERPRETEUR);

			print_numlog("printat(",val1,", ");
			print_numlog("",x,", ");
			print_numlog("",y,", ");
			print_numlog("",col,")\n");
		}

		else if (opcode == 19)	// var -= var
		{
			val1=base_opcode[index_opc++];
			val2=base_opcode[index_opc++];
			tab_vars[val1]-=tab_vars[val2];

			print_numlog("V",val1," -= ");
			print_numlog("V",val2,"\n");
		}

		else if (opcode == 20)	// var &= val
		{
			val1=base_opcode[index_opc++];
			val2=base_opcode[index_opc++]<<8;
			val2|=base_opcode[index_opc++];
			tab_vars[val1]=(u16)tab_vars[val1] & (u16)val2;

			print_numlog("V",val1," &= ");
			print_numlog("",val2,"\n");
		}

		else if (opcode == 21)	// var |= val
		{
			val1=base_opcode[index_opc++];
			val2=base_opcode[index_opc++]<<8;
			val2|=base_opcode[index_opc++];
			tab_vars[val1]=(u16)tab_vars[val1] | (u16)val2;

			print_numlog("V",val1," |= ");
			print_numlog("",val2,"\n");
		}

		else if (opcode == 22)	// var <<= val
		{
			val1=base_opcode[index_opc++];
			val2=base_opcode[index_opc++]<<8;
			val2|=base_opcode[index_opc++];
			tab_vars[val1]=(u16)tab_vars[val1] << (u16)val2;

			print_numlog("V",val1," <<= ");
			print_numlog("",val2,"\n");
		}

		else if (opcode == 23)	// var >>= val
		{
			val1=base_opcode[index_opc++];
			val2=base_opcode[index_opc++]<<8;
			val2|=base_opcode[index_opc++];
			tab_vars[val1]=(u16)tab_vars[val1] >> (u16)val2;

			print_numlog("V",val1," >>= ");
			print_numlog("",val2,"\n");
		}

		else if (opcode == 24)	// sound(nfile, speed, volume, chan)
		{
			u16	speed, chan, vol;

			val1=base_opcode[index_opc++]<<8;
			val1|=base_opcode[index_opc++];
			speed=base_opcode[index_opc++];
			vol=base_opcode[index_opc++];
			chan=base_opcode[index_opc++];

			if (speed>38)
				speed=38;

			if (vol>63)
				vol=63;

			print_numlog("sound(",val1,", ");
			print_numlog("",speed,", ");
			print_numlog("",vol,", ");
			print_numlog("",chan,")\n");

#if PlayModule
			if (vol == 0)
#if USE_KRAWALL
				kramStop(chan);
#else
				AAS_SFX_Stop(chan);
#endif
			else
			{
				if ((filesdata[val1] != 0) && (filestype[val1] == 0))
				{
#if USE_KRAWALL
					while(kramWorkerCall);
					kramPlayCall=TRUE;
					if (!kramHandleValid(chan))
						kramPlayExt(samples[(u32)filesdata[val1]], 1, chan, tab_spl_freqs[speed], vol, 0);
					kramPlayCall=FALSE;
#else
					u32		*sample=(u32 *)filesdata[val1];
					AAS_s8	*spl_start, *spl_end, *spl_loop;

					spl_start=(AAS_s8*)&sample[2];
					spl_end=&spl_start[sample[0]+sample[1]];
					if (sample[1])
						spl_loop=&spl_start[sample[0]];
					else
						spl_loop=AAS_NULL;

					AAS_SFX_Play(chan, vol, tab_spl_freqs[speed], (const AAS_s8*)spl_start, (const AAS_s8*)spl_end, (const AAS_s8*)spl_loop);
#endif
				}
			}
#endif
		}

		else if (opcode == 25)	// load(num_file)
		{
			val1=base_opcode[index_opc++]<<8;
			val1|=base_opcode[index_opc++];

			if (val1 >= 16000)
				game_part=val1;
			else
			{
				if (filestype[val1] == 2)
				{
					if (filesdata[val1] != 0)
					{
						DMACopyCH3(filesdata[val1], tab_screens[0], (LG_SCREEN*HT_SCREEN)/2, DMA_16NOW);
					}

				}
			}
			print_numlog("load(",val1,")\n");
		}

		else if (opcode == 26)	// music(num_file, pos, tempo)
		{
			u16 num_file, pos, tempo;

			num_file=base_opcode[index_opc++]<<8;
			num_file|=base_opcode[index_opc++];

			pos=base_opcode[index_opc++]<<8;
			pos|=base_opcode[index_opc++];

			tempo=base_opcode[index_opc++];

			if ((game_current_part==16001) || (game_current_part==16007))
			{
#if PlayModule
/*				kragInit( KRAG_INIT_STEREO );
				kramStop(0);
				kramStop(1);
				kramStop(2);
				kramStop(3);
				kramSetSFXVol(0);	
				krapSetMusicVol(128,0);	*/

				if (((num_file | pos | tempo) == 0) && (game_current_part==16001))
#if USE_KRAWALL
					krapStop();
#else
					AAS_MOD_Stop();
#endif
				else if (num_file && !pos)
				{
#if USE_KRAWALL
					while(kramWorkerCall);
					kramPlayCall=TRUE;
#endif
					if (game_current_part==16001)
					{
#if USE_KRAWALL
						krapPlay(&mod_intro2004, 0, 0);
#else
						AAS_MOD_Play(AAS_DATA_MOD_intro2004);
						AAS_MOD_SetLoop(AAS_FALSE);
#endif
					}
					else
					{
#if USE_KRAWALL
						krapPlay(&mod_end, KRAP_MODE_LOOP, 0);
					}
					kramPlayCall=FALSE;
#else
						AAS_MOD_SetVolume(256);
						AAS_MOD_Play(AAS_DATA_MOD_end2004);
						AAS_MOD_SetLoop(AAS_TRUE);
				}
#endif
				}
#endif
			}
			print_numlog("music(",num_file,", ");
			print_numlog("",tempo,", ");
			print_numlog("",pos,")");
		}
		else
			print_numlog("Erreur opcode ", opcode,"\n");
	}
	
	return index_opc;
}

void interpret_all()
{
	u16	i, part2;

	profil_rout(PRF_INTERPRETEUR);

	part2=tab_vars[0];

	// Initialisation des tables
	for (i=0; i<MAX_ENTITY; i++)
	{
		tab_entity_flags[i]=tab_entity_frame_flags[i];
		if (tab_entity_frame[i] != -1)
		{
			if (tab_entity_frame[i] == -2)
				tab_entity_pt[i]=-1;
			else
				tab_entity_pt[i]=tab_entity_frame[i];

			tab_entity_frame[i]=-1;
		}
	}

	tab_vars[250]=0;	// Button state
	tab_vars[251]=0;	// Y direction
	tab_vars[252]=0;	// X direction
	tab_vars[253]=0;	// Joystick direction
	tab_vars[254]=0;	// Joystick all states

	if (KEY_DOWN(K_RIGHT))
	{
		tab_vars[252] = 1;
		tab_vars[253] |= 1;
	}

	if (KEY_DOWN(K_LEFT))
	{
		tab_vars[252] = -1;
		tab_vars[253] |= 2;
	}

	if (KEY_DOWN(K_DOWN))
	{
		tab_vars[251] = 1;
		tab_vars[253] |= 4;
	}

	tab_vars[229]=tab_vars[251];

	if (KEY_DOWN(K_A))
	{
		tab_vars[251] = -1;
		tab_vars[253] |= 8;
	}

	if (KEY_DOWN(K_UP))
	{
		tab_vars[229] = -1;
	}	

	tab_vars[254]=tab_vars[253];

	if (KEY_DOWN(K_B))
	{
		tab_vars[250] = 1;
		tab_vars[254] |= 0x80;
	}

	for (i=0; i<MAX_ENTITY; i++)
	{
		pt_op_stack=op_stack;

		if (tab_entity_flags[i] == 0)
		{
			if (tab_entity_pt[i] != -1)
			{
				print_numlog("Entity:",i,"\n");
				tab_entity_pt[i]=interpret(tab_entity_pt[i]);
			}
		}
	}

	// Sauvegarde automatique
	if (tab_vars[0] != part2)
		save_game();
}

