
@ v1.2

@ This file has no copyright assigned and is placed in the Public Domain.
@ You are free to use this source code without limitation.
@
@ This software is distributed WITHOUT ANY WARRANTY. 
@ ALL WARRANTIES, EXPRESSED OR IMPLIED ARE HEREBY DISCLAIMED.
@ This includes but is not limited to warranties
@ of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

.IFNDEF LZSS_D_H
.EQU    LZSS_D_H, 1

.GLOBAL LZ77UnCompWRAM, LZ77UnCompVRAM

.ENDIF  @ LZSS_D_H
