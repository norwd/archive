#ifndef __AAS_DATA__
#define __AAS_DATA__

#include "AAS.h"

#if AAS_VERSION != 0x110
#error AAS version does not match Conv2AAS version
#endif

AAS_BEGIN_DECLS

extern const AAS_u8 AAS_DATA_MOD_intro2004;

extern const AAS_u8 AAS_DATA_MOD_end2004;

AAS_END_DECLS

#endif
