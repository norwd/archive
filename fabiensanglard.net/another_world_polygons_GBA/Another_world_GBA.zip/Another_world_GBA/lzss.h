
@ v1.2.03

@ This file has no copyright assigned and is placed in the Public Domain.
@ You are free to use this source code without limitation.
@
@ This software is distributed WITHOUT ANY WARRANTY. 
@ ALL WARRANTIES, EXPRESSED OR IMPLIED ARE HEREBY DISCLAIMED.
@ This includes but is not limited to warranties
@ of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

.IFNDEF LZSS_H
.EQU    LZSS_H, 1

.GLOBAL LZ77CompWRAM


LOGN           =          12
N              =     1<<LOGN
NULL           =          -2
NULL_COMP      =       ~NULL
ND_X_SIZE      =     1<<LOGN
BST_SIZE       =   ND_X_SIZE * 3
HASH_SIZE      =         256
TEMP_SIZE      =   HASH_SIZE + BST_SIZE
F              =          18
THRESHOLD      =           2

MASK_INIT      =        0x80


REG_DMA3SAD    =  0x040000D4
DMA_MODE_01    =  0x85000000

SP_BASOFF_OUT  =           0           @ These 4 values must stay glued
SP_MASK        =           4           @ and at the top of the stack (ldm possible)
SP_COMP_CODE   =           8           @
SP_LIMIT_OUT   =          12           @
SP_CODE_PTR    =          16

.ENDIF  @ LZSS_H
