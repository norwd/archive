#include "gbatypes.h"

const u8 file001[6716]={};
const u8 file002[11828]={};
const u8 file003[27128]={};
const u8 file004[17872]={};
const u8 file005[3836]={}
const u8 file006[3368]={}
const u8 file008[9844]={}
const u8 file009[11192]={}
const u8 file010[11188]={}
const u8 file011[1064]={}
const u8 file012[6228]={}
const u8 file013[1428]={}
const u8 file014[5104]={}
const u8 file015[1952]={}
const u8 file016[22180]={}
const u8 file017[25108]={}
const u8 file020[1024]={}
const u8 file021[4508]={}
const u8 file022[5124]={}
const u8 file023[1024]={}
const u8 file024[9908]={}
const u8 file025[65232]={}
const u8 file026[1024]={}
const u8 file027[21032]={}
const u8 file028[57512]={}
const u8 file029[1024]={}
const u8 file030[41128]={}
const u8 file031[51784]={}
const u8 file032[1024]={}
const u8 file033[63200]={}
const u8 file034[62716]={}
const u8 file035[1024]={}
const u8 file036[8096]={}
const u8 file037[23120]={}
const u8 file038[1024]={}
const u8 file039[51084]={}
const u8 file040[57524]={}
const u8 file041[1024]={}
const u8 file042[2908]={}
const u8 file043[16792]={}
const u8 file044[884]={}
const u8 file045[7684]={}
const u8 file046[2284]={}
const u8 file047[6728]={}
const u8 file048[13376]={}
const u8 file049[5280]={}
const u8 file050[6248]={}
const u8 file051[616]={}
const u8 file053[424]={}
const u8 file054[8172]={}
const u8 file055[5028]={}
const u8 file056[5572]={}
const u8 file057[3628]={}
const u8 file058[872]={}
const u8 file059[120]={}
const u8 file060[5012]={}
const u8 file061[1760]={}
const u8 file062[8624]={}
const u8 file063[1276]={}
const u8 file064[4768]={}
const u8 file065[2484]={}
const u8 file066[1260]={}
const u8 file067[36000]={}
const u8 file068[36000]={}
const u8 file069[36000]={}
const u8 file070[36000]={}
const u8 file072[36000]={}
const u8 file073[36000]={}
const u8 file074[960]={}
const u8 file075[5096]={}
const u8 file076[1248]={}
const u8 file077[1532]={}
const u8 file078[608]={}
const u8 file079[1604]={}
const u8 file080[6608]={}
const u8 file081[232]={}
const u8 file082[4132]={}
const u8 file084[22700]={}
const u8 file085[2448]={}
const u8 file086[11332]={}
const u8 file087[5420]={}
const u8 file088[1460]={}
const u8 file089[9140]={}
const u8 file090[8100]={}
const u8 file091[3360]={}
const u8 file092[1320]={}
const u8 file093[5640]={}
const u8 file094[492]={}
const u8 file095[2028]={}
const u8 file096[232]={}
const u8 file097[14712]={}
const u8 file098[4472]={}
const u8 file099[5296]={}
const u8 file100[2724]={}
const u8 file101[732]={}
const u8 file102[9844]={}
const u8 file103[4848]={}
const u8 file104[23896]={}
const u8 file105[41508]={}
const u8 file106[11880]={}
const u8 file107[20936]={}
const u8 file108[5096]={}
const u8 file109[5280]={}
const u8 file110[22700]={}
const u8 file111[17500]={}
const u8 file112[3472]={}
const u8 file113[2532]={}
const u8 file114[6540]={}
const u8 file115[9684]={}
const u8 file116[9264]={}
const u8 file117[4888]={}
const u8 file118[544]={}
const u8 file119[1516]={}
const u8 file120[1084]={}
const u8 file121[2284]={}
const u8 file122[5240]={}
const u8 file123[17200]={}
const u8 file124[1744]={}
const u8 file125[1024]={}
const u8 file126[3036]={}
const u8 file127[784]={}
const u8 file128[6300]={}
const u8 file129[2008]={}
const u8 file130[1124]={}
const u8 file131[4008]={}
const u8 file132[26416]={}
const u8 file136[9340]={}
const u8 file139[20316]={}
const u8 file140[17432]={}
const u8 file141[10556]={}
const u8 file142[16328]={}
const u8 file144[36000]={}
const u8 file145[36000]={}


const u8 *filesdata[146]={
	0,
	file001,
	file002,
	file003,
	file004,
	file005,
	file006,
	0,
	file008,
	file009,
	file010,
	file011,
	file012,
	file013,
	file014,
	file015,
	file016,
	file017,
	0,
	0,
	file020,
	file021,
	file022,
	file023,
	file024,
	file025,
	file026,
	file027,
	file028,
	file029,
	file030,
	file031,
	file032,
	file033,
	file034,
	file035,
	file036,
	file037,
	file038,
	file039,
	file040,
	file041,
	file042,
	file043,
	file044,
	file045,
	file046,
	file047,
	file048,
	file049,
	file050,
	file051,
	0,
	file053,
	file054,
	file055,
	file056,
	file057,
	file058,
	file059,
	file060,
	file061,
	file062,
	file063,
	file064,
	file065,
	file066,
	file067,
	file068,
	file069,
	file070,
	0,
	file072,
	file073,
	file074,
	file075,
	file076,
	file077,
	file078,
	file079,
	file080,
	file081,
	file082,
	0,
	file084,
	file085,
	file086,
	file087,
	file088,
	file089,
	file090,
	file091,
	file092,
	file093,
	file094,
	file095,
	file096,
	file097,
	file098,
	file099,
	file100,
	file101,
	file102,
	file103,
	file104,
	file105,
	file106,
	file107,
	file108,
	file109,
	file110,
	file111,
	file112,
	file113,
	file114,
	file115,
	file116,
	file117,
	file118,
	file119,
	file120,
	file121,
	file122,
	file123,
	file124,
	file125,
	file126,
	file127,
	file128,
	file129,
	file130,
	file131,
	file132,
	0,
	0,
	0,
	file136,
	0,
	0,
	file139,
	file140,
	file141,
	file142,
	0,
	file144,
	file145	};

const u8 filestype[146]={
	0, 0, 0, 0, 0, 0, 0, 1,
	0, 0, 0, 0, 0, 0, 0, 0,
	0, 6, 2, 2, 3, 4, 5, 3,
	4, 5, 3, 4, 5, 3, 4, 5,
	3, 4, 5, 3, 4, 5, 3, 4,
	5, 3, 4, 5, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 2, 2, 2, 2, 2,
	2, 2, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 2, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 3, 4, 5,
	0, 0, 0, 0, 0, 0, 0, 0,
	0, 1, 1, 0, 0, 0, 0, 0,
	2, 2	};
