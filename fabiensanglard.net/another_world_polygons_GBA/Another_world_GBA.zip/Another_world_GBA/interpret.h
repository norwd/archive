#ifndef _INTERPRET_H_
#define _INTERPRET_H_

#include "gbatypes.h"

extern	s16		*tab_vars;
extern	u16		game_current_part,
				game_part;

extern	void	init_interpret(u16 part, u16 part2);
extern	void	load_gamepart();
extern	void	interpret_all();

#endif
