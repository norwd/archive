/**************************************************************
*	
* GBAInterrupts.h : Fichier en-tete comprenant les elements
*                   permettant l'utilisation des Interruptions
*
*            NE PAS OUBLIER DE MODIFIER "crt0.s" !!! :
*               .equ __InterruptSupport, 1
*            et
*               .equ __SingleInterrupts, 1 
*           (ou .equ __MultipleInterrupts, 1 @mais pas les 2!)
*
*            et eventuellement  (si blocage du prog):
*               @.equ __ISRinIWRAM, 1 
*
* Cree le : 03.03.2002
* Par : Edorul (edorul@free.fr)
*         http://www.ifrance.com/edorul/
*
* Ver. : 0.1.1
* Modifi� le 05.03.2002
*
***************************************************************/

#ifndef GBAINTERRUPT_H
#define GBAINTERRUPT_H

#include "GBATypes.h"

// DEFINITIONS 
//-------------

#define IME_REG					*(u16*)0x4000208
#define IE_REG					*(u16*)0x4000200
#define IF_REG					*(volatile u16*)0x4000202

#define KEYCNT_REG				*(u16*)0x4000132

#define IT_VBLANK				1
#define IT_HBLANK				2
#define IT_YTRIG				4
#define IT_TIMER0				8
#define IT_TIMER1				0x10
#define IT_TIMER2				0x20
#define IT_TIMER3				0x40
#define IT_COMMS				0x80
#define IT_DMA0					0x100
#define IT_DMA1					0x200
#define IT_DMA2					0x400
#define IT_DMA3					0x800
#define IT_KEYPAD				0x1000
#define IT_CART					0x2000
#define IT_ALL					0x3FFF

#define KEYIT_ENABLE	0x4000
#define KEYIT_OR		0
#define KEYIT_AND		0x8000

// definition du registre DISP_SR
#define DISP_SR			*(volatile u16*)0x4000004
#define INT_VBLANK		0x1
#define INT_HBLANK		0x2
#define INT_YTRIG		0x4
#define E_VBLANK		0x8
#define E_HBLANK		0x10
#define E_YTRIG			0x20
#define YTRIG_VAL		0xff00

//ecriture DISP_SR buffer
#define SetDISP_SR(mode) DISP_SR=((mode)+(DISP_SR&E_VBLANK)+(DISP_SR&E_HBLANK)+(DISP_SR&E_YTRIG))

//ajouter les options passees en argument a DISP_SR
#define EnableDISP_SR(mode) DISP_SR|=(mode)

//supprime les options de DISP_SR passees en argument
#define DisableDISP_SR(mode) DISP_SR&=~(mode)


extern	void Set_Interrupt(u16 Interrupt, void *function);
extern	void Enable_Interrupts(u16 Interrupt);
extern	void Disable_Interrupts(u16 Interrupt);
extern	void Set_KEYPADInterrupt(u16 it_type, u16 it_keys, void *function);
extern	void Set_YTRIGInterrupt(u16 val, void *function);

#endif

