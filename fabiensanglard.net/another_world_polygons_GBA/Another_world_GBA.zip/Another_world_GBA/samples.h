#ifndef __SAMPLES_H__
#define __SAMPLES_H__

#define SAMPLE_IN_CLEAN 0
#define SAMPLE_DR_ZBASS 2
#define SAMPLE_DR_HATIN 3
#define SAMPLE_DR_HIHAT4 4
#define SAMPLE_IN_PIANOLIGHT 5
#define SAMPLE_E 6
#define SAMPLE_H 7
#define SAMPLE_E 8
#define SAMPLE_NAPP3L2 14
#define SAMPLE_BBASS2SHORT 15
#define SAMPLE_BEEP4 18
#define SAMPLE_SNARVAN2 19

#endif

