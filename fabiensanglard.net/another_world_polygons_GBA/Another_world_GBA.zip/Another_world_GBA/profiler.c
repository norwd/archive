#include "gbatypes.h"
#include "GBAInterrupts.h"
#include "inters.h"
#include "profiler.h"
#include "gbainput.h"

#if PROFILER

#define REG_TM3CNT_L    *(volatile u16*)0x400010C
#define REG_TM3CNT_H    *(volatile u16*)0x400010E

#define MAX_PROFIL_ROUTS	50

u8	flag_log=1;
u16	profil_on=0;
volatile u16	current_rout;
u32 profil_times[MAX_PROFIL_ROUTS];
u32 total_time;

void profil_it()
{
	if (profil_on)
	{
		profil_times[current_rout]++;
		total_time++;
	}
}

void print_log(const char *s,...)
{
	if (KEY_DOWN(K_START))
		flag_log=1;
	if (flag_log==0)
		return;

    asm volatile("mov r0, %0;"
                  "swi 0xff0000;"
                  : // no ouput
                  : "r" (s)
                  : "r0");
}

void print_numlog(char *s1, u32 val, char *s2)
{
	u16	i;
	u8	txt[9],chr;

	txt[8]=0;
	for (i=0; i<8; i++)
	{
		chr=((val>>(i*4)) & 15);
		if (chr<10)
			txt[7-i]='0'+chr;
		else
			txt[7-i]='A'+chr-10;
	}
	print_log(s1);
	print_log(txt);
	print_log(s2);
}

void profil_init()
{
	Set_Interrupt(IT_TIMER3, &profil_it);
	REG_TM3CNT_L=0xffff-(unsigned int)16772216/44100;
	REG_TM3CNT_H=0x00C0;
}

void profil_start(u16 rout)
{
	int i;

	for (i=0; i<MAX_PROFIL_ROUTS; i++)
		profil_times[i]=0;
	total_time=0;
	current_rout=rout;
	profil_on=1;
}

void profil_stop()
{
	profil_on=0;

	print_log("-----------------------\n");

	print_numlog("Main: ", profil_times[PRF_MAINLOOP], "");
	print_numlog(" -> ", (profil_times[PRF_MAINLOOP]*100)/total_time, "%\n");

	print_numlog("Interpreteur: ", profil_times[PRF_INTERPRETEUR], "");
	print_numlog(" -> ", (profil_times[PRF_INTERPRETEUR]*100)/total_time, "%\n");

	print_numlog("DrawShape: ", profil_times[PRF_DRAWSHAPE], "");
	print_numlog(" -> ", (profil_times[PRF_DRAWSHAPE]*100)/total_time, "%\n");

	print_numlog("Print: ", profil_times[PRF_PRINT], "");
	print_numlog(" -> ", (profil_times[PRF_PRINT]*100)/total_time, "%\n");

	print_numlog("GFX Divers: ", profil_times[PRF_GFX_DIVERS], "");
	print_numlog(" -> ", (profil_times[PRF_GFX_DIVERS]*100)/total_time, "%\n");

	print_numlog("\nTotal_time=",total_time,"\n");
}

void profil_rout(u16 num_rout)
{
	current_rout=num_rout;
}
#endif
