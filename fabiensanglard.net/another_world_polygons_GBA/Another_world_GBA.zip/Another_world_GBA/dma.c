/************************************\
* DMA.c by dovoto *
\************************************/
#define DMA_C
#include "gbatypes.h"
#include "dma.h"

//DMA registers
#define REG_DMA0SAD     *(volatile u32*)0x40000B0
#define REG_DMA0SAD_L   *(volatile u16*)0x40000B0
#define REG_DMA0SAD_H   *(volatile u16*)0x40000B2
#define REG_DMA0DAD     *(volatile u32*)0x40000B4
#define REG_DMA0DAD_L   *(volatile u16*)0x40000B4
#define REG_DMA0DAD_H   *(volatile u16*)0x40000B6
#define REG_DMA0CNT     *(volatile u32*)0x40000B8
#define REG_DMA0CNT_L   *(volatile u16*)0x40000B8
#define REG_DMA0CNT_H   *(volatile u16*)0x40000BA
#define REG_DMA1SAD     *(volatile u32*)0x40000BC
#define REG_DMA1SAD_L   *(volatile u16*)0x40000BC
#define REG_DMA1SAD_H   *(volatile u16*)0x40000BE
#define REG_DMA1DAD     *(volatile u32*)0x40000C0
#define REG_DMA1DAD_L   *(volatile u16*)0x40000C0
#define REG_DMA1DAD_H   *(volatile u16*)0x40000C2
#define REG_DMA1CNT     *(volatile u32*)0x40000C4
#define REG_DMA1CNT_L   *(volatile u16*)0x40000C4
#define REG_DMA1CNT_H   *(volatile u16*)0x40000C6
#define REG_DMA2SAD     *(volatile u32*)0x40000C8
#define REG_DMA2SAD_L   *(volatile u16*)0x40000C8
#define REG_DMA2SAD_H   *(volatile u16*)0x40000CA
#define REG_DMA2DAD     *(volatile u32*)0x40000CC
#define REG_DMA2DAD_L   *(volatile u16*)0x40000CC
#define REG_DMA2DAD_H   *(volatile u16*)0x40000CE
#define REG_DMA2CNT     *(volatile u32*)0x40000D0
#define REG_DMA2CNT_L   *(volatile u16*)0x40000D0
#define REG_DMA2CNT_H   *(volatile u16*)0x40000D2
#define REG_DMA3SAD     *(volatile u32*)0x40000D4
#define REG_DMA3SAD_L   *(volatile u16*)0x40000D4
#define REG_DMA3SAD_H   *(volatile u16*)0x40000D6
#define REG_DMA3DAD     *(volatile u32*)0x40000D8
#define REG_DMA3DAD_L   *(volatile u16*)0x40000D8
#define REG_DMA3DAD_H   *(volatile u16*)0x40000DA
#define REG_DMA3CNT     *(volatile u32*)0x40000DC
#define REG_DMA3CNT_L   *(volatile u16*)0x40000DC
#define REG_DMA3CNT_H   *(volatile u16*)0x40000DE

//just an little bit of empty memory
u32 clear = 0;
u32	fill32 =0;
u16	fill16 =0;

void DMACopyCH0(void* source, void* dest, u32 WordCount, u32 mode) {
//	while((volatile)REG_DMA0CNT & DMA_ENABLE);
	REG_DMA0CNT = 0;
    REG_DMA0SAD = (u32)source;      //Tell the gba our source address
    REG_DMA0DAD = (u32)dest;        //Tell the gba where the data should get copied to
    REG_DMA0CNT = WordCount | mode; //Set the mode
}

void DMACopyCH1(void* source, void* dest, u32 WordCount, u32 mode) {
//	while((volatile)REG_DMA1CNT & DMA_ENABLE);
	REG_DMA1CNT = 0;
    REG_DMA1SAD = (u32)source;
    REG_DMA1DAD = (u32)dest;
    REG_DMA1CNT = WordCount | mode;
}

void DMACopyCH2(void* source, void* dest, u32 WordCount, u32 mode) {
//	while((volatile)REG_DMA2CNT & DMA_ENABLE);
	REG_DMA2CNT = 0;
    REG_DMA2SAD = (u32)source;
    REG_DMA2DAD = (u32)dest;
    REG_DMA2CNT = WordCount | mode;
}

void wait_DMACH3()
{
	while(REG_DMA3CNT & DMA_ENABLE);
}

/*
void DMACopyCH3(void* source, void* dest, u32 WordCount, u32 mode)
{
//	wait_DMACH3();

	REG_DMA3CNT = 0;
    REG_DMA3SAD = (u32)source;
    REG_DMA3DAD = (u32)dest;
    REG_DMA3CNT = WordCount | mode;
}	*/

void CODE_IN_IWRAM DMACopyCH3(void* source, void* dest, u32 WordCount, u32 mode)
{
	u32 i;

	for (i=0; i<WordCount; i++)
		*((u16 *)dest)++=*((u16 *)source)++;
}

//these functions are very handy for cleaning ploted text
//since the source is fixed, the function will always copy 0
void DMAClearMemory16(void* dest, u32 WordCount) {
	REG_DMA3CNT = 0;
    REG_DMA3SAD = (u32)&clear; //get the address of "clear" and pass it to the DMA controller as our source
    REG_DMA3DAD = (u32)dest;
    REG_DMA3CNT = WordCount | DMA_ENABLE | DMA_TIMEING_IMMEDIATE | DMA_16 | DMA_SOURCE_FIXED;
}

void DMAClearMemory32(void* dest, u32 WordCount) {
	REG_DMA3CNT = 0;
    REG_DMA3SAD = (u32)&clear;
    REG_DMA3DAD = (u32)dest;
    REG_DMA3CNT = WordCount | DMA_ENABLE | DMA_TIMEING_IMMEDIATE | DMA_32 | DMA_SOURCE_FIXED;
}

/*
void DMAFillMemory16(void* dest, u32 WordCount, u16 val_fill) {
	fill16=val_fill;
	REG_DMA3CNT = 0;
    REG_DMA3SAD = (u32)&fill16; //get the address of "clear" and pass it to the DMA controller as our source
    REG_DMA3DAD = (u32)dest;
    REG_DMA3CNT = WordCount | DMA_ENABLE | DMA_TIMEING_IMMEDIATE | DMA_16 | DMA_SOURCE_FIXED;
}	*/

void CODE_IN_IWRAM DMAFillMemory16(void* dest, u32 WordCount, u16 val_fill)
{
	u32 i;

	for (i=0; i<WordCount; i++)
		*((u16 *)dest)++=val_fill;
}

void DMAFillMemory32(void* dest, u32 WordCount, u32 val_fill) {
	fill32=val_fill;
	REG_DMA3CNT = 0;
    REG_DMA3SAD = (u32)&fill32;
    REG_DMA3DAD = (u32)dest;
    REG_DMA3CNT = WordCount | DMA_ENABLE | DMA_TIMEING_IMMEDIATE | DMA_32 | DMA_SOURCE_FIXED;
}
