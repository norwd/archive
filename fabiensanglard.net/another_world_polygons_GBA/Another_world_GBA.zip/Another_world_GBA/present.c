#include "gbatypes.h"
#include "gbainput.h"
#include "inters.h"
#if PlayModule
#if USE_KRAWALL
#include "krawall.h"
#include "modules.h"
#else
#include "aas.h"
#include "AAS_Data.h"
#endif
#endif
#include "graphs.h"
#include "interpret.h"

#define BGPaletteMem	((u16 *)0x5000000)		/* Background Palette */
#define FrontBuffer		((u16 *)0x6000000)		/* Front Display Memory (the screen) */
#define BackBuffer		((u16 *)0x600a000)
#define GamepakRam		((u8 *)0x0E000000)
#define DISP_CR			*(u16*)0x4000000
#define BACKBUFFER		0x10

//#include "gfx\splash.pal.c"
//#include "gfx\splash.raw.c"
#include "gfx\titre3_2.pal.c"
#include "gfx\titre3_2.raw.c"
#include "gfx\titre3e_2.pal.c"
#include "gfx\titre3e_2.raw.c"
#include "gfx\credit5.pal.c"
#include "gfx\credit5.raw.c"
#include "gfx\credit8.pal.c"
#include "gfx\credit8.raw.c"
#include "gfx\Foxy1.pal.c"
#include "gfx\Foxy1.raw.c"
//#include "gfx\Playeradvance1.pal.c"
//#include "gfx\Playeradvance1.raw.c"
#include "gfx\titre_another_world2.pal.c"
#include "gfx\titre_another_world2.raw.c"

#define getRGB(R,G,B,PAL) (B) = ((PAL) >> 10) & 31; \
	                      (G) = ((PAL) >> 5)  & 31; \
                          (R) = (PAL) & 31;

#define setRGB(R,G,B) (B) << 10 | (G) << 5 | (R)

extern u16 part2;

u16	old_part;
u16	*pt_titre_Pal=(u16 *)titre3e_2_Palette;
u8	*pt_titre_Bmp=(u8 *)titre3e_2_Bitmap;

const	u8	*savram[]={"EEPROM_V124"};

// extern __attribute__((long_call)) *char LZ77CompWRAM(char*, char*, int, short*, char*);
// u8	__attribute__ ((aligned (2))) tmp_pack[25088];

void save_game()
{
	u8	*pt_gpram=GamepakRam;
//	u8	i;

	if ((game_current_part == 16008) || (game_current_part == 16009))
		return;

	*pt_gpram++='F';
	*pt_gpram++='A';
	*pt_gpram++='n';
	*pt_gpram++='W';
	*pt_gpram++='o';
	*pt_gpram++='r';
	*pt_gpram++='l';
	*pt_gpram++='d';

	*pt_gpram++=(game_current_part >> 8) & 0xFF;
	*pt_gpram++=game_current_part & 0xFF;
	*pt_gpram++=luminosite;
	*pt_gpram++=contraste;
	*pt_gpram++=(tab_vars[0] >> 8) & 0xFF;
	*pt_gpram++=tab_vars[0] & 0xFF;
	*pt_gpram++=langue;

/*
	*pt_gpram++=0;	// Pad pour un alignement sur un word

	// Sauvegarde les ecrans
	for (i=0; i<4; i++)
		pt_gpram=LZ77CompWRAM(tab_screens[i], pt_gpram, LG_SCREEN*HT_SCREEN, tmp_pack, (char*) 0x0E040000);

	pt_gpram=LZ77CompWRAM(tab_screens[i], pt_gpram, LG_SCREEN*HT_SCREEN, tmp_pack, (char*) 0x0E040000);
*/
}

void load_game()
{
	u8	*pt_gpram=GamepakRam;
	u32	val;

	old_part=16001;
	val=(pt_gpram[0]<<24)+(pt_gpram[1]<<16)+(pt_gpram[2]<<8)+pt_gpram[3];
	if (val != ('F'<<24)+('A'<<16)+('n'<<8)+'W')
		return;
	pt_gpram+=4;
	val=(pt_gpram[0]<<24)+(pt_gpram[1]<<16)+(pt_gpram[2]<<8)+pt_gpram[3];
	if (val != ('o'<<24)+('r'<<16)+('l'<<8)+'d')
		return;
	pt_gpram+=4;

	old_part=(pt_gpram[0]<<8)+pt_gpram[1];
	pt_gpram+=2;

	luminosite=*pt_gpram++;
	contraste=*pt_gpram++;

	part2=(pt_gpram[0]<<8)+pt_gpram[1];
	pt_gpram+=2;

	langue=*pt_gpram++;

	if ((luminosite == 0) || (contraste == 0) || (luminosite > 127) || (contraste > 127))
	{
		luminosite=70;
		contraste=70;
	}

	if (langue)
	{
		pt_titre_Pal=(u16 *)titre3e_2_Palette;
		pt_titre_Bmp=(u8 *)titre3e_2_Bitmap;
	}
	else
	{
		pt_titre_Pal=(u16 *)titre3_2_Palette;
		pt_titre_Bmp=(u8 *)titre3_2_Bitmap;
	}
}

void set_palette(u16 *pal, u16 *mem, u16 ncol)
{
    int i;

    for (i=0; i<ncol; i++)
        mem[i]=pal[i];
}

void fade_out(const u16 *pal, u16 *pdst, u16 step, u16 ncol, u16 speed)
{
	u16 fader, fadeg, fadeb;
	u16 colr,colg,colb;
	u16 i,j,fadepal[256];

    for (j=0; j<step; j++)
    {
    	for (i=0; i<ncol; i++)
    	{
    		getRGB(fader, fadeg, fadeb, pdst[i]);
    		getRGB(colr, colg, colb, pal[i]);
    		if (fader<colr)  fader++;
    		if (fadeg<colg)  fadeg++;
    		if (fadeb<colb)  fadeb++;
    		fadepal[i] = setRGB(fader, fadeg, fadeb);
    	}

        for (i=0; i<speed; i++)
		{
			num_vbl=0;
			while(!num_vbl);
		}

        set_palette(fadepal, pdst, ncol);
    }
}

void fade_in(u16 *pdst, u16 step, u16 ncol, u16 speed)
{
	s16 fader, fadeg, fadeb;
	u16 i,j,fadepal[256];

    for (j=0; j<step; j++)
    {
    	for (i=0; i<ncol; i++)
    	{
    		getRGB(fader, fadeg, fadeb, pdst[i]);
    		fader--;   if (fader<0)  fader=0;
    		fadeg--;   if (fadeg<0)  fadeg=0;
    		fadeb--;   if (fadeb<0)  fadeb=0;
    		fadepal[i] = setRGB(fader, fadeg, fadeb);
    	}

        for (i=0; i<speed; i++)
		{
			num_vbl=0;
			while(!num_vbl);
		}

        set_palette(fadepal, pdst, ncol);
    }
}

void affiche_image_pres(u16 *pt_gfx, const u16 *pal)
{
    u16 i;

	for (i=0; i<256; i++)
		BGPaletteMem[i]=0;

    for (i=0; i<(240*160)/2; i++)
        FrontBuffer[i] = *pt_gfx++;

	fade_out(pal,BGPaletteMem,32,256,2);

	for (i=0; i<60*4; i++)
	{
		num_vbl=0;
		while(!num_vbl);

		if (KEY_DOWN(K_A | K_B | K_START))
			break;
	}

	fade_in(BGPaletteMem, 32, 256, 2);
}

void presentation()
{
//	u16 i;
//	u16 *pt_gfx;

	affiche_image_pres((u16 *)Foxy1_Bitmap, Foxy1_Palette);
//	affiche_image_pres((u16 *)Playeradvance1_Bitmap, Playeradvance1_Palette);

/*	load_game();

	pt_gfx=(u16 *)titre_another_world2_Bitmap;

    for (i=0; i<(240*160)/2; i++)
        FrontBuffer[i] = BackBuffer[i] = *pt_gfx++;

	work_screen=(u8 *)BackBuffer;

	printat(910, -1, 180, 1);

	fade_out(titre_another_world2_Palette,BGPaletteMem,32,256,2);

	while(1)
	{
		num_vbl=0;
		while(!num_vbl);

		if (!(i & 15))
			flip();

		if (KEY_DOWN(K_A | K_B | K_START))
			break;

		i++;
	} */
}

void credits()
{
    u16 *pt_gfx,
		*pt_pal;
    u16 i;

	fade_in(BGPaletteMem, 32, 256, 2);

	if (myrand(10) > 5)
	{
		pt_gfx=(u16 *)credit5_Bitmap;
		pt_pal=(u16 *)credit5_Palette;
	}
	else
	{
		pt_gfx=(u16 *)credit8_Bitmap;
		pt_pal=(u16 *)credit8_Palette;
	}

    for (i=0; i<(240*160)/2; i++)
        FrontBuffer[i] = *pt_gfx++;

	fade_out(pt_pal,BGPaletteMem,32,256,2);

	for (i=0; i<60*15; i++)
	{
		num_vbl=0;
		while(!num_vbl);

		if (KEY_DOWN(K_A | K_B | K_START))
			break;
	}

	fade_in(BGPaletteMem, 32, 256, 2);

	pt_gfx=(u16 *)pt_titre_Bmp;

    for (i=0; i<(240*160)/2; i++)
        FrontBuffer[i] = *pt_gfx++;

	fade_out(pt_titre_Pal,BGPaletteMem,32,256,2);
}

u16 menu()
{
    u16 *pt_gfx;
    u16 i, tempo,
		col=0,last_key=0;
	s16	inc=1,pt=0;

	load_game();
	
	for (i=0; i<256; i++)
		BGPaletteMem[i]=0;

	DISP_CR &= ~BACKBUFFER;

	pt_gfx=(u16 *)pt_titre_Bmp;

    for (i=0; i<(240*160)/2; i++)
        FrontBuffer[i] = *pt_gfx++;
/*
#if PlayModule
#if USE_KRAWALL
	krapPlay(&mod_intro, KRAP_MODE_LOOP, 0);
	krapSetMusicVol(128,0);
#else
//	AAS_SetConfig( AAS_CONFIG_MIX_32KHZ, AAS_CONFIG_CHANS_16, AAS_CONFIG_SPATIAL_STEREO, AAS_CONFIG_DYNAMIC_OFF );
	AAS_SetConfig( AAS_CONFIG_MIX_32KHZ, AAS_CONFIG_CHANS_16, AAS_CONFIG_SPATIAL_MONO, AAS_CONFIG_DYNAMIC_OFF );
	AAS_MOD_Play(AAS_DATA_MOD_intro);
	AAS_MOD_SetLoop(AAS_TRUE);
#endif
#endif
*/
	fade_out(pt_titre_Pal,BGPaletteMem,32,256,2);

	tempo=0;

	while(1)
	{
		num_vbl=0;
		while(!num_vbl);

		if ((KEY_DOWN(K_UP) & ~last_key) && (pt != 0))
		{
			BGPaletteMem[252+pt]=setRGB(31,31,31);
			pt--;
			tempo=0;
		}

		if ((KEY_DOWN(K_DOWN) & ~last_key) && (pt != 3))
		{
			BGPaletteMem[252+pt]=setRGB(31,31,31);
			pt++;
			tempo=0;
		}

		if (KEY_DOWN(K_A | K_B))
		{
			if (pt==2)
				credits();
			else if (pt==3)
			{
				langue ^= 1;
				save_game();

				fade_in(BGPaletteMem, 32, 256, 1);

				if (langue)
				{
					pt_titre_Pal=(u16 *)titre3e_2_Palette;
					pt_titre_Bmp=(u8 *)titre3e_2_Bitmap;
				}
				else
				{
					pt_titre_Pal=(u16 *)titre3_2_Palette;
					pt_titre_Bmp=(u8 *)titre3_2_Bitmap;
				}

				pt_gfx=(u16 *)pt_titre_Bmp;

				for (i=0; i<(240*160)/2; i++)
					FrontBuffer[i] = *pt_gfx++;

				fade_out(pt_titre_Pal,BGPaletteMem,32,256,1);

				tempo=0;
			}
			else
				break;
		}
		col+=inc;

		if (col == 0)
			inc=1;
		if (col == 31)
			inc=-1;

		BGPaletteMem[252+pt]=setRGB(col,col,col);

		last_key=KEY_DOWN(K_ALL);

		tempo++;
		if (tempo > 60*30)
		{
			tempo=0;
			credits();
		}
	}

	fade_in(BGPaletteMem, 32, 256, 2);

/*
#if PlayModule
#if USE_KRAWALL
	krapStop();
#else
	AAS_MOD_Stop();
#endif
#endif
*/
	if ((old_part==16001) || (pt!=0))
		affiche_image_pres((u16 *)titre_another_world2_Bitmap, titre_another_world2_Palette);

	if (pt==0)
		return old_part;
	else
	{
		part2=0;
		return 16001;
	}
}
