#ifndef _PRESENT_H_
#define _PRESENT_H_

extern	void	presentation();
extern	u16		menu();
extern	void	save_game();
extern	void	fade_out(const u16 *pal, u16 *pdst, u16 step, u16 ncol, u16 speed);
extern	void	fade_in(u16 *pdst, u16 step, u16 ncol, u16 speed);

#endif
