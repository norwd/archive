/**************************************************************
*	
* GBAInput.h : Fichier en-tete comprenant les elements
*              permettant l'utilisation du JoyPad de la GBA
*
* Cree le : 18.11.2001
* Par : Edorul (edorul@free.fr)
*         http://www.ifrance.com/edorul/
*
* Ver. : 0.2.2
* Modifi� le 11.10.2002
*
***************************************************************/

#ifndef GBAINPUT_H
#define GBAINPUT_H

#include "GBATypes.h"

// DEFINITIONS 
//-------------

// definition du registre KEYS_REG
#define KEYS_REG		*(volatile u16*)0x4000130
#define KEYCNT_REG		*(u16*)0x4000132
#define K_A				0x1
#define K_B				0x2
#define K_SELECT		0x4
#define K_START			0x8
#define K_RIGHT			0x10
#define K_LEFT			0x20
#define K_UP			0x40
#define K_DOWN			0x80
#define K_R				0x100
#define K_L				0x200
#define K_NONE			0x0
#define K_ALL			0x3FF

// MACROS & FONCTIONS
//--------------------

//verification si une des touches est pressee
//   si = 0 touches non pressees
//   si = 1 touche pressee
#define KEY_DOWN(keys)		(~(KEYS_REG | 0xFC00) & (keys))

//verification si une des touches est relachee
//   si = 0 touches non relachees
//   si = 1 touche relachee
#define KEY_UP(keys)		!(~(KEYS_REG | 0xFC00) & (keys)) 

/*
//attente que au moins l'une des touches 
// passee en argument soit pressee
void Wait_KeyDown(u16 keys){
	while (KEY_UP(keys));
}
 
//attente que TOUTES les touches passees en argument soient relachees 
// ###fonctionne pas super...mais OK pour K_ALL et K_NONE :)
void Wait_KeyUp(u16 keys){
	while (KEY_DOWN(keys));
}

// FONCTION CODEE PAR "ANTHONY MARAGOU"
//
// attente que L'UNE des touches passees en argument soit relachee
// la fonction renvoie la touche relachee
u16 Wait_KeyRelease(u16 keys){
	u16 monitor_K_A = keys&K_A ;
	u16 monitor_K_B = keys&K_B ;
	u16 monitor_K_SELECT = keys&K_SELECT ;
	u16 monitor_K_START = keys&K_START ;
	u16 monitor_K_RIGHT = keys&K_RIGHT ;
	u16 monitor_K_LEFT = keys&K_LEFT ;
	u16 monitor_K_UP = keys&K_UP ;
	u16 monitor_K_DOWN = keys&K_DOWN ;
	u16 monitor_K_R = keys&K_R ;
	u16 monitor_K_L = keys&K_L ;
 
	while (1) {
		if (monitor_K_A&KEY_UP(K_A)) return K_A ;
		if (monitor_K_B&KEY_UP(K_B)) return K_B ;
		if (monitor_K_SELECT&KEY_UP(K_SELECT)) return K_SELECT ;
		if (monitor_K_START&KEY_UP(K_START)) return K_START ;
		if (monitor_K_RIGHT&KEY_UP(K_RIGHT)) return K_RIGHT ;
		if (monitor_K_LEFT&KEY_UP(K_LEFT)) return K_LEFT ;
		if (monitor_K_UP&KEY_UP(K_UP)) return K_UP ;
		if (monitor_K_DOWN&KEY_UP(K_DOWN)) return K_DOWN ;
		if (monitor_K_R&KEY_UP(K_R)) return K_R ;
		if (monitor_K_L&KEY_UP(K_L)) return K_L ;
	}
}

// renvoi dans une variable les touches pressees
u16 GetKeys(void){
	return (u32)~(KEYS_REG | 0xFC00);
}
*/
#endif

