#include "gbatypes.h"
#include "GBAInterrupts.h"
#include "inters.h"
#if PlayModule
#if USE_KRAWALL
#include "krawall.h"
#else
#include "aas.h"
#endif
#endif

#define	RAND_MAX	32767

volatile u16	num_vbl;
volatile BOOL kramWorkerCall=FALSE;
volatile BOOL kramPlayCall=FALSE;

u32	seed;

//Tableau contenant les fonctions � appeler en fonction de l'interruption active
void *AAS_IntrTable[14] = {	NULL, NULL, NULL, NULL, NULL,
						NULL, NULL, NULL, NULL, NULL,
						NULL, NULL, NULL, NULL };
void it_vbl()
{
#if PlayModule
#if USE_KRAWALL
	while(kramPlayCall);
	kramWorkerCall=TRUE;
	kramWorker();
	kramWorkerCall=FALSE;
#else
	AAS_DoWork();
#endif
#endif
	num_vbl++;

	seed *= 20077;
	seed += 12345;
} 

void init_inters()
{
	num_vbl=0;
	Set_Interrupt(IT_VBLANK, &it_vbl);
#if PlayModule
#if USE_KRAWALL
	Set_Interrupt(IT_TIMER1, &kradInterrupt);
#else
	Set_Interrupt(IT_TIMER1, &AAS_Timer1InterruptHandler);
#endif
#endif
}

s16 myrand(s16 Value)
{
   seed *= 20077;
   seed += 12345;
   return ((((seed >> 16) & RAND_MAX) * Value) >> 15);
}

// FONCTIONS 
//-----------

//Active une interruption et definie le nom de la fonction a lancer en cas d'activation de l'interruption
void Set_Interrupt(u16 Interrupt, void *function)
{
	u16 i=0;

	IME_REG = 0;
	
	IE_REG |= Interrupt;

	//En plus, il faut mettre la validation de l'interruption
	// dans d'autres registres en fonction de l'interruption
	// demandee : c'est obligatoire, sinon ca ne marche pas !
	// (IF_REG n'est pas modifie)
	if(Interrupt == IT_VBLANK)
		DISP_SR |= E_VBLANK;

	if(Interrupt == IT_HBLANK)
		DISP_SR |= E_HBLANK;
	
	//IT_YTRIG ne devrait pas etre defini par cette fonction... mais on sait jamais
	if(Interrupt == IT_YTRIG)
		DISP_SR |= E_YTRIG;

	if(Interrupt == IT_TIMER0)
		*(u16*)0x4000102 |= 0x40;

	if(Interrupt == IT_TIMER1)
		*(u16*)0x4000106 |= 0x40;

	if(Interrupt == IT_TIMER2)
		*(u16*)0x400010A |= 0x40;

	if(Interrupt == IT_TIMER3)
		*(u16*)0x400010E |= 0x40;

	if(Interrupt == IT_COMMS)
		*(u16*)0x4000128 |= 0x4000;

	if(Interrupt == IT_DMA0)
		*(u16*)0x40000BA |= 0x4000;

	if(Interrupt == IT_DMA1)
		*(u16*)0x40000C6 |= 0x4000;

	if(Interrupt == IT_DMA2)
		*(u16*)0x40000D2 |= 0x4000;

	if(Interrupt == IT_DMA3)
		*(u16*)0x40000DE |= 0x4000;

	//IT_KEYPAD ne devrait pas etre defini par cette fonction... mais on sait jamais
	if(Interrupt == IT_KEYPAD)
		KEYCNT_REG |= KEYIT_ENABLE;

	while((1<<i) != Interrupt)
		i++;

	AAS_IntrTable[i] = function;

	IME_REG = 1;
}

void Enable_Interrupts(u16 Interrupt)
{
	IME_REG = 0;
	
	IE_REG |= Interrupt;

	//En plus, il faut mettre la validation de l'interruption
	// dans d'autres registres en fonction de l'interruption
	// demandee : c'est obligatoire, sinon ca ne marche pas !
	if(Interrupt & IT_VBLANK)
		DISP_SR |= E_VBLANK;

	if(Interrupt & IT_HBLANK)
		DISP_SR |= E_HBLANK;
	
	if(Interrupt & IT_YTRIG)
		DISP_SR |= E_YTRIG;

	if(Interrupt & IT_TIMER0)
		*(u16*)0x4000102 |= 0x40;

	if(Interrupt & IT_TIMER1)
		*(u16*)0x4000106 |= 0x40;

	if(Interrupt & IT_TIMER2)
		*(u16*)0x400010A |= 0x40;

	if(Interrupt & IT_TIMER3)
		*(u16*)0x400010E |= 0x40;

	if(Interrupt & IT_COMMS)
		*(u16*)0x4000128 |= 0x4000;

	if(Interrupt & IT_DMA0)
		*(u16*)0x40000BA |= 0x4000;

	if(Interrupt & IT_DMA1)
		*(u16*)0x40000C6 |= 0x4000;

	if(Interrupt & IT_DMA2)
		*(u16*)0x40000D2 |= 0x4000;

	if(Interrupt & IT_DMA3)
		*(u16*)0x40000DE |= 0x4000;

	if(Interrupt & IT_KEYPAD)
		KEYCNT_REG |= KEYIT_ENABLE;

	IME_REG = 1;
}

// Desactive une (plusieurs ou toutes les) interruption(s)
void Disable_Interrupts(u16 Interrupt)
{
	u16 i;

	if (Interrupt == IT_ALL)
	{
		for(i=0; i<14; i++)
			IE_REG &= ~(1<<i);
		IME_REG = 0;
	}
	else
		IE_REG &= ~(Interrupt);
}

// Active une interruption si les touches pass�es en argument sont appuyee:
//  it_type = KEYIT_OR : IT generee si une des touches activee
//          = KEYIT_AND : IT generee si toutes les touches activees
void Set_KEYPADInterrupt(u16 it_type, u16 it_keys, void *function)
{
	IME_REG = 0;
	
	IE_REG |= IT_KEYPAD;
	KEYCNT_REG = it_type + KEYIT_ENABLE + it_keys;
	AAS_IntrTable[12] = function;

	IME_REG = 1;
}

// Active une interruption lorsque la ligne affichee a l'ecran est egale 
//  a la valeur passee en argument:
void Set_YTRIGInterrupt(u16 val, void *function)
{
	IME_REG = 0;
	
	IE_REG |= IT_YTRIG;
	DISP_SR |= E_YTRIG + (val<<8);
	AAS_IntrTable[2] = function;

	IME_REG = 1;
}

