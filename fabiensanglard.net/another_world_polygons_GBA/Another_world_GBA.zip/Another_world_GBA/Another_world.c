// Another_world.c AGBmain Entry point is contained here (main program loop)

#include "gbatypes.h"
#include "gbadraw.h"
#include "gbainput.h"
#include "inters.h"
#if PlayModule
#if USE_KRAWALL
#include "krawall.h"
#else
#include "aas.h"
#endif
#endif
#include "graphs.h"
#include "interpret.h"
#include "present.h"
#include "profiler.h"

#define REG_WSCNT      *(volatile u16*)0x4000204

u16 part2;

void AgbMain(void)
//int main(void)
{
	u16	part,old_part=16001;

#if PlayModule
#if USE_KRAWALL
#else
	AAS_ShowLogo();
#endif
#endif

	REG_WSCNT=0x4317;	// ROM Booster

	SetVideoMode(MODE4 | BG2);
	DISP_CR &= ~BACKBUFFER;

	init_inters();
	profil_init();

#if PlayModule
#if USE_KRAWALL
#else
	AAS_SetConfig(AAS_CONFIG_MIX_32KHZ, AAS_CONFIG_CHANS_8, AAS_CONFIG_SPATIAL_MONO, AAS_CONFIG_DYNAMIC_OFF);
#endif
#endif

	luminosite=70;
	contraste=70;
	langue=1;	// Defaut: anglais

	init_interpret(16001, 0);
	presentation();

#if PlayModule
#if USE_KRAWALL
//		kragReset();
		kragInit( KRAG_INIT_MONO );
		kramSetSFXVol(128);
#else
//		AAS_SetConfig(AAS_CONFIG_MIX_32KHZ, AAS_CONFIG_CHANS_8, AAS_CONFIG_SPATIAL_MONO, AAS_CONFIG_DYNAMIC_OFF);
#endif
#endif
	while(1)
	{
		part=menu();

//		part=16007;	// Scene finale et cr�dits

		init_interpret(part, part2);
		init_graphs();

		while(1)
		{
			profil_start(PRF_MAINLOOP);

			load_gamepart();
			interpret_all();
			if (KEY_DOWN(K_SELECT))
			{
				if ((game_current_part==16008) || (game_current_part==16009))
					game_part=old_part;
				else
				{
					old_part=game_current_part;
					game_part=16009;
				}
				while(KEY_DOWN(K_SELECT));
			}

			if (KEY_DOWN(K_ALL)==(K_START | K_L | K_R))
				break;

			if (KEY_DOWN(K_START))	// && (game_current_part != 16001))
				pause();

			profil_stop();
		}

#if USE_KRAWALL
		krapStop();
#else
		AAS_MOD_Stop();
#endif
	}
}

