PDRTJS_550718_post_1083.avg_rating = 5;
PDRTJS_550718_post_1083.votes = 4;		
PDRTJS_settings_550718_post_1083= {
			"type" : "stars",
			"size" : "sml",
			"star_color" : "yellow",
			"custom_star" : "",
			"font_size" : "",
			"font_line_height" : "16px",
			"font_color" : "",
			"font_align" : "left",
			"font_position" : "right",
			"font_family" : "",
			"font_bold" : "normal",
			"font_italic" : "normal",
			"text_votes" : "Votes",
			"text_rate_this" : "Rate This",
			"text_1_star" : "Very Poor",
			"text_2_star" : "Poor",
			"text_3_star" : "Average",
			"text_4_star" : "Good",
			"text_5_star" : "Excellent",
			"text_thank_you" : "Thank You",
			"text_rate_up" : "Rate Up",
			"text_rate_down" : "Rate Down"
		};
PDRTJS_550718_post_1083.init();		
PDRTJS_550718_post_1083.token='e32387fb3597b8c5f7ea0fd695e2ddd9';
/*550718,_post_1083,wp-post-1083,845495155,5-4*/