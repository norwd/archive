PDRTJS_550721_comm_3003.nero_up = 0;
PDRTJS_550721_comm_3003.nero_dn = 0;		
PDRTJS_settings_550721_comm_3003= {
			"type" : "nero",
			"size" : "sml",
			"star_color" : "hand",
			"custom_star" : "",
			"font_size" : "",
			"font_line_height" : "16px",
			"font_color" : "",
			"font_align" : "left",
			"font_position" : "right",
			"font_family" : "",
			"font_bold" : "normal",
			"font_italic" : "normal",
			"text_votes" : "Votes",
			"text_rate_this" : "Rate This",
			"text_1_star" : "Very Poor",
			"text_2_star" : "Poor",
			"text_3_star" : "Average",
			"text_4_star" : "Good",
			"text_5_star" : "Excellent",
			"text_thank_you" : "Thank You",
			"text_rate_up" : "Rate Up",
			"text_rate_down" : "Rate Down"
		};
PDRTJS_550721_comm_3003.init();		
PDRTJS_550721_comm_3003.token='51e090ae2c82924433ba7ddb9ad29710';
/*550721,_comm_3003,wp-comment-3003,845495155,0-0*/