PDRTJS_550721_comm_4573.nero_up = 3;
PDRTJS_550721_comm_4573.nero_dn = 0;		
PDRTJS_settings_550721_comm_4573= {
			"type" : "nero",
			"size" : "sml",
			"star_color" : "hand",
			"custom_star" : "",
			"font_size" : "",
			"font_line_height" : "16px",
			"font_color" : "",
			"font_align" : "left",
			"font_position" : "right",
			"font_family" : "",
			"font_bold" : "normal",
			"font_italic" : "normal",
			"text_votes" : "Votes",
			"text_rate_this" : "Rate This",
			"text_1_star" : "Very Poor",
			"text_2_star" : "Poor",
			"text_3_star" : "Average",
			"text_4_star" : "Good",
			"text_5_star" : "Excellent",
			"text_thank_you" : "Thank You",
			"text_rate_up" : "Rate Up",
			"text_rate_down" : "Rate Down"
		};
PDRTJS_550721_comm_4573.init();		
PDRTJS_550721_comm_4573.token='3d37b6a13babf066ae93246e0ae7a5b6';
/*550721,_comm_4573,wp-comment-4573,845495155,3-0*/