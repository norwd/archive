// sets language
function setlang(lang)
{
 document.cookie = 'lang=' + lang + '; expires=Sat, 31 Dec 2099 23:59:59 UTC; path=/';
 window.location.reload();
}


function menutoggle(id)
{
 if (document.getElementById(id).style.display == 'none') { document.getElementById(id).style.display = 'block'; }
 else { document.getElementById(id).style.display = 'none'; }
}


function reveal(show, hide)
// hide must be one of the arrays below
{
 var menus = ['site_menu', 'content_menu', 'utilities_menu'];
 var tabs = ['thumbnail_view', 'detailed_view'];
 var companypage = ['omni', 'devlist', 'publist', 'alllist'];

 if (hide == 'menus') { hide = menus; }
 if (hide == 'tabs') { hide = tabs; }
 if (hide == 'companypage') { hide = companypage; }

 for (i=0; i < hide.length; i++) { document.getElementById(hide[i]).style.display = 'none'; }

 document.getElementById(show).style.display = 'block';
}