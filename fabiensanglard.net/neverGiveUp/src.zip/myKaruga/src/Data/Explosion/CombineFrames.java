package Data.Explosion;

import java.applet.Applet;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.DataBuffer;
import java.awt.image.DataBufferByte;
import java.awt.image.DirectColorModel;
import java.awt.image.MemoryImageSource;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class CombineFrames extends Applet{


	public static void main(String[] args) {
		CombineFrames applet = new CombineFrames();
		applet.go(args);
	}
	
	public void go(String[] args) {

		if (args.length < 2)
		{
			System.out.println("Not enough arguments, you must provide");
			System.out.println("1/ The base pattern of the PNG");
			System.out.println("2/ The number of frames");
			System.out.println("Example: 'explosion 60' to consolidate explosion0001.png to explosion0060.png");
			return;
		}
		
		String framePattern = args[0];
		int numberOfFrames = Integer.parseInt(args[1]);
		BufferedImage buffImage = null;
		
		int textWidth=0;
		int textHeight=0;
		int bytesPerPixel =0;
		try
		{
			String fileName = getName(framePattern,1);
			System.out.print("Loading:"+fileName+"\n");
			buffImage = ImageIO.read(CombineFrames.class.getResourceAsStream(fileName));
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		bytesPerPixel= buffImage.getColorModel().getPixelSize() / 8;
		if (textWidth == 0)
			textWidth = buffImage.getWidth();
		if (textHeight == 0)
			textHeight = buffImage.getHeight();
		
		int[] raster = new int[bytesPerPixel * textWidth * textHeight *  numberOfFrames];
		int rasterCounter = 0;
		
		
		BufferedImage[] buffImages = new BufferedImage[numberOfFrames];
		String currentfile = null;
		System.out.println();
		for (int i=0;i<numberOfFrames;i++)
		{
			currentfile = getName(framePattern,i+1);
			try {
				System.out.print("Loading:"+currentfile);
				buffImages[i] = buffImage = ImageIO.read(CombineFrames.class.getResourceAsStream(currentfile));
				System.out.print("...done:\n");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		int columns = 1;
		int lines = 1;
		
		while (columns* lines < numberOfFrames)
		{
			columns *= 2;
			lines *= 2;
		}
		
		
		System.out.print("Consolidated image will have :"+columns+" columns and "+ lines + " lines.");
		BufferedImage rendImage = new BufferedImage(columns*textWidth, lines*textHeight, BufferedImage.TYPE_INT_ARGB);
		
		Image finalImagetoDraw =  null;
		MemoryImageSource source ;
		ColorModel colorModel = new DirectColorModel(32, 0xff000000, 0x00ff0000, 0x0000ff00, 0x000000ff);
		int[] offScreenRaster = new int[columns*textWidth*lines*textHeight];
		source = new MemoryImageSource(columns*textWidth, lines*textHeight, colorModel , offScreenRaster, 0, columns*textWidth);
		source.setAnimated(true);
		source.setFullBufferUpdates(true);
		finalImagetoDraw  = createImage(source); 
		
		System.out.println();
		
		for (int j= 0 ; j < lines ; j++)
		{
			for (int i= 0 ; i < columns ; i++)
			{
				int indice = lines*j+i ;
				int offSet = i* textWidth + j* columns * textWidth * textHeight;


				

				
				if (indice>= numberOfFrames)
				{
					System.out.println("Skipping column:"+i+" and line:"+j);
					continue;
				}
				DataBufferByte frameRaster = (DataBufferByte) buffImages[indice].getData().getDataBuffer();
				
				
				//int gridOffset = indice * (textWidth * textHeight);
				System.out.println("Processing item: columns="+i+ " and line"+j+ " item="+(indice)+ " offset="+offSet);
				for (int frameRasterHeight =0 ; frameRasterHeight < textHeight ; frameRasterHeight++)
				{
					for (int frameRasterWidth = 0 ; frameRasterWidth < textWidth ; frameRasterWidth++)
					{
						offScreenRaster[  offSet +  frameRasterWidth + frameRasterHeight * textWidth  * columns ] = getColorFormRaster(frameRaster,4*(frameRasterWidth+frameRasterHeight*textWidth));
					}
				}
				
				
			}
		}
		
		
		source.newPixels();
		rendImage.getGraphics().drawImage(finalImagetoDraw,0,0,null);
		
		
		 File file = new File(framePattern+".png");
		 if (file.exists())
			 file.delete();
	     try {
			ImageIO.write(rendImage, "png", file);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

	private int getColorFormRaster(DataBufferByte frameRaster, int i)
	{
		int r = frameRaster.getElem(i);
		int g = frameRaster.getElem(i+1);
		int b = frameRaster.getElem(i+2);
		int a = frameRaster.getElem(i+3);
		
		r = r << 24;
		g = g << 16;
		b = b << 8;
		
		return r | g | b |a ;
	}
	
	private static String getName(String pattern, int i) {
		String toReturn = "" + i;
		while(toReturn.length() < 4)
			toReturn = "0" + toReturn;
		return pattern + toReturn + ".png";
	}

}
