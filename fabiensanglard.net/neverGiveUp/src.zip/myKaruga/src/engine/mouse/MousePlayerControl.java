package engine.mouse;

import org.lwjgl.input.Mouse;

import com.Vertex;

import engine.Engine;
import engine.entities.Player;

public class MousePlayerControl implements MouseControl {

	private int startX=Engine.SCREEN_WIDTH/2;
	private int startY=Engine.SCREEN_HEIGHT/2;
	
	private float mouseCursorSpeed = 50;
	
	private MouseButton button1 = new MouseButton1((Player) Engine.players.getEntities().get(0));
	private MouseButton button2 = new MouseButton2((Player) Engine.players.getEntities().get(0));
	private MouseButton button3 = new MouseButton3((Player) Engine.players.getEntities().get(0));
	
	public MousePlayerControl()
	{
		Mouse.setGrabbed(true);
		Mouse.setCursorPosition(Engine.SCREEN_WIDTH/2,Engine.SCREEN_HEIGHT/2);
	}
	
	
	public void update() {
	
		int deltaX = -(startX -Mouse.getX());
		int deltaY = -(startY -Mouse.getY());
		
		//System.out.println("x="+Mouse.getX());
		//System.out.println("y="+Mouse.getY());
	
		// Do my shits
		Player player = (Player) Engine.players.getEntities().get(0);
		Vertex playerPosition = player.position ;
		playerPosition.setX(playerPosition.getX() + deltaX * mouseCursorSpeed * Engine.timer.delta);
		
		if (playerPosition.getX()+player.leftWidth < -Engine.SCREEN_WIDTH/2)
			playerPosition.setX(-Engine.SCREEN_WIDTH/2-player.leftWidth);
		
		if (playerPosition.getX()+player.rightWidth > Engine.SCREEN_WIDTH/2)
			playerPosition.setX(Engine.SCREEN_WIDTH/2-player.rightWidth);
		
		
		playerPosition.setY(playerPosition.getY() + deltaY * mouseCursorSpeed * Engine.timer.delta);
		if (playerPosition.getY()+player.lowerHeight < -Engine.SCREEN_HEIGHT/2)
			playerPosition.setY(-Engine.SCREEN_HEIGHT/2-player.lowerHeight);
		if (playerPosition.getY()+player.upperHeight > Engine.SCREEN_HEIGHT/2)
			playerPosition.setY(Engine.SCREEN_HEIGHT/2-player.upperHeight);
		
		Mouse.setCursorPosition(Engine.SCREEN_WIDTH/2,Engine.SCREEN_HEIGHT/2);
		
		button1.update();
		button2.update();
		button3.update();
	}


	public void onActivate() {
		Mouse.setGrabbed(true);
		Mouse.setCursorPosition(Engine.SCREEN_WIDTH/2,Engine.SCREEN_HEIGHT/2);
		
	}

}
