package engine.mouse;

import org.lwjgl.input.Mouse;

import engine.level.Level3;

public class MouseCoordinateGetter implements MouseControl{

	boolean wasDown = false;
	
	public MouseCoordinateGetter()
	{
		Mouse.setGrabbed(false);
	}
	
	public void update() {
		if (Mouse.isButtonDown(0))
		{
			if (!wasDown && Level3.boss != null)
				System.out.println("X="+(Level3.boss.position.getX()- Mouse.getX())+" , Y="+(Level3.boss.position.getY() - Mouse.getY()));
			wasDown = true;
		}
		else
			wasDown = false;

	}

	public void onActivate() {
		Mouse.setGrabbed(false);
		
	}

}
