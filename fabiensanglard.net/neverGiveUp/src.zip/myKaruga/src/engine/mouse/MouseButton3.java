package engine.mouse;

import engine.entities.Player;

public class MouseButton3 extends MouseButton {

	private Player player;
	
	public MouseButton3(Player player) {
		this.player = player;
		this.buttonNumber = 2;
	}

	@Override
	public void onButtonPressed() {
		player.fireSpecialWeapon();
	}

	@Override
	public void onRapidFire() {
		// TODO Auto-generated method stub

	}

}
