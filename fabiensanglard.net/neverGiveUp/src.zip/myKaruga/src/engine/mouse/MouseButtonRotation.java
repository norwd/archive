package engine.mouse;

import org.lwjgl.input.Mouse;

import com.Vertex;

import engine.Engine;

public class MouseButtonRotation implements MouseButtonHandler {

	private int startX=0;
	private int startY=0;
	
	public void justReleased() {
		Mouse.setGrabbed(false);

	}

	public void justPressed() {
		Mouse.setGrabbed(true);
		startX = Mouse.getX();
		startY = Mouse.getY();
	}

	public void down() {
		int dX = startX - Mouse.getX();
		int dY = startY - Mouse.getY();
		
		startX = Mouse.getX();
		startY = Mouse.getY();
		
		Vertex rotation = new Vertex(-dY,dX,0);
		Engine.currentLevel.camera.rotate(rotation);
	}

	public void up() {
//		 TODO Auto-generated method stub

	}

}
