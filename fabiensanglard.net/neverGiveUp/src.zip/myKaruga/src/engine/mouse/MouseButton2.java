package engine.mouse;

import engine.entities.Player;

public class MouseButton2 extends MouseButton {

	
	private Player player;
	
	public MouseButton2(Player player) {
		this.player = player;
		this.buttonNumber = 1;
	}

	@Override
	public void onButtonPressed() {
		player.startFlip();
	}

	@Override
	public void onRapidFire() {
		// TODO Auto-generated method stub

	}

}
