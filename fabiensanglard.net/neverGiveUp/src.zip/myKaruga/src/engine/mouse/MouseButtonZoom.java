package engine.mouse;

import org.lwjgl.input.Mouse;

public class MouseButtonZoom implements MouseButtonHandler {

	public void justReleased() {
		Mouse.setGrabbed(false);

	}

	public void justPressed() {
		Mouse.setGrabbed(true);
	}

	public void down() {
	}

	public void up() {
		// TODO Auto-generated method stub

	}

}
