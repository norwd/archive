package engine.mouse;

import org.lwjgl.input.Mouse;

import engine.Engine;
import engine.keyboard.playerControl.PlayerControlConstants;

public abstract class MouseButton implements PlayerControlConstants {

	boolean buttonWasPressed = false;
	public int buttonNumber = 0;
	
	protected float rapidFireLimit;
	protected float rapidFireCounter;
	
	public void update()
	{
		if (Mouse.isButtonDown(buttonNumber))
			if (buttonWasPressed)
			{
				rapidFireCounter += Engine.timer.delta;
				if (rapidFireCounter > rapidFireLimit)
				{
					onRapidFire();
					rapidFireCounter=0;
				}
			}
			else
			{
				buttonWasPressed = true;
				onButtonPressed();
			}
		else
			buttonWasPressed = false;
	}
	
	
	public abstract void onButtonPressed();
	public abstract void onRapidFire() ;
}
