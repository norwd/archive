package engine.mouse;

import engine.Engine;
import engine.entities.Player;

public class MouseButton1 extends MouseButton {

	private Player player;
	private float doubleBulletCounter = 0;
	private float doubleBulletLimit = 0;
	
	public MouseButton1(Player player)
	{
		this.player = player;
		this.buttonNumber = 0;
		this.rapidFireLimit = MOUVEMEMT_BULLET_RAPID_FIRE;
		this.doubleBulletLimit = rapidFireLimit/2.5f;
	}
	
	@Override
	public void onButtonPressed() {
		doubleBulletCounter =0;	
		player.fireBullet(0);
	}

	@Override
	public void onRapidFire() {
		doubleBulletCounter+=Engine.timer.delta;
		if (doubleBulletCounter > doubleBulletLimit)
		{
			player.fireBullet(player.rightWidth/2f);
			player.fireBullet(player.leftWidth/2f);
		}
		else
			player.fireBullet(0);

	}

}
