package engine.mouse;

public interface MouseControl {

	public void update();
	public void onActivate();
}
