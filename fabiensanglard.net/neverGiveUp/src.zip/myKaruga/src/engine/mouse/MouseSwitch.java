package engine.mouse;

public class MouseSwitch implements MouseControl {

	private MouseControl[] controls = null;
	private int currentControl =0;
	
	public MouseSwitch()
	{
		controls = new MouseControl[3];
		controls[1] = new MouseViewHandler();
		controls[2] = new MouseCoordinateGetter();
		controls[0] = new MousePlayerControl();
	}
	
	public void toogle()
	{
		currentControl= ++currentControl % controls.length;
	}
	
	public void update() {
		controls[currentControl].update();

	}

	public void onActivate() {
		// TODO Auto-generated method stub
		
	}

}
