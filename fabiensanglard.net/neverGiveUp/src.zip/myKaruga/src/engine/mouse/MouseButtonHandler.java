package engine.mouse;

public interface MouseButtonHandler {

	void up();
	void down();
	void justReleased();
	void justPressed();
}
