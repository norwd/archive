package engine;

public class Constants {

	public static float cameraMvtSpeed = 40f ; // Unit/sec
}
