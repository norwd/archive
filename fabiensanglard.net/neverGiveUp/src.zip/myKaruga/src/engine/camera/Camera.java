package engine.camera;

import java.util.Stack;

import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;

import com.Vertex;

import engine.entities.Entity;

public class Camera extends Entity{


	public Stack<CameraUpdate> updates= new Stack<CameraUpdate>();
	
	//Used for lookAt;
	public Vertex upVector = new Vertex(0,1,0);
	
	private Entity target = null;
	public void followEntity(Entity entity)
	{
		target = entity;
	}
	public void dropEntity()
	{
		target = null;
	}
	
	public Camera()
	{
	
		
	}
	
	public void render()
	{
		
	}
	
	public void update()
	{			
		super.update();
		
		if (updates.size() == 0)
			return;
		
		CameraUpdate update = updates.peek() ;

		update.update();
		if (update.isDone())
			updates.pop();
		
		
	}
	
	public void move(Vertex delta)
	{
		this.position.setX(this.position.getX()+delta.getX());
		this.position.setY(this.position.getY()+delta.getY());
		this.position.setZ(this.position.getZ()+delta.getZ());
	}
	
	public void move(float delta)
	{
		this.position.setX(this.position.getX()+delta * (float)Math.cos(rotation.getY()*2*Math.PI/360));
		this.position.setY(this.position.getY()+delta * (float)Math.cos(rotation.getZ()*2*Math.PI/360));
		this.position.setZ(this.position.getZ()+delta * (float)Math.cos(rotation.getX()*2*Math.PI/360));
	}

	public void rotate(Vertex delta)
	{
		this.rotation.setX(this.rotation.getX()+delta.getX());
		this.rotation.setY(this.rotation.getY()+delta.getY());
		this.rotation.setZ(this.rotation.getZ()+delta.getZ());
	}
	
	public void applyMatrixTransformations()
	{
		if (target==null)
		{
			GL11.glRotatef(180-rotation.getY(),0,1,0);
			GL11.glRotatef(180-rotation.getX(),1,0,0);
			GL11.glRotatef(rotation.getZ(),0,0,1);
			GL11.glTranslatef(-position.getX(),-position.getY(),-position.getZ());
		}
		else
		{
			Vertex center = target.position ;
			GLU.gluLookAt(position.getX(),position.getY(),position.getZ(), center.getX(),center.getY(),center.getZ(), upVector.getX(),upVector.getY(),upVector.getZ());
		}
	}

	public Vertex getPosition() {
		return position;
	}

	public Vertex getRotation() {
		return rotation;
	}
}
