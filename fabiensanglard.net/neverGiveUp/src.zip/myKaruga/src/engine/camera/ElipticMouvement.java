package engine.camera;

import com.Vertex;

import engine.Engine;

public class ElipticMouvement implements CameraUpdate {

	private Vertex direction;
	private float speed;
	

	
	boolean done = false;
	
	public ElipticMouvement(Vertex direction, float speed,  float width)
	{
		this.direction = direction;
		this.speed = speed;
	}
	

	public boolean isDone() {
		return this.done;
	}


	public void update() {
		
		Engine.currentLevel.camera.mouvementdirection= direction ;
		Engine.currentLevel.camera.mouvementSpeed = speed;
		
		
		
		Engine.currentLevel.camera.rotationdirection.setY(10);
		Engine.currentLevel.camera.rotationdirection.setX(-2);
		//Engine.camera.rotationdirection.setZ(0);
		
		Engine.currentLevel.camera.rotationSpeed = 10;

		this.done = true;
		System.out.println("ElipticMouvement done");
		

	}

}
