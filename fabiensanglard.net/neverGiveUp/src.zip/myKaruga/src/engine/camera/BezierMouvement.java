package engine.camera;

import com.Vertex;

import engine.Engine;


public class BezierMouvement implements CameraUpdate {

	Vertex from;
	Vertex to;
	Vertex controlPoint1;
	Vertex controlPoint2;
	float speed;
	
	private boolean isDone = false;
	
	public BezierMouvement(Vertex from, Vertex to, Vertex controlPoint1, Vertex controlPoint2, float speed)
	{
		this.from = from;
		this.to = to;
		this.speed = speed;
	}
	
	public void update() {
		
		Vertex cameraPosition = Engine.currentLevel.camera.getPosition();
		
		if (cameraPosition.distanceFrom(to) < 4)
		{
			this.isDone =true;
			System.out.println("BezierMouvement done");
			return;
		}
		
		
		
		Vertex directionToTarget = new Vertex(	to.getX()-cameraPosition.getX(),
												to.getY()-cameraPosition.getY(),
												to.getZ()-cameraPosition.getZ());
		
		directionToTarget.normalize();
		
		Engine.currentLevel.camera.mouvementdirection = directionToTarget;
		Engine.currentLevel.camera.mouvementSpeed = speed;

		
		
		
	}
	
	public boolean isDone() {
		return isDone;
		
	}

}
