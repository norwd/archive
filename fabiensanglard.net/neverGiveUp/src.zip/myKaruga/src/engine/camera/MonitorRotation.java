package engine.camera;

import com.Vertex;

import engine.Engine;

public class MonitorRotation implements CameraUpdate {

	private boolean done = false;

	public boolean isDone() {
		return done;
	}


	public void update() {

		if (Engine.currentLevel.camera.rotation.getY() > 180)
		{
			Engine.currentLevel.camera.rotationdirection.setY(0);
		}

		
		if (Engine.currentLevel.camera.rotation.getX()<-90)
		{
			Engine.currentLevel.camera.rotationdirection.setX(0);
			Engine.currentLevel.camera.rotationdirection.setZ(-2);
			this.done = true;
		}
		
			
/*
		if (Engine.camera.rotation.getY() > 180)
			Engine.camera.rotationdirection.setY(0);
			*/
	}

}
