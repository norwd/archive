package engine.camera;

public interface CameraUpdate {

	boolean isDone();
	void update();
}
