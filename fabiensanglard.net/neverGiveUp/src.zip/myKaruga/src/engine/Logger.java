package engine;

public class Logger {

	public static final boolean logging = false;
	
	public static void log(String text)
	{
		if (logging)
			System.out.println(text);
	}
}
