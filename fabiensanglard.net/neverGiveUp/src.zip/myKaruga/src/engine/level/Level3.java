package engine.level;

import java.nio.FloatBuffer;

import org.lwjgl.BufferUtils;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;

import com.Vertex;

import engine.Engine;
import engine.ObjLibrary;
import engine.VisibleElement;
import engine.camera.Camera;
import engine.entities.Frame;
import engine.entities.HeartBoss;
import engine.entities.action.ActionSet;
import engine.entities.action.Wait;
import engine.keyboard.ArmsControlerToogler;
import engine.keyboard.HeartBossArmControlAdd;
import engine.keyboard.HeartBossArmControlMinus;
import engine.keyboard.KeyBoardHandler;
import engine.level.action.ChangeFog;
import engine.level.action.DisplayWarningMessage;
import engine.level.action.ShowWeakness;
import engine.level.action.StartBoss;
import engine.level.action.StartGame;

public class Level3  extends Level implements VisibleElement{

	
	private static final float frameSpeed = 20;
	
	Frame frame1;
	Frame frame2;
	Frame frame3;
	
	public static HeartBoss boss = null;
	static KeyBoardHandler keyboard;
	

	static public float fogColor[] = {0.8f, 0.8f,0.8f,  1f};
	//static public float fogColor[] = {0f, 0f,0f,  1f};
	public Level3()
	{
		
		setFog();
		
		
		camera = new Camera();
		camera.position.setZ(-15);
		camera.rotation.setX(-12);

		boss = new HeartBoss(new Vertex(0,-Engine.SCREEN_HEIGHT*2,-800));
		//boss = new HeartBoss(new Vertex(0,0,-1000));
		
		
		
		frame1 = new Frame(ObjLibrary.TIKA01);
		frame1.position = new Vertex(0,0,0);
		
		frame2 = new Frame(ObjLibrary.TIKA01);
		frame2.position = new Vertex(0,-400,0);
		
		frame3 = new Frame(ObjLibrary.TIKA01);
		frame3.position = new Vertex(0,-800,0);
		
		
		
		frames.add(frame1);
		frames.add(frame2);
		frames.add(frame3);
		
		
		keyboard = new KeyBoardHandler();
		keyboard.addKey(Keyboard.KEY_ADD,new HeartBossArmControlAdd());
		keyboard.addKey(Keyboard.KEY_SUBTRACT,new HeartBossArmControlMinus());
		keyboard.addKey(Keyboard.KEY_NUMPAD9,new ArmsControlerToogler());
		
		actions.addAction(new Wait(5));
		actions.addAction(new DisplayWarningMessage(17));
		actions.addAction(new Wait(1));
		actions.addAction(new ChangeFog(0.0f, 0.0f,0.0f, 1f,1.5f,4));
		actions.addAction(new Wait(5));
		actions.addAction(new ShowWeakness(5));
		actions.addAction(new StartBoss());
		actions.addAction(new StartGame());
		
		actions.start();
	}
	
	public static void setFog() {
		
		GL11.glClearColor(fogColor[0],fogColor[1],fogColor[2], 1f);
		GL11.glEnable(GL11.GL_FOG);	
		FloatBuffer fogColorNative = BufferUtils.createFloatBuffer(4);	
		fogColorNative.put(fogColor).flip();
		GL11.glFogi(GL11.GL_FOG_MODE, GL11.GL_LINEAR);		// Fog Mode
		GL11.glFog(GL11.GL_FOG_COLOR,fogColorNative);			// Set Fog Color
		GL11.glFogf(GL11.GL_FOG_DENSITY, 22f);				// How Dense Will The Fog Be
		GL11.glHint(GL11.GL_FOG_HINT, GL11.GL_FASTEST);			// Fog Hint Value
		GL11.glFogf(GL11.GL_FOG_START, -40.0f);				// Fog Start Depth
		GL11.glFogf(GL11.GL_FOG_END, 800.0f);				// Fog End Depth
	}

	public void update()
	{
		Frame minY = minY();
		
		for (Frame frame : frames)
		{
			frame.position.setY(frame.position.getY()+frameSpeed*Engine.timer.delta);
			
		}
		
		for (Frame frame : frames)
		{
			if (frame.position.getY() > 420)
			{
				frame.position.setY(minY.position.getY() -800);
				
			}
			
		}
		
		actions.update();
		//camera.update();
		keyboard.update();
	}
	
	
	
	
	private static final String[] specialGroups = {"TIKA0113","TIKA0127","TIKA0128","TIKA0114"};
	
	public void render()
	{
		GL11.glDisable(GL11.GL_LIGHTING);
		
		while(frames.size() != 0)
		{
			Frame toRender = maxY();
			GL11.glPushMatrix();		
				GL11.glTranslatef(toRender.position.getX(), toRender.position.getY(), toRender.position.getZ());
				GL11.glRotatef(90,1, 0, 0);
				toRender.obj.renderAllBut(specialGroups);
			GL11.glPopMatrix();
			frames.remove(toRender);
		}
		
		frames.add(frame1);
		frames.add(frame2);
		frames.add(frame3);
		
		
		while(frames.size() != 0)
		{
			Frame toRender = minY();
			GL11.glPushMatrix();		
				GL11.glTranslatef(toRender.position.getX(), toRender.position.getY(), toRender.position.getZ());
				GL11.glRotatef(90,1, 0, 0);
				toRender.obj.renderOnly(specialGroups);
			GL11.glPopMatrix();
			frames.remove(toRender);
		}
		
		frames.add(frame1);
		frames.add(frame2);
		frames.add(frame3);
		
		GL11.glEnable(GL11.GL_LIGHTING);
	}

	static FloatBuffer lightPosition0 = (FloatBuffer)BufferUtils.createFloatBuffer(4).put(new float[] { 0f, 0f, 0f, -200f  }).rewind();
	static FloatBuffer lightPosition1 = (FloatBuffer)BufferUtils.createFloatBuffer(4).put(new float[] { 50f, 0f, 0f, 200f  }).rewind();
	
	@Override
	public
	void setupPerspective() {
		
			GL11.glEnable(GL11.GL_LIGHTING);
			GL11.glEnable(GL11.GL_DEPTH_TEST);
			GL11.glMatrixMode(GL11.GL_PROJECTION); // Select The Projection Matrix
		    GL11.glLoadIdentity(); // Reset The Projection Matrix
			GLU.gluPerspective(55.0f,Engine.SCREEN_WIDTH/Engine.SCREEN_HEIGHT,0.1f,10000.0f); 
			GL11.glMatrixMode(GL11.GL_MODELVIEW); 
			GL11.glLoadIdentity();
		    GL11.glLight(GL11.GL_LIGHT1, GL11.GL_POSITION, lightPosition0);
			GL11.glLight(GL11.GL_LIGHT2, GL11.GL_POSITION, lightPosition1);
	}
}
