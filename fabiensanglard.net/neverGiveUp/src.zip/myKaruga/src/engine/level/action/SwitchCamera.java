package engine.level.action;

import engine.camera.Camera;
import engine.entities.action.Action;

public class SwitchCamera extends Action {

	Camera camera;
	
	public SwitchCamera(Camera camera) {
		this.camera= camera;
	}

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub

	}

	@Override
	public void update() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onActivated() {
		camera.dropEntity();
		camera.rotation.setX(90);
		camera.rotation.setY(0);
		camera.rotation.setZ(0);
		
		//camera.rotationSpeed = 1
		this.done=true;
		activateNext();
	}

}
