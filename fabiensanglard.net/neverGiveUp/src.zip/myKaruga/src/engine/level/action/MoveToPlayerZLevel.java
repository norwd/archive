package engine.level.action;

import com.Vertex;

import engine.camera.Camera;
import engine.entities.ScenePlayer;
import engine.entities.action.Action;

public class MoveToPlayerZLevel extends Action {

	ScenePlayer player;
	Camera camera;
	
	public MoveToPlayerZLevel(ScenePlayer player, Camera camera) {
		this.player = player;
		this.camera = camera;
	}

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub

	}

	@Override
	public void update() {
		
		//System.out.println("aaaa dZ="+(this.player.position.getZ() - this.camera.position.getZ()));
		//System.out.println("player speed="+player.mouvementSpeed );
		//System.out.println("camera speed="+camera.mouvementSpeed );
		float cameraDistance = this.player.position.getZ() - this.camera.position.getZ();
		
		if ( cameraDistance < 5 )
		{
			this.camera.mouvementSpeed = player.mouvementSpeed ;
			this.done =true;
			activateNext();
		}
		 
	}

	@Override
	public void onActivated() 
	{
		this.camera.mouvementSpeed = player.mouvementSpeed *1.2f;
		this.camera.mouvementdirection = new Vertex(0,1,1);
		System.out.println("player speed="+player.mouvementSpeed );
		System.out.println("camera speed="+camera.mouvementSpeed );
		// Make player go Down
		activateNext();
	}

}
