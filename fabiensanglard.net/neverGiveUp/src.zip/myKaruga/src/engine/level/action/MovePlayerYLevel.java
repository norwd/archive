package engine.level.action;

import com.Vertex;

import engine.camera.Camera;
import engine.entities.ScenePlayer;
import engine.entities.action.Action;

public class MovePlayerYLevel extends Action {

	ScenePlayer player;
	Camera camera;
	float playerYInitial = 0;
	
	public MovePlayerYLevel(ScenePlayer player, Camera camera) {
		this.player = player;
		this.camera = camera;
		playerYInitial = player.position.getY();
	}

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub

	}

	@Override
	public void update() {
		if (playerYInitial - player.position.getY() >=40)
		{
			player.mouvementdirection = new Vertex(0,0,1);
			done=true;
			activateNext();
			
		}

	}

	@Override
	public void onActivated() {
		player.mouvementdirection = new Vertex(0,-0.7f,1);
		//player.mouvementSpeed = 10;
		//activateNext();
	}

	
}
