package engine.level.action;

import com.Vertex;

import engine.Engine;
import engine.entities.Entity;
import engine.entities.ScenePlayer;
import engine.entities.action.Action;

public class MoveTo extends Action {

	private Vertex relativePositionTarget= null;
	private Entity relativeToEntity= null;
	float time = 0;
	Entity entityToMove = null;
	
	public MoveTo(Entity entityToMove, Vertex relativePositionTarget, Entity relativeToEntity, float time) {
		this.relativePositionTarget = relativePositionTarget;
		this.relativeToEntity = relativeToEntity;
		this.time = time;
		this.entityToMove = entityToMove;
	}

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub

	}

	float timeCounter = 0;
	@Override
	public void update() 
	{	
		//System.out.println("update");
		
		timeCounter+= Engine.timer.delta;
				
		float t = timeCounter/time;
		t = (t > 1) ? 1 : t;
		
		Vertex bezierInterpolation = bezier(t,origin,controlPoint1,controlPoint2,destination);
		
		entityToMove.position = relativeToEntity.position.copyAndAdd(bezierInterpolation);
		
		if (timeCounter >= time)
		{
			entityToMove.position = relativeToEntity.position.copyAndAdd(relativePositionTarget);
			this.done=true;
			activateNext();
		}

	}

	private Vertex bezier(float t,Vertex p0, Vertex p1, Vertex p2, Vertex p3) {
		return new Vertex(
				
			p0.mult(Math.pow(1-t,3)).copyAndAdd(
				p1.mult(Math.pow(1-t,2) * 3 * t).copyAndAdd(
						p2.mult((1-t) * 3 * t * t).copyAndAdd(
							p3.copyAndMult(t*t*t)
								
						)
				)
			)
		);
	}

	Vertex destination = null;
	Vertex origin = null;
	Vertex controlPoint1 = null;
	Vertex controlPoint2 = null;
	@Override
	public void onActivated() {
		
		//System.out.println("onActivated");
		
		// destination
		origin = entityToMove.position.copyAndSub(relativeToEntity.position);
		destination = relativePositionTarget;
		
		
		// Calculate bezierpoint
		controlPoint1 = new Vertex(origin);
		controlPoint1.setZ(destination.getZ());
		
		controlPoint2 = new Vertex(destination);
		controlPoint2.setZ(origin.getZ());

	}
}
