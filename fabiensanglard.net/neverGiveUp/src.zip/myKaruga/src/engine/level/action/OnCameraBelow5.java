package engine.level.action;

import engine.camera.Camera;
import engine.entities.action.Action;
import engine.level.Level1;

public class OnCameraBelow5 extends Action {

	Camera camera = null;
	
	public OnCameraBelow5(Camera camera) {
		this.camera = camera;
	}

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub

	}

	@Override
	public void update() {
		/*
		if (camera.position.getZ() < 5)
		{
			Level1.spawnEnemies = true;
			done= true;
			activateNext();
		}
		 */
	}

}
