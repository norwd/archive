package engine.level.action;

import com.Vertex;

import engine.Engine;
import engine.entities.Player;
import engine.entities.action.Action;
import engine.level.Level1;

public class SwitchPlayerScene extends Action {

	Level1 level1;
	
	public SwitchPlayerScene(Level1 level1) {
		this.level1 = level1;
	}

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub

	}

	@Override
	public void update() {
		boolean rightTime = false;
		
		float p_rotation = Math.abs(level1.player.rotation.getZ() % 360);
		if (p_rotation > 85 && p_rotation < 90)
			rightTime = true;
			
		
		if (rightTime)
		{
			Player player = (Player) Engine.players.getEntities().get(0);
			
			player.position.setY(0);
			player.rotation.setZ(player.rotation.getZ() + 90);
			player.startFlip();
			
			Level1.player.doNotRender=true;
			Level1.player.position.setX(0);
			Level1.player.position.setY(-200);
			Level1.player.rotationSpeed=0;
			Level1.player.rotation=new Vertex();
			
			
			this.done = true;
			this.activateNext();
		}

	}

	
	
}
