package engine.level.action;

import engine.camera.Camera;
import engine.entities.ScenePlayer;
import engine.entities.action.Action;

public class OnPlayerPassCamera extends Action {

	ScenePlayer player = null;
	Camera camera = null;
	
	public OnPlayerPassCamera(ScenePlayer player, Camera camera) {
		this.player = player;
		this.camera = camera;
	}

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub

	}

	@Override
	public void update() {
		if (player.position.getZ() - camera.position.getZ() >= 10 )
		{
			//camera.mouvementdirection = player.mouvementdirection;
			//camera.mouvementSpeed = player.mouvementSpeed ;
			this.done = true;
			activateNext();
		}

	}

}
