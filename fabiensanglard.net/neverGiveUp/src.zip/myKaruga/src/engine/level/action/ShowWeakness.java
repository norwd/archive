package engine.level.action;

import com.Vertex;

import engine.Engine;
import engine.entities.WeakPointIndicator;
import engine.entities.action.Action;

public class ShowWeakness extends Action {

	private float time;
	
	private WeakPointIndicator wpILeft;
	private WeakPointIndicator wpIRight;
	
	public ShowWeakness(float time) {
		this.time = time;
	}

	@Override
	public void onAdded() {
		

	}
	
	public void onActivated()
	{
		Engine.weakPoints = new WeakPointIndicator[2];
		
		wpILeft = new WeakPointIndicator(WeakPointIndicator.leftType);
		wpILeft.position = new Vertex(-160f,+20,-800);
		Engine.weakPoints [0] = wpILeft;
		
		wpIRight = new WeakPointIndicator(WeakPointIndicator.rightType);
		wpIRight.position = new Vertex(160f,-20,-800);
		Engine.weakPoints [1] = wpIRight;
	}

	@Override
	public void update() {
		
		
		time -= Engine.timer.delta;
		if (time > 0)
			Engine.showWeaKPoints = true;
		else
		{
			Engine.showWeaKPoints = false;
			done=true;
			activateNext();
			Engine.plasmaExplositions.getEntities().remove(wpIRight);
			Engine.plasmaExplositions.getEntities().remove(wpILeft);
		}

	}

}
