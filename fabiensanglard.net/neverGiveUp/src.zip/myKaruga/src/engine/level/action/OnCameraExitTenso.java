package engine.level.action;

import engine.Engine;
import engine.camera.Camera;
import engine.entities.Entity;
import engine.entities.action.Action;
import engine.level.Level1;

public class OnCameraExitTenso extends Action {

	private Camera camera;

	public OnCameraExitTenso(Camera camera) {
		this.camera = camera;
	}

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub

	}

	@Override
	public void update() {
		if (camera.position.getZ() > 1800)
		{
			for(Entity entity :Engine.enemies.getEntities())
				entity.explode();
			
			Engine.enemieBullets.clear();
			Level1.spawnEnemies = false;
			done= true;
			activateNext();
		}

	}

}
