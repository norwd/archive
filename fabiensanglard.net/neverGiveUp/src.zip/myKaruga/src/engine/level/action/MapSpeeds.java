package engine.level.action;

import engine.camera.Camera;
import engine.entities.ScenePlayer;
import engine.entities.action.Action;

public class MapSpeeds extends Action {

	ScenePlayer player=null;
	Camera camera=null;
	
	public MapSpeeds(ScenePlayer player, Camera camera) {
		this.player = player;
		this.camera = camera;
	}

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub

	}

	@Override
	public void update() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onActivated() {
		camera.mouvementdirection = player.mouvementdirection;
		camera.mouvementSpeed = player.mouvementSpeed;
		this.done = true;
		activateNext();
	}

}
