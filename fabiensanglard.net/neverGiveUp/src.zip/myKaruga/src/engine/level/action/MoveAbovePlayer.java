package engine.level.action;

import com.Vertex;

import engine.camera.Camera;
import engine.entities.ScenePlayer;
import engine.entities.action.Action;

public class MoveAbovePlayer extends Action {

	ScenePlayer player = null;
	Camera camera = null;
	
	public MoveAbovePlayer(ScenePlayer player, Camera camera) {
		this.player = player;
		this.camera = camera;
	}

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub

	}

	@Override
	public void update() {
		if (this.camera.position.getX() <= player.position.getX())
		{
			this.done =true;
			this.activateNext();
		}

	}

	@Override
	public void onActivated() {
		
		
		this.camera.mouvementSpeed = player.mouvementSpeed * 0.5f;
		//this.camera.mouvementdirection.setY(1 );
		this.camera.mouvementdirection.setX(-1 );
		//this.camera.mouvementdirection.setZ(player.mouvementSpeed /20);
		
	}

	
}
