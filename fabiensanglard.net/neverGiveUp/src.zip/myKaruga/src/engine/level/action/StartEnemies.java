package engine.level.action;

import engine.Engine;
import engine.entities.action.Action;
import engine.level.Level1;

public class StartEnemies extends Action {

	private Level1 level1;

	public StartEnemies(Level1 level1) {
		this.level1 = level1;
	}

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub

	}

	@Override
	public void update() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onActivated() {
		Engine.detectCollisions = true;
		level1.spawnEnemies = true;
		done=true;
		activateNext();
	}

}
