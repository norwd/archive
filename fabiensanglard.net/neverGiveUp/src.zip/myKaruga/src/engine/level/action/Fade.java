package engine.level.action;

import engine.entities.action.Action;

public class Fade extends Action {

	public Fade(float targetFade, float delay) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub

	}

	@Override
	public void update() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onActivated() {
		activateNext();
	}

	
}
