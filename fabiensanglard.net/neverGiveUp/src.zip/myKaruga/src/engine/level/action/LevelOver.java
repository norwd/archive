package engine.level.action;

import engine.entities.action.Action;
import engine.level.Level1;

public class LevelOver extends Action {

	public LevelOver(Level1 level1) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub

	}

	@Override
	public void update() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onActivated() {
		activateNext();
	}
}
