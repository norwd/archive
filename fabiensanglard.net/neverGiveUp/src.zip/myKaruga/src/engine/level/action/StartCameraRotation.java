package engine.level.action;

import engine.Engine;
import engine.camera.Camera;
import engine.entities.action.Action;
import engine.level.Level1;;

public class StartCameraRotation extends Action {

	private Camera camera;

	public StartCameraRotation(Camera camera) {
		this.camera = camera;
	}

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub

	}

	
	@Override
	public void update() {
		Level1.player.position.rotateZ(1*Engine.timer.delta/5);
		

	}

	float twich = 0;
	float maxTwich = (float) (Math.PI/20);
	@Override
	public void onActivated() {
		
		System.out.println(twich);
		twich+= Engine.timer.delta;
		twich %= 2* maxTwich;
		twich -= maxTwich;
		//done=true;
		activateNext();
		camera.upVector.rotateX( Math.PI/2+maxTwich);
	}

}
