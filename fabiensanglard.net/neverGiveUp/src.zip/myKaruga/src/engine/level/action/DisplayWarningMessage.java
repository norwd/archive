package engine.level.action;

import engine.Engine;
import engine.entities.action.Action;

public class DisplayWarningMessage extends Action {

	private float time;
	
	public DisplayWarningMessage(float time) {
		this.time = time;
	}

	@Override
	public void onAdded() {
		

	}

	@Override
	public void update() {
		time -= Engine.timer.delta;
		if (time > 0)
			Engine.showMessage = true;
		else
		{
			Engine.showMessage = false;
			done=true;
			activateNext();
		}

	}

}
