package engine.level.action;

import engine.Engine;
import engine.entities.action.Action;
import engine.level.Level3;

public class ChangeFog extends Action {

	float fogColorDelta[] = new float[4];
	float speed;
	float ttl;
	
	
	public ChangeFog(float r, float g, float b, float a, float speed, float ttl) {
		this.ttl = ttl;
		fogColorDelta[0] = (r - Level3.fogColor[0])  / speed ;
		fogColorDelta[1] = (g - Level3.fogColor[1])  / speed;
		fogColorDelta[2] = (b - Level3.fogColor[2])  / speed;
		fogColorDelta[3] = (a - Level3.fogColor[3])  / speed;
	}



	@Override
	public void onAdded() {
		// TODO Auto-generated method stub

	}
	
	

	@Override
	public void onActivated() {
		activateNext();
	}



	@Override
	public void update() {
		
		ttl-=Engine.timer.delta;
		
		if (ttl <=0)
		{
			done=true;
			activateNext();
		}
		
		Level3.fogColor[0] += fogColorDelta[0] * Engine.timer.delta ;
		Level3.fogColor[1] += fogColorDelta[1] * Engine.timer.delta ;
		Level3.fogColor[2] += fogColorDelta[2] * Engine.timer.delta ;
		Level3.fogColor[3] += fogColorDelta[3] * Engine.timer.delta ;
		Level3.setFog();
	}

}
