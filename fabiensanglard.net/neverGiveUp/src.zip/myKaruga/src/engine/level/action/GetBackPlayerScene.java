package engine.level.action;

import engine.Engine;
import engine.entities.ScenePlayer;
import engine.entities.action.Action;
import engine.level.Level1;

public class GetBackPlayerScene extends Action {

	public GetBackPlayerScene(ScenePlayer player) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub

	}

	@Override
	public void update() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onActivated() {
		Engine.players.getEntities().get(0).position.setY(-Engine.SCREEN_HEIGHT);
		Level1.player.doNotRender=false;
		Level1.player.position.setX(0);
		Level1.player.position.setY(-30);
		
		Engine.controlEnabled = false;
		Engine.enemies.clear();
		this.done = true;
		this.activateNext();
		
	}

}
