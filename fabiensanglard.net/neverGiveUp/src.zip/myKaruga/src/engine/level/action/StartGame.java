package engine.level.action;

import engine.Engine;
import engine.entities.action.Action;

public class StartGame extends Action {

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub

	}

	@Override
	public void update() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onActivated() {
		Engine.start();
		done=true;
		activateNext();
	}

	
}
