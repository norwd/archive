package engine.level.action;

import com.Vertex;

import engine.Engine;
import engine.entities.ScenePlayer;
import engine.entities.action.Action;

public class StopRotationAt extends Action {

	ScenePlayer player=null;
	float angle;
	
	public StopRotationAt(ScenePlayer player, float angle) {
		this.player = player;
		this.angle=angle;
	}

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub

	}

	boolean startTour = false;
	
	@Override
	public void update() {
		
		float currentRotation = player.rotation.getZ() % 360;
		
		if (currentRotation >0 && currentRotation < 5)
			startTour = true;
		
		
		if ( currentRotation > angle)
		{
			//player.rotationdirection = new Vertex();
			player.rotation = new Vertex(0,0,angle);
			//Engine.players.getEntities().get(0).rotation =  new Vertex(angle,0,0);
			player.rotationSpeed = 0;
		}

	}

	@Override
	public void onActivated() {
		activateNext();
	}

}
