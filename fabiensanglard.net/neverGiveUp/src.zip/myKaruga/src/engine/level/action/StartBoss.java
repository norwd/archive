package engine.level.action;

import engine.entities.action.Action;
import engine.level.Level3;

public class StartBoss extends Action {

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub

	}

	@Override
	public void update() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onActivated() {
		Level3.boss.start();
		done=true;
		activateNext();
	}

	
}
