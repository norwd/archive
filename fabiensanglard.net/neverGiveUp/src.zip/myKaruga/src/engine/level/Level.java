package engine.level;

import java.util.ArrayList;

import org.lwjgl.util.glu.GLU;

import engine.VisibleElement;
import engine.camera.Camera;
import engine.entities.Frame;
import engine.entities.action.ActionSet;

public abstract class Level implements VisibleElement{

	public Camera camera;
	
	protected ActionSet actions = new ActionSet();

	
	public void applyCamera()
	{
		camera.applyMatrixTransformations();
		//GLU.gluLookAt(0, 0, 0, 0, 0, 1500, 0, 1, 0);
	}
	
	public abstract void setupPerspective(); 
	
	
	ArrayList<Frame> frames = new ArrayList<Frame>();
	protected Frame maxZ() {
        Frame toReturn  = frames.get(0);
		for (Frame frame : frames)
		{
			if (frame.position.getZ() > toReturn.position.getZ())
				toReturn = frame;
		}
		return toReturn;
	}
	
	protected Frame minZ() {
        Frame toReturn  = frames.get(0);
		for (Frame frame : frames)
		{
			if (frame.position.getZ() < toReturn.position.getZ())
				toReturn = frame;
		}
		return toReturn;
	}
	
	protected Frame minY() {
        Frame toReturn  = frames.get(0);
		for (Frame frame : frames)
		{
			if (frame.position.getY() < toReturn.position.getY())
				toReturn = frame;
		}
		return toReturn;
	}
	
	protected Frame maxY() {
        Frame toReturn  = frames.get(0);
		for (Frame frame : frames)
		{
			if (frame.position.getY() > toReturn.position.getY())
				toReturn = frame;
		}
		return toReturn;
	}
}
