package engine.level;

import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.Random;

import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;

import com.Vertex;
import com.obj.WavefrontObject;

import engine.Engine;
import engine.ObjLibrary;
import engine.VisibleElement;
import engine.camera.Camera;
import engine.entities.CircleTama;
import engine.entities.Entity;
import engine.entities.Evil;
import engine.entities.Frame;

public class Level2 extends Level implements VisibleElement {

	
	//WavefrontObject frameFinal = new WavefrontObject("/Data/LVL2/FRA200F/FRA200F.OBJ");
	
	private static final float frameSpeed = -40;
	
	
	static Random random = new Random(System.currentTimeMillis());
	
	float cameraMouvementSpeed =10;
	float cameraRotationSpeed  = (float) (Math.PI/4);
	
	public Level2()
	{
		
		Engine.detectCollisions = true;
		
		/*
		Evil evil = new Evil();
		//evil.position = new Vertex(Engine.SCREEN_WIDTH/4,Engine.SCREEN_HEIGHT/4,-500);
		evil.position = new Vertex(0,0,-500);
		evil.rotation.setX(90);
		//evil.rotationdirection.setZ(-1);
		//evil.rotationSpeed= 100;
		evil.polarity = Entity.RED;
		Engine.enemies.addEntity(evil);
		
		evil = new Evil();
		//evil.position = new Vertex(-Engine.SCREEN_WIDTH/4,Engine.SCREEN_HEIGHT/4,-500);
		evil.rotation.setX(90);
		evil.rotation.setZ(180);
		//evil.rotationdirection.setZ(1);
		//evil.rotationSpeed= 50;
		evil.polarity = Entity.BLUE;
		//Engine.enemies.addEntity(evil);
		*/
		
		//GL11.glClearColor(0.8f, 0.8f, 0.8f, 1f);
		GL11.glClearColor(0, 0, 0, 1f);
		camera = new Camera();
		camera.position = new Vertex(00,0,200);
		camera.rotation = new Vertex(-100,0,0);
		camera.mouvementdirection = new Vertex(1,0,0);
		camera.mouvementSpeed = 10;
		
		
		
		
		Frame frame1 = new Frame(ObjLibrary.LEVEL2_FRAME);
		frame1.position = new Vertex(0,0,200);
		
		Frame frame2 = new Frame(ObjLibrary.LEVEL2_FRAME);
		frame2.position = new Vertex(0,0,400);
		
		
		frames.add(frame1);
		frames.add(frame2);
		

		
		// FOG ////////////////////////////////////////////////////////////////////////////
		GL11.glEnable(GL11.GL_FOG);	
		FloatBuffer fogColor = BufferUtils.createFloatBuffer(4);
		float fogColorNative[] = {0.8f, 0.8f,1f, 1f};  
		//float fogColorNative[] = {0.8f, 0.8f, 1f, 1.0f};
		//float fogColorNative[] = {1f, 0f,0f,  1.0f};
		fogColor.put(fogColorNative).flip();
		
		GL11.glFogi(GL11.GL_FOG_MODE, GL11.GL_LINEAR);		// Fog Mode
		GL11.glFog(GL11.GL_FOG_COLOR,fogColor);			// Set Fog Color
		GL11.glFogf(GL11.GL_FOG_DENSITY, 0.2f);				// How Dense Will The Fog Be
		GL11.glHint(GL11.GL_FOG_HINT, GL11.GL_FASTEST);			// Fog Hint Value
		GL11.glFogf(GL11.GL_FOG_START, 70.0f);				// Fog Start Depth
		GL11.glFogf(GL11.GL_FOG_END, 250.0f);				// Fog End Depth
		// FOG ////////////////////////////////////////////////////////////////////////////
		 
		 
	}
	
	public void render() {
		GL11.glDisable(GL11.GL_LIGHTING);
		for (Frame frame : frames)
		{
			GL11.glPushMatrix();		
				GL11.glTranslatef(frame.position.getX(), frame.position.getY(), frame.position.getZ());
				GL11.glTranslatef(frame.position.getX(), frame.position.getY(), frame.position.getZ());
				frame.render();
			GL11.glPopMatrix();
		}
		GL11.glEnable(GL11.GL_LIGHTING);

	}


	static final float  TAMA_SPAWNING_RATE = 1.5f;
	float tamaSpawningCounter = TAMA_SPAWNING_RATE;
	boolean polarity = Entity.RED;
	public void update() 
	{
		
		tamaSpawningCounter -= Engine.timer.delta;
		
		if (tamaSpawningCounter <= 0)
		{
			CircleTama circleTama = new CircleTama();
			circleTama.polarity = polarity;
			polarity = !polarity;
			Engine.enemies.addEntity(circleTama);
			tamaSpawningCounter = TAMA_SPAWNING_RATE;
		}
		
		
		Frame maxZ = maxZ();
		//camera.position.setX((float)Math.cos(maxZ.position.getZ()/100)*50);
		
		for (Frame frame : frames)
		{
			frame.position.setZ(frame.position.getZ()+frameSpeed*Engine.timer.delta);
			
		}
		
		// Cycling frames for endless scrolling
		for (Frame frame : frames)
		{
			if (frame.position.getZ() < -50)
			{
				frame.position.setZ(maxZ.position.getZ()+200);
				
			}
		}
		
		if (camera.position.getX() > 70 && camera.mouvementSpeed > 0)
			camera.mouvementSpeed = -camera.mouvementSpeed ;
		
		if (camera.position.getX() < -70 && camera.mouvementSpeed < 0)
			camera.mouvementSpeed = -camera.mouvementSpeed ;
		
		
		camera.update();
		
	}

	

	

	static FloatBuffer lightPosition0 = (FloatBuffer)BufferUtils.createFloatBuffer(4).put(new float[] { 50f, 0f, 0f, 1f  }).rewind();
	static FloatBuffer lightPosition1 = (FloatBuffer)BufferUtils.createFloatBuffer(4).put(new float[] { 0f, 0f, 0f, 1f  }).rewind();
	
	@Override
	public
	void setupPerspective() {
		
			GL11.glEnable(GL11.GL_LIGHTING);
			GL11.glEnable(GL11.GL_DEPTH_TEST);
			GL11.glMatrixMode(GL11.GL_PROJECTION); // Select The Projection Matrix
		    GL11.glLoadIdentity(); // Reset The Projection Matrix
			GLU.gluPerspective(75.0f,Engine.SCREEN_WIDTH/Engine.SCREEN_HEIGHT*1.5f,0.1f,10000.0f); 
			GL11.glMatrixMode(GL11.GL_MODELVIEW); 
			GL11.glLoadIdentity();
		    GL11.glLight(GL11.GL_LIGHT1, GL11.GL_POSITION, lightPosition0);
			GL11.glLight(GL11.GL_LIGHT2, GL11.GL_POSITION, lightPosition1);
	}

	public static void spawRandomEvil()
	{
		Evil evil = new Evil();
		
		float p_x = random.nextInt(Engine.SCREEN_WIDTH/2);
		if (random.nextBoolean())
			p_x = -p_x;
		
		float p_y = random.nextInt(Engine.SCREEN_HEIGHT/2);
		if (random.nextBoolean())
			p_y = -p_y;
		
		
		evil.position = new Vertex(p_x,p_y,-500);
		evil.rotation.setX(90);
		evil.polarity = random.nextBoolean();
		Engine.enemies.addEntity(evil);
	}
}
