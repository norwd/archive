package engine.level;

import java.nio.FloatBuffer;
import java.util.ArrayList;

import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;

import com.Vertex;
import com.obj.WavefrontObject;

import engine.Engine;
import engine.Layer;
import engine.ObjLibrary;
import engine.VisibleElement;
import engine.camera.BezierMouvement;
import engine.camera.Camera;
import engine.camera.ElipticMouvement;
import engine.camera.MonitorRotation;
import engine.entities.CircleTama;
import engine.entities.Player;
import engine.entities.ScenePlayer;
import engine.entities.SortedWfObject;
import engine.entities.Spark;
import engine.entities.SparkAnimation;
import engine.entities.Tama;
import engine.entities.action.Wait;
import engine.level.action.DisplayWarningMessage;
import engine.level.action.EnableControls;
import engine.level.action.Fade;

import engine.level.action.GetBackPlayerScene;
import engine.level.action.LevelOver;
import engine.level.action.MapSpeeds;
import engine.level.action.MoveAbovePlayer;
import engine.level.action.MovePlayerYLevel;
import engine.level.action.MoveTo;
import engine.level.action.MoveToPlayerZLevel;
import engine.level.action.OnCameraBelow5;
import engine.level.action.OnCameraExitTenso;
import engine.level.action.OnPlayerPassCamera;
import engine.level.action.StartCameraRotation;
import engine.level.action.StartEnemies;
import engine.level.action.StopRotationAt;
import engine.level.action.SwitchCamera;
import engine.level.action.SwitchPlayerScene;

public class Level1  extends Level implements VisibleElement{

	
	public static boolean spawnEnemies = false;
	
	// Enemey spawning
	static final float  TAMA_SPAWNING_RATE = 4.5f;
	float tamaSpawningCounter = TAMA_SPAWNING_RATE;

	
	// Animation
	static float skyYRotation = 0;
	static float skyRotationSpeed = 1;
	
	// Objects
	WavefrontObject tenso = null;
	WavefrontObject sky1 = null;
	WavefrontObject sky2 = null;
	static public ScenePlayer player = null;
	static public Layer sparks = new Layer();
	
	public Level1()
	{
		GL11.glClearColor(205f/255f, 165f/255f, 139f/255f, 1f);
		
		tenso = ObjLibrary.instance().getObj(ObjLibrary.TENSO); 
		sky1 = ObjLibrary.instance().getObj(ObjLibrary.SKY1);
		sky2 = ObjLibrary.instance().getObj(ObjLibrary.SKY2);
		
		spawnSpark();
		
		player = new ScenePlayer();
		
		player.position = new Vertex(0,0,-100);
		
		player.mouvementdirection = new Vertex(0,0,1);
		player.mouvementSpeed = 40f;//40;
		player.rotationdirection = new Vertex(0,0,1);
		player.rotationSpeed = -200;
		
		camera = new Camera();
		camera.position = new Vertex(10,0,50);
		camera.mouvementdirection = new Vertex(0,0,1);
		camera.mouvementSpeed = 15f;//15;
		camera.followEntity(player);
		
		/*
		camera.position = new Vertex(500,-500,500);
		//position = new Vertex(0,0,0);
		
		
		camera.rotation = new Vertex(30,-20,0);
		camera.rotationdirection = new Vertex(4,-4,0);
		camera.rotationSpeed = 1;
		
		camera.updates.push(new MonitorRotation());
		camera.updates.push(new ElipticMouvement(new Vertex(0,0,1),30f,50f));
		camera.updates.push(new BezierMouvement(camera.position,new Vertex(),new Vertex(),new Vertex(),100f));
		*/
		
		
		// FOG ////////////////////////////////////////////////////////////////////////////
		GL11.glEnable(GL11.GL_FOG);	
		FloatBuffer fogColor = BufferUtils.createFloatBuffer(4);
		float fogColorNative[] = {205f/255f, 165f/255f, 139f/255f, 1f};  
		//float fogColorNative[] = {0.5f, 0.5f, 0.5f, 1.0f};
		//float fogColorNative[] = {1f, 0f,0f,  1.0f};
		fogColor.put(fogColorNative).flip();
		
		GL11.glFogi(GL11.GL_FOG_MODE, GL11.GL_LINEAR);		// Fog Mode
		GL11.glFog(GL11.GL_FOG_COLOR,fogColor);			// Set Fog Color
		GL11.glFogf(GL11.GL_FOG_DENSITY, 0.0002f);				// How Dense Will The Fog Be
		GL11.glHint(GL11.GL_FOG_HINT, GL11.GL_FASTEST);			// Fog Hint Value
		GL11.glFogf(GL11.GL_FOG_START, 6000.0f);				// Fog Start Depth
		GL11.glFogf(GL11.GL_FOG_END, 10000.0f);				// Fog End Depth
		// FOG ////////////////////////////////////////////////////////////////////////////
		
		
		actions.addAction(new Wait(1));
		actions.addAction(new Fade(1,1));
		actions.addAction(new OnPlayerPassCamera(player,camera));
		actions.addAction(new MoveTo(camera,new Vertex(0,20,-30),player,1));
		actions.addAction(new MoveTo(camera,new Vertex(0,10,-1),player,1));
		actions.addAction(new MapSpeeds(player,camera));
		actions.addAction(new MovePlayerYLevel(player,camera));
		actions.addAction(new SwitchPlayerScene(this));
		actions.addAction(new StartCameraRotation(camera));
		actions.addAction(new Wait(2));
		actions.addAction(new StartEnemies(this));
		actions.addAction(new EnableControls());
		actions.addAction(new OnCameraExitTenso(camera));
		actions.addAction(new GetBackPlayerScene(player));
		actions.addAction(new MoveTo(camera,new Vertex(-10,5,30),player,4));
		actions.addAction(new Wait(1));
		actions.addAction(new Fade(0,2));
		actions.addAction(new LevelOver(this));
		
		actions.start();
	}
	
	private void spawnSpark() {
		SparkAnimation spark = new SparkAnimation(SparkAnimation.ROTATIONSPEED);
		spark.position = new Vertex(0,0,10);
		sparks.addEntity(spark);
		
		spark = new SparkAnimation(-SparkAnimation.ROTATIONSPEED);
		spark.position = new Vertex(0,0,10);
		sparks.addEntity(spark);
		
	}

	public static boolean rotatate = false;
	
	static final float SPARK_RATE = 1f;
	float sparkCounter = 0;
	public void update()
	{
		sparkCounter +=Engine.timer.delta;
		if (sparkCounter > SPARK_RATE)
		{
			sparkCounter=0;
			spawnSpark() ;
		}
		
		player.update();
		sparks.update();
		if (rotatate)
			player.position.rotateZ(Engine.timer.delta * 1);
		
		skyYRotation += skyRotationSpeed * Engine.timer.delta;
		camera.update();
		
		actions.update();
		
		tamaSpawningCounter -= Engine.timer.delta;
		

		if (tamaSpawningCounter < 0 && spawnEnemies)

		{
			CircleTama circleTama = new CircleTama();
			Engine.enemies.addEntity(circleTama);
			tamaSpawningCounter = TAMA_SPAWNING_RATE;
		}
	}
	
	
	
	
	public void render()
	{
		GL11.glDisable(GL11.GL_LIGHTING);
		GL11.glPushMatrix();
			GL11.glDisable(GL11.GL_DEPTH_TEST);
			GL11.glRotatef(skyYRotation,0,1,0);
			
			sky2.render();
			GL11.glRotatef(180,0,1,0);
			sky2.render();
			
			GL11.glRotatef(180,0,0,1);
			sky1.render();
			GL11.glEnable(GL11.GL_DEPTH_TEST);
		GL11.glPopMatrix();
		GL11.glEnable(GL11.GL_LIGHTING);
		
		
		
		
		GL11.glPushMatrix();		
			tenso.render();
		GL11.glPopMatrix();
		
		GL11.glPushMatrix();
			GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
			sparks.render();
			GL11.glBlendFunc(GL11.GL_SRC_ALPHA,GL11.GL_ONE_MINUS_SRC_ALPHA);
		GL11.glPopMatrix();
		
		GL11.glPushMatrix();
			player.render();
		GL11.glPopMatrix();
		
		
		
	}

	static FloatBuffer lightPosition0 = (FloatBuffer)BufferUtils.createFloatBuffer(4).put(new float[] { 00f, 0f, 50f, 1f  }).rewind();
	static FloatBuffer lightPosition1 = (FloatBuffer)BufferUtils.createFloatBuffer(4).put(new float[] { 0f, 0f, 0f, 1f  }).rewind();
	
	
	
	@Override
	public
	void setupPerspective() {
		
			GL11.glEnable(GL11.GL_LIGHTING);
			GL11.glEnable(GL11.GL_DEPTH_TEST);
			GL11.glMatrixMode(GL11.GL_PROJECTION); // Select The Projection Matrix
		    GL11.glLoadIdentity(); // Reset The Projection Matrix
			GLU.gluPerspective(85.0f,Engine.SCREEN_WIDTH/Engine.SCREEN_HEIGHT,0.1f,10000.0f); 
			GL11.glMatrixMode(GL11.GL_MODELVIEW); 
			GL11.glLoadIdentity();
		    GL11.glLight(GL11.GL_LIGHT1, GL11.GL_POSITION, lightPosition0);

		    /*
		    FloatBuffer lightDiffuse1 = (FloatBuffer)BufferUtils.createFloatBuffer(4).put(new float[] { 0.2f, 0.2f, 0.9f, 0.5f  }).rewind();
			GL11.glLight(GL11.GL_LIGHT1, GL11.GL_DIFFUSE, lightDiffuse1);
			
			GL11.glLightf (GL11.GL_LIGHT1, GL11.GL_SPOT_CUTOFF, 15.f);
			
			//setupOrtho();
			FloatBuffer lightSpec0= (FloatBuffer)BufferUtils.createFloatBuffer(4).put(new float[] { 0.8f, 0.8f, 0.8f, 1f  }).rewind();
			GL11.glLight(GL11.GL_LIGHT1, GL11.GL_SPECULAR, lightSpec0);
			
			//GL11.glColorMaterial(GL11.GL_FRONT,GL11.GL_AMBIENT);

			FloatBuffer lightDirection1= (FloatBuffer)BufferUtils.createFloatBuffer(4).put(new float[] { 0f, 0f, 500f, 1f  }).rewind();
			GL11.glLight(GL11.GL_LIGHT1, GL11.GL_SPOT_DIRECTION, lightDirection1);
		    
			GL11.glLight(GL11.GL_LIGHT1, GL11.GL_POSITION, lightPosition1);
			*/
	}
}
