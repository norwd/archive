package engine.keyboard;

import com.Vertex;

import engine.Engine;
import engine.entities.Explosion;

public class SpawnExplosionKey extends KeyBoardKeyHandler {

	@Override
	public void onKeyPressed() {
		Explosion explosion = new Explosion();
		explosion.position = new Vertex();
		Engine.explosions.addEntity(explosion);

	}

	@Override
	public void onRapidFire() {
		// TODO Auto-generated method stub

	}

}
