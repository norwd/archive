package engine.keyboard;

public class ArmsControlerToogler extends KeyBoardKeyHandler {

	@Override
	public void onKeyPressed() {
		HeartBossArmControlAdd.mode += 1;
		HeartBossArmControlAdd.mode %= 3;

	}

	@Override
	public void onRapidFire() {
		// TODO Auto-generated method stub

	}

}
