package engine.keyboard;

public abstract class KeyBoardKeyHandler {

	
	protected float rapidFireLimit;
	protected float rapidFireCounter;
	
	public abstract void onKeyPressed();
	public abstract void onRapidFire();
}
