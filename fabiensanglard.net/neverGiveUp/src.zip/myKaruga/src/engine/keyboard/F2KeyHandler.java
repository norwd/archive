package engine.keyboard;

import engine.Engine;

public class F2KeyHandler extends KeyBoardKeyHandler {

	@Override
	public void onKeyPressed() {
		Engine.drawCollisionBoxes= !Engine.drawCollisionBoxes;

	}

	@Override
	public void onRapidFire() {
		// TODO Auto-generated method stub

	}

}
