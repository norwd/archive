package engine.keyboard;

import java.util.ArrayList;

import org.lwjgl.input.Keyboard;

import engine.Engine;

public class KeyBoardHandler {

	private ArrayList<Key> keyHandlers = new ArrayList<Key>();
	
	public KeyBoardHandler()
	{
	}
	
	public void addKey(int keyId, KeyBoardKeyHandler handler)
	{
		this.keyHandlers.add(new Key(keyId, handler));
	}
	
	public void update()
	{
		
		for (Key key: keyHandlers)
		{
			if (Keyboard.isKeyDown(key.getKeyId()))
			{
				if (!key.isWasPressed())	
					key.handler.onKeyPressed();
				else
				{
					key.handler.rapidFireCounter+=Engine.timer.delta;
					if (key.handler.rapidFireCounter > key.handler.rapidFireLimit)
						key.handler.onRapidFire();
				}
				key.setWasPressed(true);
			}
			else
			{
				key.setWasPressed(false);
			}
		}
	}
}
