package engine.keyboard;

import engine.Engine;
import engine.level.Level3;

public class HeartBossArmControlAdd extends KeyBoardKeyHandler {

	
	static public int JOIN0=0;
	static public int PISTON0=1;
	static public int JOIN1=2;
	static public int PISTON1=3;
	static public int JOIN2=4;	
	
	static protected int mode = 0;
	
	@Override
	public void onKeyPressed() 
	{
		doIt();
	}

	@Override
	public void onRapidFire() {
		doIt();
		
	}
	
	
	
	private void doIt()
	{
		if (mode == PISTON0)
		{
			Level3.boss.piston0 -= 30 * Engine.timer.delta;
			Level3.boss.extendPiston0(Level3.boss.piston0);
		}
		
		if (mode == JOIN0)
		{
			Level3.boss.join0 -= 30 * Engine.timer.delta;
			Level3.boss.rotateArmJoin0(Level3.boss.join0);
		}
		
		if (mode == PISTON1)
		{
			Level3.boss.piston1 -= 30 * Engine.timer.delta;
			Level3.boss.extendPiston1(Level3.boss.piston1);
		}
		
		if (mode == JOIN1)
		{
			Level3.boss.join1 -= 30 * Engine.timer.delta;
			Level3.boss.rotateArmJoin1(Level3.boss.join1);
		}
	}

}
