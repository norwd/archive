package engine.keyboard;

import com.Vertex;

import engine.Constants;
import engine.Engine;

public class RightKeyHandler extends KeyBoardKeyHandler {

	public void onKeyPressed() {
		Vertex mouvment = new Vertex(+1,0,0);
		Engine.currentLevel.camera.move(mouvment);

	}

	public void onRapidFire() {
		Vertex mouvment = new Vertex(+Engine.timer.delta*Constants.cameraMvtSpeed,0,0);
		Engine.currentLevel.camera.move(mouvment);
		
	}

}
