package engine.keyboard;

import engine.Engine;

public class SpaceKeyHandler extends KeyBoardKeyHandler {

	float repeatCounter = 0;
	
	boolean paused = false;
	
	@Override
	public void onRapidFire() {
			if (repeatCounter > 0.1)
			{
				repeatCounter = 0;
			}
			repeatCounter += Engine.timer.delta;
	}

	@Override
	public void onKeyPressed() {
			if (!paused)
			{
				Engine.timer.pause();
				paused=true;
			}
			else
			{
				Engine.timer.resume();
				paused =false;
			}
	}

}
