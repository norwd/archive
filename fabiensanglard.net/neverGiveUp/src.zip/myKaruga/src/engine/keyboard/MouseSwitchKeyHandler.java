package engine.keyboard;

import engine.Engine;

public class MouseSwitchKeyHandler  extends KeyBoardKeyHandler  {

	@Override
	public void onKeyPressed() {
		Engine.mouseSwitch.toogle() ;
		
	}

	@Override
	public void onRapidFire() {
		// TODO Auto-generated method stub
		
	}

}
