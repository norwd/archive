package engine.keyboard;


import engine.Engine;

public class F1KeyHandler extends KeyBoardKeyHandler {

	@Override
	public void onKeyPressed() {
		Engine.drawBackGroup = !Engine.drawBackGroup;

	}

	@Override
	public void onRapidFire() {
		// TODO Auto-generated method stub

	}

}
