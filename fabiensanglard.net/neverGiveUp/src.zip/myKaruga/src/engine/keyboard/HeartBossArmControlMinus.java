package engine.keyboard;

import engine.Engine;
import engine.level.Level3;

public class HeartBossArmControlMinus extends KeyBoardKeyHandler {

	@Override
	public void onKeyPressed() {
		doIt();

	}

	@Override
	public void onRapidFire() {
		doIt();
	}

	private void doIt()
	{
		if (HeartBossArmControlAdd.mode == HeartBossArmControlAdd.PISTON0)
		{
			Level3.boss.piston0 += 30 * Engine.timer.delta;
			Level3.boss.extendPiston0(Level3.boss.piston0);
		}
		
		if (HeartBossArmControlAdd.mode == HeartBossArmControlAdd.JOIN0)
		{
			Level3.boss.join0 += 30 * Engine.timer.delta;
			Level3.boss.rotateArmJoin0(Level3.boss.join0);
		}
		
		if (HeartBossArmControlAdd.mode == HeartBossArmControlAdd.PISTON1)
		{
			Level3.boss.piston1 += 30 * Engine.timer.delta;
			Level3.boss.extendPiston1(Level3.boss.piston1);
		}
		
		if (HeartBossArmControlAdd.mode == HeartBossArmControlAdd.JOIN1)
		{
			Level3.boss.join1 += 30 * Engine.timer.delta;
			Level3.boss.rotateArmJoin1(Level3.boss.join1);
		}
	}
}
