package engine.keyboard;

import com.Vertex;

import engine.Constants;
import engine.Engine;

public class DownKeyHandler extends KeyBoardKeyHandler {

	public void onKeyPressed() {
		Vertex mouvment = new Vertex(0,0,1);
		Engine.currentLevel.camera.move(mouvment);

	}

	public void onRapidFire() {
		Vertex mouvment = new Vertex(0,0,Engine.timer.delta*Constants.cameraMvtSpeed);
		Engine.currentLevel.camera.move(mouvment);
	}

}
