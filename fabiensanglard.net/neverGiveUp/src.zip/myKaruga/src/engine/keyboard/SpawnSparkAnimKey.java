package engine.keyboard;

import com.Vertex;

import engine.Engine;
import engine.entities.Explosion;
import engine.entities.SparkAnimation;

public class SpawnSparkAnimKey extends KeyBoardKeyHandler {

	@Override
	public void onKeyPressed() {
		SparkAnimation anim = new SparkAnimation(SparkAnimation.ROTATIONSPEED);
		anim.position = new Vertex();
		Engine.enemieBullets.addEntity(anim);

	}

	@Override
	public void onRapidFire() {
		// TODO Auto-generated method stub

	}

}
