package engine.keyboard;

public class Key 
{
	public Key(int keyId, KeyBoardKeyHandler handler)
	{
		this.keyId = keyId;
		this.handler = handler;
		this.wasPressed = false;
	}
	
	private int keyId;
	KeyBoardKeyHandler handler;
	private boolean wasPressed ;
	
	public KeyBoardKeyHandler getHandler() {
		return handler;
	}
	public int getKeyId() {
		return keyId;
	}
	public boolean isWasPressed() {
		return wasPressed;
	}
	public void setWasPressed(boolean wasPressed) {
		this.wasPressed = wasPressed;
	}
	
	
}
