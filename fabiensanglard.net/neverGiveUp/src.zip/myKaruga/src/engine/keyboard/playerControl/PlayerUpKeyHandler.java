package engine.keyboard.playerControl;

import engine.Engine;
import engine.entities.Player;
import engine.keyboard.KeyBoardKeyHandler;

public class PlayerUpKeyHandler extends KeyBoardKeyHandler implements PlayerControlConstants{

	Player player = null;
	
	public PlayerUpKeyHandler(Player player)
	{
		this.player = player;
		this.rapidFireLimit = MOUVEMEMT_DEFAULT_RAPID_FIRE;
	}
	

	public void onRapidFire() {
		player.position.setY(player.position.getY()+MOUVEMEMT_DEFAULT_UNIT*Engine.timer.delta);

	}


	public void onKeyPressed() {
		player.position.setY(player.position.getY()+MOUVEMEMT_DEFAULT_UNIT*Engine.timer.delta);

	}

}
