package engine.keyboard.playerControl;

public interface PlayerKeyHandler {

	//protected float KEY_REPEAT;
}
