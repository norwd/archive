package engine.keyboard.playerControl;

import com.Vertex;

import engine.Engine;
import engine.entities.Bullet;
import engine.entities.Flash;
import engine.entities.Player;
import engine.keyboard.KeyBoardKeyHandler;

public class PlayerZKeyHandler extends KeyBoardKeyHandler implements PlayerControlConstants{

	private Player player;

	public PlayerZKeyHandler(Player player) {
		this.player = player;
		this.rapidFireLimit = MOUVEMEMT_BULLET_RAPID_FIRE;
		this.doubleBulletLimit = rapidFireLimit/2.5f;

	}

	private float doubleBulletCounter = 0;
	private float doubleBulletLimit = 0;
	public void onRapidFire() 
	{
		doubleBulletCounter+=Engine.timer.delta;
		//System.out.println("doubleBulletCounter="+doubleBulletCounter+" -doubleBulletLimit="+doubleBulletLimit);
		if (doubleBulletCounter > doubleBulletLimit)
		{
			player.fireBullet(player.rightWidth/3f);
			player.fireBullet(player.leftWidth/3f);
		}
		else
			player.fireBullet(0);
		
		this.rapidFireCounter=0;
	}


	public void onKeyPressed() {
		doubleBulletCounter = 0;
		player.fireBullet(0);
	}
	
	

}
