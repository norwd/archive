package engine.keyboard.playerControl;

import com.Vertex;

import engine.Engine;
import engine.entities.Player;
import engine.entities.SmartPlasma;
import engine.keyboard.KeyBoardKeyHandler;

public class PlayerCKeyHandler extends KeyBoardKeyHandler {

	private Player player;


	
	public PlayerCKeyHandler(Player player) {
		this.player = player;
	}

	
	public void onRapidFire() {
		// TODO Auto-generated method stub

	}


	public void onKeyPressed() {		
		player.fireSpecialWeapon();

	}

}
