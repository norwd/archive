package engine.keyboard.playerControl;

import engine.entities.Player;
import engine.keyboard.KeyBoardKeyHandler;

public class PlayerXKeyHandler extends KeyBoardKeyHandler {

	private Player player;

	public PlayerXKeyHandler(Player player) {
		this.player = player;
	}


	public void onRapidFire() {
		// TODO Auto-generated method stub

	}


	public void onKeyPressed() {
		player.startFlip();
	}

}
