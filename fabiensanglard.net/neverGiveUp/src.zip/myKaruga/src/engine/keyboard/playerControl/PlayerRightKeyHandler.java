package engine.keyboard.playerControl;

import engine.Engine;
import engine.entities.Player;
import engine.keyboard.KeyBoardKeyHandler;

public class PlayerRightKeyHandler extends KeyBoardKeyHandler implements PlayerControlConstants{

	private Player player;

	public PlayerRightKeyHandler(Player player) {
		this.player = player;
		this.rapidFireLimit = MOUVEMEMT_DEFAULT_RAPID_FIRE;
	}

	@Override
	public void onRapidFire() {
		player.position.setX(player.position.getX()+MOUVEMEMT_DEFAULT_UNIT*Engine.timer.delta);

	}

	@Override
	public void onKeyPressed() {
		player.position.setX(player.position.getX()+MOUVEMEMT_DEFAULT_UNIT*Engine.timer.delta);

	}

}
