package engine.keyboard.playerControl;

public interface PlayerControlConstants {

	float MOUVEMEMT_DEFAULT_RAPID_FIRE = 0.020f;
	float MOUVEMEMT_BULLET_RAPID_FIRE = 0.090f/1.5f;
	float MOUVEMEMT_DEFAULT_UNIT = 500f;
}
