package engine;

import com.Vertex;
import com.obj.WavefrontObject;

import engine.entities.Bullet;
import engine.entities.Explosion;
import engine.entities.SortedWfObject;
import engine.entities.SparkAnimation;

public class ObjLibrary {

	public static int PLAYER=0;
	public static int BOSS_BODY=1;
	public static int BOSS_LEG_L=2;
	public static int BOSS_LEG_R=3;
	public static int BOSS_BOP=4;
	public static int BOSS_SHIELD_L=5;
	public static int BOSS_SHIELD_R=6;
	public static int BOSS_ARM_L=7;
	public static int BOSS_ARM_R=8;
	public static int BOSS_ARM_SHOULDER_L=9;
	public static int BOSS_ARM_SHOULDER_R=10;
	public static int BOSS_COAJ_L=11;
	public static int BOSS_COAJ_R=12;
	public static int TIKA01=13;
	public static int LEVEL2_FRAME=14;
	public static int TAMA=15;
	public static int TENSO=16;
	public static int SKY1=17;
	public static int SKY2=18;
	public static int VANILLA_PLAYER=19;
	
	private static WavefrontObject[] library = new WavefrontObject[20];
	private static Loader[] loaders = new Loader[20];
	
	private class Loader
	{
		public static final int NORMAL=0;
		public static final int SORTED=1;
		
		
		private String path = null;
		private int type = 0;
		private float scaleFactor=1f;
		private Vertex translation;
		private Vertex rotation;
		
		Loader(String path)
		{
			this(NORMAL,path);
		}
		
		Loader(String path, float scaleFactor)
		{
			this(NORMAL,path,scaleFactor);
		}
		
		Loader(String path, float scaleFactor,Vertex translation, Vertex rotation)
		{
			this(NORMAL,path,scaleFactor);
			this.translation = translation;
			this.rotation = rotation;
		}
		
		Loader(int type,String path)
		{
			this.path = path;
			this.type=type;
		}
		
		Loader(int type,String path, float scaleFactor)
		{
			this(type,path);
			this.scaleFactor = scaleFactor;
		}
		
		public WavefrontObject load()
		{
			if (type==NORMAL)
				if (translation != null)
					return new WavefrontObject(path,scaleFactor,translation,rotation);
				else
					return new WavefrontObject(path,scaleFactor);
			else
				return new SortedWfObject(path);
		}
	}
	
	static private ObjLibrary instance=null;
	private ObjLibrary()
	{
		float scaleFactor = 10;
		loaders[PLAYER] = new Loader("/Data/IKAL/IKAL.OBJ",10);
		loaders[VANILLA_PLAYER] = new Loader("/Data/IKAL/IKAL.OBJ");
		
		scaleFactor = 12;
		loaders[BOSS_BODY] =  new Loader("/Data/LVL3/S1_BOSS_BODY/S1_BOSS_BODY.OBJ",scaleFactor);
		loaders[BOSS_LEG_L] = new Loader("/Data/LVL3/S1_BOSS_LEG_L/S1_BOSS_LEG_L.OBJ",scaleFactor);
		loaders[BOSS_LEG_R] = new Loader("/Data/LVL3/S1_BOSS_LEG_R/S1_BOSS_LEG_R.OBJ",scaleFactor);
		loaders[BOSS_BOP]   =  new Loader("/Data/LVL3/S1_BOSS_BOP/S1_BOSS_BOP.OBJ",scaleFactor);
		loaders[BOSS_ARM_L] = new Loader("/Data/LVL3/S1_BOSS_ARM_L/S1_BOSS_ARM_L.OBJ",scaleFactor,new Vertex(10,10,0), new Vertex());
		loaders[BOSS_ARM_R] = new Loader("/Data/LVL3/S1_BOSS_ARM_R/S1_BOSS_ARM_R.OBJ",scaleFactor,new Vertex(-10,10,0),new Vertex());
		loaders[BOSS_ARM_SHOULDER_L] =  new Loader("/Data/LVL3/S1_BOSS_ARM_L/S1_BOSS_ARM_SHOULDER_L.OBJ",scaleFactor);
		loaders[BOSS_ARM_SHOULDER_R] = new Loader("/Data/LVL3/S1_BOSS_ARM_R/S1_BOSS_ARM_SHOULDER_R.OBJ",scaleFactor);
		loaders[BOSS_COAJ_L] = new Loader("/Data/LVL3/S1_BOSS_COAJ_L/S1_BOSS_COAJ_L.OBJ",scaleFactor);
		loaders[BOSS_COAJ_R] = new Loader("/Data/LVL3/S1_BOSS_COAJ_R/S1_BOSS_COAJ_R.OBJ",scaleFactor);
		
		scaleFactor = 10.5f;
		loaders[BOSS_SHIELD_L] = new Loader("/Data/LVL3/S1_BOSS_GUA_L/S1_BOSS_GUA_L.OBJ",scaleFactor);
		loaders[BOSS_SHIELD_R] = new Loader("/Data/LVL3/S1_BOSS_GUA_R/S1_BOSS_GUA_R.OBJ",scaleFactor);
		
		loaders[TIKA01] = new Loader(Loader.SORTED,"/Data/LVL3/TIKA01/TIKA01.OBJ"); 
		
		
		loaders[LEVEL2_FRAME] = new Loader("/Data/LVL2/FRA200L/FRA200L.OBJ");
		
		loaders[TAMA] = new Loader("/Data/TAMA/TAMA.OBJ",10);
		
		new Explosion();
		new Bullet();
		new SparkAnimation(1);
		
		loaders[TENSO] = new Loader(Loader.SORTED,"/Data/LVL1/TENSO/TENSO.OBJ");
		loaders[SKY1] = new Loader("/Data/LVL1/SKY1/SKY1.OBJ");
		loaders[SKY2] = new Loader("/Data/LVL1/SKY2/SKY2.OBJ");
	}
	
	public static ObjLibrary instance()
	{
		if (instance == null)
			instance = new ObjLibrary();
		return instance;
	}
	
	public WavefrontObject getObj(int id)
	{
		WavefrontObject obj = library[id];
		if (obj == null)
			library[id] = loaders[id].load();
			
		return library[id];
	}
	
}
