package engine;

import java.util.ArrayList;
import java.util.Iterator;

import org.lwjgl.opengl.GL11;

import com.Vertex;

import engine.entities.Bullet;
import engine.entities.Entity;

public class Layer implements VisibleElement{

	private ArrayList<Entity> entities = new ArrayList<Entity>();
	
	public void render()
	{
		for (Entity entity : entities)
		{
			GL11.glPushMatrix();	
				//GL11.glLoadIdentity();
				entity.render();
			GL11.glPopMatrix();
		}
	}
	
	public void update()
	{
		Entity entity = null;
		for (Iterator<Entity> it = entities.iterator(); it.hasNext();)
		{
			entity = it.next();
			if (entity.toBeCleared)
				it.remove();
		}
		
		
		for (int i=0 ; i < entities.size() ; i ++)
			entities.get(i).update();
	}
	
	public void detectCollision(Layer otherLayer)
	{
		
		Vertex position = null;
		for (Entity entity : entities)
		{
			for (Entity remoteEntity : otherLayer.getEntities())
			{
				position = entity.position;
				
				if (
						entity.energyRemaining <= 0 ||
						remoteEntity.energyRemaining <= 0 ||
						position.getY() + entity.upperHeight < remoteEntity.position.getY() + remoteEntity.lowerHeight ||
						position.getY() + entity.lowerHeight > remoteEntity.position.getY() + remoteEntity.upperHeight ||
						position.getX() + entity.rightWidth < remoteEntity.position.getX() + remoteEntity.leftWidth   ||
						position.getX() + entity.leftWidth > remoteEntity.position.getX() + remoteEntity.rightWidth 
				)
				{
					continue;
				}
				
				
				int entityNRJ = entity.energyRemaining;
				int remotentityNRK = remoteEntity.energyRemaining;
				
				entity.collide(remoteEntity,remotentityNRK);
				remoteEntity.collide(entity,entityNRJ);
				
			}
		}
		
	}
	
	public void addEntity(Entity entity)
	{
		entities.add(entity);
	}
	
	public void addEntityOnTop(Entity entity)
	{
		entities.add(0,entity);
	}
	
	public void clear()
	{
		entities.clear();
	}
	
	public ArrayList<Entity> getEntities()
	{
		return entities;
	}
}
