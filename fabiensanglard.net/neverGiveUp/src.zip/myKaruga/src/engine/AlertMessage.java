package engine;

import org.lwjgl.opengl.GL11;

import com.TextureLoader;

import engine.entities.Entity;

public class AlertMessage extends Entity {

	int textureId = 0;
	
	public AlertMessage()
	{
	 	textureId = TextureLoader.instance().loadTexture("/Data/SPR/Warning.png").getTextureID();
		width=512;
		height=-256;
		completeContructor();
	}
	
	public void render() 
	{
		GL11.glTranslatef(0,0,0);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, textureId);

		GL11.glBegin(GL11.GL_QUADS);
			GL11.glTexCoord2f(1,1); //Upper right
			GL11.glVertex2f(rightWidth,upperHeight);
		
			GL11.glTexCoord2f(1,0); // Lower right
			GL11.glVertex2f(rightWidth,lowerHeight);
			
			GL11.glTexCoord2f(0,0); //Lower left
			GL11.glVertex2f(leftWidth,lowerHeight);
			GL11.glTexCoord2f(0,1); //Upper left			
			GL11.glVertex2f(leftWidth,upperHeight);        
		GL11.glEnd();
		
	}
}
