package engine;

public interface VisibleElement {

	void update();
	void render();
}
