package engine.entities;

import com.Vertex;

import engine.Engine;
import engine.entities.SmartPlasma;

public class SmartPlasmaPart {

	public Vertex position;
	public Vertex leftSide;
	public Vertex rightSide;
	public float cumulatedTailLength;
	
	public static final float PART_WIDTH = 8;
	
	private Vertex leftExpansionVector;
	private Vertex rightExpansionVector;
	
	
	final static float INITIAL_TTL = SmartPlasma.INITIAL_TTL ;
	float ttl = INITIAL_TTL;
	
	SmartPlasma smartPlasma = null;
	
	public SmartPlasmaPart(SmartPlasma smartPlasma, float cumulatedTailLength ) {
		
		this.smartPlasma = smartPlasma;
		
		this.position = new Vertex(smartPlasma.position);
		this.rightSide = new Vertex(smartPlasma.mouvementdirection.copyAndRotateZ((float)Math.PI/2));
		this.rightSide = rightSide.mult(PART_WIDTH);
		this.rightSide = rightSide.copyAndAdd(this.position);
		
		
		this.leftSide = new Vertex(smartPlasma.mouvementdirection.copyAndRotateZ(-(float)Math.PI/2));
		this.leftSide = leftSide.mult(PART_WIDTH);
		this.leftSide = leftSide.copyAndAdd(this.position);
		
		this.cumulatedTailLength = cumulatedTailLength;
		
		this.leftExpansionVector = new Vertex(smartPlasma.mouvementdirection).copyAndRotateZ(-(float)Math.PI/2);
		this.rightExpansionVector = new Vertex(smartPlasma.mouvementdirection).copyAndRotateZ((float)Math.PI/2);
		
	}
	
	public void update()
	{
		leftSide.add(leftExpansionVector .mult(Engine.timer.delta * smartPlasma.EXPANSION_SPEED) );
		rightSide.add(rightExpansionVector.mult(Engine.timer.delta * smartPlasma.EXPANSION_SPEED) );
		
		ttl -= Engine.timer.delta ;
	}

}
