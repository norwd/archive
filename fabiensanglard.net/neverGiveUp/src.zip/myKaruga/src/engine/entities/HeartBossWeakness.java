package engine.entities;

import org.lwjgl.opengl.GL11;

import com.Vertex;
import com.obj.WavefrontObject;

import engine.Engine;
import engine.ObjLibrary;


public class HeartBossWeakness extends Entity {

	private HeartBoss heartBoss;
	
	boolean isLeftSide ;
	
	WavefrontObject obj = null;
	
	public float hitHighLightTime = 0;
	public float hitHighLightCounter = 0;
	public boolean drawHighLighted = false;
	
	Vertex explosionColor = new Vertex(1,0.3f,0);
	
	public HeartBossWeakness(HeartBoss heartBoss, boolean isLeftSide)
	{
		this.heartBoss = heartBoss;
		width = 70f;
		height = 28f;
		
		hitHighLightTime = 0.02f;
		
		completeContructor();
		upperHeight += 100;
		lowerHeight += 30;
		
		energyStart = 2000;
		energyRemaining = energyStart;
		this.isLeftSide = isLeftSide;
		
		this.position = new Vertex(heartBoss.position);
		
		this.polarity = isLeftSide;
		
		if (isLeftSide)
			obj = 	ObjLibrary.instance().getObj(ObjLibrary.BOSS_COAJ_L);	
		else
			obj = 	ObjLibrary.instance().getObj(ObjLibrary.BOSS_COAJ_R);	
		
		float sign = isLeftSide ? -1  : 1;
		
		this.position.setX(this.position.getX()+ sign * HeartBoss.heartXOffset);
		this.position.setY(this.position.getY()-HeartBoss.heartWeaknessY);
	}
	
	private boolean exploded = false;
	
	public void render()
	{
		if (isLeftSide)
			GL11.glTranslatef(position.getX()+HeartBoss.heartXOffset,position.getY()+HeartBoss.heartWeaknessY,position.getZ());
		else
			GL11.glTranslatef(position.getX()-HeartBoss.heartXOffset,position.getY()+HeartBoss.heartWeaknessY,position.getZ());
		
		GL11.glRotatef(90,1, 0,0);
		
		
		if (energyRemaining <=0 || drawHighLighted)
		{
			if (energyRemaining <=0 && !exploded)
			{
				exploded = true;
				explod();
			}
			
			if (drawHighLighted)
				GL11.glTexEnvi(GL11.GL_TEXTURE_ENV, GL11.GL_TEXTURE_ENV_MODE, GL11.GL_ADD);
			obj.render();
			if (drawHighLighted)
				GL11.glTexEnvi(GL11.GL_TEXTURE_ENV, GL11.GL_TEXTURE_ENV_MODE, GL11.GL_MODULATE);
		}
	}
	
	private void explod() {
		PlasmaWave plasmaWave = new PlasmaWave(this,Engine.SCREEN_WIDTH/4,500,explosionColor); 
		Engine.explosions.addEntity(plasmaWave);
		Explosion explosion = null;
		
		explosion = new Explosion();
		explosion.position = new Vertex(position.getX()+ leftWidth,position.getY(),0);
		Engine.explosions.addEntity(explosion);
		
		explosion = new Explosion();
		explosion.position = new Vertex(position.getX()+ rightWidth,position.getY(),0);
		Engine.explosions.addEntity(explosion);
		
		explosion = new Explosion();
		explosion.position = new Vertex(position.getX()+ leftWidth,position.getY()+lowerHeight,0);
		Engine.explosions.addEntity(explosion);
		
		explosion = new Explosion();
		explosion.position = new Vertex(position.getX()+ rightWidth,position.getY()+upperHeight,0);
		Engine.explosions.addEntity(explosion);
		
	}

	public void update()
	{
		if (heartBoss.toBeCleared)
			toBeCleared = true;
		
		if (drawHighLighted)
		{
			hitHighLightCounter -= Engine.timer.delta;
			if (hitHighLightCounter < 0)
				drawHighLighted = false;
		}
	}
	
	@Override
	public void collide(Entity remoteEntity,int remoteEnergy) 
	{
		super.collide(remoteEntity,remoteEnergy);
		drawHighLighted = true;
		hitHighLightCounter = hitHighLightTime;

	}
}
