package engine.entities;

import java.util.ArrayList;
import java.util.Random;

import org.lwjgl.opengl.GL11;

import com.TextureLoader;
import com.Vertex;


import engine.Engine;

public class SmartPlasma extends Entity {
	
	private ArrayList<SmartPlasmaPart> tail = new ArrayList<SmartPlasmaPart>();
	
	private static final float DEFAUTL_PART_LIMIT =  0.5f;// Engine.SCREEN_WIDTH/10000f;
	
	public static final float INITIAL_TTL=0.5f ;
	
	private float timeCounter;
	protected float ttl = INITIAL_TTL ;
	
	static private int textureId = TextureLoader.instance().loadTexture("/Data/SPR/SmartPlasma2.png").getTextureID();
	
	float EXPANSION_SPEED = 2  ;
	
	Random random = new Random(System.currentTimeMillis());
	
	Entity target = null;
	
	public SmartPlasma(Vertex position, boolean polarity, Vertex mouvementdirection, float maxDirectionChange)
	{
		//System.out.println("SmartPlasma created");
		this.maxDirectionChange = maxDirectionChange;
		this.mouvementSpeed = 1500 ;
		this.position = new Vertex(position);
		this.polarity = polarity;
		this.mouvementdirection = mouvementdirection;
		height = Engine.SCREEN_WIDTH/60f;
		width = height;
		completeContructor();
		energyRemaining = 10;
		
		renewTarget();
		
		
		
		tail.add(0,new SmartPlasmaPart(this,distanceFromLastPoint));
	}
	
	private void renewTarget() 
	{
		ArrayList<Entity> enemies = Engine.enemies.getEntities();
		
		if (Engine.enemies.getEntities().size() > 0)
			target = enemies.get(0);//targetRotation++ % enemies.size());
		else
			target = getTarget();
		
	}


	float distanceFromLastPoint =0;
	float totalTailLength=0;
	
	//static final float MAX_DIRECTION_CHANGE = 12f;
	float maxDirectionChange = 0;
	
	public void update()
	{
		this.position.setX(this.position.getX() +  this.mouvementdirection.getX() * Engine.timer.delta * mouvementSpeed);
		this.position.setY(this.position.getY() + this.mouvementdirection.getY() * Engine.timer.delta * mouvementSpeed);
		
		//Adjust trajectory
		
		if (timeCounter > this.ttl/200)
		{
			double rotationToApply = 0;
			
			if (target == null || target.toBeCleared)
				renewTarget();
			
			if (target != null)
			{
			
				Vertex vectorToEnemy = target.position.copyAndSub(this.position);
				
				double angleDirection = Math.atan2(mouvementdirection.getY(),mouvementdirection.getX());
				double angleEnemy     = Math.atan2(vectorToEnemy.getY(),vectorToEnemy.getX());
				
				
				// Try cos-1(A.B / ||A|| ||B||)   where A.B = x1*x2 + y1*y2
				//http://gpwiki.org/index.php/Math:Vector
				double angleBetweenDirectionAndTargetVectors =  angleDirection - angleEnemy;

				if (angleEnemy < 0 && angleDirection >  angleEnemy + Math.PI)
					angleBetweenDirectionAndTargetVectors = -2*Math.PI + angleBetweenDirectionAndTargetVectors;
				else
					if (angleEnemy > 0 && angleDirection <  angleEnemy - Math.PI)
						angleBetweenDirectionAndTargetVectors = 2*Math.PI + angleBetweenDirectionAndTargetVectors;
				
				
				if (angleBetweenDirectionAndTargetVectors > 0)		
					rotationToApply =  Math.min(angleBetweenDirectionAndTargetVectors,14*Engine.timer.delta );//*Engine.timer.delta);
				
				if (angleBetweenDirectionAndTargetVectors < 0)
					rotationToApply =  Math.max(angleBetweenDirectionAndTargetVectors,-14*Engine.timer.delta );//*Engine.timer.delta);
			
		
				
				mouvementdirection.rotateZ(rotationToApply);
			}
		}
		
	

		
		timeCounter += Engine.timer.delta;
		
		if (timeCounter > this.ttl)
		{
			this.mouvementSpeed = 0;
			this.EXPANSION_SPEED =0;
			if (timeCounter > this.ttl*4)
				this.toBeCleared = true;
		}

		
		SmartPlasmaPart part = null;
		for (int i=0;i<tail.size();i++)
		{
			tail.get(i).update() ;
			/*
			if (part.ttl  < 0 )
			{
				for (int j=i;j<tail.size();j++)
				{
					if (tail.get(j).ttl < 0)
						tail.remove(i);
				}
				break;
			}
			*/
		}
		
		
		if (tail.size() == 0)
			return;
		
		distanceFromLastPoint = getDistanceFromLast();
		SmartPlasmaPart lastPart = tail.get(0);
		if (distanceFromLastPoint > DEFAUTL_PART_LIMIT )
			tail.add(0,new SmartPlasmaPart(this,distanceFromLastPoint+lastPart.cumulatedTailLength));

	
		totalTailLength = lastPart.cumulatedTailLength +  distanceFromLastPoint;
	}
	
	

	private int roundRobin;
	private Entity getTarget() {
		
		if (Engine.privilegiedSmartPlasmaTarget == null || Engine.privilegiedSmartPlasmaTarget.length == 0)
			if (Engine.enemies.getEntities().size() > 0)
				return Engine.enemies.getEntities().get(0);
			else
				return null;
		else
		{
			roundRobin = roundRobin % Engine.privilegiedSmartPlasmaTarget.length;
			return Engine.privilegiedSmartPlasmaTarget[roundRobin++];
		}
	}
	

	private float getDistanceFromLast() 
	{
		Vertex lastPosition = tail.get(0).position;
		float deltaX = position.getX()-lastPosition.getX();
		float deltaY = position.getY()-lastPosition.getY();
		return (float)Math.sqrt(
					Math.pow(deltaX,2) +
					Math.pow(deltaY,2)
					);
	}

	public void render()
	{
		//GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, textureId);
		drawHead();
		
		SmartPlasmaPart precedentPart = null;
		SmartPlasmaPart currentPart = null;
		for (int i=0;i<tail.size()-1;i++)
		{
			currentPart = tail.get(i);
			precedentPart = tail.get(i+1);
			drawPart(currentPart,precedentPart);
			
		}
		
		
	//	GL11.glBlendFunc(GL11.GL_SRC_ALPHA,GL11.GL_ONE_MINUS_SRC_ALPHA);
		GL11.glColor4f(1,1,1,1);
	}

	
	
	private void drawPart(SmartPlasmaPart currentPart,SmartPlasmaPart precedentPart) {
		
		
		if (currentPart.ttl < 0 && precedentPart.ttl < 0)
		{
			
			return;
		}
		
		float currenPartAlpha = currentPart.ttl/SmartPlasmaPart.INITIAL_TTL;
		if (currenPartAlpha < 0.5f)
			currenPartAlpha = currenPartAlpha*currenPartAlpha;
		if (currenPartAlpha > 0.7f)
			currenPartAlpha = 1;
		
		
		float precedentPartAlpha = precedentPart.ttl/SmartPlasmaPart.INITIAL_TTL;
		if (precedentPartAlpha < 0.5f)
			precedentPartAlpha = precedentPartAlpha * precedentPartAlpha ;
		if (precedentPartAlpha > 0.7f)
			precedentPartAlpha = 1;
		
			
			GL11.glBegin(GL11.GL_QUADS);
			
			
			if (polarity == BLUE)
				GL11.glColor4f(0.1f,0.1f,0.5f,currenPartAlpha);
			else
				GL11.glColor4f(1,0.1f,0.1f,currenPartAlpha);
			
			
				
			GL11.glTexCoord2f(0,1-currentPart.cumulatedTailLength/totalTailLength); //Upper left			
			GL11.glVertex2f(currentPart.leftSide.getX(),currentPart.leftSide.getY());
			GL11.glTexCoord2f(1,1-currentPart.cumulatedTailLength/totalTailLength); //Upper right
			GL11.glVertex2f(currentPart.rightSide.getX(),currentPart.rightSide.getY());
		
		
			if (polarity == BLUE)
				GL11.glColor4f(0.1f,0.1f,0.5f,precedentPartAlpha);
			else
				GL11.glColor4f(1,0.1f,0.1f,precedentPartAlpha);
			
			
			GL11.glTexCoord2f(1,1-precedentPart.cumulatedTailLength/totalTailLength); // Lower right
			GL11.glVertex2f(precedentPart.rightSide.getX(),precedentPart.rightSide.getY());
			GL11.glTexCoord2f(0,1-precedentPart.cumulatedTailLength/totalTailLength); //Lower left
			GL11.glVertex2f(precedentPart.leftSide.getX(),precedentPart.leftSide.getY());
				
				

			GL11.glEnd();
	}

	
	
	private void drawHead() {
		if (tail.size() == 0)
			return;
		
		SmartPlasmaPart lastPart = tail.get(0);
		SmartPlasmaPart currentPosition = new SmartPlasmaPart(this,distanceFromLastPoint+lastPart.cumulatedTailLength);
		
		drawPart(currentPosition,lastPart);
		
	}
	
	
	public void collide(Entity remoteEntity, int remoteEnergy) 
	{
		
		super.collide(remoteEntity, remoteEnergy);
		if (energyRemaining < 0)
		{
			//this.mouvementSpeed = 0;
			this.energyRemaining = 0;
			EXPANSION_SPEED = 0;
		}
		
		Impact plasmaWave = new Impact(this,Engine.SCREEN_WIDTH/4,120,true,0.55f); 
		Engine.plasmaExplositions.addEntity(plasmaWave);
		
		maxDirectionChange = maxDirectionChange * 2f;
	}
}
