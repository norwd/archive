package engine.entities;

import java.util.ArrayList;

import org.lwjgl.opengl.GL11;

import com.obj.Group;
import com.obj.WavefrontObject;

import engine.Engine;

public class SortedWfObject extends WavefrontObject {

	private boolean sortedGroups = false;
	
	private ArrayList<Group> upperGroups = new ArrayList<Group>();
	private ArrayList<Group> lowerGroups = new ArrayList<Group>();
	
	public SortedWfObject(String fileName) {
		super(fileName);
	}
	
	public void render() 
	{
		if (!sortedGroups)
			sortGroups();
		
		if (displayListId != 0)
		{
			GL11.glCallList(displayListId);
			return;
		}

		displayListId = GL11.glGenLists(1);
		
		GL11.glNewList(displayListId,GL11.GL_COMPILE);

		/*
		for (int i=0;i<upperGroups.size() ;i++) //&& i < Engine.faceLimit
			renderGroup(upperGroups.get(i));
		
		for (int i=0;i<lowerGroups.size() ;i++) //&& i < Engine.faceLimit
			renderGroup(lowerGroups.get(i));
		*/
		for (int i=upperGroups.size()-1 ;  i >=0 ;i--) // && upperGroups.size()-i <= Engine.faceLimit
			renderGroup(upperGroups.get(i));
		
		for (int i=lowerGroups.size()-1 ; i >=0  ;i--) //&& lowerGroups.size()-i <= Engine.faceLimit
			renderGroup(lowerGroups.get(i));

		
		
		GL11.glEndList();
	}

	private void sortGroups() {
		
		Group sortedGroup = null;
		
		for (int i=0;i<getGroups().size();i++)
		{
			sortedGroup = getGroups().get(i);
			sortedGroup.pack();
			
			if (sortedGroup.getName().equals("TENSO22") || sortedGroup.getName().equals("TENSO23"))
			{
				lowerGroups.add(0,sortedGroup);
				continue;
			}
				
			if (sortedGroup.getMin().getY() > 0)
				insertIntoUpperList(sortedGroup);
			else
				insertIntoLowerList(sortedGroup);
			
		}
		
		sortedGroups = true;
	}

	private void insertIntoLowerList(Group sortedGroup) {
		
		int i=0;
		while(i < upperGroups.size() && lowerGroups.get(i).getMin().getY() > sortedGroup.getMin().getY())
			i++;
		
		lowerGroups.add(i, sortedGroup);
	}

	private void insertIntoUpperList(Group sortedGroup) {
		int i=0;
		while(i < upperGroups.size() && upperGroups.get(i).getMin().getY() < sortedGroup.getMin().getY())
			i++;
		
		upperGroups.add(i, sortedGroup);
		
	}
	
}
