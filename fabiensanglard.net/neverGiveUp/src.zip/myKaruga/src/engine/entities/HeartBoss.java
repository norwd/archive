package engine.entities;

import org.lwjgl.opengl.GL11;

import com.Vertex;
import com.obj.WavefrontObject;

import engine.Engine;
import engine.ObjLibrary;
import engine.entities.action.ActionSet;
import engine.entities.action.MoveArmsToFront;
import engine.entities.action.MoveTo;
import engine.entities.action.MovePiston1;
import engine.entities.action.RotateJoin0;
import engine.entities.action.RotateJoin2;
import engine.entities.action.RotateLegX;
import engine.entities.action.RotateLegZ;
import engine.entities.action.ShowWeakPoints;
import engine.entities.action.StartHeartsMouvements;
import engine.entities.action.StartRotationArms;
import engine.entities.action.Wait;

public class HeartBoss extends Entity {


	static WavefrontObject body = ObjLibrary.instance().getObj(ObjLibrary.BOSS_BODY);
	static WavefrontObject legL = ObjLibrary.instance().getObj(ObjLibrary.BOSS_LEG_L);
	static WavefrontObject legR = ObjLibrary.instance().getObj(ObjLibrary.BOSS_LEG_R);
	static WavefrontObject bop =  ObjLibrary.instance().getObj(ObjLibrary.BOSS_BOP);
	
	private final static float legXOffset = 50; 
	public final static Vertex legLRotation = new  Vertex(0,70,0);
	public final static Vertex legRRotation = new  Vertex(0,-70,0);
	public final static float legRotationSpeed = 50;
	
	public final static float heartXOffset = 60;
	public final static float heartYMin =180;
	public final static float heartYMax = 340;
	public static final float heartWeaknessY = 150;
	
	private float timeCounter = 0;
	
	private HeartBossshield shieldL ;
	private HeartBossshield shieldR ;
	
	private HeartBossArms armL ;
	private HeartBossArms armR ;
	
	private HeartBossWeakness weaknessL ;
	private HeartBossWeakness weaknessR ;
	
	private ActionSet actions = new ActionSet();
	
	public float join0=-70;
	public float piston0=-110;//-190;
	public float join1=0;//120;
	public float piston1=-65;
	public float join2=100;
	
	Vertex explosionColor = new Vertex(1,0.3f,0);
	
	public HeartBoss(Vertex position)
	{
		width = 175f;
		height = 100f;
		
		completeContructor();
		energyStart = 400000;
		energyRemaining = energyStart;
		
		this.position = position;

		
		shieldL = new HeartBossshield(this,true);
		shieldR = new HeartBossshield(this,false);
		
		armL = new HeartBossArms(this,true);
		armR = new HeartBossArms(this,false);
		
		weaknessL = new HeartBossWeakness(this,true);
		weaknessR = new HeartBossWeakness(this,false);
		
		Engine.privilegiedSmartPlasmaTarget = new Entity[2];
		Engine.privilegiedSmartPlasmaTarget[1] = weaknessL;
		Engine.privilegiedSmartPlasmaTarget[0] = weaknessR;
		
		rotateArmJoin0(join0);
		extendPiston0(piston0);
		rotateArmJoin1(join1);
		extendPiston1(piston1);
		rotateArmJoin2(join2);
		
		Engine.enemies.addEntity(shieldL);
		Engine.enemies.addEntity(shieldR);
		Engine.enemies.addEntity(this);
		Engine.enemies.addEntityOnTop(weaknessL);
		Engine.enemies.addEntityOnTop(weaknessR);
		
		
		actions.addAction(new MoveTo(this,new Vertex(0,Engine.SCREEN_HEIGHT/5)));
		actions.addAction(new Wait(1));
		actions.addAction(new RotateLegX(this,5));
		actions.addAction(new Wait(1));
		actions.addAction(new RotateLegZ(this,17));
		actions.addAction(new Wait(1));
		actions.addAction(new MovePiston1(-100,100));
		actions.addAction(new RotateJoin0(40,70));
		actions.addAction(new RotateJoin2(-10,70));
		actions.addAction(new MoveArmsToFront(this,15));
		actions.addAction(new ShowWeakPoints(this,5));
		actions.addAction(new StartHeartsMouvements(this));
		//actions.addAction(new Wait(1));
		//actions.addAction(new StartRotationArms(10));
		
		actions.start();
		
	}
	
	public void rotateArmJoin2(float angle)
	{
		armL.join2 = angle;
		armR.join2 = angle;
	}
	
	public void rotateArmJoin1(float angle)
	{
		armL.join1 = angle;
		armR.join1 = angle;
	}
	
	public void rotateArmJoin0(float angle)
	{
		armL.join0 = angle;
		armR.join0 = angle;
	}
	
	public void extendPiston0(float size)
	{
		armL.piston0 = size;
		armR.piston0 = size;
	}
	
	public void extendPiston1(float piston1) {
		armL.piston1 = piston1;
		armR.piston1 = piston1;
		
	}
	
	public void render() {

		
		
		GL11.glTranslatef(position.getX(),position.getY(),position.getZ());
		
		
		GL11.glPushMatrix();
			GL11.glRotatef(90,1, 0,0);
			GL11.glTranslatef(-legXOffset,0,10);			
			GL11.glRotatef(legLRotation.getY(),0, 1,0);
			GL11.glRotatef(legLRotation.getZ(),0, 0,1);
			legL.render();
		GL11.glPopMatrix();
		GL11.glPushMatrix();
			GL11.glRotatef(90,1, 0,0);
			GL11.glTranslatef(legXOffset,0,10);			
			GL11.glRotatef(legRRotation.getY(),0, 1,0);
			GL11.glRotatef(legRRotation.getZ(),0, 0,1);
			legR.render();
		GL11.glPopMatrix();
		GL11.glPushMatrix();
			GL11.glRotatef(90,1, 0,0);
			bop.render();
		GL11.glPopMatrix();
		GL11.glPushMatrix();
			GL11.glRotatef(90,1, 0,0);
			body.render();
		GL11.glPopMatrix();
		
		GL11.glPushMatrix();
			armL.render();
		GL11.glPopMatrix();	
		GL11.glPushMatrix();	
			armR.render();
		GL11.glPopMatrix();	
		
		if (getEnergyRemaining() != weaknessL.energyStart+weaknessR.energyStart)
		{
			GL11.glDisable(GL11.GL_LIGHTING);
			GL11.glDisable(GL11.GL_DEPTH_TEST);
			GL11.glDisable(GL11.GL_TEXTURE_2D);
			drawEnergyBar();
			
			GL11.glEnable(GL11.GL_LIGHTING);
			GL11.glEnable(GL11.GL_DEPTH_TEST);
			GL11.glEnable(GL11.GL_TEXTURE_2D);
		}
		}

		private void drawEnergyBar() {
			//GL11.glTranslatef(0,-30, 0);
			GL11.glLoadIdentity();
			GL11.glTranslatef(position.getX(),position.getY()+upperHeight*2.8f,position.getZ());
			//GL11.glTranslatef(0,upperHeight/2,50);
			//GL11.glTranslatef(0,-100, 0);
			GL11.glColor4f(1,0,0,1);
			GL11.glBegin(GL11.GL_QUADS);
				GL11.glVertex2f(rightWidth*2,upperHeight+energyBarWidth);
				GL11.glVertex2f(rightWidth*2,upperHeight);
				GL11.glVertex2f(leftWidth*2,upperHeight);		
				GL11.glVertex2f(leftWidth*2, upperHeight+energyBarWidth);       
			GL11.glEnd();
			
			float heartsEnerny = getEnergyRemaining();
			float heartsStartEnery = weaknessL.energyStart+weaknessR.energyStart;
			float percentageEnergyRemaining = heartsEnerny/(float)heartsStartEnery * 2;
			
			GL11.glColor4f(0,1,0,1);
			GL11.glBegin(GL11.GL_QUADS);
				GL11.glVertex2f(percentageEnergyRemaining*rightWidth*2-rightWidth*2,upperHeight+energyBarWidth);
				GL11.glVertex2f(percentageEnergyRemaining*rightWidth*2-rightWidth*2,upperHeight);
				GL11.glVertex2f(leftWidth*2, upperHeight);		
				GL11.glVertex2f(leftWidth*2, upperHeight+energyBarWidth);       
			GL11.glEnd();
			
			GL11.glColor3f(1,1,1);
		}
	
	public void update()
	{
		Vertex deltaMovment = new Vertex(position);
		
		super.update();
		if (getEnergyRemaining() <=0)
		{
			toBeCleared = true;
			
			shieldL.toBeCleared=true;
			shieldR.toBeCleared=true;
			PlasmaWave plasmaWave = new PlasmaWave(shieldL,Engine.SCREEN_WIDTH/4,500,explosionColor); 
			Engine.explosions.addEntity(plasmaWave);
			
			PlasmaWave plasmaWave2 = new PlasmaWave(shieldR,Engine.SCREEN_WIDTH/4,500,explosionColor); 
			Engine.explosions.addEntity(plasmaWave2);
			
			PlasmaWave plasmaWave3 = new PlasmaWave(this,Engine.SCREEN_WIDTH/4,500,explosionColor); 
			Engine.explosions.addEntity(plasmaWave3);
			
			Explosion explosion = null;
			
			explosion = new Explosion();
			explosion.position = new Vertex(position.getX()+ leftWidth,position.getY(),0);
			Engine.explosions.addEntity(explosion);
			
			explosion = new Explosion();
			explosion.position = new Vertex(position.getX()+ rightWidth,position.getY(),0);
			Engine.explosions.addEntity(explosion);
			
			explosion = new Explosion();
			explosion.position = new Vertex(position.getX()+ leftWidth,position.getY()+lowerHeight,0);
			Engine.explosions.addEntity(explosion);
			
			explosion = new Explosion();
			explosion.position = new Vertex(position.getX()+ rightWidth,position.getY()+upperHeight,0);
			Engine.explosions.addEntity(explosion);
		}
			
		
		deltaMovment.subFrom(this.position);
		
		// Update all parts;
		shieldL.position.add(deltaMovment);
		shieldR.position.add(deltaMovment);
		weaknessL.position.add(deltaMovment);
		weaknessR.position.add(deltaMovment);
		
		shieldL.update();
		shieldR.update();
		
		timeCounter += Engine.timer.delta;
		
		actions.update();

	}
	
	private float getEnergyRemaining()
	{
		return weaknessL.energyRemaining+weaknessR.energyRemaining;
	}

	public void start() {
		shieldL.mouvementActivated = true;
		shieldR.mouvementActivated = true;
		
	}

	
}
