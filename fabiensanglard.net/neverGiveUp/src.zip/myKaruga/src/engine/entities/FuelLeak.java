package engine.entities;

public class FuelLeak extends Entity {

	
	
	public FuelLeak()
	{
		width=0;
		height=0;
		completeContructor();
		
	}
	
	public void update()
	{
		
	}
	
	public void render()
	{
		
	}
	
}
