package engine.entities;

import org.lwjgl.opengl.GL11;

import com.Vertex;
import com.obj.WavefrontObject;

import engine.Engine;
import engine.level.Level2;

public class Evil extends Entity {

	WavefrontObject obj = null;
	
	
	
	FireBattery[] batteries = new FireBattery[2]; 
	
	public Evil()
	{
		obj =  new WavefrontObject("/Data/EVIL/EVIL.OBJ",12,10,10);
		
		//rotationdirection.setX(-1);
		
		//obj =  new WavefrontObject("/Data/LVL2/FRA200F/FRA200F.OBJ");
		
		width = 175f;//1.5f;
		height = 100f;//6.8f;
		
		completeContructor();
		energyStart = 500;
		energyRemaining = energyStart;
		
		batteries[0] = new FireBattery(this,new Vertex(upperHeight,rightWidth/2,0));
		batteries[1] = new FireBattery(this,new Vertex(lowerHeight,rightWidth/2,0));
		
		
		hitHighLightTime = 0.02f;
	}
	
	public void render() {
		GL11.glTranslatef(position.getX(),position.getY(),position.getZ());
		GL11.glRotatef(rotation.getX(),1,0,0);
		GL11.glRotatef(rotation.getY(),0,1,0);
		GL11.glRotatef(rotation.getZ(),0,0,1);
		
		if (drawHighLighted)
			GL11.glTexEnvi(GL11.GL_TEXTURE_ENV, GL11.GL_TEXTURE_ENV_MODE, GL11.GL_ADD);
		if (polarity == BLUE)
			GL11.glColor4f(0.8f,0.8f,1f,1f);//GL11.glColor4f(0.2f,0.2f,0.4f,1f);
		else
			GL11.glColor4f(1f,0.80f,0.80f,1f);
		obj.render();
		
		if (drawHighLighted)
			GL11.glTexEnvi(GL11.GL_TEXTURE_ENV, GL11.GL_TEXTURE_ENV_MODE, GL11.GL_MODULATE);
		
		GL11.glColor4f(1,1,1,1);
		GL11.glDisable(GL11.GL_LIGHTING);
		GL11.glDisable(GL11.GL_DEPTH_TEST);
		GL11.glDisable(GL11.GL_TEXTURE_2D);
		drawEnergyBar();
		
		GL11.glEnable(GL11.GL_LIGHTING);
		GL11.glEnable(GL11.GL_DEPTH_TEST);
		GL11.glEnable(GL11.GL_TEXTURE_2D);
	}

	private void drawEnergyBar() {
		//GL11.glTranslatef(0,-30, 0);
		GL11.glLoadIdentity();
		GL11.glTranslatef(position.getX(),position.getY()+upperHeight*2/3,position.getZ());
		//GL11.glTranslatef(0,upperHeight/2,50);
		//GL11.glTranslatef(0,-100, 0);
		GL11.glColor4f(1,0,0,1);
		GL11.glBegin(GL11.GL_QUADS);
			GL11.glVertex2f(rightWidth,upperHeight+energyBarWidth);
			GL11.glVertex2f(rightWidth,upperHeight);
			GL11.glVertex2f(leftWidth,upperHeight);		
			GL11.glVertex2f(leftWidth, upperHeight+energyBarWidth);       
		GL11.glEnd();
		
		float percentageEnergyRemaining = energyRemaining/(float)energyStart * 2;
		
		GL11.glColor4f(0,1,0,1);
		GL11.glBegin(GL11.GL_QUADS);
			GL11.glVertex2f(percentageEnergyRemaining*rightWidth-rightWidth,upperHeight+energyBarWidth);
			GL11.glVertex2f(percentageEnergyRemaining*rightWidth-rightWidth,upperHeight);
			GL11.glVertex2f(leftWidth, upperHeight);		
			GL11.glVertex2f(leftWidth, upperHeight+energyBarWidth);       
		GL11.glEnd();
		
		GL11.glColor3f(1,1,1);
	}

	public void update()
	{
		super.update();
		
		if (energyRemaining <= 0)
		{
			PlasmaWave plasmaWave = new PlasmaWave(this,Engine.SCREEN_WIDTH/4); 
			Engine.explosions.addEntity(plasmaWave);
			
			Explosion explosion = new Explosion();
			explosion.position = new Vertex(this.position.getX()+upperHeight,position.getY(),position.getZ());
			Engine.explosions.addEntity(explosion);
			
			explosion.position = new Vertex(this.position.getX()+lowerHeight,position.getY(),position.getZ());
			Engine.explosions.addEntity(explosion);
			
			explosion.position = new Vertex(this.position.getX(),position.getY()+leftWidth,position.getZ());
			Engine.explosions.addEntity(explosion);
			
			explosion.position = new Vertex(this.position.getX(),position.getY()+rightWidth,position.getZ());
			Engine.explosions.addEntity(explosion);
			
			Level2.spawRandomEvil();
		}
		
		for (FireBattery battery : batteries)
			battery.update();
		
		if (drawHighLighted)
		{
			hitHighLightCounter -= Engine.timer.delta;
			if (hitHighLightCounter < 0)
				drawHighLighted = false;
		}
	}
	
	@Override
	public void collide(Entity remoteEntity, int remoteEnergy) 
	{
		super.collide(remoteEntity, remoteEnergy);
		drawHighLighted = true;
		hitHighLightCounter = hitHighLightTime;

	}
}
