package engine.entities;

import java.util.ArrayList;

import org.lwjgl.opengl.GL11;

import com.TextureLoader;
import com.Vertex;

import engine.Engine;

public class PlasmaWave extends TTLEntity {

	static final int CIRCLE_DIVISION = 32;
	
	static final ArrayList<Vertex> waveVectors = new ArrayList<Vertex>();
	static
	{
		Vertex up = new Vertex(0,1,0);
		for (int i=0;i<CIRCLE_DIVISION;i++)
		{
			waveVectors.add(new Vertex(up));
			up.rotateZ(2*Math.PI/CIRCLE_DIVISION);
		}
	}
	
	private ArrayList<WaveElement> wavePoints = new ArrayList<WaveElement>();
	
	static private int textureId = TextureLoader.instance().loadTexture("/Data/SPR/plasmaWave.png").getTextureID();
	
	private class WaveElement
	{
		public WaveElement(PlasmaWave wave)
		{
			this.innerPosition = new Vertex(wave.position);
			this.outerPosition = new Vertex(wave.position);
		}
		
		protected Vertex innerPosition;
		protected Vertex outerPosition;
	}
	
	public PlasmaWave(Entity masterEntity, float amplitude) 
	{
		this(masterEntity,amplitude,0,null);
	}
	
	Vertex color = null;
	
	public PlasmaWave(Entity masterEntity, float amplitude, float mouvementSpeed, Vertex color) 
	{
		this.color = color;
		
		if (mouvementSpeed == 0)
			this.mouvementSpeed = 1000 ;
		else
			this.mouvementSpeed = mouvementSpeed;
		
		this.position = new Vertex(masterEntity.position);
		this.polarity = masterEntity.polarity;
		energyRemaining = 1;
		TTL = 0.7f;
		
		for(int i=0; i < CIRCLE_DIVISION ; i ++)
			wavePoints.add(new WaveElement(this));
		
	}

	public void update()
	{
		timeCounter += Engine.timer.delta;
		if (timeCounter > TTL)
			this.toBeCleared = true;
		
		for(int i=0; i < waveVectors.size() ; i ++)
		{ 
			wavePoints.get(i).innerPosition.add(waveVectors.get(i).copyAndMult(Engine.timer.delta*mouvementSpeed));
			wavePoints.get(i).outerPosition.add(waveVectors.get(i).copyAndMult(Engine.timer.delta*mouvementSpeed*1.3f));
		}
	}
	
	public void render()
	{
		/*
		System.out.println("current.innerPosition(0): x="+wavePoints.get(0).innerPosition.getX()+" y="+wavePoints.get(0).innerPosition.getY());
		System.out.println("current.outerPosition(0): x="+wavePoints.get(0).outerPosition.getX()+" y="+wavePoints.get(0).outerPosition.getY());
		System.out.println("next.innerPosition(1): x="+wavePoints.get(1).innerPosition.getX()+" y="+wavePoints.get(1).innerPosition.getY());
		System.out.println("next.outerPosition(1): x="+wavePoints.get(1).outerPosition.getX()+" y="+wavePoints.get(1).outerPosition.getY());
		System.out.println();
		*/
		
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, textureId);
		for(int i=0; i < wavePoints.size()-1 ; i ++)
			drawElements(i,i+1);
		
		drawElements(wavePoints.size()-1,0);
	}

	private void drawElements(int i, int j) {
		
		WaveElement current = null;
		WaveElement next = null;
		
		current = wavePoints.get(i);
		next = wavePoints.get(j);
		
			float outerAlpha = timeCounter > TTL*2/3 ? 1-(timeCounter/TTL) : 1;
		
			GL11.glBegin(GL11.GL_QUADS);
		
			if (color == null)
				if (polarity == BLUE)
					GL11.glColor4f(0.1f,0.1f,0.5f,outerAlpha);
				else
					GL11.glColor4f(1,0.1f,0.1f,outerAlpha);
			else
				GL11.glColor4f(color.getX(),color.getY(),color.getZ(),outerAlpha);
			//System.out.println("TTL="+TTL+" timeCounter="+timeCounter);
			//System.out.println("1-TTL/timeCounter="+(1-(TTL/timeCounter)));
			
			GL11.glTexCoord2f(1,1); //Upper left			
			GL11.glVertex2f(current.outerPosition.getX(),current.outerPosition.getY());
			GL11.glTexCoord2f(1,1); //Upper right
			GL11.glVertex2f(next.outerPosition.getX(),next.outerPosition.getY());
			
			if (polarity == BLUE)
				GL11.glColor4f(0.1f,0.1f,0.5f,0);
			else
				GL11.glColor4f(1,0.1f,0.1f,0);
			GL11.glTexCoord2f(0,0); // Lower right
			GL11.glVertex2f(next.innerPosition.getX(),next.innerPosition.getY());
			GL11.glTexCoord2f(0,0); //Lower left
			GL11.glVertex2f(current.innerPosition.getX(),current.innerPosition.getY());
			
		GL11.glEnd();
		
	}
}
