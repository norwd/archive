package engine.entities;

import org.lwjgl.opengl.GL11;

import com.TextureLoader;
import com.Vertex;

import engine.Engine;

public class Spark extends Entity {

	int textureId = TextureLoader.instance().loadTexture("/Data/SPR/spark.png").getTextureID();
	
	float alpha= 1;
	
	float rotationSpeed1;
	float rotation1;
	
	float rotationSpeed2;
	float rotation2;

	float rotationSpeed3;
	float rotation3;

	
	public Spark()
	{
		rotationSpeed1 = -8;
		rotationSpeed2 = -8;
		rotationSpeed3 = -10;
	}
	
	float baseWidth = 5;
	float UpWidth = 10;
	
	float _height = 10;
	
	public void render()
	{
		GL11.glTranslatef(position.getX(),position.getY(),position.getZ());
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, textureId);	
		GL11.glColor4f(1,1,1,1f);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
		
		GL11.glPushMatrix();
			GL11.glRotatef(rotation1,0,0,1);
			for(int i=0 ; i< 1 ; i++)
			{
				draw();
				GL11.glRotatef(90,0,0, 1);
			}
		GL11.glPopMatrix();
		
		GL11.glPushMatrix();
			GL11.glRotatef(45,0,0, 1);
			GL11.glRotatef(rotation2,0,0,1);
			for(int i=0 ; i< 4 ; i++)
			{
				//draw();
				GL11.glRotatef(90,0,0, 1);
			}
		GL11.glPopMatrix();
			
		GL11.glPushMatrix();
		GL11.glRotatef(15,0,0, 1);
		GL11.glRotatef(rotation3,0,0,1);
		for(int i=0 ; i< 4 ; i++)
		{
			//draw();
			GL11.glRotatef(90,0,0, 1);
		}
		GL11.glPopMatrix();
			
			//draw();
			
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA,GL11.GL_ONE_MINUS_SRC_ALPHA);
	}
	
	private void draw() {
		
		GL11.glBegin(GL11.GL_QUADS);
			
				GL11.glColor4f(0.5f,0.5f,1f, alpha);
				
				GL11.glTexCoord2f(1,0); //Upper right
				GL11.glVertex3f(-UpWidth,_height,_height*4);    
				
				GL11.glTexCoord2f(1,1); // Lower right
				GL11.glVertex3f(-baseWidth,0,0);
				
				GL11.glColor4f(1,1,1, 0);//alpha/2);
				
				GL11.glTexCoord2f(0,1); //Lower left	
				GL11.glVertex3f(0,0,0);
				
				GL11.glTexCoord2f(0,0); //Upper left
				GL11.glVertex3f(0,_height,_height*4);
			
		GL11.glEnd();	
		
		GL11.glBegin(GL11.GL_QUADS);
			
			GL11.glColor4f(0.5f,0.5f,1f, alpha);
			GL11.glTexCoord2f(0.5f,1); //Lower left	
			GL11.glVertex3f(baseWidth,0,0);
			
			GL11.glTexCoord2f(0.5f,0); //Upper left
			GL11.glVertex3f(UpWidth,_height,_height*4);
			
			
			GL11.glColor4f(1,1,1, 0);//alpha/2);
			GL11.glTexCoord2f(0,0); //Upper right
			GL11.glVertex3f(0,_height,_height*4);    
			
			GL11.glTexCoord2f(0,1); // Lower right
			GL11.glVertex3f(0,0,0);
	 
		GL11.glEnd();
		
	}

	public void update()
	{
		rotation1 += Engine.timer.delta * rotationSpeed1;
		//rotation1 %= 360;
		rotation2 += Engine.timer.delta * rotationSpeed2;
		//rotation2 %= 360;
		rotation3 += Engine.timer.delta * rotationSpeed3;
		//rotation3 %= 360;
	}
}
