package engine.entities;

import org.lwjgl.opengl.GL11;

import com.obj.WavefrontObject;

import engine.ObjLibrary;

public class Frame extends Entity {

	public WavefrontObject obj = null;
	
	public Frame(int model)
	{
		obj =  ObjLibrary.instance().getObj(model);
		//position.setZ(-20);
		//rotation.setX(90);
		//rotationdirection.setZ(-1);
		//rotationdirection.setX(-1);
		//rotationSpeed= 100;
		//obj =  new WavefrontObject("/Data/LVL2/FRA200F/FRA200F.OBJ");
		
		//width = 30f;//1.5f;
		//height = 15f;//6.8f;
		
		//completeContructor();
	}
	
	public void render() {
		//GL11.glTranslatef(position.getX(),position.getY(),position.getZ());
		//GL11.glRotatef(rotation.getX(),1,0,0);
		//GL11.glRotatef(rotation.getY(),0,1,0);
		//GL11.glRotatef(rotation.getZ(),0,0,1);
		obj.render();
	}
}
