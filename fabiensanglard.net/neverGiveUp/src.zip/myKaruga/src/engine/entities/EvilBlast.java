package engine.entities;

import org.lwjgl.opengl.GL11;

import com.TextureLoader;

import engine.Engine;

public class EvilBlast extends TTLEntity {

	static private int textureId = TextureLoader.instance().loadTexture("/Data/SPR/devilBlast.png").getTextureID();
	private float timeCounter;
	
	public EvilBlast()
	{
		this.mouvementSpeed = 400;
		width = 20f;//1.5f;
		height = width*3;//6.8f;
		toBeCleared = false;
		completeContructor();
		
		energyRemaining= 1;
		TTL = 3;
	}
	
	@Override
	public void render() 
	{
		GL11.glTranslatef(position.getX(),position.getY(),position.getZ());
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, textureId);
		
		
		GL11.glRotatef(rotation.getZ(),0,0,1);
		
		if (polarity == BLUE)
			GL11.glColor4f(0.1f,0.1f,0.8f,1);
		else
			GL11.glColor4f(0.8f,0.1f,0.1f,1);
		
		//GL11.glRotatef(180,1,0,0);
		GL11.glBegin(GL11.GL_QUADS);
			GL11.glTexCoord2f(1,1); //Upper right
			GL11.glVertex2f(rightWidth,upperHeight);
		
			GL11.glTexCoord2f(1,0); // Lower right
			GL11.glVertex2f(rightWidth,lowerHeight);
			
			GL11.glTexCoord2f(0,0); //Lower left
			GL11.glVertex2f(leftWidth,lowerHeight);
			
			
			GL11.glTexCoord2f(0,1); //Upper left			
			GL11.glVertex2f(leftWidth, upperHeight);        
		GL11.glEnd();
	}

	@Override
	public void collide(Entity remoteEntity, int remoteEnergy) {
		super.collide(remoteEntity, remoteEnergy);
		
		if (energyRemaining <=0)
		{
			Impact plasmaWave = new Impact(this,Engine.SCREEN_WIDTH/4,120,true,0.55f); 
			Engine.plasmaExplositions.addEntity(plasmaWave);
		}
	}
	
	
	
}
