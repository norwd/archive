package engine.entities;

import java.util.ArrayList;
import java.util.Random;

import org.lwjgl.opengl.GL11;

import com.Texture;
import com.TextureLoader;
import com.Vertex;

import engine.Engine;

public class Flash extends Entity {

	static ArrayList<Texture> textures = new ArrayList<Texture>();
	static
	{
		//textures.add(TextureLoader.instance().loadTexture("/Data/SPR/Flash1.png"));
		//textures.add(TextureLoader.instance().loadTexture("/Data/SPR/Flash2.png"));
		//textures.add(TextureLoader.instance().loadTexture("/Data/SPR/Flash3.png"));
		textures.add(TextureLoader.instance().loadTexture("/Data/SPR/Flash4.png"));
		textures.add(TextureLoader.instance().loadTexture("/Data/SPR/Flash5.png"));
		textures.add(TextureLoader.instance().loadTexture("/Data/SPR/Flash6.png"));
		textures.add(TextureLoader.instance().loadTexture("/Data/SPR/Flash7.png"));
		textures.add(TextureLoader.instance().loadTexture("/Data/SPR/Flash8.png"));
	}
	
	private int type = 0;
	
	static Random random = new Random(System.currentTimeMillis());
	
	private int textureId = 0;
	private float timeCounter;
	private float timeToLive = 0.1f;//0.0250f;

	public float offsetX;

	public float offsetY;
	
	
	public Flash(Player player)
	{
		type = random.nextInt(5);
		
		
		this.position = player.position;
		
		textureId = textures.get(type).getTextureID();
		timeCounter = 0;
		//mouvementdirection = new Vertex(0,1,0);
		
		width = 50f;//1.5f;
		height = width*2f;//6.8f;
		
		completeContructor();
		int leftRight = random.nextInt(2);
		if (leftRight == 0)
		{
			rightWidth = - rightWidth;
			leftWidth = - leftWidth;
			
		}
		energyStart = 1;
		energyRemaining = energyStart;
		
	}
	
	public void update()
	{
		super.update();
		timeCounter += Engine.timer.delta;
		
		//upperHeight=height/2*(1/timeCounter/timeToLive);
		
		if (timeCounter > timeToLive)
			this.toBeCleared = true;
	}
	
	@Override
	public void render() 
	{
		GL11.glTranslatef(position.getX()+offsetX,position.getY()+offsetY,position.getZ()-200);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, textureId);
		if (polarity == BLUE)
			GL11.glColor4f(0.1f,0.1f,0.5f,1);
		else
			GL11.glColor4f(1,0.1f,0.1f,1);
		
		GL11.glRotatef(180,1,0,0);
		
		lowerHeight = upperHeight + ((-height/2)*timeCounter/timeToLive*2);
		super.render();
		
	}
}
