package engine.entities;

import org.lwjgl.opengl.GL11;

import com.Vertex;
import com.obj.WavefrontObject;

import engine.Engine;
import engine.ObjLibrary;

public class HeartBossshield extends Entity {

	private HeartBoss heartBoss;
	
	boolean isLeftSide ;
	
	WavefrontObject obj = null;
	
	public HeartBossshield(HeartBoss heartBoss, boolean isLeftSide) {
		this.heartBoss = heartBoss;
		width = 70f;
		height = 28f;
		
		completeContructor();
		energyStart = 200000;
		energyRemaining = energyStart;
		this.isLeftSide = isLeftSide;
		
		this.position = new Vertex(heartBoss.position);
		
		if (isLeftSide)
		{
			this.position.setX(this.position.getX() -HeartBoss.heartXOffset);
			obj = 	ObjLibrary.instance().getObj(ObjLibrary.BOSS_SHIELD_L);
			this.position.setY(this.position.getY()-HeartBoss.heartYMin);
		}
		else
		{
			this.position.setX(this.position.getX() +HeartBoss.heartXOffset);
			obj = 	ObjLibrary.instance().getObj(ObjLibrary.BOSS_SHIELD_R);
			this.position.setY(this.position.getY()-HeartBoss.heartYMin);
		}
		
		
	}
	
	public void render()
	{
		GL11.glTranslatef(position.getX(),position.getY(),position.getZ());
		GL11.glRotatef(90,1, 0,0);
		obj.render();
	}
	
	static final int UP =0;
	static final int DOWN =1;
	static final int NONE =2;
	int movingDirection = DOWN;
	float waitCounter = 0;
	protected boolean mouvementActivated = false;
	
	public void update()
	{
		if (!mouvementActivated)
			return;
		
		if (-(heartBoss.position.getY()-position.getY()) < -HeartBoss.heartYMax)
		{
			if (movingDirection != UP)
			{
				movingDirection = NONE;
				waitCounter+=Engine.timer.delta;
				if (waitCounter > 4)
				{
					movingDirection= UP;
					waitCounter = 0;
				}
			}
		}
		
		if ((heartBoss.position.getY()-position.getY()) > -HeartBoss.heartYMin)
		{
			if (movingDirection != DOWN)
			{
				movingDirection = NONE;
				waitCounter+=Engine.timer.delta;
				if (waitCounter > 3)
				{
					movingDirection= DOWN;
					waitCounter = 0;
				}
			}
		}
		
		if (movingDirection==DOWN)
		{
			position.setY(position.getY()- 50 * Engine.timer.delta);
		}
		if (movingDirection==UP)
		{
			position.setY(position.getY()+ 200 * Engine.timer.delta);
		}
	}

}
