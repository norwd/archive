package engine.entities;

import com.Vertex;

public class WaveElement
{
	public WaveElement(float offsetX, float offsetY)
	{
		this.innerPosition = new Vertex( offsetX,offsetY,0);//wave.position);
		this.outerPosition = new Vertex();//wave.position);
	}
	
	protected Vertex innerPosition;
	protected Vertex outerPosition;
}
