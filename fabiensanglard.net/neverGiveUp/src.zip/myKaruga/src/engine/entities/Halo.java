package engine.entities;

import java.util.ArrayList;

import org.lwjgl.opengl.GL11;

import com.Texture;
import com.TextureLoader;
import com.Vertex;

import engine.Engine;

public class Halo extends TTLEntity {

	static private int textureId = TextureLoader.instance().loadTexture("/Data/SPR/Halo.png").getTextureID();
	
	private Player player;
	
	public float expansionSpeed = 180;
	float size =0;
	float SIZE_MAX =40;
	
	boolean disposing = false;
	
	static final int CIRCLE_DIVISION = 32;
	static final ArrayList<Vertex> waveVectors = new ArrayList<Vertex>();
	static
	{
		Vertex up = new Vertex(0,1,0);
		for (int i=0;i<CIRCLE_DIVISION;i++)
		{
			waveVectors.add(new Vertex(up));
			up.rotateZ(2*Math.PI/CIRCLE_DIVISION);
		}
	}
	
	private ArrayList<WaveElement> wavePoints = new ArrayList<WaveElement>();

	
	public Halo(Player player)
	{
		this.player = player;
		width = 80.5f;
		height = 80.5f;
		completeContructor();
		
		for(int i=0; i < CIRCLE_DIVISION ; i ++)
			wavePoints.add(new WaveElement(0f,0f));
		
		this.polarity = player.polarity;
		
		TTL=0.5f;
		timeCounter = 0;
	}
	
	
	
	
	public void render()
	{
		GL11.glTranslatef(position.getX(),position.getY(),-100);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, textureId);
		for(int i=0; i < wavePoints.size()-1 ; i ++)
			drawElements(i,i+1);
		
		drawElements(wavePoints.size()-1,0);
	}

	private void drawElements(int i, int j) {
		
		WaveElement current = null;
		WaveElement next = null;
		
		current = wavePoints.get(i);
		next = wavePoints.get(j);
		
			float outerAlpha =  1-(timeCounter/TTL) ;
		
			GL11.glBegin(GL11.GL_QUADS);
		
			
			if (polarity == BLUE)
				GL11.glColor4f(0.1f,0.1f,0.5f,1);
			else
				GL11.glColor4f(1,0.1f,0.1f,1);
			
			GL11.glTexCoord2f(1,1); //Upper left			
			GL11.glVertex2f(current.outerPosition.getX(),current.outerPosition.getY());
			GL11.glTexCoord2f(1,0); //Upper right
			GL11.glVertex2f(next.outerPosition.getX(),next.outerPosition.getY());
			
			if (polarity == BLUE)
				GL11.glColor4f(0.1f,0.1f,0.5f,outerAlpha);
			else
				GL11.glColor4f(1,0.1f,0.1f,outerAlpha);
			
			
			GL11.glTexCoord2f(0,0); // Lower right
			GL11.glVertex2f(next.innerPosition.getX(),next.innerPosition.getY());
			GL11.glTexCoord2f(0,1); //Lower left
			GL11.glVertex2f(current.innerPosition.getX(),current.innerPosition.getY());
			
		GL11.glEnd();
		
	}

	public float innerExpansionSpeedFactor = 0;
	public void update()
	{
		if (size >= SIZE_MAX && !disposing)
			return;
		
		if (disposing)
		{
			timeCounter += Engine.timer.delta;
			if (timeCounter > TTL)
				this.toBeCleared = true;
		}
		for(int i=0; i < waveVectors.size() ; i ++)
		{ 
			wavePoints.get(i).innerPosition.add(waveVectors.get(i).copyAndMult(Engine.timer.delta*expansionSpeed*innerExpansionSpeedFactor));
			wavePoints.get(i).outerPosition.add(waveVectors.get(i).copyAndMult(Engine.timer.delta*expansionSpeed));
		}
		calculateSize();
	}
	
	private void calculateSize() {
		
		WaveElement waveElem = wavePoints.get(0);
		Vertex outerSide = waveElem.outerPosition;
		
		size = (float) Math.sqrt(Math.pow(outerSide.getX(),2)+Math.pow(outerSide.getY(),2));
		
	}




	public void dispose()
	{
		this.disposing =true;
	}
}
