package engine.entities;

import org.lwjgl.opengl.GL11;

import com.Vertex;
import com.obj.WavefrontObject;

import engine.ObjLibrary;

public class HeartBossArms extends Entity
{
	public WavefrontObject arm = null;
	public WavefrontObject shoulder = null;
	
	float join0 = 0;
	float piston0 = 0;
	float join1 = 0;
	float piston1 = 0;
	float join2 = 0;
	
	boolean isLeft = true;
	
	public HeartBossArms(HeartBoss boss , boolean isLeft)
	{
		this.isLeft = isLeft;
		if (isLeft)
		{
			arm = ObjLibrary.instance().getObj(ObjLibrary.BOSS_ARM_L);		
			shoulder = ObjLibrary.instance().getObj(ObjLibrary.BOSS_ARM_SHOULDER_L);
		}
		else
		{
			arm = ObjLibrary.instance().getObj(ObjLibrary.BOSS_ARM_R);
			shoulder =  ObjLibrary.instance().getObj(ObjLibrary.BOSS_ARM_SHOULDER_R);
		}
		this.position = boss.position;
		
		for (int i=0; i< batteryL.length ; i++)
		{
			Vertex offSet = new Vertex(i*10,i*10);
			batteryL[i] = new FireBattery(boss,offSet);
			
			offSet = new Vertex(-i*10,-i*10);
			batteryR[i] = new FireBattery(boss,offSet);
		}
		
		
		
	}
	
	public void render()
	{
		
		//GL11.glTranslatef(position.getX(),position.getY(),0);
		GL11.glRotatef(isLeft ? join0 : -join0, 0, 0, 1);
		GL11.glTranslatef(isLeft ? piston0 : -piston0,0,0);
		GL11.glRotatef(isLeft ? join1 : -join1, 0, 0, 1);
		//
		GL11.glRotatef(-270,1,0,0);
		shoulder.render();
		GL11.glRotatef(270,1,0,0);
		GL11.glTranslatef(isLeft ? piston1 : -piston1,0,0);
		GL11.glRotatef(isLeft ? join2 : -join2, 0, 0, 1);
		
		GL11.glRotatef(-270,1,0,0);
		arm.render();
		GL11.glRotatef(270,1,0,0);
		
		
		
	}
	private static FireBattery[] batteryL = new FireBattery[6];
	private static FireBattery[] batteryR = new FireBattery[6];
	
	
	public void update()
	{
		if (isLeft)
			for (FireBattery battery : batteryL)
				battery.update();
		else
			for (FireBattery battery : batteryR)
				battery.update();
	}
	
	private static final float FIRE_FREQUENCY = 1; 
	private static final Vertex[] firingPositionL = null;
	private static final Vertex[] firingPositionR = null;
	

	public void fire()
	{
		
	}
}
