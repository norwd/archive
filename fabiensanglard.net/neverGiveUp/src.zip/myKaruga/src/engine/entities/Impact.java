package engine.entities;

import java.util.ArrayList;
import java.util.Random;

import org.lwjgl.opengl.GL11;

import com.TextureLoader;
import com.Vertex;

import engine.Engine;

public class Impact extends TTLEntity {

	static final int CIRCLE_DIVISION = 32;
	
	static Random randon = new Random(System.currentTimeMillis());
	
	
	static final ArrayList<Vertex> waveVectors = new ArrayList<Vertex>();
	static
	{
		Vertex up = new Vertex(0,1,0);
		for (int i=0;i<CIRCLE_DIVISION;i++)
		{
			waveVectors.add(new Vertex(up));
			up.rotateZ(2*Math.PI/CIRCLE_DIVISION);
		}
	}
	
	private ArrayList<WaveElement> wavePoints = new ArrayList<WaveElement>();
	
	static private int textureId = TextureLoader.instance().loadTexture("/Data/SPR/impact.png").getTextureID();
	
	float expansionSpeed = 80;
	
	private static Random random = new Random(System.currentTimeMillis());
	
	public Impact(Entity masterEntity, float amplitude) 
	{
		this(masterEntity,amplitude,500);
	}
	public Impact(Entity masterEntity, float amplitude, float expansionSpeed ) 
	{
		this(masterEntity,amplitude,expansionSpeed,false,0.35f);
		
	}
	
	float offsetX;
	float offsetY;
	

	public Impact(Entity masterEntity, float amplitude, float expansionSpeed, boolean stayStill, float ttl) 
	{
		// In order to make the impact sexy, the center of the inner circle is excentred:
		offsetX = randon.nextBoolean() ? randon.nextInt(10)+1 : -(randon.nextInt(10)+1);
		offsetY = randon.nextBoolean() ? randon.nextInt(10)+1 : -(randon.nextInt(10)+1);
		
		this.rotationSpeed = 0;//900;
		this.rotationdirection = new Vertex(0,0,1);
		this.expansionSpeed = expansionSpeed;
		
		
		
	
		//this.mouvementdirection.rotateZ(Math.toRadians(randomTwik));
		
		if (stayStill)
			this.mouvementSpeed = 0;
		else
		{
			expansionSpeed = expansionSpeed/1000;
			this.mouvementSpeed = masterEntity.mouvementSpeed/20;
			this.mouvementdirection = new Vertex(masterEntity.mouvementdirection);
			
			float randomTwik = random.nextFloat() * 5;
			if (random.nextBoolean())
				randomTwik = -randomTwik;
		}
		
		this.position = new Vertex(masterEntity.position);
		this.polarity = masterEntity.polarity;
		energyRemaining = 1;
		TTL = ttl ;
		
		for(int i=0; i < CIRCLE_DIVISION ; i ++)
			wavePoints.add(new WaveElement(offsetX,offsetY));
		
	}

	public void update()
	{
		this.position.setX(this.position.getX() +  this.mouvementdirection.getX() * Engine.timer.delta * mouvementSpeed);
		this.position.setY(this.position.getY() + this.mouvementdirection.getY() * Engine.timer.delta * mouvementSpeed);
		
		this.rotation.setZ(this.rotation.getZ() +  this.rotationdirection.getZ() * Engine.timer.delta * rotationSpeed);
		
		timeCounter += Engine.timer.delta;
		if (timeCounter > TTL)
			this.toBeCleared = true;
		
		for(int i=0; i < waveVectors.size() ; i ++)
		{ 
			wavePoints.get(i).innerPosition.add(waveVectors.get(i).copyAndMult(Engine.timer.delta*expansionSpeed*1/2));
			wavePoints.get(i).outerPosition.add(waveVectors.get(i).copyAndMult(Engine.timer.delta*expansionSpeed));
		}
	}
	
	public void render()
	{
		GL11.glLoadIdentity();
		GL11.glTranslatef(position.getX(),position.getY(),position.getZ());
		GL11.glRotatef(rotation.getZ(),0,0,1);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, textureId);
		for(int i=0; i < wavePoints.size()-1 ; i ++)
			drawElements(i,i+1);
		
		drawElements(wavePoints.size()-1,0);
	}

	private void drawElements(int i, int j) {
		
		WaveElement current = null;
		WaveElement next = null;
		
		current = wavePoints.get(i);
		next = wavePoints.get(j);
		
			float outerAlpha = timeCounter > TTL*3/4 ? 1-(timeCounter/TTL) : 1;
		
			GL11.glBegin(GL11.GL_QUADS);
		
			if (polarity == BLUE)
				GL11.glColor4f(0.1f,0.1f,0.5f,outerAlpha);
			else
				GL11.glColor4f(1,0.1f,0.1f,outerAlpha);
			
			//System.out.println("TTL="+TTL+" timeCounter="+timeCounter);
			//System.out.println("1-TTL/timeCounter="+(1-(TTL/timeCounter)));
			
			GL11.glTexCoord2f(0,0); //Upper left			
			GL11.glVertex2f(current.outerPosition.getX(),current.outerPosition.getY());
			GL11.glTexCoord2f(0,0); //Upper right
			GL11.glVertex2f(next.outerPosition.getX(),next.outerPosition.getY());
			
			if (polarity == BLUE)
				GL11.glColor4f(0.1f,0.1f,0.5f,0);
			else
				GL11.glColor4f(1,0.1f,0.1f,0);
			
			GL11.glTexCoord2f(0,0); // Lower right
			GL11.glVertex2f(next.innerPosition.getX(),next.innerPosition.getY());
			GL11.glTexCoord2f(0,0); //Lower left
			GL11.glVertex2f(current.innerPosition.getX(),current.innerPosition.getY());
			
		GL11.glEnd();
		
	}
}
