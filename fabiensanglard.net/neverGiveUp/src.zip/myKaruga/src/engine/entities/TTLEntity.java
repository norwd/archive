package engine.entities;

import engine.Engine;

public class TTLEntity extends Entity {
	protected float timeCounter=0;
	protected float TTL;
	
	public void update()
	{
		super.update();
		timeCounter += Engine.timer.delta;
		if (timeCounter > TTL)
			this.toBeCleared = true;
	}
}
