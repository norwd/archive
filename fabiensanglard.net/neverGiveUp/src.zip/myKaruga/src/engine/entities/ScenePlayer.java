package engine.entities;

import org.lwjgl.opengl.GL11;

import engine.Engine;
import engine.ObjLibrary;

public class ScenePlayer extends Player {

	public boolean doNotRender = false;

	public ScenePlayer()
	{
		obj = ObjLibrary.instance().getObj(ObjLibrary.VANILLA_PLAYER);
	}
	
	public void update()
	{
		this.position.setX(this.position.getX() +  this.mouvementdirection.getX() * Engine.timer.delta * mouvementSpeed);
		this.position.setY(this.position.getY() + this.mouvementdirection.getY() * Engine.timer.delta * mouvementSpeed);
		this.position.setZ(this.position.getZ() + this.mouvementdirection.getZ() * Engine.timer.delta * mouvementSpeed);
		
		this.rotation.setX(this.rotation.getX() +  this.rotationdirection.getX() * Engine.timer.delta * rotationSpeed);
		this.rotation.setY(this.rotation.getY() +  this.rotationdirection.getY() * Engine.timer.delta * rotationSpeed);
		this.rotation.setZ(this.rotation.getZ() +  this.rotationdirection.getZ() * Engine.timer.delta * rotationSpeed);

	}
	
	public void render()
	{
		if (doNotRender)
			return;
		
			GL11.glTranslatef(position.getX(),position.getY(),position.getZ());
			GL11.glRotatef(180,0,1,0);
			//GL11.glRotatef(rotation.getY()+180,0,1,0);
			//GL11.glRotatef(rotation.getX(),1,0,0);
			
			GL11.glRotatef(rotation.getZ(),0,0,1);
			obj.render();
	}
}
