package engine.entities;

import java.util.Random;

import org.lwjgl.opengl.GL11;

import com.TextureLoader;
import com.Vertex;

import engine.Engine;

public class GenericEnemyBullet extends TTLEntity {

	static private int textureId = TextureLoader.instance().loadTexture("/Data/SPR/GenericEnemyBullet.png").getTextureID();
	float timeToDisplay = 0f;
	
	public GenericEnemyBullet()
	{
		this.energyRemaining = 1;
		this.TTL = 4;
		this.width = 20;
		this.height = 20;
		completeContructor();
		this.mouvementSpeed = 40;
		timeToDisplay = TTL/10*9;
	}
	
	static final Random random = new Random(System.currentTimeMillis());
	public static GenericEnemyBullet[] getBucket(Entity mother, int reqUnitNumber)
	{
		GenericEnemyBullet[] bullets = new GenericEnemyBullet[reqUnitNumber];
		
		GenericEnemyBullet enemy = null;
		float fudgeFactor = 0;
		
		for (int i=0; i< reqUnitNumber ;i++)
		{
			fudgeFactor = random.nextFloat() * 2;
			if (random.nextBoolean())
				fudgeFactor *= -1;
			
			enemy = new GenericEnemyBullet();
			enemy.position = new Vertex(mother.position);
			enemy.position.setX(enemy.position.getX() + random.nextFloat() * enemy.rightWidth * 2 + enemy.leftWidth);
			enemy.position.setY(enemy.position.getY() + random.nextFloat() * enemy.upperHeight * 2 + enemy.lowerHeight);
			enemy.polarity = mother.polarity;
			enemy.mouvementdirection = new Vertex(mother.mouvementdirection);
			enemy.mouvementdirection.rotateZ(fudgeFactor);
			bullets[i] = enemy;
		}
		
		return bullets;
	}
	
	float alpha=1;
	public void render()
	{
		if (timeCounter < timeToDisplay )
			alpha=1;
		else
			alpha = (TTL - timeCounter) / (TTL -  timeToDisplay);
		
		
		if (polarity == BLUE)
			GL11.glColor4f(0.1f,0.1f,0.5f,alpha);
		else
			GL11.glColor4f(1,0.1f,0.1f,alpha);
		GL11.glTranslatef(position.getX(),position.getY(),position.getZ());
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, textureId);
		super.render();
		GL11.glColor4f(1,1f,1f,1);
	}

	@Override
	public void collide(Entity remoteEntity, int remoteEnergy) {
		super.collide(remoteEntity, remoteEnergy);
		if (energyRemaining <=0)
		{
			Impact plasmaWave = new Impact(this,Engine.SCREEN_WIDTH/4,50,true,0.35f); 
			plasmaWave.position.setY(this.position.getY()+upperHeight);
			Engine.plasmaExplositions.addEntity(plasmaWave);
		}
		
	}
	
	
}
