package engine.entities.action;

import engine.Engine;
import engine.level.Level3;

public class RotateJoin2 extends Action {

	private float angle;
	private float speed;
	
	public RotateJoin2(int angle, int speed) {
		this.angle = angle;
		this.speed = speed;
	}

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub

	}

	@Override
	public void update() {
		if (Level3.boss.join2 >= angle)
		{
			Level3.boss.join2 -= Engine.timer.delta * speed;
			Level3.boss.rotateArmJoin2(Level3.boss.join2);
		}
		else
		{
			done=true;
			activateNext();
		}
	}

}
