package engine.entities.action;

import com.Vertex;

import engine.Engine;
import engine.entities.HeartBoss;

public class RotateLegZ extends Action {

	private HeartBoss boss = null;
	private Vertex legLRotation = null;
	private Vertex legRRotation = null;
	
	private float rotation = 0f;
	
	public RotateLegZ(HeartBoss boss, int rotation) {
		this.boss = boss;
		legLRotation = boss.legLRotation;
		legRRotation = boss.legRRotation;
		this.rotation=rotation;
	}

	@Override
	public void update() {
		if (legLRotation.getZ() < rotation)
		{
			legLRotation.setZ(legLRotation.getZ() + Engine.timer.delta * boss.legRotationSpeed/2);
			legRRotation.setZ(legRRotation.getZ() - Engine.timer.delta * boss.legRotationSpeed/2);
		}
		else
		{
			done=true;
			activateNext();
		}

	}

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub
		
	}

}
