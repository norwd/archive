package engine.entities.action;

import engine.Engine;
import engine.level.Level3;

public class MovePiston1 extends Action{

	
	
	private float angle;
	private float speed;
	
	public MovePiston1(int angle, int speed) {
		this.angle = angle;
		this.speed = speed;
	}

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update() {
		if (Level3.boss.piston1  > angle)
		{
			Level3.boss.piston1 -= Engine.timer.delta * speed;
			Level3.boss.extendPiston1(Level3.boss.piston1);
			
		}
		else
		{
			done=true;
			activateNext();
		}
	}

}
