package engine.entities.action;

import java.util.ArrayList;
import java.util.Iterator;

import engine.entities.HeartBoss;

public class ActionSet {

	ArrayList<Action> actions = new ArrayList<Action>();

	public void addAction(Action action)
	{
		action.setActionSet(this);
		actions.add(action);
		action.onAdded();
	}
	
	public void activateNext(Action action) 
	{
		Action currentAction = null;
		Action nextAction = null;
		for (Iterator acIt = actions.iterator(); acIt.hasNext() && nextAction == null ;)
		{
			currentAction = (Action) acIt.next();
			if (currentAction == action && acIt.hasNext() )
			{
				nextAction = (Action) acIt.next();
				break;
			}
		}
		
		if (nextAction != null)
			nextAction.activate();
		
	}
	
	
	public void update()
	{
		Action action = null;
		for (Iterator<Action> acIt = actions.iterator(); acIt.hasNext();)
		{
			action = acIt.next();
			
			if (action.isDone())
				acIt.remove();
			
			if (action.isActive())
			{
				//System.out.println("Updating"+action.getClass().getName());
				action.update();
			}
		}
	}

	public void start() {
		
		if (actions.size() > 0)
			actions.get(0).activate();
		
	}
	
}
