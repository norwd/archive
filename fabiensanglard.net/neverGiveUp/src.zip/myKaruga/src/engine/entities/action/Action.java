package engine.entities.action;

public abstract class Action {

	
	boolean active=false;
	protected boolean done=false;
	
	
	ActionSet actions = null;
	
	public void setActionSet(ActionSet actions)
	{
		this.actions =actions;
	}
	
	public abstract void update();
	public abstract void onAdded();
	
	public void activateNext()
	{
		actions.activateNext(this);
	}
	
	public boolean isActive() {
		return active;
	}

	public void activate() {
		this.active = true;
		onActivated();
	}

	public boolean isDone() {
		return done;
	}
	
	public void onActivated(){}
}
