package engine.entities.action;

import engine.Engine;
import engine.entities.action.Action;
import engine.level.Level3;

public class RotateJoin0 extends Action {

	private float angle;
	private float speed;
	
	public RotateJoin0(int angle, int speed) {
		this.angle = angle;
		this.speed = speed;
	}

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub

	}

	@Override
	public void update() {
		if (Level3.boss.join0 < angle)
		{
			Level3.boss.join0 += Engine.timer.delta * speed;
			Level3.boss.rotateArmJoin0(Level3.boss.join0);
			
			if (Level3.boss.join0 < 0)
				activateNext();
		}
		else
		{
			done=true;
		}

	}

}
