package engine.entities.action;

import com.Vertex;

import engine.Engine;
import engine.entities.HeartBoss;

public class RotateLegX extends Action {

	private HeartBoss boss = null;
	private Vertex legLRotation = null;
	private Vertex legRRotation = null;
	
	private float rotation = 0f;
	
	public RotateLegX(HeartBoss boss, int rotation) {
		this.boss = boss;
		legLRotation = boss.legLRotation;
		legRRotation = boss.legRRotation;
		this.rotation = rotation;
	}

	

	@Override
	public void update() {
		if (legRRotation.getY() < rotation)
		{
			legLRotation.setY(legLRotation.getY() - Engine.timer.delta * boss.legRotationSpeed);
			legRRotation.setY(legRRotation.getY() + Engine.timer.delta * boss.legRotationSpeed);
		}
		else
		{
			done=true;
			activateNext();
		}
	}



	@Override
	public void onAdded() {
		// TODO Auto-generated method stub
		
	}

}
