package engine.entities.action;

import engine.entities.HeartBoss;

public class StartHeartsMouvements extends Action {

	public StartHeartsMouvements(HeartBoss heartBoss) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub

	}

	@Override
	public void update() {
		done=true;
		activateNext();

	}

}
