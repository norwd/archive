package engine.entities.action;

import engine.entities.HeartBoss;

public class ShowWeakPoints extends Action {

	public ShowWeakPoints(HeartBoss heartBoss, int i) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub

	}

	@Override
	public void update() {
		done=true;
		activateNext();

	}

}
