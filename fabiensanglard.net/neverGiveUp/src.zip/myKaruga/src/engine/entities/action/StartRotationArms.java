package engine.entities.action;

import engine.Engine;
import engine.level.Level3;

public class StartRotationArms extends Action {

	public StartRotationArms(int i) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub

	}

	@Override
	public void update() {
		Level3.boss.join2 += 300 * Engine.timer.delta;
		Level3.boss.rotateArmJoin2(Level3.boss.join2);

	}

}
