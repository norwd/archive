package engine.entities.action;

import com.Vertex;

import engine.Engine;
import engine.entities.Entity;


public class MoveTo extends Action {

	private Vertex target =null;
	private Entity entity = null;
	
	public MoveTo(Entity entity,Vertex vertex) {
		super();
		this.target = vertex;
		this.entity =entity;
	}

	
	
	boolean nextStarted = false;
	@Override
	public void update() {
		
		if (!nextStarted && entity.position.getY() > Engine.SCREEN_HEIGHT/3)
			activateNext();
		
		//System.out.println("entity.position.getY() > Engine.SCREEN_HEIGHT/5="+entity.position.getY() + " " +  Engine.SCREEN_HEIGHT/5);
		if (entity.position.getY() > Engine.SCREEN_HEIGHT/5)
		{
			entity.mouvementSpeed = 0;
			activateNext();
			this.done = true;
		}
		
		
	}




	@Override
	public void onAdded() {
		entity.mouvementdirection = new Vertex(0,1f,0);
		entity.mouvementSpeed = 70;
		
	}

}
