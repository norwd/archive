package engine.entities.action;

import engine.Engine;
import engine.entities.Entity;
import engine.entities.action.Action;

public class Wait extends Action {

	
	private float ttw=0f;
	
	public Wait(int ttw) {
		this.ttw = ttw;
	}

	@Override
	public void update() {
		ttw -= Engine.timer.delta;
		
		if (ttw <=0)
		{
			done=true;
			activateNext();
		}

	}

	@Override
	public void onAdded() {
		// TODO Auto-generated method stub
		
	}

}
