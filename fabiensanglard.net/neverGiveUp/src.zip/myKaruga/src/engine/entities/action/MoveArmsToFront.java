package engine.entities.action;

import engine.Engine;
import engine.entities.HeartBoss;
import engine.level.Level3;

public class MoveArmsToFront extends Action {

	HeartBoss boss = null;
	float targetPiston = 0f;
	
	public MoveArmsToFront(HeartBoss boss, int i) {
		this.boss = boss;
		targetPiston =  boss.piston0 + boss.piston0/40f;
	}

	@Override
	public void onAdded() {

	}

	@Override
	public void update() 
	{
			if (boss.piston1  >= -150)
			{
				boss.piston1 -= Engine.timer.delta * 100;
				boss.extendPiston1(boss.piston1);
				
				if (Level3.boss.join2 >= 10)
				{
					Level3.boss.join2 -= Engine.timer.delta * 70;
					Level3.boss.rotateArmJoin2(Level3.boss.join2);
				}
			}
			else
			{
				done=true;
				activateNext();
			}
	}

}
