package engine.entities;

import java.util.ArrayList;
import com.Texture;
import com.TextureLoader;
import com.Vertex;

import engine.Engine;

import java.util.Random;

import org.lwjgl.opengl.GL11;

public class Bullet extends TTLEntity {

	public static ArrayList<Texture> textures = new ArrayList<Texture>();
	static
	{
		textures.add(TextureLoader.instance().loadTexture("/Data/SPR/Plasma1.png"));
		textures.add(TextureLoader.instance().loadTexture("/Data/SPR/Plasma2.png"));
		textures.add(TextureLoader.instance().loadTexture("/Data/SPR/Plasma3.png"));
		textures.add(TextureLoader.instance().loadTexture("/Data/SPR/Plasma4.png"));
	}
	
	private int type = 0;
	
	static Random random = new Random(System.currentTimeMillis());
	
	private int textureId = 0;
	private float timeCounter;
	
	public Bullet()
	{
		type = random.nextInt(4);
		textureId = textures.get(type).getTextureID();
		timeCounter = 0;
		mouvementdirection = new Vertex(0,1,0);
		mouvementSpeed = 2000f;
		width = 30f;//1.5f;
		height = width*5f;//6.8f;
		
		completeContructor();
		energyStart = 10;
		energyRemaining = energyStart;
		
		TTL = 0.5f;
	}

	@Override
	public void render() 
	{
		GL11.glTranslatef(position.getX(),position.getY(),position.getZ());
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, textureId);
		if (polarity == BLUE)
			GL11.glColor4f(0.1f,0.1f,0.5f,1);
		else
			GL11.glColor4f(1,0.1f,0.1f,1);
		
		GL11.glRotatef(180,1,0,0);

		
		GL11.glBegin(GL11.GL_QUADS);
			GL11.glTexCoord2f(1,1); //Upper right
			GL11.glVertex2f(rightWidth,upperHeight);
		
			GL11.glTexCoord2f(1,0); // Lower right
			GL11.glVertex2f(rightWidth,lowerHeight);
			
			GL11.glTexCoord2f(0,0); //Lower left
			GL11.glVertex2f(leftWidth,lowerHeight);
			GL11.glTexCoord2f(0,1); //Upper left			
			GL11.glVertex2f(leftWidth,upperHeight);        
		GL11.glEnd();
		
		
	}

	@Override
	public void collide(Entity remoteEntity, int remoteEnergy) {
		super.collide(remoteEntity, remoteEnergy);
		this.toBeCleared=true;
		Impact plasmaWave = new Impact(this,Engine.SCREEN_WIDTH/4,50,true,0.35f); 
		plasmaWave.position.setY(this.position.getY()+upperHeight);
		Engine.plasmaExplositions.addEntity(plasmaWave);
	}
}
