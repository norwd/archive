package engine.entities;

import org.lwjgl.opengl.GL11;

import com.Vertex;
import com.obj.WavefrontObject;

import engine.Engine;
import engine.ObjLibrary;

public class Tama extends Entity {

	WavefrontObject obj = null;
	
	static final Vertex explosionColor = new Vertex(1,0.3f,0);

	public Vertex circleTamaBranch = null;
	
	public Tama()
	{
		position.setZ(-10);
		rotation.setX(90);
		rotationdirection.setY(-1);
		//rotationdirection.setX(-1);
		rotationSpeed= 100;
		obj =  ObjLibrary.instance().getObj(ObjLibrary.TAMA);
		
		width = 50f;//1.5f;
		height = 50f;//6.8f;
		
		completeContructor();
	}
	
	
	
	public Tama(Vertex position) {
		this();
		this.position = new Vertex(position);
	}



	@Override
	public void render() {
		GL11.glTranslatef(position.getX(),position.getY(),position.getZ());
		GL11.glRotatef(rotation.getX(),1,0,0);
		GL11.glRotatef(rotation.getY(),0,1,0);
		GL11.glRotatef(rotation.getZ(),0,0,1);
		obj.render();
	}

	public void collide(Entity remoteEntity, int remoteEnergy) {
		super.collide(remoteEntity,remoteEnergy);
		if (energyRemaining<=0)
		{
			explode();
		}
	}



	public void explode() {
		
		this.energyRemaining = 0;
		
		Explosion exp = new Explosion();
		exp.position = position;
		Engine.explosions.addEntity(exp);
		
		if (circleTamaBranch != null)
		{
			this.mouvementdirection = circleTamaBranch;
			this.mouvementdirection.rotateZ(-90);
			this.mouvementdirection.normalize();
		}
		
		GenericEnemyBullet[] bullets = GenericEnemyBullet.getBucket(this,1);
		for(GenericEnemyBullet bullet : bullets )
			Engine.enemieBullets.addEntity(bullet);
		
	}
}
