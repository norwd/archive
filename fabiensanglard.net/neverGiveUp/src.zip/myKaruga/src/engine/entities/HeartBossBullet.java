package engine.entities;

import org.lwjgl.opengl.GL11;

import com.TextureLoader;
import com.Vertex;

public class HeartBossBullet extends Entity {

	private int textureId = TextureLoader.instance().loadTexture("/Data/SPR/impact.png").getTextureID();
	
	public HeartBossBullet(Vertex position, Vertex mouvementDirection, float mouvementSpeed)
	{
		this.position = position;
		this.mouvementdirection = mouvementDirection;
		this.mouvementSpeed = mouvementSpeed;
	}
	
	public void render()
	{
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, textureId);
		super.render();
	}
	
}
