package engine.entities;

import org.lwjgl.opengl.GL11;

import com.Texture;
import com.TextureLoader;
import com.Vertex;

public class SparkAnimation extends TTLEntity {

	static private Texture[] frames = TextureLoader.instance().loadAnimation("/Data/Explosion/spark2.png",8,8,256,256,0,0,60);
	
	int currentFrame;
	
	float timeToDisplay = 0f;
	
	float alpha = 1f;
	
	public static final float ROTATIONSPEED=10f;
	
	public SparkAnimation(float rotationSpeed)
	{
		width=256;
		height=256;
		
		energyRemaining=1;
		TTL = 1f ;
		timeToDisplay = TTL/7*5;
		completeContructor();
		
		rotationdirection = new Vertex(0,0,1);
		this.rotationSpeed = rotationSpeed;
	}
	
	public void update()
	{
		super.update();
		
		if (timeCounter < timeToDisplay )
			currentFrame = (int)(timeCounter* frames.length/timeToDisplay) ;
		else
		{
			alpha = (TTL - timeCounter) / (TTL -  timeToDisplay);
			currentFrame = frames.length-1;
		}
		//if (currentFrame >= frames.length )
		//	energyRemaining = 0;
	}
	
	float depth = 1000;
	float width = 2;
	float height = 0.0005f;
	
	public void render()
	{
		if (energyRemaining == 0)
			return;
		
		
		GL11.glTranslatef(position.getX(),position.getY(),position.getZ());
		GL11.glRotatef(rotation.getZ(), 0,0,1);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, frames[currentFrame].getTextureID());
		drawFace();
		
		
	}
	
	private static final float alphaBorder = 1f;
	private static final float alphaCenter = 0.4f;
	
	private void drawFace() {
		GL11.glBegin(GL11.GL_TRIANGLES);
		
			GL11.glColor4f(1,1,1,alphaCenter);
			GL11.glTexCoord2f(0.5f,0.5f); //Upper right
			GL11.glVertex3f(0,0,0);
		
			GL11.glColor4f(1,1,1,alphaBorder);
			GL11.glTexCoord2f(0,1); // Lower right
			GL11.glVertex3f(width,height,depth);

			GL11.glTexCoord2f(1,1); //Lower left
			GL11.glVertex3f(-width,height,depth);
		GL11.glEnd();
		
		GL11.glRotatef(90,0,0, 1);
		
		GL11.glBegin(GL11.GL_TRIANGLES);
			GL11.glColor4f(1,1,1,alphaCenter);
			GL11.glTexCoord2f(0.5f,0.5f); //Upper right
			GL11.glVertex3f(0,0,0);
		
			GL11.glColor4f(1,1,1,alphaBorder);
			GL11.glTexCoord2f(1,1); // Lower right
			GL11.glVertex3f(width,height,depth);
			
			GL11.glTexCoord2f(1,0); //Lower left
			GL11.glVertex3f(-width,height,depth);
		GL11.glEnd();
		
		GL11.glRotatef(90,0,0, 1);
		GL11.glBegin(GL11.GL_TRIANGLES);
			GL11.glColor4f(1,1,1,alphaCenter);		
			GL11.glTexCoord2f(0.5f,0.5f); //Upper right
			GL11.glVertex3f(0,0,0);
		
			GL11.glColor4f(1,1,1,alphaBorder);
			GL11.glTexCoord2f(1,0); // Lower right
			GL11.glVertex3f(width,height,depth);
			
			GL11.glTexCoord2f(0,0); //Lower left
			GL11.glVertex3f(-width,height,depth);
		GL11.glEnd();
		
		GL11.glRotatef(90,0,0, 1);
		GL11.glBegin(GL11.GL_TRIANGLES);
			GL11.glColor4f(1,1,1,alphaCenter);		
			GL11.glTexCoord2f(0.5f,0.5f); //Upper right
			GL11.glVertex3f(0,0,0);
		
			GL11.glColor4f(1,1,1,alphaBorder);
			GL11.glTexCoord2f(0,0); // Lower right
			GL11.glVertex3f(width,height,depth);
			
			GL11.glTexCoord2f(0,1); //Lower left
			GL11.glVertex3f(-width,height,depth);	
		GL11.glEnd();
		
	}
}
