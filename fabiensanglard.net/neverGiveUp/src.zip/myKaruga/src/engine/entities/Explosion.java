package engine.entities;

import java.util.Random;

import org.lwjgl.opengl.GL11;

import com.Texture;
import com.TextureLoader;


public class Explosion extends TTLEntity {

	static private Texture[] frames = TextureLoader.instance().loadAnimation("/Data/Explosion/explosion.png",8,8,256,256,0,0,60);
	//static private Texture[] frames = TextureLoader.instance().loadSparedAnimation("/Data/Explosion/explosion",60);
	
	static Random random = new Random(System.currentTimeMillis());
	
	
	int currentFrame;
	
	float timeToDisplay = 0f;
	
	float DEFAULT_ALPHA = 0.6f;
	float alpha;
	public Explosion()
	{
		//int r = random.nextInt(2) + 3 ;
		
		
		
		width=256;
		height=256;
		
		energyRemaining=1;
		TTL = 1f ;
		timeToDisplay = TTL/7*5;
		completeContructor();
		
		if (random.nextBoolean())
		{
			upperHeight = -upperHeight;
			lowerHeight = -lowerHeight;
		}
		
		if (random.nextBoolean())
		{
			leftWidth = -leftWidth;
			rightWidth = - rightWidth;
		}
	}
	
	public void update()
	{
		super.update();
		
		if (timeCounter < timeToDisplay )
		{
			currentFrame = (int)(timeCounter* frames.length/timeToDisplay) ;
			alpha = DEFAULT_ALPHA;
		}
		else
		{
			alpha = DEFAULT_ALPHA * (TTL - timeCounter) / (TTL -  timeToDisplay);
			currentFrame = frames.length-1;
		}
		//if (currentFrame >= frames.length )
		//	energyRemaining = 0;
	}
	
	public void render()
	{
		if (energyRemaining == 0)
			return;
		
		GL11.glColor4f(1,1,1,alpha);
		GL11.glTranslatef(position.getX(),position.getY(),position.getZ());
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, frames[currentFrame].getTextureID());
		GL11.glBegin(GL11.GL_QUADS);
			GL11.glTexCoord2f(1,1); //Upper right
			GL11.glVertex2f(rightWidth,upperHeight);
		
			GL11.glTexCoord2f(1,0); // Lower right
			GL11.glVertex2f(rightWidth,lowerHeight);
			
			GL11.glTexCoord2f(0,0); //Lower left
			GL11.glVertex2f(leftWidth,lowerHeight);
			
			
			GL11.glTexCoord2f(0,1); //Upper left			
			GL11.glVertex2f(leftWidth, upperHeight);        
		GL11.glEnd();
		
	}
}
