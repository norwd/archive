package engine.entities;

import com.Vertex;

import engine.Engine;

public class FireBattery {

	float fireFrequency = 0.15f;
	float fireCounter;
	float fireCounterRotationSpeed = 0.07f;
	Vertex[] fireVectors = new Vertex[4];
	float rotationCounter = (float)Math.PI;
	Entity motherEntity = null;
	Vertex offSet = null;
	
	public FireBattery(Entity motherEntity, Vertex offSet)
	{
		fireVectors[0] = new Vertex(00,01,0);
		fireVectors[1] = new Vertex(-1,00,0);
		fireVectors[2] = new Vertex(00,-1,0);
		fireVectors[3] = new Vertex(01,00,0);
		this.motherEntity = motherEntity;
		this.offSet = offSet;
	}
	
	public void update()
	{
		fireCounter+=Engine.timer.delta;
		if (fireCounter > fireFrequency)
		{
			fireCounter=0;
			EvilBlast blast = null;
			for (int i=0; i <fireVectors.length;i++ )
			{
				blast = new EvilBlast();
				blast.mouvementdirection = new Vertex(fireVectors[i]);
				blast.position = new Vertex(motherEntity.position).copyAndAdd(offSet);
				blast.rotation.setZ((float)Math.toDegrees(rotationCounter)+90*i);
				blast.polarity = motherEntity.polarity;
				Engine.enemieBullets.addEntity(blast);
			}
			
			for (int i=0; i <fireVectors.length;i++ )
				fireVectors[i].rotateZ(-fireCounterRotationSpeed);
			
			rotationCounter+= fireCounterRotationSpeed;
			if (rotationCounter > 2*Math.PI)
				rotationCounter -= 2*Math.PI;
		}
	}
	
	
}
