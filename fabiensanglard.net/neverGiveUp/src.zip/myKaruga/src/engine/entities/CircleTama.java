package engine.entities;

import java.util.ArrayList;
import java.util.Random;

import com.Vertex;

import engine.Engine;

public class CircleTama extends Entity {

	static final int NUMBER_OF_BRANCHES = 20;
	ArrayList<Vertex> branches  = new ArrayList<Vertex>();
	ArrayList<Tama> tamas  = new ArrayList<Tama>();
	
	float BRANCH_ROTATION_SPEED = 1;
	float BRANCHES_MOVEMENT_SPEED = -0.3f;
	
	Random random = new Random(System.currentTimeMillis());

	
	public CircleTama()
	{
		width=0;
		height=0;
		completeContructor();
		energyRemaining=0;
		
		if (random.nextBoolean())
			BRANCH_ROTATION_SPEED *= -1;
		
		Vertex tamaPosition = new Vertex(0,600,-200);
		Tama tama = null;
		for (int i =0 ; i < NUMBER_OF_BRANCHES ; i ++)
		{
			tama = new Tama(tamaPosition);
			tama.polarity = polarity;
			tama.circleTamaBranch = new Vertex(tamaPosition);
			branches.add(new Vertex(tamaPosition));
			tamas.add(tama);
			Engine.enemies.addEntity(tama);
			tamaPosition.rotateZ(Math.PI*2/20);
		}
	}
	
	public void update()
	{
		this.position.setX(this.position.getX() +  this.mouvementdirection.getX() * Engine.timer.delta * mouvementSpeed);
		this.position.setY(this.position.getY() + this.mouvementdirection.getY() * Engine.timer.delta * mouvementSpeed);
		
		Vertex branche = null;
		for(int i=0;i<branches.size();i++)
		{
			branche = branches.get(i);
			
			branche.setX(branche.getX() + branche.getX() * BRANCHES_MOVEMENT_SPEED * Engine.timer.delta);
			branche.setY(branche.getY() + branche.getY() * BRANCHES_MOVEMENT_SPEED * Engine.timer.delta);
		}
		
		
		Tama tama = null;
		for(int i=0;i<branches.size();i++)
		{
			tama = tamas.get(i);
			tama.position = this.position.copyAndAdd(branches.get(i)) ;
		}
		
		
		for (Vertex rot : branches)
		{
			rot.rotateZ(BRANCH_ROTATION_SPEED * Engine.timer.delta);
		}
		
		// If all Tamas are destroyed, remove this entity.
		boolean oneAlive = false;
		for(Tama _tama: tamas)
			if (!_tama.toBeCleared)
			{
				oneAlive=true;
				break;
			}
		if (!oneAlive)
			this.toBeCleared=true;
	}
	
	public void render()
	{
	}

	@Override
	public void collide(Entity remoteEntity, int remoteEnergy) {
		
	}
	
	
}
