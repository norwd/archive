package engine.entities;

import org.lwjgl.opengl.GL11;

import com.TextureLoader;
import com.Vertex;

import engine.Engine;

public class WeakPointIndicator extends TTLEntity {

	public static final int leftType = 0;
	public static final int rightType = 1;
	
	int textureId = 0;
	
	public WeakPointIndicator(int type)
	{
		if (type == leftType)
			textureId = TextureLoader.instance().loadTexture("/Data/SPR/WeakPointUpperLeft.png").getTextureID();
		else
			textureId = TextureLoader.instance().loadTexture("/Data/SPR/WeakPointLowerRight.png").getTextureID();
		width=256;
		height=-128;
		completeContructor();
	}
	
	public void render()
	{	
		GL11.glLoadIdentity();	
		GL11.glTranslatef(position.getX(),position.getY(),position.getZ());
		
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, textureId);
		
			GL11.glBegin(GL11.GL_QUADS);
				GL11.glTexCoord2f(1,1); //Upper right
				GL11.glVertex2f(rightWidth,upperHeight);
			
				GL11.glTexCoord2f(1,0); // Lower right
				GL11.glVertex2f(rightWidth,lowerHeight);
				
				GL11.glTexCoord2f(0,0); //Lower left
				GL11.glVertex2f(leftWidth,lowerHeight);
				
				
				GL11.glTexCoord2f(0,1); //Upper left			
				GL11.glVertex2f(leftWidth, upperHeight);        
			GL11.glEnd();
			//GL11.glColor4f(1,1,1,1);
	}
	
	public void update()
	{
		
	}
}
