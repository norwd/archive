package engine.entities;

import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import com.Vertex;
import com.obj.WavefrontObject;

import engine.Engine;
import engine.ObjLibrary;
import engine.keyboard.KeyBoardHandler;
import engine.keyboard.playerControl.PlayerCKeyHandler;
import engine.keyboard.playerControl.PlayerDownKeyHandler;
import engine.keyboard.playerControl.PlayerLeftKeyHandler;
import engine.keyboard.playerControl.PlayerRightKeyHandler;
import engine.keyboard.playerControl.PlayerUpKeyHandler;
import engine.keyboard.playerControl.PlayerXKeyHandler;
import engine.keyboard.playerControl.PlayerZKeyHandler;

public class Player extends Entity {

	public WavefrontObject obj =  ObjLibrary.instance().getObj(ObjLibrary.PLAYER);
	
	
	private static float DEFAULT_FLIP_SPEED = 332;


	public static Vertex startingPosition = new Vertex(0,Engine.SCREEN_HEIGHT,-500);
	private int PLASMA_COUNT = 5;
	KeyBoardHandler keyboard = new KeyBoardHandler();
	
	Halo halo = null;
	
	Vertex explosionColor = new Vertex(1,0.3f,0);
	
	
	public Player()
	{
		halo = new Halo(this);
		position.setZ(-10);
		rotation.setX(90);
		rotationSpeed = DEFAULT_FLIP_SPEED;
		
		width = 50;
		this.height = width/2;
		this.completeContructor();
		
		keyboard.addKey(Keyboard.KEY_LEFT, new PlayerLeftKeyHandler(this));
		keyboard.addKey(Keyboard.KEY_RIGHT, new PlayerRightKeyHandler(this));
		keyboard.addKey(Keyboard.KEY_UP, new PlayerUpKeyHandler(this));
		keyboard.addKey(Keyboard.KEY_DOWN, new PlayerDownKeyHandler(this));
		keyboard.addKey(Keyboard.KEY_Z, new PlayerZKeyHandler(this));
		keyboard.addKey(Keyboard.KEY_X, new PlayerXKeyHandler(this));
		keyboard.addKey(Keyboard.KEY_C, new PlayerCKeyHandler(this));
	}
	
	public void update()
	{
		this.rotation.setX(this.rotation.getX() +  this.rotationdirection.getX() * Engine.timer.delta * rotationSpeed);
		this.rotation.setY(this.rotation.getY() +  this.rotationdirection.getY() * Engine.timer.delta * rotationSpeed);
		this.rotation.setZ(this.rotation.getZ() +  this.rotationdirection.getZ() * Engine.timer.delta * rotationSpeed);
		
		
		
		if (polarity && rotation.getZ()  > 180  )
		{
			onFinishRotation();
		}
		if (!polarity && rotation.getZ()  < 0  )
		{
			onFinishRotation();
		}
		
		keyboard.update();
		halo.update();
	}

	private void onFinishRotation() {
		rotationdirection.setZ(0);

		
	}

	@Override
	public 	void render() {
		
			GL11.glTranslatef(position.getX(),position.getY(),position.getZ());
			GL11.glPushMatrix();
				GL11.glTranslatef(0,-5,-100);

				//GL11.glTexEnvi(GL11.GL_TEXTURE_ENV, GL11.GL_TEXTURE_ENV_MODE, GL11.GL_ADD);
				//GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
				GL11.glDisable(GL11.GL_LIGHTING);
				//halo.render();
				GL11.glEnable(GL11.GL_LIGHTING);
				//GL11.glBlendFunc(GL11.GL_SRC_ALPHA,GL11.GL_ONE_MINUS_SRC_ALPHA);
				//GL11.glTexEnvi(GL11.GL_TEXTURE_ENV, GL11.GL_TEXTURE_ENV_MODE, GL11.GL_MODULATE);
				
			GL11.glPopMatrix();
			GL11.glRotatef(rotation.getX(),1,0,0);
			GL11.glRotatef(rotation.getY(),0,1,0);
			GL11.glRotatef(rotation.getZ(),0,0,1);
			obj.render();
	}
	
	

	public void fireSpecialWeapon()
	{
		Vertex vRight =  new Vertex(0,1,0);
		Vertex vLeft =  new Vertex(0,1,0);
		
		Vertex upperLeft = new Vertex(position.getX()+rightWidth,position.getY(),position.getZ());
		Vertex upperRight = new Vertex(position.getX()+leftWidth,position.getY(),position.getZ());
		
		float stepDown = height/PLASMA_COUNT;
		
		for (int i=0; i< PLASMA_COUNT ; i++)
		{
			
			SmartPlasma smartPlasma = new SmartPlasma(upperLeft,this.polarity,new Vertex(vRight.rotateZ((float)Math.PI/8)),300*(i+2));
			Engine.playerBullets.addEntity(smartPlasma);
			 
			smartPlasma = new SmartPlasma(upperRight,this.polarity,new Vertex(vLeft.rotateZ(-(float)Math.PI/8)),300*(i+2));
			Engine.playerBullets.addEntity(smartPlasma);
			
			
			upperRight.setY(upperRight.getY()-stepDown);
			upperLeft.setY(upperLeft.getY()-stepDown);
		}
		
		//PlasmaWave plasmaWave = new PlasmaWave(this,Engine.SCREEN_WIDTH/4); 
		//Engine.plasmaExplositions.addEntity(plasmaWave);
	}

	public void fireBullet(float offSetX)
	{
		Bullet bullet = new Bullet();
		bullet.polarity = polarity;
		//System.out.println("player.polarity="+player.polarity);
		bullet.position = new Vertex(position.getX()+offSetX,position.getY()+upperHeight*3,position.getZ());
		Engine.playerBullets.addEntity((bullet));
		
		Flash flash = new Flash(this);
		flash.polarity = polarity;
		flash.offsetX = offSetX;
		flash.offsetY = upperHeight*4;
		//flash.position =  new Vertex(posX,position.getY()+upperHeight*4,position.getZ());
		Engine.plasmaExplositions.addEntity(flash);
	}
	
	public void collide(Entity remoteEntity, int remoteEnergy) 
	{
		if (remoteEntity.polarity != this.polarity)
			this.energyRemaining -= remoteEnergy;
		else
		{
			//fireSpecialWeapon();
		}
		if (energyRemaining <= 0)
			die();
	}
	
	private void die() {
		
		
		Explosion exp = new Explosion();
		exp.position = position;
		Engine.explosions.addEntity(exp);
		
		PlasmaWave plasmaWave = new PlasmaWave(this,Engine.SCREEN_WIDTH/4,500,explosionColor); 
		Engine.explosions.addEntity(plasmaWave);
		
		position = new Vertex(Player.startingPosition);
		energyRemaining = 1;
		

	}

	public void startFlip()
	{
		
		halo.dispose();
		polarity = !polarity;
		halo.position = new Vertex(position);
		halo.expansionSpeed += 10f;
		halo.innerExpansionSpeedFactor = 0.5f;
		halo.TTL /= 1.7f;
		//Engine.explosions.addEntity(halo);
		halo = new Halo(this);
		if (polarity)
		{
			rotationdirection.setZ(2);
		}
		else
		{
			rotationdirection.setZ(-2);
		}
	}
}
