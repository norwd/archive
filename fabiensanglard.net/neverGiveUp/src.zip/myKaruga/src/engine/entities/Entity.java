package engine.entities;

import org.lwjgl.opengl.GL11;

import com.Vertex;

import engine.Engine;
import engine.VisibleElement;

public abstract class Entity implements VisibleElement{
	
	public final static boolean BLUE = true;
	public final static boolean RED = false;
	
	public Vertex position = new Vertex();
	public Vertex mouvementdirection = new Vertex();
	
	public Vertex rotation = new Vertex();
	public Vertex rotationdirection = new Vertex();
	
	public float mouvementSpeed = 0;
	public float rotationSpeed = 0;
	public boolean polarity = BLUE;
	
	public boolean toBeCleared = false;
	
	public float height;
	public float width;
	public float upperHeight;
	public float lowerHeight;
	public float leftWidth;
	public float rightWidth;
	
	public int energyRemaining=1;
	public int energyStart;
	
	protected final float energyBarWidth = 3f;
	
	public float hitHighLightTime = 0;
	public float hitHighLightCounter = 0;
	public boolean drawHighLighted = false;
	
	public void update()
	{
		this.position.setX(this.position.getX() +  this.mouvementdirection.getX() * Engine.timer.delta * mouvementSpeed);
		this.position.setY(this.position.getY() + this.mouvementdirection.getY() * Engine.timer.delta * mouvementSpeed);
		this.position.setZ(this.position.getZ() + this.mouvementdirection.getZ() * Engine.timer.delta * mouvementSpeed);
		
		this.rotation.setX(this.rotation.getX() +  this.rotationdirection.getX() * Engine.timer.delta * rotationSpeed);
		this.rotation.setY(this.rotation.getY() +  this.rotationdirection.getY() * Engine.timer.delta * rotationSpeed);
		this.rotation.setZ(this.rotation.getZ() +  this.rotationdirection.getZ() * Engine.timer.delta * rotationSpeed);
		
		if (energyRemaining <=0)
			toBeCleared = true;
	}
	
	public void render()
	{
		GL11.glBegin(GL11.GL_QUADS);
			GL11.glTexCoord2f(1,1); //Upper right
			GL11.glVertex2f(rightWidth,upperHeight);
		
			GL11.glTexCoord2f(1,0); // Lower right
			GL11.glVertex2f(rightWidth,lowerHeight);
			
			GL11.glTexCoord2f(0,0); //Lower left
			GL11.glVertex2f(leftWidth,lowerHeight);
			
			
			GL11.glTexCoord2f(0,1); //Upper left			
			GL11.glVertex2f(leftWidth, upperHeight);        
		GL11.glEnd();
	}
	
	protected void completeContructor()
	{
		upperHeight = height/2;
		lowerHeight = -height/2;
		leftWidth = -width/2;
		rightWidth = width/2;
	}

	public void collide(Entity remoteEntity, int remoteEnergy) {
		if (remoteEntity.polarity != this.polarity)
			this.energyRemaining -= remoteEnergy*2;
		else
			this.energyRemaining -= remoteEnergy;
	}
	
	public void explode(){}
}
