package engine;

import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.Iterator;


import org.lwjgl.BufferUtils;
import org.lwjgl.Sys;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;
import org.lwjgl.opengl.GL13;
import org.lwjgl.util.glu.GLU;

import com.Text;
import com.Vertex;
import com.obj.WavefrontObject;

import engine.camera.Camera;
import engine.entities.Bullet;
import engine.entities.Entity;
import engine.entities.Evil;
import engine.entities.Player;
import engine.entities.Tama;
import engine.entities.SortedWfObject;
import engine.entities.WeakPointIndicator;
import engine.keyboard.SpawnExplosionKey;
import engine.keyboard.F1KeyHandler;
import engine.keyboard.F2KeyHandler;
import engine.keyboard.KeyBoardHandler;
import engine.keyboard.MouseSwitchKeyHandler;
import engine.keyboard.SpaceKeyHandler;
import engine.keyboard.SpawnSparkAnimKey;
import engine.level.Level;
import engine.level.Level1;
import engine.level.Level2;
import engine.level.Level3;
import engine.mouse.MouseControl;
import engine.mouse.MousePlayerControl;
import engine.mouse.MouseSwitch;
import engine.mouse.MouseViewHandler;

public class Engine {

	
	/*
	 TODO
	 		- Display warning (Level3)																	DONE 9/11/2008
	 		- Debug, weak points are not flashing when hit anymore										DONE 9/12/2008
	 		- Display Boss weak Points																	DONE
	 		- DEBUG player Halo...
	 		- Re-activate collision detection
	 		- Make player die																			DONE
	 		- Make player explode 
	 		- Make player revive but unvulnerable 	 		
	 		- Make boss body and arms shake/mov (based on cos)
	 		- BUG Fix boss weakness explode  
	 		- Boss Final Explosion must kick asses (Use GL11.GL_SRC_ALPHA, GL11.GL_ONE blending)
	 		- Make player flash upon firing progressibly big, not all in one							DONE  9/13/2008
	 		- Make Impact from SmartPlasma bigger
	 		- Debug make weakPoints pointers sparkling white
	 		- SHIP IT !
	 */
	static public final int SCREEN_WIDTH = 1024;
	static public final int SCREEN_HEIGHT = 768; //480
	private static final boolean FULL_SCREEN = false;
		
	static FloatBuffer lightPosition0 = (FloatBuffer)BufferUtils.createFloatBuffer(4).put(new float[] { 50f, 0f, 0f, 1f  }).rewind();
	static FloatBuffer lightPosition1 = (FloatBuffer)BufferUtils.createFloatBuffer(4).put(new float[] { 0f, 0f, 0f, 1f  }).rewind();
	static FloatBuffer lightPositionAbove = (FloatBuffer)BufferUtils.createFloatBuffer(4).put(new float[] { 0f, 0f, -50, 1f  }).rewind();
	static FloatBuffer lightPositionAboveSide = (FloatBuffer)BufferUtils.createFloatBuffer(4).put(new float[] { 0f, 5f, -50, 1f  }).rewind();
	
	// Flags
	public static boolean drawBackGroup = true;
	public static boolean drawCollisionBoxes = false;
	public static boolean detectCollisions = false;
	public static boolean connectedToRemoteWorld = false;
	public static boolean controlEnabled = false;
	
	// Network piece
	public static RemoteWorld remoteWorld = null;
	
	// End Flags
	
	public static Timer timer ;

	public static Layer players = new Layer();
	public static Layer playerBullets = new Layer();
	public static Layer enemies = new Layer();
	public static Layer enemieBullets = new Layer();
	public static Layer explosions = new Layer();
	public static Layer plasmaExplositions = new Layer();
	
	public static Level currentLevel = null;
	public static void setCurrentLevel(Level level)
	{
		currentLevel = level;
	}
	
	static public Entity[] privilegiedSmartPlasmaTarget = null; 
	
	static AlertMessage alertMessage = null;
	public static WeakPointIndicator[] weakPoints = null;
	
	private static void initGL() {
    	
		
		GL11.glEnable(GL11.GL_LIGHTING);
		GL11.glEnable(GL11.GL_LIGHT1);
		GL11.glEnable(GL11.GL_LIGHT2);
		GL11.glEnable(GL11.GL_COLOR_MATERIAL);
        
		
		FloatBuffer lightAmbient0 = (FloatBuffer)BufferUtils.createFloatBuffer(4).put(new float[] { 0f, 0f, 0f, 1f  }).rewind();
		//GL11.glLight(GL11.GL_LIGHT1, GL11.GL_AMBIENT, lightAmbient);
		GL11.glLightModel(GL11.GL_LIGHT_MODEL_AMBIENT, lightAmbient0);
		
		//FloatBuffer materialProp = (FloatBuffer)BufferUtils.createFloatBuffer(4).put(new float[] { 0.1f, 0.1f, 0.1f, 1f  }).rewind();
		//GL11.glLightModel(GL11.GL_LIGHT_MODEL_AMBIENT,materialProp);
		
		GL11.glColorMaterial(GL11.GL_FRONT,GL11.GL_DIFFUSE);
		
		
		FloatBuffer lightDiffuse0 = (FloatBuffer)BufferUtils.createFloatBuffer(4).put(new float[] { 0.7f, 0.7f, 0.7f, 1f  }).rewind();
		GL11.glLight(GL11.GL_LIGHT1, GL11.GL_DIFFUSE, lightDiffuse0);
		

		FloatBuffer lightSpec0= (FloatBuffer)BufferUtils.createFloatBuffer(4).put(new float[] { 0.8f, 0.8f, 0.8f, 1f  }).rewind();
		GL11.glLight(GL11.GL_LIGHT1, GL11.GL_SPECULAR, lightSpec0);
		
		
		FloatBuffer lightDiffuse1 = (FloatBuffer)BufferUtils.createFloatBuffer(4).put(new float[] { 0.2f, 0.2f, 0.9f, 0.5f  }).rewind();
		GL11.glLight(GL11.GL_LIGHT2, GL11.GL_DIFFUSE, lightDiffuse1);
		
		GL11.glLightf (GL11.GL_LIGHT2, GL11.GL_SPOT_CUTOFF, 15.f);
		
		//setupOrtho();
		
		
		

		FloatBuffer lightDirection1= (FloatBuffer)BufferUtils.createFloatBuffer(4).put(new float[] { 0f, 0f, 10f, 1f  }).rewind();
		GL11.glLight(GL11.GL_LIGHT2, GL11.GL_SPOT_DIRECTION, lightDirection1);

		
		GL11.glEnable(GL11.GL_DEPTH_TEST);
		//GL11.glEnable(GL11.GL_CULL_FACE);
		//GL11.glFrontFace(GL11.GL_CW);
		//GL11.glFrontFace(GL11.GL_CCW);
		//GL11.glDisable(GL11.GL_CULL_FACE);
		
	//	GL11.glShadeModel(GL11.GL_SMOOTH);
		
		//GL11.glClearColor(1,1,1,1);
		
        
		GL11.glEnable(GL11.GL_TEXTURE_2D);
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA,GL11.GL_ONE_MINUS_SRC_ALPHA);
		//GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
		
        GL11.glTexEnvi(GL11.GL_TEXTURE_ENV, GL11.GL_TEXTURE_ENV_MODE, GL11.GL_MODULATE);   // Blending texture and light effect
        //GL11.glLightModeli(GL12.GL_LIGHT_MODEL_COLOR_CONTROL, GL12.GL_SEPARATE_SPECULAR_COLOR);
        
		FloatBuffer specref= (FloatBuffer)BufferUtils.createFloatBuffer(4).put(new float[] { 0.9f, 0.9f, 0.9f, 1f  }).rewind();
		GL11.glMaterial(GL11.GL_FRONT, GL11.GL_SPECULAR, specref);
		GL11.glMaterialf(GL11.GL_FRONT, GL11.GL_SHININESS, 64);
		
		GL11.glHint(GL11.GL_PERSPECTIVE_CORRECTION_HINT, GL11.GL_NICEST);
		GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_NICEST);
		
		GL11.glEnable(GL11.GL_POINT_SMOOTH);
		GL11.glHint(GL11.GL_POINT_SMOOTH_HINT,GL11.GL_NICEST);
		
		GL11.glEnable(GL11.GL_LINE_SMOOTH);
		GL11.glHint(GL11.GL_LINE_SMOOTH_HINT,GL11.GL_NICEST);
		
		GL11.glEnable(GL11.GL_POLYGON_SMOOTH);
		GL11.glHint(GL11.GL_POLYGON_SMOOTH_HINT,GL11.GL_NICEST);
		
		GL11.glEnable(GL13.GL_MULTISAMPLE);
    }
	
	private static void createWindow(int screenWidth, int screenHeight, boolean fullscreen) {
	    
		try
		{
		    if (!fullscreen) // create windowed mode
		    	Display.setDisplayMode(new DisplayMode(screenWidth, screenHeight));
		    else
	    	{
	    		Display.setFullscreen(true);
	            try
	            {
	            	DisplayMode dm[] = org.lwjgl.util.Display.getAvailableDisplayModes(320, 240, -1, -1, -1, -1, 60, 85);
	                org.lwjgl.util.Display.setDisplayMode(dm, new String[] {
	                    "width=" + screenWidth, "height=" + screenHeight, "freq=85", 
	                    "bpp=" + Display.getDisplayMode().getBitsPerPixel()
	                });
	            }
	            catch(Exception e)
	            {
	                Sys.alert("Error", "Could not start full screen, switching to windowed mode");
	                Display.setDisplayMode(new DisplayMode(screenWidth, screenHeight));
	            }           
	    	}
	
	        Display.create();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    }

	

	public static MouseSwitch mouseSwitch = null;
	
	
	public static void main(String[] argv)
	{

		
		
		createWindow(SCREEN_WIDTH, SCREEN_HEIGHT, FULL_SCREEN) ;
    	initGL();
    	Display.setVSyncEnabled(true);
    	
    	// Library of OBJ
    	ObjLibrary.instance();
    	
    	// Network layer
    	if (connectedToRemoteWorld)
    		remoteWorld = new RemoteWorld();
    	
    	// The time and accesory: a crappy comment
    	timer = new Timer();
		timer.update();
		
		Vertex positionFpsText = new Vertex(-SCREEN_WIDTH/2+140,SCREEN_HEIGHT/2-30,0);
		Vertex positionFpsNumber = new Vertex(-SCREEN_WIDTH/2+100,SCREEN_HEIGHT/2-30,0);
		
		
		Text testFont = new Text(positionFpsNumber);
		testFont.setSens(Text.RIGHT_TO_LEFT);
		testFont.setString("");

		Text fps = new Text(positionFpsText);
		fps.setString("fps");
		
		alertMessage = new AlertMessage();
		
		currentLevel = new Level1();
		//currentLevel = new Level2();
		//currentLevel = new Level3();
		
		
		
		Player player = new Player();
		player.position = new Vertex(Player.startingPosition);
		
		players.addEntity(player);
		

		
		
	
		KeyBoardHandler keyboard = new KeyBoardHandler();
		keyboard.addKey(Keyboard.KEY_SPACE,new SpaceKeyHandler());
		keyboard.addKey(Keyboard.KEY_F1,new F1KeyHandler());
		keyboard.addKey(Keyboard.KEY_F2,new F2KeyHandler());
		keyboard.addKey(Keyboard.KEY_E,new SpawnExplosionKey());
		keyboard.addKey(Keyboard.KEY_S,new SpawnSparkAnimKey());
		keyboard.addKey(Keyboard.KEY_M,new MouseSwitchKeyHandler());
		//addKey(Keyboard.KEY_LEFT,new LeftKeyHandler());
		//addKey(Keyboard.KEY_RIGHT,new RightKeyHandler());
		//addKey(Keyboard.KEY_UP,new UpKeyHandler());
		//addKey(Keyboard.KEY_DOWN,new DownKeyHandler());
		//addKey(Keyboard.KEY_SPACE,new SpaceKeyHandler());
		
		mouseSwitch = new MouseSwitch();
	
    	boolean running = true;
		while(running)
		{
			if (Logger.logging)
				Logger.log("Starting loop iteration");
			//Update state
			timer.update();
			
			updateWarning();
			updateWeakPoints();
			testFont.setString(timer.fps);
			
			if (controlEnabled)
			{
				
				mouseSwitch.update();
			}
			keyboard.update();

			plasmaExplositions.update();
			
			playerBullets.update();
			players.update();
			enemies.update();
			enemieBullets.update();
			
			explosions.update();
			
			if (detectCollisions)
			{
				playerBullets.detectCollision(enemies);
				players.detectCollision(enemies);
				players.detectCollision(enemieBullets);
			}
			
			currentLevel.update();			

			
			//System.out.println("fxPlayers#="+fxPlayers.getEntities().size());
			//Drawing
			
			GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);
			
			if (drawBackGroup)
			{
				currentLevel.setupPerspective();			
				currentLevel.applyCamera();
				currentLevel.render();
			}

			GL11.glDisable(GL11.GL_FOG);
			setupOrthoEntities();
			
			GL11.glLight(GL11.GL_LIGHT1, GL11.GL_POSITION, lightPositionAbove);
			GL11.glLight(GL11.GL_LIGHT2, GL11.GL_POSITION, lightPositionAboveSide);
			
			
			
			
			enemies.render();

			GL11.glTexEnvi(GL11.GL_TEXTURE_ENV, GL11.GL_TEXTURE_ENV_MODE, GL11.GL_ADD);
			GL11.glDisable(GL11.GL_LIGHTING);
			GL11.glDisable(GL11.GL_DEPTH_TEST);
			
				GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
				plasmaExplositions.render();
				playerBullets.render();
				
				enemieBullets.render();
				GL11.glBlendFunc(GL11.GL_SRC_ALPHA,GL11.GL_ONE_MINUS_SRC_ALPHA);
			GL11.glTexEnvi(GL11.GL_TEXTURE_ENV, GL11.GL_TEXTURE_ENV_MODE, GL11.GL_MODULATE);
			
			GL11.glEnable(GL11.GL_LIGHTING);
			GL11.glEnable(GL11.GL_DEPTH_TEST);
			players.render();
			GL11.glDisable(GL11.GL_LIGHTING);
			GL11.glDisable(GL11.GL_DEPTH_TEST);
			
			GL11.glColor4f(1,1,1,0.8f);
			explosions.render();
			
			GL11.glEnable(GL11.GL_LIGHTING);
			GL11.glEnable(GL11.GL_DEPTH_TEST);
			//GL11.glBlendFunc(GL11.GL_SRC_ALPHA,GL11.GL_ONE_MINUS_SRC_ALPHA);
		
			

			if (drawCollisionBoxes)
			{
				GL11.glDisable(GL11.GL_TEXTURE_2D);
				GL11.glDisable(GL11.GL_LIGHTING);
				GL11.glDisable(GL11.GL_DEPTH_TEST);
				GL11.glColor4f(1,1,0,0.3f);
				drawLayersBoxes(enemies.getEntities());
				drawLayersBoxes(playerBullets.getEntities());
				drawLayersBoxes(enemieBullets.getEntities());
				drawLayersBoxes(players.getEntities());
				GL11.glColor4f(1,1,1,1);
				GL11.glEnable(GL11.GL_TEXTURE_2D);
				GL11.glEnable(GL11.GL_LIGHTING);
				GL11.glEnable(GL11.GL_DEPTH_TEST);
			}

			
			setupOrtho();
			
			
			testFont.draw();
			fps.draw();
			
			drawWarning();
			drawWeakPoints();
			
			GL11.glEnable(GL11.GL_FOG);
			// Push generated image
			Display.update();
			if (Keyboard.isKeyDown(Keyboard.KEY_ESCAPE) || Display.isCloseRequested())
				running = false;
		}
		
		Display.destroy();
	}

	private static float MAX_MESSAGE_HEIGHT = SCREEN_HEIGHT/6;
	private static float messageHeight = 0;
	private static float messageHeightExpansionSpeed = 100;
	public static boolean showMessage = false;
	
	private static void updateWarning() 
	{
		if (showMessage && messageHeight < MAX_MESSAGE_HEIGHT)
			messageHeight += messageHeightExpansionSpeed * timer.delta;
		
		if (!showMessage && messageHeight >0)
			messageHeight -= messageHeightExpansionSpeed * timer.delta;
		
	}
	
	
	
	
	private static void drawWarning() {
		
		if (messageHeight <= 0)
			return;
		
		//GL11.glBlendFunc(GL11.GL_ONE_MINUS_CONSTANT_COLOR, GL11.GL_DST_COLOR);
		GL11.glBlendFunc(GL11.GL_ONE, GL11.GL_DST_COLOR);
		GL11.glColor4f(1,0.3f,0,0f);
		GL11.glDisable(GL11.GL_TEXTURE_2D);
		GL11.glDisable(GL11.GL_LIGHTING);
		//GL11.glEnable(GL11.GL_BLEND);
		GL11.glLoadIdentity();
			GL11.glBegin(GL11.GL_QUADS);
				GL11.glVertex2f(-SCREEN_WIDTH/2,-messageHeight);
				GL11.glVertex2f(-SCREEN_WIDTH/2,messageHeight);
				GL11.glVertex2f(SCREEN_WIDTH/2,messageHeight);		
				GL11.glVertex2f(SCREEN_WIDTH/2,-messageHeight);        
			GL11.glEnd();
		GL11.glEnable(GL11.GL_TEXTURE_2D);
		GL11.glEnable(GL11.GL_LIGHTING);
		GL11.glColor3f(1,1,1);
		
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA,GL11.GL_ONE_MINUS_SRC_ALPHA);
		//GL11.glTexEnvi(GL11.GL_TEXTURE_ENV, GL11.GL_TEXTURE_ENV_MODE, GL11.GL_ADD);
		
		if (messageHeight > MAX_MESSAGE_HEIGHT/1.15f)
			alertMessage.render();
		GL11.glColor4f(1,1,1,1);
		//GL11.glTexEnvi(GL11.GL_TEXTURE_ENV, GL11.GL_TEXTURE_ENV_MODE, GL11.GL_MODULATE);
		
	}
	
	public static boolean showWeaKPoints = false;
	private static void updateWeakPoints() 
	{
		if (showWeaKPoints && weakPointsScreenAlpha <= 0.5f)
			weakPointsScreenAlpha += weakPointsfadingSpeed * timer.delta;
		
		if (!showWeaKPoints && weakPointsScreenAlpha >= 0)
			weakPointsScreenAlpha -= weakPointsfadingSpeed * timer.delta;
		
	}
	
	public static float weakPointsScreenAlpha = 0f;
	private static float weakPointsfadingSpeed = 2.5f;
	private static void drawWeakPoints()
	{
		if (weakPointsScreenAlpha < 0)
			return;
		
		/*
		//GL11.glBlendFunc(GL11.GL_ZERO, GL11.GL_DST_COLOR);
		GL11.glColor4f(1,1,1,0.5f);
		GL11.glDisable(GL11.GL_TEXTURE_2D);
		GL11.glDisable(GL11.GL_LIGHTING);
		//GL11.glEnable(GL11.GL_BLEND);
		GL11.glLoadIdentity();
			GL11.glBegin(GL11.GL_QUADS);
				GL11.glVertex2f(-SCREEN_WIDTH/2,-SCREEN_HEIGHT/2);
				GL11.glVertex2f(-SCREEN_WIDTH/2,SCREEN_WIDTH/2);
				GL11.glVertex2f(SCREEN_WIDTH/2,SCREEN_WIDTH/2);		
				GL11.glVertex2f(SCREEN_WIDTH/2,-SCREEN_WIDTH/2);        
			GL11.glEnd();
		GL11.glEnable(GL11.GL_TEXTURE_2D);
		GL11.glEnable(GL11.GL_LIGHTING);
		*/
		
		//GL11.glBlendFunc(GL11.GL_ONE_MINUS_SRC_ALPHA,GL11.GL_ONE);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
		GL11.glTexEnvi(GL11.GL_TEXTURE_ENV, GL11.GL_TEXTURE_ENV_MODE, GL11.GL_ADD);
		GL11.glColor4f(1,1,1,Engine.weakPointsScreenAlpha);
		for (WeakPointIndicator weakPoint : weakPoints)
		{
			weakPoint.render();
				
		}	
		GL11.glColor4f(1,1,1,1);
		GL11.glTexEnvi(GL11.GL_TEXTURE_ENV, GL11.GL_TEXTURE_ENV_MODE, GL11.GL_MODULATE);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA,GL11.GL_ONE_MINUS_SRC_ALPHA);
	}
	

	private static void drawLayersBoxes(ArrayList<Entity> entities) {
		for(Entity entity : entities  )
		{
			GL11.glLoadIdentity();
			GL11.glTranslatef(entity.position.getX(),entity.position.getY(),entity.position.getZ());
			GL11.glBegin(GL11.GL_QUADS);
				GL11.glVertex2f(entity.rightWidth,entity.upperHeight);
				GL11.glVertex2f(entity.rightWidth,entity.lowerHeight);
				GL11.glVertex2f(entity.leftWidth,entity.lowerHeight);
				GL11.glVertex2f(entity.leftWidth,entity.upperHeight);        
			GL11.glEnd();		
		}
		
	}


	private static void setupOrthoEntities() {
		GL11.glEnable(GL11.GL_DEPTH_TEST);
		GL11.glEnable(GL11.GL_LIGHTING);
		GL11.glMatrixMode(GL11.GL_PROJECTION); // Select The Projection Matrix
	    GL11.glLoadIdentity(); // Reset The Projection Matrix
	    GL11.glOrtho(-(int)SCREEN_WIDTH/2,(int)SCREEN_WIDTH/2,(int)-SCREEN_HEIGHT/2,(int)SCREEN_HEIGHT/2,0f,10000f);
	    GL11.glMatrixMode(GL11.GL_MODELVIEW);
	    GL11.glLoadIdentity();
	}
	
	private static void setupOrtho() {
		GL11.glDisable(GL11.GL_LIGHTING);
		GL11.glDisable(GL11.GL_DEPTH_TEST);
		GL11.glMatrixMode(GL11.GL_PROJECTION); // Select The Projection Matrix
	    GL11.glLoadIdentity(); // Reset The Projection Matrix
	    GL11.glOrtho(-(int)SCREEN_WIDTH/2,(int)SCREEN_WIDTH/2,(int)-SCREEN_HEIGHT/2,(int)SCREEN_HEIGHT/2,0f,10000f);
	    GL11.glMatrixMode(GL11.GL_MODELVIEW);
	    GL11.glLoadIdentity();
	   // GL11.glLight(GL11.GL_LIGHT1, GL11.GL_POSITION, lightPosition0);
		//GL11.glLight(GL11.GL_LIGHT2, GL11.GL_POSITION, lightPosition1);
	}
	
	public static void start()
	{
		detectCollisions = true;
		
	}

}

