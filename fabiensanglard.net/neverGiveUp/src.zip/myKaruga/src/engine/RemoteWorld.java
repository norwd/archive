package engine;

import java.io.IOException;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.DatagramChannel;

public class RemoteWorld {

	int remotePort = 6990;
	int localPort = 6990;
	DatagramChannel  dsocket = null;

    
    private SocketAddress localAddress = new InetSocketAddress( localPort);
    private SocketAddress remoteAddress = new InetSocketAddress("10.10.1.1", remotePort);
    
	public RemoteWorld()
	{
		try
		{
			 
			 dsocket =  DatagramChannel.open();
			 dsocket.configureBlocking(false);
			 dsocket.socket().bind(localAddress);
			 dsocket.connect(remoteAddress);
			 
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	int dataReceived;
	public void update()
	{
		sendData();
		receiveData();
		
		
	}
	
	
	 ByteBuffer in = ByteBuffer.allocate(8096);
	private void receiveData() 
	{
		
		
		try {
			dataReceived = dsocket.read(in);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		if (dataReceived != 0)
			System.out.println("Received packet");
		
	}
	
	
	private void sendData() {
		ByteBuffer out = ByteBuffer.allocate(8);
		out.order(ByteOrder.BIG_ENDIAN);
	    // send a byte of data to the server
		out.put((byte) Engine.players.getEntities().get(0).position.getX());
		out.put((byte) Engine.players.getEntities().get(0).position.getY());
		out.flip();
		try {
			dsocket.write(out);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
