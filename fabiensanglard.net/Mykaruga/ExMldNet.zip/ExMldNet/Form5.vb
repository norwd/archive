Public Class Form5
    'Batch Conversion of Models, from NJ/MLD to whatever.
    Private Inmode As Integer = 0
    Private OutMode As Integer = 0
    Private Sub SetContainerFile()
        With OpenFileDialog1
            .Filter = "Ninja Model Files (*.nj)|*.nj|Skies of Arcadia MLD files (*.MLD)|*.mld"
            .FilterIndex = 2
            .InitialDirectory = Form1.InDir
            .Multiselect = True
            If .ShowDialog = Windows.Forms.DialogResult.OK Then
                TextBox1.Text = "File List :" & vbCrLf
                For Each a As String In .FileNames
                    TextBox1.Text &= a & vbCrLf
                Next
                Inmode = .FilterIndex
                Form1.InDir = Strings.Mid(.FileNames(0), 1, Strings.InStrRev(.FileNames(0), "\") - 1)
            End If
        End With
    End Sub
    Private Sub SetOutputDirectory()
        With FolderBrowserDialog1
            .RootFolder = Environment.SpecialFolder.Desktop
            .ShowNewFolderButton = True
            If .ShowDialog = Windows.Forms.DialogResult.OK Then
                TextBox2.Text = .SelectedPath
                Form1.OutDir = .SelectedPath
            End If
        End With
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        SetContainerFile()
    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        SetOutputDirectory()
    End Sub
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim ext() As String = {".RAW", ".OBJ", ".TXT"}
        Do While TextBox1.Text = "" : SetContainerFile() : Loop
        Do While TextBox2.Text = "" : SetOutputDirectory() : Loop
        OutMode = Me.ComboBox2.SelectedIndex + 1

        Form1.Verbosity = CheckBox1.Checked
        If CheckBox1.Checked Then
            If ComboBox1.SelectedIndex = -1 Then ComboBox1.SelectedIndex = 1
            Form1.VerbosityLevel = Val(ComboBox1.SelectedItem)
        Else
            Form1.VerbosityLevel = 0
        End If
        If TextBox3.Text = "" Then TextBox3.Text = "1"
        Dim MyScale As Integer = Int(Val(TextBox3.Text))
        If MyScale < 0 Then MyScale = 1
        Me.Hide()
        Cls()
        Application.DoEvents()
        For Each A As String In Me.OpenFileDialog1.FileNames
            Dim InpFile As String = A
            Dim OutDir As String = TextBox2.Text & "\" & StripFileName(A)
            Dim OutFile As String = OutDir & "\" & StripFileName(A) & ext(Me.ComboBox2.SelectedIndex)
            If CheckBox1.Checked = True Then
                My.Computer.FileSystem.CreateDirectory(OutDir)
            End If
            DoConversion(A, OutFile, Inmode, OutMode, MyScale)
        Next
    End Sub
    Private Sub Form5_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        With Me
            .CheckBox1.Checked = True
            .CheckBox2.Checked = False
            .ComboBox1.SelectedIndex = 0
            .ComboBox2.SelectedIndex = 0
            .TextBox3.Text = "1"
        End With
    End Sub
    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged
        With Me
            .ComboBox1.Visible = .CheckBox2.Checked
        End With
    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox2.SelectedIndexChanged

    End Sub
End Class