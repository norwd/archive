#Region "System Includes"
Imports System.IO
Imports WindowsApplication1.MatrixMath
Imports WindowsApplication1.VectorMath
Imports WindowsApplication1.Utility
#End Region
#Region "C/C++ types in VB.NET"
Imports qword = System.UInt64
Imports dword = System.UInt32
Imports float = System.Single
Imports word = System.UInt16
Imports bool = System.Boolean
#End Region
Namespace Stripmaker
    Public Class Triangle
        Const nullstrip = -99999
        Public vtx_idx() As Integer = New Integer(3) {}
        Public edg_idx() As Integer = New Integer(3) {}
        Public adj_tri() As Integer = New Integer(3) {}
        Public shared_edges As Integer = 0

        Sub New()
            With Me
                For I As Integer = 0 To 2
                    .vtx_idx(I) = nullstrip
                    .edg_idx(I) = nullstrip
                    .adj_tri(I) = nullstrip
                    .shared_edges = 0
                Next
            End With
        End Sub
    End Class
    Public Class Edge
        Implements ICloneable

        Public A As Integer
        Public B As Integer

        Sub New()
            Me.A = -99999
            Me.B = -99999
        End Sub

        Sub New(ByVal V1 As Integer, ByVal V2 As Integer)
            Me.A = V1
            Me.B = V2
        End Sub
        Public Overloads Shared Operator =(ByVal A As Edge, ByVal B As Edge) As Boolean
            Return ((A.A = B.A) And (A.B = B.B)) Or ((A.B = B.A) And (A.A = B.B))
        End Operator
        Public Overloads Shared Operator <>(ByVal A As Edge, ByVal B As Edge) As Boolean
            Return Not (((A.A = B.A) And (A.B = B.B)) Or ((A.B = B.A) And (A.A = B.B)))
        End Operator
        Public Function Reversed(ByVal A As Edge, ByVal B As Edge) As Boolean
            If ((A.B = B.A) And (A.A = B.B)) Then Return True Else Return False
        End Function

        Public Function Clone() As Object Implements System.ICloneable.Clone
            Return New Edge(Me.A, Me.B)
        End Function
    End Class
    Public Module Stitcher
        Dim trilist As New List(Of Stripmaker.Triangle)
        Dim edgelist As New List(Of Stripmaker.Edge)

        Function GetEdgeListIndex(ByVal A As Stripmaker.Edge) As Integer
            Dim wrkv As Edge = A.Clone
            Dim retv As Integer = -1
            Dim idx As Integer = 0

            Do While idx < edgelist.Count
                If edgelist(idx) = wrkv Then retv = idx : Exit Do
                idx += 1
            Loop
            If retv = -1 Then
                retv = edgelist.Count
                edgelist.Add(wrkv)
            End If
            Return retv
        End Function

        Sub FillEdgeIndices()
            Dim wrkv As New Stripmaker.Triangle
            For I As Integer = 0 To trilist.Count - 1
                wrkv = trilist(I)
                wrkv.edg_idx(0) = GetEdgeListIndex(New Edge(wrkv.vtx_idx(0), wrkv.vtx_idx(1)))
                wrkv.edg_idx(1) = GetEdgeListIndex(New Edge(wrkv.vtx_idx(1), wrkv.vtx_idx(2)))
                wrkv.edg_idx(2) = GetEdgeListIndex(New Edge(wrkv.vtx_idx(2), wrkv.vtx_idx(0)))
                trilist(I) = wrkv
            Next
        End Sub

        Sub FillAdjacencies()
            Dim wrkv As New Stripmaker.Triangle
            Dim I As Integer = 0
            Dim J As Integer = 0

        End Sub

    End Module
End Namespace

