<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.rt1 = New System.Windows.Forms.RichTextBox
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ScanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.NewUIToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.BatchConversionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.UtilityToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BMLUtilities = New System.Windows.Forms.ToolStripMenuItem
        Me.BMLUnpack = New System.Windows.Forms.ToolStripMenuItem
        Me.PRSUtilities = New System.Windows.Forms.ToolStripMenuItem
        Me.PRSCompress = New System.Windows.Forms.ToolStripMenuItem
        Me.PRSDecompress = New System.Windows.Forms.ToolStripMenuItem
        Me.GSLUtilities = New System.Windows.Forms.ToolStripMenuItem
        Me.GSLUnpack = New System.Windows.Forms.ToolStripMenuItem
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog
        Me.Button1 = New System.Windows.Forms.Button
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.Label1 = New System.Windows.Forms.Label
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'rt1
        '
        Me.rt1.Font = New System.Drawing.Font("Bitstream Vera Sans Mono", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rt1.Location = New System.Drawing.Point(15, 43)
        Me.rt1.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.rt1.Name = "rt1"
        Me.rt1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical
        Me.rt1.Size = New System.Drawing.Size(781, 563)
        Me.rt1.TabIndex = 0
        Me.rt1.Text = ""
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.UtilityToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(807, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ScanToolStripMenuItem, Me.NewUIToolStripMenuItem, Me.ToolStripSeparator2, Me.BatchConversionToolStripMenuItem, Me.ToolStripSeparator1, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(35, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'ScanToolStripMenuItem
        '
        Me.ScanToolStripMenuItem.Name = "ScanToolStripMenuItem"
        Me.ScanToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
        Me.ScanToolStripMenuItem.Text = "Scan"
        '
        'NewUIToolStripMenuItem
        '
        Me.NewUIToolStripMenuItem.Name = "NewUIToolStripMenuItem"
        Me.NewUIToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
        Me.NewUIToolStripMenuItem.Text = "Convert"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(166, 6)
        '
        'BatchConversionToolStripMenuItem
        '
        Me.BatchConversionToolStripMenuItem.Name = "BatchConversionToolStripMenuItem"
        Me.BatchConversionToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
        Me.BatchConversionToolStripMenuItem.Text = "Batch Conversion"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(166, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'UtilityToolStripMenuItem
        '
        Me.UtilityToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BMLUtilities, Me.PRSUtilities, Me.GSLUtilities})
        Me.UtilityToolStripMenuItem.Name = "UtilityToolStripMenuItem"
        Me.UtilityToolStripMenuItem.Size = New System.Drawing.Size(46, 20)
        Me.UtilityToolStripMenuItem.Text = "Utility"
        '
        'BMLUtilities
        '
        Me.BMLUtilities.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BMLUnpack})
        Me.BMLUtilities.Name = "BMLUtilities"
        Me.BMLUtilities.Size = New System.Drawing.Size(152, 22)
        Me.BMLUtilities.Text = "BML"
        '
        'BMLUnpack
        '
        Me.BMLUnpack.Name = "BMLUnpack"
        Me.BMLUnpack.Size = New System.Drawing.Size(152, 22)
        Me.BMLUnpack.Text = "Unpack"
        '
        'PRSUtilities
        '
        Me.PRSUtilities.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PRSCompress, Me.PRSDecompress})
        Me.PRSUtilities.Name = "PRSUtilities"
        Me.PRSUtilities.Size = New System.Drawing.Size(152, 22)
        Me.PRSUtilities.Text = "PRS"
        '
        'PRSCompress
        '
        Me.PRSCompress.Name = "PRSCompress"
        Me.PRSCompress.Size = New System.Drawing.Size(152, 22)
        Me.PRSCompress.Text = "Compress"
        '
        'PRSDecompress
        '
        Me.PRSDecompress.Name = "PRSDecompress"
        Me.PRSDecompress.Size = New System.Drawing.Size(152, 22)
        Me.PRSDecompress.Text = "Decompress"
        '
        'GSLUtilities
        '
        Me.GSLUtilities.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GSLUnpack})
        Me.GSLUtilities.Name = "GSLUtilities"
        Me.GSLUtilities.Size = New System.Drawing.Size(152, 22)
        Me.GSLUtilities.Text = "GSL"
        '
        'GSLUnpack
        '
        Me.GSLUnpack.Name = "GSLUnpack"
        Me.GSLUnpack.Size = New System.Drawing.Size(152, 22)
        Me.GSLUnpack.Text = "Unpack"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(40, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(114, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Button1
        '
        Me.Button1.Enabled = False
        Me.Button1.Location = New System.Drawing.Point(636, 614)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(160, 30)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Step Control"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "sphereblu.png")
        Me.ImageList1.Images.SetKeyName(1, "spheregrn.png")
        Me.ImageList1.Images.SetKeyName(2, "CLSDFOLD.BMP")
        Me.ImageList1.Images.SetKeyName(3, "DOC.BMP")
        Me.ImageList1.Images.SetKeyName(4, "OPENFOLD.BMP")
        Me.ImageList1.Images.SetKeyName(5, "EXPLORER.BMP")
        Me.ImageList1.Images.SetKeyName(6, "ARW06RT.ICO")
        Me.ImageList1.Images.SetKeyName(7, "ARW06DN.ICO")
        Me.ImageList1.Images.SetKeyName(8, "vert-icon.png")
        Me.ImageList1.Images.SetKeyName(9, "tri-icon.png")
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Bitstream Vera Sans", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(121, 15)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Output Window"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(807, 650)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.rt1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Name = "Form1"
        Me.Text = "ExMLDNet 1.0"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents rt1 As System.Windows.Forms.RichTextBox
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents ScanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewUIToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents UtilityToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BatchConversionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BMLUtilities As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PRSUtilities As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GSLUtilities As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BMLUnpack As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PRSCompress As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PRSDecompress As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GSLUnpack As System.Windows.Forms.ToolStripMenuItem

End Class
