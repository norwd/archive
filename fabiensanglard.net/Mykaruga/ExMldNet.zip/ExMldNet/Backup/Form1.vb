#Region "System Includes"
Imports WindowsApplication1.Utility
Imports WindowsApplication1.Scanner
Imports WindowsApplication1.Multi
Imports WindowsApplication1.NJCM.Types
Imports WindowsApplication1.MatrixMath
Imports WindowsApplication1.PRS
Imports WindowsApplication1.BMLExploder
Imports System.IO
#End Region

#Region "C/C++ types in VB.NET"
Imports qword = System.UInt64
Imports dword = System.UInt32
Imports float = System.Single
Imports word = System.UInt16
Imports bool = System.Boolean
#End Region

Public Class Form1
#Region "Public Properties"
    Public InDir As String = ""
    Public OutDir As String = ""
    Public Verbosity As Boolean = True
    Public VerbosityLevel As Integer = 0
#End Region
#Region "Private Properties"
    Private ClosingFlag As Boolean = False
    Private SavedInfo As System.Globalization.CultureInfo = Application.CurrentCulture
#End Region
#Region "Form Events"
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim fn As String = System.IO.Path.Combine(My.Computer.FileSystem.SpecialDirectories.CurrentUserApplicationData, "exmldnet.ini")
        Me.Text = "ExMLDNet Version " & GetVersion()
        If File.Exists(fn) Then
            Dim fs As New FileStream(fn, FileMode.Open)
            Dim sr As New StreamReader(fs)
            InDir = sr.ReadLine
            OutDir = sr.ReadLine
            sr.Close()
        Else
            InDir = "C:\"
            OutDir = "C:\"
        End If
        Application.CurrentCulture = New System.Globalization.CultureInfo("en-us")
    End Sub
    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Application.CurrentCulture = SavedInfo
        If ClosingFlag = False Then
            WriteLn("The program will now end...")
            Dim fn As String = System.IO.Path.Combine(My.Computer.FileSystem.SpecialDirectories.CurrentUserApplicationData, "exmldnet.ini")
            Dim fs As New FileStream(fn, FileMode.Create)
            Dim sw As New StreamWriter(fs)
            sw.WriteLine(InDir)
            sw.WriteLine(OutDir)
            sw.Close()
        End If
        End
    End Sub
    Private Sub Form1_Resize(ByVal sender As System.Object, ByVal Byvale As System.EventArgs) Handles MyBase.Resize
        Dim u As System.Drawing.Point = Me.Size
        With Me
            .rt1.Location = New System.Drawing.Point(15, 43)
            .rt1.Size = New System.Drawing.Point(u.X - 40, u.Y - 108)
            .Button1.Location = New System.Drawing.Point(u.X - 185, u.Y - 60)
            .Button1.Size = New System.Drawing.Point(160, 30)
        End With
    End Sub
#End Region
#Region "UI Click Events"
    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutToolStripMenuItem.Click
        WriteLn("Version :" & GetVersion())
        WriteLn("By Steve Pettit")
        WriteLn("Some code provided by Andrew Doane and several others...")
        WriteLn("Batch Conversion Code provided by Minti.")
        WriteLn("BML Unpacker based on source code by Syphos and DeathRabbit.")
        WriteLn("PRS Implementation based on source code by Fuzziqer Software.")
    End Sub
    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        WriteLn("The program will now end...")
        Dim fn As String = System.IO.Path.Combine(My.Computer.FileSystem.SpecialDirectories.CurrentUserApplicationData, "exmldnet.ini")
        Dim fs As New FileStream(fn, FileMode.Create)
        Dim sw As New StreamWriter(fs)
        sw.WriteLine(InDir)
        sw.WriteLine(OutDir)
        sw.Close()
        ClosingFlag = True
        End
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Utility.ControlFlag = True
    End Sub
    Private Sub ScanToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim OF1 As New OpenFileDialog
        OF1.Filter = "Ninja Model Files (*.nj)|*.nj|Skies of Arcadia MLD files (*.MLD)|*.mld"
        OF1.FilterIndex = 2
        OF1.InitialDirectory = InDir
        If OF1.ShowDialog = Windows.Forms.DialogResult.OK Then
            WriteLn("Scanning " & OF1.FileName)
            ScanModel(OF1.FileName)
            InDir = Strings.Left(OF1.FileName, Strings.InStrRev(OF1.FileName, "\") - 1)
        End If
    End Sub
    Private Sub ScanToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ScanToolStripMenuItem.Click
        Dim OF1 As New OpenFileDialog
        OF1.Filter = "Ninja Model Files (*.nj)|*.nj|Skies of Arcadia MLD files (*.MLD)|*.mld"
        OF1.FilterIndex = 2
        OF1.InitialDirectory = InDir
        If OF1.ShowDialog = Windows.Forms.DialogResult.OK Then
            WriteLn("Scanning " & OF1.FileName)
            ScanModel(OF1.FileName)
            InDir = Strings.Left(OF1.FileName, Strings.InStrRev(OF1.FileName, "\") - 1)
        End If
    End Sub
    Private Sub TrialFunctionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        WriteLn("This was supposed to do something!")
        'Dim OF1 As New OpenFileDialog
        'Dim SF1 As New SaveFileDialog'
        'OF1.Filter = "Ninja Model Files (*.nj)|*.nj|Skies of Arcadia MLD files (*.MLD)|*.mld"
        'OF1.FilterIndex = 1
        'OF1.InitialDirectory = InDir
        'SF1.Filter = "Raw Triangles (*.raw)|*.raw|Wavefront OBJ (*.OBJ|*.obj|Milkshape 3D ASCII(*.txt)|*.txt"
        'SF1.FilterIndex = 3
        'SF1.InitialDirectory = OutDir'
        'If OF1.ShowDialog = Windows.Forms.DialogResult.OK Then
        ' Dim t1 As Integer = Strings.InStrRev(OF1.FileName, "\") + 1
        ' Dim t2 As Integer = Strings.InStrRev(OF1.FileName, ".")
        ' Dim t3 As String = Strings.Mid(OF1.FileName, t1, t2 - t1)
        ' Dim ofn As String = ""
        ' SF1.FileName = t3
        ' If SF1.ShowDialog = Windows.Forms.DialogResult.OK Then
        ' Trial2(OF1.FileName, SF1.FileName, OF1.FilterIndex, SF1.FilterIndex)
        ' End If
        ' End If
        'InDir = Strings.Left(OF1.FileName, Strings.InStrRev(OF1.FileName, "\") - 1)
        'OutDir = Strings.Left(SF1.FileName, Strings.InStrRev(SF1.FileName, "\") - 1)
    End Sub
    Private Sub BitSetTestToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        WriteLn("Depreciated Code!")
    End Sub
    Private Sub NewUIToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewUIToolStripMenuItem.Click
        Form2.Show()
        Application.DoEvents()
    End Sub
    Private Sub BMLUnpack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BMLUnpack.Click
        Form3.Show()
        Application.DoEvents()
    End Sub
    Private Sub PRSCompress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PRSCompress.Click
        Dim OF1 As New OpenFileDialog
        OF1.Filter = "All Files|*.*"
        OF1.FilterIndex = 1
        OF1.InitialDirectory = InDir

        If OF1.ShowDialog = Windows.Forms.DialogResult.OK Then
            Dim tfn As String = Strings.Replace(OF1.FileName, ".", "_") & ".prs"
            'Read our test file
            WriteLn("Reading " & OF1.FileName)
            Dim buf1() As Byte = FileToBuffer(OF1.FileName)
            Dim buf2(buf1.Length) As Byte
            Dim ln As Integer = 0
            WriteLn("Compressing...")
            ln = PRS.compress(buf1, buf2, buf1.Length)
            WriteLn("Writing " & tfn)
            BufferToFile(getdestbuffer(ln), tfn)
            WriteLn("Done!")
        End If
    End Sub
    Private Sub PRSDecompress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PRSDecompress.Click
        Dim OF1 As New OpenFileDialog
        OF1.Filter = "PRS Archives|*.prs"
        OF1.FilterIndex = 1
        OF1.InitialDirectory = InDir

        If OF1.ShowDialog = Windows.Forms.DialogResult.OK Then
            Dim tfn As String = OF1.FileName
            'Make the original file name from the input file name
            tfn = Strings.Replace(tfn, ".prs", "")
            tfn = Strings.Replace(tfn, "_", ".")
            WriteLn("Reading " & OF1.FileName)
            Dim buf1() As Byte = FileToBuffer(OF1.FileName)
            Dim buf2(decompress_size(buf1)) As Byte
            Dim ln As Integer = 0
            WriteLn("Decompressing...")
            ln = decompress(buf1, buf2)
            WriteLn("Writing " & tfn)
            BufferToFile(getdestbuffer(ln), tfn)
            WriteLn("Done!")
        End If
    End Sub
    Private Sub GSLUnpack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GSLUnpack.Click
        Form4.Show()
        Application.DoEvents()
    End Sub
    Private Sub BatchConversionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BatchConversionToolStripMenuItem.Click
        Form5.Show()
        Application.DoEvents()
    End Sub
    Private Sub XJTrialCodeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Cls()
        WriteLn("Code Hook for .XJ file reading and conversion...")
        Dim OF1 As New OpenFileDialog
        OF1.Filter = "Ninja Model Files (*.nj)|*.nj|Skies of Arcadia MLD files (*.MLD)|*.mld|NinjaX model files (*.xj)|*.xj"
        OF1.FilterIndex = 3
        OF1.InitialDirectory = InDir
        If OF1.ShowDialog = Windows.Forms.DialogResult.OK Then
            WriteLn("Scanning " & OF1.FileName)
            Dim g As New NJCM.Model
            g.XJProcess(OF1.FileName)
            InDir = Strings.Left(OF1.FileName, Strings.InStrRev(OF1.FileName, "\") - 1)
        End If
    End Sub
#End Region
End Class
