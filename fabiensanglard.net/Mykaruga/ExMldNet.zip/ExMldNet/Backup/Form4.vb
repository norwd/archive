Imports WindowsApplication1.Form1
Imports WindowsApplication1.NJCM.Types
Imports WindowsApplication1.Multi
Imports WindowsApplication1.BMLExploder

Public Class Form4
    Private Sub SetContainerFile()
        With OpenFileDialog1
            .Filter = "GSL Container Files|*.GSL"
            .FilterIndex = 1
            .InitialDirectory = Form1.InDir
            If .ShowDialog = Windows.Forms.DialogResult.OK Then
                TextBox1.Text = .FileName
            End If
        End With
    End Sub
    Private Sub SetOutputDirectory()
        With FolderBrowserDialog1
            .RootFolder = Environment.SpecialFolder.Desktop
            .ShowNewFolderButton = True
            If .ShowDialog = Windows.Forms.DialogResult.OK Then
                TextBox2.Text = .SelectedPath
            End If
        End With
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        SetContainerFile()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        SetOutputDirectory()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If TextBox1.Text = "" Then SetContainerFile()
        If TextBox2.Text = "" Then SetOutputDirectory()
        'BMLExplode takes InFile and OutDir as arguments
        WriteLn("Exploding GSL File " & TextBox1.Text)
        Me.Hide()
        GSLExplode(TextBox1.Text, TextBox2.Text)
        Application.DoEvents()
    End Sub
End Class