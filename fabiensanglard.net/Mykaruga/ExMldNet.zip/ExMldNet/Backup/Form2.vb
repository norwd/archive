Imports WindowsApplication1.Form1
Imports WindowsApplication1.NJCM.Types
Imports WindowsApplication1.Multi

Public Class Form2
    Private InMode As Integer
    Private OutMode As Integer

    Private Sub SetOpenFileData()
        'Opens the Open File Dialog Box
        With OpenFileDialog1
            .Filter = "Ninja Model Files (*.nj)|*.nj|Skies of Arcadia MLD files (*.MLD)|*.mld"
            .FilterIndex = 2
            .InitialDirectory = Form1.InDir
            If .ShowDialog = Windows.Forms.DialogResult.OK Then
                Me.TextBox1.Text = .FileName
                InMode = .FilterIndex
                Form1.InDir = Strings.Mid(.FileName, 1, Strings.InStrRev(.FileName, "\") - 1)
            End If
        End With
    End Sub
    Private Sub SetSaveFileData()
        With SaveFileDialog1
            .Filter = "Raw Triangles (*.raw)|*.raw|Wavefront OBJ (*.OBJ|*.obj|Milkshape 3D ASCII(*.txt)|*.txt"
            .FilterIndex = 3
            .InitialDirectory = Form1.OutDir
            If .ShowDialog = Windows.Forms.DialogResult.OK Then
                Me.TextBox2.Text = .FileName
                OutMode = .FilterIndex
                Form1.OutDir = Strings.Mid(.FileName, 1, Strings.InStrRev(.FileName, "\") - 1)
            End If
        End With
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        SetOpenFileData()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        SetSaveFileData()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Do While TextBox1.Text = "" : SetOpenFileData() : Loop
        Do While TextBox2.Text = "" : SetSaveFileData() : Loop

        Form1.Verbosity = CheckBox1.Checked
        If CheckBox1.Checked Then
            If ComboBox1.SelectedIndex = -1 Then ComboBox1.SelectedIndex = 1
            Form1.VerbosityLevel = Val(ComboBox1.SelectedItem)
        Else
            Form1.VerbosityLevel = 0
        End If

        If TextBox3.Text = "" Then TextBox3.Text = "1"
        Dim MyScale As Integer = Int(Val(TextBox3.Text))
        If MyScale < 0 Then MyScale = 1
        Me.Hide()
        Cls()
        DoConversion(TextBox1.Text, TextBox2.Text, InMode, OutMode, MyScale)
        Application.DoEvents()
    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        ComboBox1.Visible = CheckBox1.Checked
        Label5.Visible = CheckBox1.Checked
    End Sub

End Class