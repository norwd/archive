rm /private/var/logs/dlci.h5-baseband*
rm /private/var/logs/commCenter.log
cp /System/Library/LaunchDaemons/com.apple.CommCenter.plist /System/Library/LaunchDaemons/com.apple.CommCenter.plist.vanilla
cp /tmp/com.apple.CommCenter.plist /System/Library/LaunchDaemons/com.apple.CommCenter.plist
launchctl unload -w /System/Library/LaunchDaemons/com.apple.CommCenter.plist
launchctl load -w /System/Library/LaunchDaemons/com.apple.CommCenter.plist
cp /System/Library/LaunchDaemons/com.apple.CommCenter.plist.vanilla /System/Library/LaunchDaemons/com.apple.CommCenter.plist
