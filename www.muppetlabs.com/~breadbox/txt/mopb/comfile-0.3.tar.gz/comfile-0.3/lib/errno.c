#include "libcom.h"

int errno = 0;
