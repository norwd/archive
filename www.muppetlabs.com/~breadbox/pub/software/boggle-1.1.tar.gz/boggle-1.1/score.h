/* (C) 1999 Brian Raiter (under the terms of the GPL) */

#ifndef	_score_h_
#define	_score_h_

/* Calculate the player's statistics.
 */
extern void scoregame(void);

/* Display the latest statistics.
 */
extern void reportscore(void);

#endif
