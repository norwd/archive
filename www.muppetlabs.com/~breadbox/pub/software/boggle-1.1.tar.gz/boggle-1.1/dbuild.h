/* (C) 1999 Brian Raiter (under the terms of the GPL) */

#ifndef	_dbuild_h_
#define	_dbuild_h_

/* Build a compressed dictionary file that contains the words listed
 * in the given files.
 */
extern int makedictfile(int filecount, char *files[]);

#endif
