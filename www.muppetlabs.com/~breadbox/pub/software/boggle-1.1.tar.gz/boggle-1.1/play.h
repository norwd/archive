/* (C) 1999 Brian Raiter (under the terms of the GPL) */

#ifndef	_play_h_
#define	_play_h_

/* Play the solitaire game.
 */
extern int playsolitaire(void);

#endif
