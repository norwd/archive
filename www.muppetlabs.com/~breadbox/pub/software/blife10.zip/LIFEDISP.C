/* lifedisp.c: Functions to manage the main window display.		*/
/*									*/
/* (C) 1997 by Brian Raiter, under the terms of the GNU General Public	*/
/* License ver. 2 (or any later version, if you like).			*/

#define	STRICT
#include	<windows.h>
#include	<windowsx.h>
#include	<stdlib.h>		/*  strtoul  */
#include	"life.h"
#include	"lifedisp.h"
#include	"lifecalc.h"
#include	"lifeclr.h"
#include	"lifemain.h"


#pragma warning(disable: 4100)

int			magnification = 1;
int			xOrg, yOrg;

/* INI file keys for the display settings. */
static const char	szIniKeySize[] = "wndpos";
static const char	szIniKeyMag[] = "mag";
static const char	*szIniKeyOrg[] = { "xorg", "yorg" };

/* Temporary holding areas for de-selected GDI objects. */
static HFONT		hfontSave;
static HPALETTE		hpalSave;
static HRGN		hrgnBkgnd;

/* Location of areas in the window. */
static RECT		rcWorld;
static RECT		rcGenTitle, rcGen, rcPopTitle, rcPop;

/* Y-coordinate of the top of the Life world display. */
static int		yScreen;

/* Top left coordinates of the visible Life world. */
static int		xPos, yPos;

/* Dimensions of the visible Life world. */
static int		cxScreen, cyScreen;

/* Dimensions of the visible Life world multiplied by the magnification. */
static int		cxScreenMag, cyScreenMag;

/* The BITMAPINFO structure used to turn the Life world into a DIB. */
static DIB256INFO	bmpiViewer = {
				sizeof(BITMAPINFOHEADER), 256, 0, 1, 8,
				0, 0, 0, 0, 0, 0
			};


/* Function to manage the main window. */
BOOL SetWindow(HWND	hwnd,
	       int	cx,
	       int	cy,
	       UINT	fAction)
{
	static HRGN	hrgnTemp1, hrgnTemp2;
	static int	cxMargin, cyMargin;
	static BOOL	bInitialized = FALSE;
	HDC		hdc;
	HFONT		hfont;
	WINDOWPLACEMENT	wndpl;
	RECT		rc;
	SIZE		size;
	char*		sz;
	int		cxClient = cx, cyClient = cy;
	int		cxTextDiff;
	int		cxStatLine, cyText;
	int		cxScroll, cyScroll;
	int		i;
	BOOL		bHorz, bVert;

	switch (fAction) {
		case SET_INIT:
		/* Calculate coordinates and sizes for most of the window
		   elements, including the main window itself. */

		hdc = GetDC(hwnd);
		hfont = SelectFont(hdc, GetStockFont(ANSI_VAR_FONT));
		GetTextExtentPoint(hdc, szBuffer, GetString(IDS_MAXWORDLEN),
									&size);
		cxStatLine = size.cx;
		GetTextExtentPoint(hdc, szBuffer, GetString(IDS_POP), &size);
		cxStatLine = max((int)cxStatLine, size.cx);
		GetTextExtentPoint(hdc, szBuffer, GetString(IDS_GEN), &size);
		cxStatLine = max((int)cxStatLine, size.cx);
		cyText = size.cy;
		cyMargin = cyText;
		cxMargin = MulDiv(cyMargin, GetDeviceCaps(hdc, ASPECTX),
					GetDeviceCaps(hdc, ASPECTY));
		SelectFont(hdc, hfont);
		ReleaseDC(hwnd, hdc);

		rcGenTitle.left = rcPopTitle.left =
				rcGen.left = rcPop.left = 0;
		rcGenTitle.right = rcPopTitle.right =
				rcGen.right = rcPop.right = cxStatLine;
		rcGenTitle.top = cyMargin;
		rcGen.top = rcGenTitle.bottom = rcGenTitle.top + cyText;
		rcPopTitle.top = rcGen.bottom = rcGen.top + cyText;
		rcPop.top = rcPopTitle.bottom = rcPopTitle.top + cyText;
		rcPop.bottom = rcPop.top + cyText;

		rcWorld.left = cxMargin;
		rcWorld.top = cyMargin;

		hrgnBkgnd = CreateRectRgn(0, 0, 0, 0);
		hrgnTemp1 = CreateRectRgn(0, 0, 0, 0);
		hrgnTemp2 = CreateRectRgn(0, 0, 0, 0);

		for (i = 0 ; i < 256 ; ++i)
			if (CellAlive(i))
				bmpiViewer.idx[i] = CellAlive(IChing[i]) ?
							EL_ALIVE : EL_DYING;
			else
				bmpiViewer.idx[i] = CellAlive(IChing[i]) ?
							EL_ZYGOTE : EL_DEAD;

		GetPrivateProfileString(szIniSubDisplay, szIniKeySize,
					"0,0,0,0", szBuffer, 64,
					szIniName);
		sz = szBuffer;
		for (i = 0 ; i < 4 ; ++i) {
			((int *)&rc)[i] = (int)strtoul(sz, &sz, 10);
			++sz;
		}
		bInitialized = TRUE;
		if (rc.left < rc.right && rc.top < rc.bottom)
			DeferWindowPos((HDWP)cx, hwnd, NULL, rc.left, rc.top,
					rc.right - rc.left, rc.bottom - rc.top,
					SWP_NOZORDER | SWP_NOACTIVATE);

		SetScrollRange(hwnd, SB_HORZ, 0, 0, FALSE);
		SetScrollRange(hwnd, SB_VERT, 0, 0, FALSE);
		break;

		case SET_ALTER:
		/* Calculate how much of the Life world is viewable, and
		   then the exact sizes and locations of all the window
		   elements. Determine the ranges of the scroll bars and
		   create the background HRGN. */

		if (cxClient != NIL && cyClient != NIL) {
			cxTextDiff = cxClient - cxMargin - rcPop.right;
			rcGenTitle.left += cxTextDiff;
			rcGenTitle.right += cxTextDiff;
			rcGen.left += cxTextDiff;
			rcGen.right += cxTextDiff;
			rcPopTitle.left += cxTextDiff;
			rcPopTitle.right += cxTextDiff;
			rcPop.left += cxTextDiff;
			rcPop.right += cxTextDiff;
			size.cx = rcPop.left - cxMargin - rcWorld.left;
			size.cy = cyClient - cyMargin - rcWorld.top;
		} else {
			GetClientRect(hwnd, &rc);
			size.cx = rcPop.left - cxMargin - rcWorld.left;
			size.cy = rc.bottom - cyMargin - rcWorld.top;
		}
		if (magnification) {
			cxScreen = min(cxField, size.cx / magnification);
			cyScreen = min(cyField, size.cy / magnification);
		} else {
			cxScreen = cxField;
			cyScreen = cyField;
		}
		yScreen = yPos + cyScreen;
		cxScreenMag = cxScreen * magnification;
		cyScreenMag = cyScreen * magnification;
		if (cxScreenMag < 0 || cyScreenMag < 0) {
			cxScreenMag = cyScreenMag = 0;
			rcWorld.right = rcWorld.left - 2;
			rcWorld.bottom = rcWorld.top - 2;
		} else {
			rcWorld.right = rcWorld.left + cxScreenMag;
			rcWorld.bottom = rcWorld.top + cyScreenMag;
		}

		cxScroll = cxField - cxScreen;
		cyScroll = cyField - cyScreen;
		GetScrollRange(hwnd, SB_VERT, &size.cx, &size.cy);
		bVert = size.cx < size.cy && !(size.cx == 0 && size.cy == 100);
		GetScrollRange(hwnd, SB_HORZ, &size.cx, &size.cy);
		bHorz = size.cx < size.cy && !(size.cx == 0 && size.cy == 100);
		if (bVert && cxScroll && !cyScroll) {
			if (cxScroll * magnification <
					GetSystemMetrics(SM_CXVSCROLL))
				cxScroll = 0;
		} else if (bHorz && !cxScroll && cyScroll) {
			if (cyScroll * magnification <
					GetSystemMetrics(SM_CYHSCROLL))
				cyScroll = 0;
		} else if (bVert && bHorz && cxScroll && cyScroll) {
			if (cxScroll * magnification <
					GetSystemMetrics(SM_CXVSCROLL) &&
					cyScroll * magnification <
						GetSystemMetrics(SM_CYHSCROLL))
				cxScroll = cyScroll = 0;
		}
		SetScrollRange(hwnd, SB_HORZ, -(cxScroll + 1) / 2,
						cxScroll / 2, TRUE);
		if ((cxScroll && !bHorz) || (!cxScroll && bHorz))
			break;
		SetScrollRange(hwnd, SB_VERT, -(cyScroll + 1) / 2,
						cyScroll / 2, TRUE);
		if ((cyScroll && !bVert) || (!cyScroll && bVert))
			break;

		if (cxClient != NIL && cyClient != NIL) {
			SetRectRgn(hrgnBkgnd, 0, 0, cxClient, cyClient);
			SetRectRgn(hrgnTemp2, rcGenTitle.left, rcGenTitle.top,
						rcPop.right, rcPop.bottom);
			SubtractRgn(hrgnTemp1, hrgnBkgnd, hrgnTemp2);
		}
		SetRectRgn(hrgnTemp2, rcWorld.left - 1, rcWorld.top - 1,
					rcWorld.right + 1, rcWorld.bottom + 1);
		SubtractRgn(hrgnBkgnd, hrgnTemp1, hrgnTemp2);
		SetRectRgn(hrgnTemp2, 0, 0, 0, 0);

		break;

		case SET_END:
		/* Clean up the HRGNs. */

		if (hrgnBkgnd)
			DeleteRgn(hrgnBkgnd);
		if (hrgnTemp1)
			DeleteRgn(hrgnTemp1);
		if (hrgnTemp2)
			DeleteRgn(hrgnTemp2);
		if (bInitialized) {
			wndpl.length = sizeof(WINDOWPLACEMENT);
			GetWindowPlacement(hwnd, &wndpl);
			wsprintf(szBuffer, "%d,%d,%d,%d",
						wndpl.rcNormalPosition);
			WritePrivateProfileString(szIniSubDisplay,
						szIniKeySize,
						szBuffer, szIniName);
		}
		break;
	}
	return TRUE;
}

/* Function to manage the viewable area of the Life world. */
BOOL SetView(HWND	hwnd,
	     int	xTo,
	     int	yTo,
	     UINT	fAction)
{
	static BOOL	bInitialized = FALSE;

	switch (fAction) {
		case SET_INIT:

		xOrg = GetPrivateProfileInt(szIniSubDisplay, szIniKeyOrg[0],
						0, szIniName);
		yOrg = GetPrivateProfileInt(szIniSubDisplay, szIniKeyOrg[1],
						0, szIniName);
		bInitialized = TRUE;
		break;

		case SET_ALTER:
		/* Change the coordinates of the viewable area, and update
		   the scroll bars. */

		if (xTo != GetScrollPos(hwnd, SB_HORZ)) {
			SetScrollPos(hwnd, SB_HORZ, xTo, TRUE);
			xOrg = GetScrollPos(hwnd, SB_HORZ);
		}
		if (yTo != -GetScrollPos(hwnd, SB_VERT)) {
			SetScrollPos(hwnd, SB_VERT, -yTo, TRUE);
			yOrg = -GetScrollPos(hwnd, SB_VERT);
		}
		xPos = xOrg + (cxField - cxScreen + 1) / 2;
		yPos = yOrg + (cyField - cyScreen) / 2;
		yScreen = yPos + cyScreen;
		break;

		case SET_END:

		if (bInitialized) {
			wsprintf(szBuffer, "%d", xOrg);
			WritePrivateProfileString(szIniSubDisplay,
							szIniKeyOrg[0],
							szBuffer, szIniName);
			wsprintf(szBuffer, "%d", yOrg);
			WritePrivateProfileString(szIniSubDisplay,
							szIniKeyOrg[1],
							szBuffer, szIniName);
		}
		break;

		
	}
	return TRUE;
}

/* Function to manage the level of magnification of the Life world display. */
BOOL SetMagnification(HWND	hwnd,
		      int	mag,
		      UINT	fAction)
{
	static BOOL	bInitialized = FALSE;

	switch (fAction) {
		case SET_INIT:

		magnification = GetPrivateProfileInt(szIniSubDisplay,
						szIniKeyMag, 1, szIniName);
		bInitialized = TRUE;
		break;

		case SET_ALTER:
		/* Change the magnification, and recalculate necessary
		   coordinates and sizes. */

		if (mag != NIL)
			magnification = mag;
		SetWindow(hwnd, NIL, NIL, SET_ALTER);
		SetView(hwnd, xOrg, yOrg, SET_ALTER);
		break;

		case SET_END:

		if (bInitialized) {
			wsprintf(szBuffer, "%d", magnification);
			WritePrivateProfileString(szIniSubDisplay,
							szIniKeyMag,
							szBuffer, szIniName);
		}
		break;
	}
	return TRUE;
}

/* "Friend function" called by SetSpace in lifecalc.c when the size of the
   Life world changes. */
void SetDisplaySpace(int	cx,
		     int	cy,
		     UINT	fAction)
{
	if (cy != NIL && fAction != SET_END)
		bmpiViewer.bmih.biHeight = cy;
}

/* A simple utoa function. Returns the number of characters written. */
static int __fastcall utosz(UINT	val,
			    char	*szOut)
{
	char	*sz;
	char	ch;

	sz = szOut;
	do {
		*sz++ = (char)(val % 10 + '0');
		val /= 10;
	} while (val);
	val = sz - szOut;
	*sz-- = '\0';
	while (sz > szOut) {
		ch = *sz;
		*sz-- = *szOut;
		*szOut++ = ch;
	}
	return val;
}

/* Prepare the given HDC for painting the main window. */
void PrepPaint(HDC	hdc)
{
	hpalSave = SelectPalette(hdc, hpalWnd, FALSE);
	RealizePalette(hdc);
	hfontSave = SelectFont(hdc, GetStockFont(ANSI_VAR_FONT));
	SetTextColor(hdc, PALETTEINDEX(EL_TEXT));
	SetBkColor(hdc, PALETTEINDEX(EL_BKGND));
	SetTextAlign(hdc, TA_RIGHT);
}

/* Clean up the HDC after calling PrepPaint. */
void FinishPaint(HDC	hdc)
{
	SelectFont(hdc, hfontSave);
	SelectPalette(hdc, hpalSave, FALSE);
}

/* Paint the static elements in the main window. */
void DoWindowDressing(HDC	hdc)
{
	HPEN	hpen;
	HBRUSH	hbrush;
	int	fAlign;

	RealizePalette(hdc);
	FillRgn(hdc, hrgnBkgnd, hbrushBkgnd);
	hpen = SelectPen(hdc, hpenRect);
	hbrush = SelectBrush(hdc, GetStockBrush(NULL_BRUSH));
	Rectangle(hdc, rcWorld.left - 1, rcWorld.top - 1,
			rcWorld.right + 1, rcWorld.bottom + 1);
	SelectPen(hdc, hpen);
	SelectBrush(hdc, hbrush);
	fAlign = SetTextAlign(hdc, TA_LEFT);
	ExtTextOut(hdc, rcGenTitle.left, rcGenTitle.top, ETO_OPAQUE,
			&rcGenTitle, szBuffer, GetString(IDS_GEN), NULL);
	ExtTextOut(hdc, rcPopTitle.left, rcPopTitle.top, ETO_OPAQUE,
			&rcPopTitle, szBuffer, GetString(IDS_POP), NULL);
	SetTextAlign(hdc, fAlign);
}

/* Paint the Life world display, and the population and generation count. */
void __fastcall TickUpdate(HDC	hdc)
{
	if (bBackground)
		if (RealizePalette(hdc))
			DoWindowDressing(hdc);

	if (magnification == 1)
		SetDIBitsToDevice(hdc, rcWorld.left, rcWorld.top,
				cxScreen, cyScreen, xPos, yPos,
				0, cyField, lpWorld, (LPBITMAPINFO)&bmpiViewer,
				DIB_PAL_COLORS);
	else if (magnification > 1)
		StretchDIBits(hdc, rcWorld.left, rcWorld.top,
				cxScreenMag, cyScreenMag,
				xPos, yPos, cxScreen, cyScreen,
				lpWorld, (LPBITMAPINFO)&bmpiViewer,
				DIB_PAL_COLORS, SRCCOPY);

	ExtTextOut(hdc, rcGen.right, rcGen.top, ETO_OPAQUE, &rcGen,
			szBuffer, utosz(generation, szBuffer), NULL);
	ExtTextOut(hdc, rcPop.right, rcPop.top, ETO_OPAQUE, &rcPop,
			szBuffer, utosz(population, szBuffer), NULL);
}

/* Paint the Life world display, and the population and generation count,
   when the Life world clock is running in Overdrive. */
void __fastcall TickUpdateOverdrive(HDC	hdc)
{
	int	yBltFirst = max(yPos, yFirst),
		yBltLast = min(yScreen, yFirst + cyActive),
		cyBlt = yBltLast - yBltFirst,
		yBltScreen = yScreen - yBltLast;

	if (bBackground)
		if (RealizePalette(hdc))
			DoWindowDressing(hdc);

	if (magnification == 1)
		SetDIBitsToDevice(hdc, rcWorld.left, rcWorld.top + yBltScreen,
				cxScreen, cyBlt, xPos, yBltFirst,
				0, cyField, lpWorld, (LPBITMAPINFO)&bmpiViewer,
				DIB_PAL_COLORS);
	else if (magnification > 1)
		StretchDIBits(hdc, rcWorld.left,
				rcWorld.top + yBltScreen * magnification,
				cxScreenMag, cyBlt * magnification,
				xPos, yBltFirst, cxScreen, cyBlt,
				lpWorld, (LPBITMAPINFO)&bmpiViewer,
				DIB_PAL_COLORS, SRCCOPY);

	ExtTextOut(hdc, rcGen.right, rcGen.top, ETO_OPAQUE, &rcGen,
			szBuffer, utosz(generation, szBuffer), NULL);
	ExtTextOut(hdc, rcPop.right, rcPop.top, ETO_OPAQUE, &rcPop,
			szBuffer, utosz(population, szBuffer), NULL);
}

/* Repaint the Life world display after a change of the view. */
void ViewPaint(HWND	hwnd)
{
	HDC		hdc;
	HPALETTE	hpal;

	hdc = GetDC(hwnd);
	hpal = SelectPalette(hdc, hpalWnd, FALSE);
	RealizePalette(hdc);
	if (magnification == 1)
		SetDIBitsToDevice(hdc, rcWorld.left, rcWorld.top,
				cxScreen, cyScreen, xPos, yPos,
				0, cyField, lpWorld, (LPBITMAPINFO)&bmpiViewer,
				DIB_PAL_COLORS);
	else if (magnification > 1)
		StretchDIBits(hdc, rcWorld.left, rcWorld.top,
				cxScreenMag, cyScreenMag,
				xPos, yPos, cxScreen, cyScreen,
				lpWorld, (LPBITMAPINFO)&bmpiViewer,
				DIB_PAL_COLORS, SRCCOPY);
	SelectPalette(hdc, hpal, FALSE);
	ReleaseDC(hwnd, hdc);
}
