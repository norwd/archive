/* lifeio.c: Functions to load and save Life worlds in various forms.	*/
/*									*/
/* (C) 1997 by Brian Raiter, under the terms of the GNU General Public	*/
/* License ver. 2 (or any later version, if you like).			*/

#define	STRICT
#include	<windows.h>
#include	<windowsx.h>
#include	<stdio.h>		/*  sscanf  */
#include	<string.h>		/*  _fmemcpy & _fmemset  */
#include	"life.h"
#include	"lifeio.h"
#include	"lifegen.h"
#include	"lifemain.h"


/* Copy the current Life world into a new DIB. */
static LPBITMAPINFO AllocTempWorldInfo(int	cyWorld)
{
	LPBITMAPINFO	lpbmpinfo;
	int		i;

	lpbmpinfo = GlobalAllocPtr(GHND, sizeof(BITMAPINFOHEADER) +
						256 * sizeof(RGBQUAD));
	lpbmpinfo->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	lpbmpinfo->bmiHeader.biWidth = 256;
	lpbmpinfo->bmiHeader.biHeight = cyWorld;
	lpbmpinfo->bmiHeader.biPlanes = 1;
	lpbmpinfo->bmiHeader.biBitCount = 8;
	for (i = 0 ; i < 256 ; ++i)
		if (!CellAlive(i))
			lpbmpinfo->bmiColors[i].rgbRed =
				lpbmpinfo->bmiColors[i].rgbBlue =
				lpbmpinfo->bmiColors[i].rgbGreen = 255;
	return lpbmpinfo;
}

/* Copy a given DIB to a DIB appropriate to the Life world (256 pixels
   across, 8 bit color, IChing palette). */
static LPBITMAPINFO FormatifyDIB(LPBITMAPINFO	lpDIBIn,
				 LPVOID		lpDIBitsIn,
				 int		cxDIB,
				 int		cyDIB,
				 LPLPVOID	lplpDIBitsOut,
				 LPDWORD	lpcbDIB)
{
	HDC		hmdcDIBOut;
	LPBITMAPINFO	lpDIBOut;
	LPRGBQUAD	lpColorsOut;
	int		i;

	lpDIBOut = CreateDIB(256, cyDIB, 8, NULL,
				&lpColorsOut, lplpDIBitsOut, lpcbDIB);
	for (i = 0 ; i < 256 ; ++i)
		if (!CellAlive(i))
			lpColorsOut[i].rgbRed =
				lpColorsOut[i].rgbGreen =
				lpColorsOut[i].rgbBlue = 255;

	hmdcDIBOut = CreateDC("DIB", NULL, NULL, lpDIBOut);
	StretchDIBits(hmdcDIBOut, 0, 0, cxDIB, cyDIB, 0, 0, cxDIB, cyDIB,
				lpDIBitsIn, lpDIBIn, DIB_RGB_COLORS, SRCCOPY);
	DeleteDC(hmdcDIBOut);
	return lpDIBOut;
}

/* Copy a DIB in the Life world format into a generic DIB, without the extra
   margins and using the native color scheme. */
static LPBITMAPINFO NativifyDIB(LPBITMAPINFO	lpDIBIn,
				LPVOID		lpDIBitsIn,
				int		cxDIB,
				int		cyDIB,
				LPLPVOID	lplpDIBitsOut,
				LPDWORD		lpcbDIB)
{
	HDC		hdc, hmdcDIBOut;
	LPBITMAPINFO	lpDIBOut;

	hdc = GetDC(NULL);
	lpDIBOut = CreateDIB(cxDIB, cyDIB, 0, hdc,
				NULL, lplpDIBitsOut, lpcbDIB);
	ReleaseDC(NULL, hdc);
	if (!lpDIBOut)
		return NULL;
	hmdcDIBOut = CreateDC("DIB", NULL, NULL, lpDIBOut);
	StretchDIBits(hmdcDIBOut, 0, 0,	cxDIB, cyDIB, 0, 0, cxDIB, cyDIB,
				lpDIBitsIn, lpDIBIn, DIB_RGB_COLORS, SRCCOPY);
	DeleteDC(hmdcDIBOut);
	return lpDIBOut;
}

/* Copy the Life world DIB into a generic DIB. */
static LPVOID WorldToDIB(LPWORLD	lpWorld,
			 int		cxWorld,
			 int		cyWorld,
			 LPLPVOID	lplpDIBits,
			 LPDWORD	lpcbDIB)
{
	LPBITMAPINFO	lpDIBInfoWorld, lpDIBNative;

	lpDIBInfoWorld = AllocTempWorldInfo(cyWorld);
	lpDIBNative = NativifyDIB(lpDIBInfoWorld, lpWorld, cxWorld, cyWorld,
					lplpDIBits, lpcbDIB);
	(void)GlobalFreePtr(lpDIBInfoWorld);
	return lpDIBNative;
}

/* Copy a given DIB into the Life world DIB. */
static BOOL DIBToWorld(LPVOID	lpDIB,
		       LPWORLD	lpWorld,
		       LPINT	lpcxWorld,
		       LPINT	lpcyWorld)
{
	LPBITMAPINFO	lpDIBTemp;
	LPVOID		lpDIBits, lpDIBitsTemp;
	int		cxDIB, cyDIB;

	if (*(LPDWORD)lpDIB == sizeof(BITMAPINFOHEADER)) {
		LPBITMAPINFO	lpDIBInfo = (LPBITMAPINFO)lpDIB;

		cxDIB = (int)lpDIBInfo->bmiHeader.biWidth;
		cyDIB = (int)lpDIBInfo->bmiHeader.biHeight;
		if (lpDIBInfo->bmiHeader.biClrUsed)
			lpDIBits = lpDIBInfo->bmiColors +
					lpDIBInfo->bmiHeader.biClrUsed;
		else if (lpDIBInfo->bmiHeader.biBitCount == 24)
			lpDIBits = lpDIBInfo->bmiColors;
		else
			lpDIBits = lpDIBInfo->bmiColors + (1 <<
					lpDIBInfo->bmiHeader.biBitCount);
	} else if (*(LPDWORD)lpDIB == sizeof(BITMAPCOREHEADER)) {
		LPBITMAPCOREINFO	lpDIBInfo = (LPBITMAPCOREINFO)lpDIB;

		cxDIB = lpDIBInfo->bmciHeader.bcWidth;
		cyDIB = lpDIBInfo->bmciHeader.bcHeight;
		if (lpDIBInfo->bmciHeader.bcBitCount == 24)
			lpDIBits = lpDIBInfo->bmciColors;
		else
			lpDIBits = lpDIBInfo->bmciColors + (1 <<
					lpDIBInfo->bmciHeader.bcBitCount);
	} else
		return FALSE;

	cxDIB = minmax(MIN_WORLDSIDE, cxDIB, MAX_WORLDSIDE);
	cyDIB = minmax(MIN_WORLDSIDE, cyDIB, MAX_WORLDSIDE);
	lpDIBTemp = FormatifyDIB(lpDIB, lpDIBits, cxDIB, cyDIB,
						&lpDIBitsTemp, NULL);
	if (!lpDIBTemp)
		return FALSE;

	hmemcpy(lpWorld, lpDIBitsTemp, 256L * cyDIB);
	(void)GlobalFreePtr(lpDIBTemp);
	if (lpcxWorld)
		*lpcxWorld = cxDIB;
	if (lpcyWorld)
		*lpcyWorld = cyDIB;
	return TRUE;
}

/* Translate the Life world into a text file, using the Life picture format. */
static void WorldToTextFile(HFILE	hfile,
			    LPWORLD	lpWorld,
			    int		cxWorld,
			    int		cyWorld)
{
	UINT		cbSpace;
	int		i, j;
	int		yTop, yBottom, xLeft;
	const char	cAlive = '*', cEmpty = ' ';

	yTop = 0;
	yBottom = cyWorld;
	xLeft = cxWorld;
	for (j = cyWorld - 1 ; j >= 0 ; --j) {
		for (i = 0 ; i < cxWorld && !CellAlive(lpWorld[j][i]) ; ++i) ;
		if (i < cxWorld) {
			if (yBottom > yTop)
				yTop = j;
			yBottom = j;
		}
		xLeft = min(xLeft, i);
	}
	if (yBottom == yTop)
		return;
	_lwrite(hfile, szBuffer,
			wsprintf(szBuffer, "#BLife -d %d,%d\n#P %d %d\n",
					cxWorld, cyWorld, xLeft - cxWorld / 2,
					cyWorld / 2 - yTop));
	for (i = 0 ; i < 256 ; ++i)
		szBuffer[i] = cEmpty;
	for (j = yTop ; j >= yBottom ; --j) {
		cbSpace = 0;
		for (i = xLeft ; i < cxWorld ; ++i) {
			if (CellAlive(lpWorld[j][i])) {
				szBuffer[cbSpace] = cAlive;
				_lwrite(hfile, szBuffer, cbSpace + 1);
				szBuffer[cbSpace] = cEmpty;
				cbSpace = 0;
			} else
				++cbSpace;
		}
		_lwrite(hfile, "\n", 1);
	}
}

/* Read one text line in from a file. If the line is too long, discard
   the remainder. */
static int ReadLine(HFILE	hfile,
		    LPSTR	lpsz,
		    int		nMax,
		    BOOL*	pbEOF)
{
	static char	szTemp[260];
	char*		sz;
	int		cbLine, cb;

	cb = _lread(hfile, szTemp, sizeof szTemp - 1);
	if (!cb) {
		*pbEOF = TRUE;
		return 0;
	}
	szTemp[cb] = '\0';
	sz = strchr(szTemp, '\n');
	if (sz) {
		cbLine = sz - szTemp;
		while (cbLine && lpsz[cbLine - 1] == '\r')
			--cbLine;
		_fmemcpy(lpsz, szTemp, cbLine);
	} else {
		cbLine = nMax - 1;
		if (cbLine > cb)
			cbLine = cb;
		_fmemcpy(lpsz, szTemp, cbLine);
		do {
			cb = _lread(hfile, szTemp, sizeof szTemp);
			sz = strchr(szTemp, '\n');
		} while (cb && !sz);
	}
	if (sz) {
		cb -= sz - szTemp + 1;
		if (cb > 0)
			_llseek(hfile, -cb, SEEK_CUR);
	}
	lpsz[cbLine] = '\0';
	return cbLine;
}

/* Read a text file containing a Life pattern in the Hensel file format. */
static BOOL TextFileToWorld(HFILE	hfile,
			    LPWORLD	lpWorld,
			    LPINT	lpcxWorld,
			    LPINT	lpcyWorld)
{
	char	*sz;
	int	cxWorld, cyWorld, xCenter, yCenter;
	int	i, j, n, cb;
	BOOL	bPicture = FALSE, bEOF = FALSE;

	cb = ReadLine(hfile, szBuffer, sizeof szBuffer, &bEOF);
	if (bEOF || !cb)
		return FALSE;
	cxWorld = MAX_WORLDSIDE;
	cyWorld = MAX_WORLDSIDE;
	if (!strncmp(szBuffer, "#BLife", 6)) {
		sz = strchr(szBuffer + 6, '-');
		while (sz) {
			if (sscanf(sz, "-d %d,%d", &cxWorld, &cyWorld) == 2)
				break;
			sz = strchr(sz + 1, '-');
		}
	} else
		_llseek(hfile, 0, SEEK_SET);
	if (cxWorld < MIN_WORLDSIDE || cxWorld > MAX_WORLDSIDE ||
			cyWorld < MIN_WORLDSIDE || cyWorld > MAX_WORLDSIDE)
		return FALSE;

	for (j = 0 ; j < cyWorld ; ++j)
		_fmemset(lpWorld[j], MakeCell(FALSE, 0, 0), cxWorld);

	i = xCenter = cxWorld / 2;
	j = yCenter = cyWorld / 2;
	cb = ReadLine(hfile, szBuffer, sizeof szBuffer, &bEOF);
	while (!bEOF) {
		if (szBuffer[0] == '#') {
			switch (szBuffer[1]) {
				case 'P':
				case 'p':

				i = j = 0;
				sscanf(szBuffer + 2, "%d%*[, ]%d", &i, &j);
				i += xCenter;
				j = yCenter - j;
				bPicture = TRUE;
				break;

				case 'A':
				case 'R':
				bPicture = FALSE;
				break;

				default:
				break;
			}
		} else if (bPicture) {
			if (j >= 0 && j < cyWorld) {
				sz = szBuffer;
				for (n = i ; *sz && n < cxWorld ; ++sz) {
					switch (*sz) {
						case '\t':

						n += 8 - ((sz - szBuffer) & 7);
						break;

						case '*':
						case 'O':
						case 'o':
						case '#':

						lpWorld[j][n++] =
							MakeCell(TRUE, 0, 0);
						break;

						case '.':
						case ' ':
						case 'b':

						++n;
						break;
					}
				}
			}
			--j;
		} else {
			if (sscanf(szBuffer, "%d%*[, ]%d", &i, &j) == 2) {
				i += xCenter;
				j = yCenter - j;
				if (i >= 0 && i < cxWorld &&
						j >= 0 && j < cyWorld)
					lpWorld[j][i] = MakeCell(TRUE, 0, 0);
			} else
				break;
		}
		cb = ReadLine(hfile, szBuffer, sizeof szBuffer, &bEOF);
	}
	*lpcxWorld = cxWorld;
	*lpcyWorld = cyWorld;
	return TRUE;
}

/* Copy the Life world into a DIB and an HBITMAP on the clipboard. */
BOOL WorldToClipboard(LPWORLD	lpWorld,
		      int	cxWorld,
		      int	cyWorld)
{
	HBITMAP	hbmpClip;
	HGLOBAL	hgmemClip;
	LPVOID	lpDIBClip, lpDIBitsClip;

	lpDIBClip = WorldToDIB(lpWorld, cxWorld, cyWorld, &lpDIBitsClip, NULL);
	if (!lpDIBClip)
		return FALSE;
	hbmpClip = NativeDIBToBitmap(lpDIBClip, lpDIBitsClip);
	if (!hbmpClip)
		return FALSE;
	hgmemClip = GlobalPtrHandle(lpDIBClip);
	GlobalUnlock(hgmemClip);
	EmptyClipboard();
	if (!SetClipboardData(CF_DIB, hgmemClip)) {
		GlobalFree(hgmemClip);
		return FALSE;
	}
	if (!SetClipboardData(CF_BITMAP, hbmpClip)) {
		DeleteBitmap(hbmpClip);
		return FALSE;
	}
	return TRUE;
}

/* Paste either a DIB or an HBITMAP on the clipboard into the Life world. */
BOOL ClipboardToWorld(LPWORLD	lpWorld,
		      LPINT	lpcxWorld,
		      LPINT	lpcyWorld)
{
	HBITMAP	hbmpClip;
	HGLOBAL	hgmemClip;
	LPVOID	lpDIBClip;
	BOOL	bRet;

	if (IsClipboardFormatAvailable(CF_DIB)) {
		hgmemClip = GetClipboardData(CF_DIB);
		lpDIBClip = GlobalLock(hgmemClip);
		if (!lpDIBClip)
			return FALSE;
		bRet = DIBToWorld(lpDIBClip, lpWorld, lpcxWorld, lpcyWorld);
		GlobalUnlock(hgmemClip);
		if (!bRet)
			return FALSE;
	} else if (IsClipboardFormatAvailable(CF_BITMAP)) {
		hbmpClip = GetClipboardData(CF_BITMAP);
		if (!hbmpClip)
			return FALSE;
		lpDIBClip = NativeBitmapToDIB(hbmpClip, NULL);
		if (!lpDIBClip)
			return FALSE;
		bRet = DIBToWorld(lpDIBClip, lpWorld, lpcxWorld, lpcyWorld);
		(void)GlobalFreePtr(lpDIBClip);
		if (!bRet)
			return FALSE;
	} else
		return FALSE;
	return TRUE;
}

/* Write out the Life world to a file. */
BOOL WorldToFile(HFILE		hfile,
		 UINT		nExtType,
		 LPWORLD	lpWorld,
		 int		cxWorld,
		 int		cyWorld)
{
	LPVOID	lpDIB;
	DWORD	cbDIB;

	if (nExtType == EXT_BMP) {
		lpDIB = WorldToDIB(lpWorld, cxWorld, cyWorld, NULL, &cbDIB);
		if (!lpDIB)
			return FALSE;
		DIBToFile(hfile, lpDIB, cbDIB);
		(void)GlobalFreePtr(lpDIB);
	} else
		WorldToTextFile(hfile, lpWorld, cxWorld, cyWorld);
	return TRUE;
}

/* Read a file into the Life world. */
BOOL FileToWorld(LPWORLD	lpWorld,
		 LPINT		lpcxWorld,
		 LPINT		lpcyWorld,
		 HFILE		hfile,
		 UINT		nExtType)
{
	LPVOID	lpDIB;

	if (nExtType == EXT_BMP) {
		lpDIB = FileToDIB(hfile, NULL, NULL);
		if (!lpDIB)
			return FALSE;
		DIBToWorld(lpDIB, lpWorld, lpcxWorld, lpcyWorld);
		(void)GlobalFreePtr(lpDIB);
		return TRUE;
	} else 
		return TextFileToWorld(hfile, lpWorld, lpcxWorld, lpcyWorld);
}
