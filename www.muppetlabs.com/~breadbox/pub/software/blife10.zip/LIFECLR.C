/* lifeclr.c: The color management and palette-handling functions.	*/
/*									*/
/* (C) 1997 by Brian Raiter, under the terms of the GNU General Public	*/
/* License ver. 2 (or any later version, if you like).			*/

#define	STRICT
#include	<windows.h>
#include	<windowsx.h>
#include	<stdlib.h>
#include	"life.h"
#include	"lifeclr.h"
#include	"lifegen.h"
#include	"lifectl.h"
#include	"lifemain.h"


#pragma warning(disable: 4100)

/* Flags for each section of the Set Color dialog box. */
#define	SCD_RGB		0x0001
#define	SCD_HLS		0x0002
#define	SCD_COLOR	0x0004

/* Data maintained during the Set Color dialog box. */
typedef	struct tagCLRPALDATA {
		PALETTEENTRY	palEl[NUM_ELS];
		LPPALETTEENTRY	lppalOrig;
		int		idxEl;
	} CLRPALDATA, FAR* LPCLRPALDATA;

HBRUSH			hbrushBkgnd;
HPEN			hpenRect;
HPALETTE		hpalWnd;

/* INI file section and key names. */
static const char	szIniKeyPaletted[] = "custom";
static const char	*szIniKeyColor[NUM_ELS] = { "bkgnd", "frame", "text",
							"empty", "alive",
							"zygote", "dying" };

/* A copy of the main window handle. */
static HWND		hwndMain;

/* The logical palette used to construct hpalWnd. */
static LOGPALETTE*	plogpalWnd = NULL;

/* Non-zero if we are using palette capabilities. */
static BOOL		bPaletted;


/* This function is called whenever part of the Set Color dialog box
   changes. All other parts, and possibly the main window, is updated to
   reflect the change. The fUpdate parameter indicates which sections
   need to be updated. */
static void UpdateColor(HWND		hdlg,
			LPPALETTEENTRY	lppalent,
			int		idxNew,
			UINT		fUpdate)
{
	HDC		hdc;
	HPALETTE	hpal;
	COLOR		color;
	int		i = 0;

	if (fUpdate & SCD_RGB) {
		i = lppalent[idxNew].peRed;
		SetScrollPos(GetDlgItem(hdlg, IDC_RED), SB_CTL, i, TRUE);
		SetDlgItemInt(hdlg, IDC_RVAL, i, FALSE);
		i = lppalent[idxNew].peGreen;
		SetScrollPos(GetDlgItem(hdlg, IDC_GRN), SB_CTL, i, TRUE);
		SetDlgItemInt(hdlg, IDC_GVAL, i, FALSE);
		i = lppalent[idxNew].peBlue;
		SetScrollPos(GetDlgItem(hdlg, IDC_BLU), SB_CTL, i, TRUE);
		SetDlgItemInt(hdlg, IDC_BVAL, i, FALSE);
	}
	if (fUpdate & SCD_HLS) {
		color.pal = lppalent[idxNew];
		color.pal.peFlags = 0;
		color = RGBtoHLS(color);
		i = color.hls.h;
		SetScrollPos(GetDlgItem(hdlg, IDC_HUE), SB_CTL, i, TRUE);
		SetDlgItemInt(hdlg, IDC_HVAL, i, FALSE);
		i = color.hls.l;
		SetScrollPos(GetDlgItem(hdlg, IDC_LUM), SB_CTL, i, TRUE);
		SetDlgItemInt(hdlg, IDC_LVAL, i, FALSE);
		i = color.hls.s;
		SetScrollPos(GetDlgItem(hdlg, IDC_SAT), SB_CTL, i, TRUE);
		SetDlgItemInt(hdlg, IDC_SVAL, i, FALSE);
	}
	if (fUpdate & SCD_COLOR)
		SendDlgItemMessage(hdlg, IDC_COLOR, CLRM_SETINDEX,
						idxNew, TRUE);

	if (bPaletted) {
		hdc = GetDC(hdlg);
		hpal = SelectPalette(hdc, hpalWnd, FALSE);
		RealizePalette(hdc);
		AnimatePalette(hpalWnd, idxNew, 1, &lppalent[idxNew]);
		SelectPalette(hdc, hpal, FALSE);
		ReleaseDC(hdlg, hdc);
			if (i != idxNew)
				InvalidateRect(GetDlgItem(hdlg, IDC_COLOR),
						NULL, TRUE);
	} else {
		hdc = GetDC(hdlg);
		color.pal = lppalent[idxNew];
		i = color.pal.peFlags;
		color.pal.peFlags = 0;
		color.ref = GetNearestColor(hdc, color.ref);
		color.pal.peFlags = (BYTE)i;
		SetColor(&color.pal, idxNew, SET_ALTER);
		ReleaseDC(hdlg, hdc);
		InvalidateRect(hwndMain, NULL, TRUE);
		InvalidateRect(GetDlgItem(hdlg, IDC_COLOR), NULL, TRUE);
		UpdateWindow(GetDlgItem(hdlg, IDC_COLOR));
	}
}

/* This function is called whenever one of the scrollbars in the Set Color
   dialog box sends a notification code. It computes what the new color
   for the current element should be. Returns zero if the color did not
   actually change. */
static BOOL ScrollColor(HWND		hdlg,
			HWND		hwndScroll,
			UINT		idScroll,
			UINT		nScrollCmd,
			int		nScrollPos,
			UINT		fScheme,
			LPPALETTEENTRY	lppalent)
{
	HDC	hdc;
	COLOR	color, colorRGB, colorTemp;
	UINT	idBase;
	int	idxVal;
	int	i, m, n;
	BOOL	bRet;

	if (nScrollCmd == SB_THUMBPOSITION || nScrollCmd == SB_ENDSCROLL)
		return FALSE;

	n = GetScrollPos(hwndScroll, SB_CTL);
	idBase = fScheme == SCD_RGB ? IDC_RED : IDC_HUE;
	idxVal = idScroll - idBase;
	color.val[0] = (BYTE)GetScrollPos(GetDlgItem(hdlg, idBase + 0),
						SB_CTL);
	color.val[1] = (BYTE)GetScrollPos(GetDlgItem(hdlg, idBase + 1),
						SB_CTL);
	color.val[2] = (BYTE)GetScrollPos(GetDlgItem(hdlg, idBase + 2),
						SB_CTL);
	color.val[3] = 0;

	switch (nScrollCmd) {
		case SB_LINEDOWN:	i = 0;	m = min(n + 1, 255);	break;
		case SB_LINEUP:		i = 0;	m = max(0, n - 1);	break;
		case SB_PAGEDOWN:	i = +1;	m = min(n + 16, 255);	break;
		case SB_PAGEUP:		i = -1;	m = max(0, n - 16);	break;
		case SB_BOTTOM:		i = 0;	m = 255;		break;
		case SB_TOP:		i = 0;	m = 0;			break;
		case SB_THUMBTRACK:	i = 0;	m = nScrollPos;		break;
		default:		return FALSE;
	}
	bRet = TRUE;
	if (!i || bPaletted) {
		if (m == n)
			return FALSE;

		color.val[idxVal] = (BYTE)m;
		if (fScheme == SCD_RGB)
			colorRGB = color;
		else
			colorRGB = HLStoRGB(color);
		
		if (!bPaletted) {
			hdc = GetDC(hdlg);
			colorRGB.ref = GetNearestColor(hdc, colorRGB.ref);
			ReleaseDC(hdlg, hdc);
			if (colorRGB.rgb.r == lppalent->peRed &&
					colorRGB.rgb.g == lppalent->peGreen &&
					colorRGB.rgb.b == lppalent->peBlue)
				bRet = FALSE;
			else
				if (fScheme == SCD_RGB)
					color = colorRGB;
				else
					color = RGBtoHLS(colorRGB);
		}
	} else {
		if (fScheme == SCD_RGB)
			colorRGB = color;
		else
			colorRGB = HLStoRGB(color);

		hdc = GetDC(hdlg);
		bRet = FALSE;
		for (m = n + i ; m >= 0 && m <= 255 ; m += i) {
			color.val[idxVal] = (BYTE)minmax(0, m, 255);
			if (fScheme == SCD_RGB)
				colorRGB = color;
			else
				colorRGB = HLStoRGB(color);
			colorRGB.ref = GetNearestColor(hdc, colorRGB.ref);
			if (colorRGB.rgb.r != lppalent->peRed ||
					colorRGB.rgb.g != lppalent->peGreen ||
					colorRGB.rgb.b != lppalent->peBlue) {
				if (!bRet) {
					bRet = TRUE;
					if (fScheme == SCD_RGB) {
						n = colorRGB.val[idxVal];
						color.val[idxVal] = (BYTE)n;
						colorTemp.ref =
							GetNearestColor(hdc,
								color.ref);
					} else {
						colorTemp = RGBtoHLS(colorRGB);
						n = colorTemp.val[idxVal];
						color.val[idxVal] = (BYTE)n;
						colorTemp = HLStoRGB(color);
						colorTemp.ref =
							GetNearestColor(hdc,
								colorTemp.ref);
					}
					if (colorTemp.ref == colorRGB.ref) {
						m = n;
						break;
					}
					n = m;
					lppalent->peRed = colorRGB.pal.peRed;
					lppalent->peGreen =
							colorRGB.pal.peGreen;
					lppalent->peBlue = colorRGB.pal.peBlue;
				} else {
					m = (m + n) / 2;
					colorRGB.pal.peRed = lppalent->peRed;
					colorRGB.pal.peGreen =
							lppalent->peGreen;
					colorRGB.pal.peBlue = lppalent->peBlue;
					break;
				}
			} else {
				if (fScheme == SCD_RGB) {
					if (colorRGB.ref == color.ref)
						break;
				} else {
					if ((RGBtoHLS(colorRGB)).ref ==
								color.ref)
						break;
				}
			}
		}
		ReleaseDC(hdlg, hdc);
		if (bRet)
			if (fScheme == SCD_RGB)
				color = colorRGB;
			else
				color = RGBtoHLS(colorRGB);
	}
	SetScrollPos(hwndScroll, SB_CTL, m, TRUE);
	if (!bRet)
		return FALSE;
	SetDlgItemInt(hdlg, idBase + IDC_SCRLVALDIFF + 0, color.val[0], FALSE);
	SetDlgItemInt(hdlg, idBase + IDC_SCRLVALDIFF + 1, color.val[1], FALSE);
	SetDlgItemInt(hdlg, idBase + IDC_SCRLVALDIFF + 2, color.val[2], FALSE);
	lppalent->peRed = colorRGB.pal.peRed;
	lppalent->peGreen = colorRGB.pal.peGreen;
	lppalent->peBlue = colorRGB.pal.peBlue;
	return TRUE;
}


/* This function manages the current palette of colors. */
BOOL SetColor(LPPALETTEENTRY	lppalentIn,
	      int		idxEl,
	      UINT		fAction)
{
	static BOOL	bInitialized = FALSE;
	HDC		hdc;
	COLOR		color;
	int		i;

	switch (fAction) {
		case SET_INIT:
		/* Create the palette of colors, one for each element on
		   the screen. */

		plogpalWnd = malloc(sizeof(LOGPALETTE) +
					NUM_ELS * sizeof(PALETTEENTRY));
		plogpalWnd->palVersion = 0x0300;
		plogpalWnd->palNumEntries = NUM_ELS;
		if (bPalatable) {
			bPaletted = GetPrivateProfileInt(szIniSubColor,
							szIniKeyPaletted,
							FALSE, szIniName);
			CheckMenuItem(hmenuBar, IDM_PALETTED, bPaletted ?
						MF_CHECKED : MF_UNCHECKED);
		} else {
			bPaletted = FALSE;
			EnableMenuItem(hmenuBar, IDM_PALETTED, MF_DISABLED);
		}
		hdc = GetDC(NULL);
		for (i = 0 ; i < NUM_ELS ; ++i) {
			GetPrivateProfileString(szIniSubColor,
						szIniKeyColor[i], "",
						szBuffer, 16, szIniName);
			if (*szBuffer)
				color.ref = strtoul(szBuffer, NULL, 16);
			else {
				if (i == EL_BKGND || i == EL_DEAD ||
							i == EL_ZYGOTE)
					color.ref = GetSysColor(COLOR_WINDOW);
				else
					color.ref =
						GetSysColor(COLOR_WINDOWTEXT);
			}
			if (!bPaletted)
				color.ref = GetNearestColor(hdc, color.ref);
			color.pal.peFlags = (BYTE)(i < EL_COLLAPSIBLE ?
							0 : 0);
			plogpalWnd->palPalEntry[i] = color.pal;
		}
		ReleaseDC(NULL, hdc);
		bInitialized = TRUE;

		hpalWnd = CreatePalette(plogpalWnd);
		hbrushBkgnd = CreateSolidBrush(PALETTEINDEX(EL_BKGND));
		hpenRect = CreatePen(PS_SOLID, 0, PALETTEINDEX(EL_RECT));
		break;

		case SET_ALTER:
		/* Change the color of element idxEl to the color pointed
		   to by lppalentIn. */

		plogpalWnd->palPalEntry[idxEl] = *lppalentIn;
		SetPaletteEntries(hpalWnd, idxEl, 1, lppalentIn);

		if (idxEl == EL_BKGND) {
			if (hbrushBkgnd)
				if (hwndMain)
					FORWARD_WM_DELETEOBJECT(hwndMain,
								hbrushBkgnd,
								PostMessage);
				else
					DeleteBrush(hbrushBkgnd);
			hbrushBkgnd = CreateSolidBrush(PALETTEINDEX(EL_BKGND));
		} else if (idxEl == EL_RECT) {
			if (hpenRect)
				if (hwndMain)
					FORWARD_WM_DELETEOBJECT(hwndMain,
								hpenRect,
								PostMessage);
				else
					DeletePen(hpenRect);
			hpenRect = CreatePen(PS_SOLID, 1,
						PALETTEINDEX(EL_RECT));
		}
		break;

		case IDM_PALETTED:
		/* Switch between using user-defined colors and system
		   colors. */

		if (bPaletted) {
			hdc = GetDC(NULL);
			for (i = 0 ; i < NUM_ELS ; ++i) {
				color.pal = plogpalWnd->palPalEntry[i];
				color.pal.peFlags = 0;
				color.ref = GetNearestColor(hdc, color.ref);
				color.pal.peFlags =
					plogpalWnd->palPalEntry[i].peFlags;
				SetColor(&color.pal, i, SET_ALTER);
			}
			ReleaseDC(NULL, hdc);
		}
		bPaletted = !bPaletted;
		CheckMenuItem(hmenuBar, fAction,
				bPaletted ? MF_CHECKED : MF_UNCHECKED);
		return !bPaletted;

		case SET_END:
		/* Clean up all color-based objects. */

		if (bInitialized && bPalatable)
			WritePrivateProfileString(szIniSubColor,
							szIniKeyPaletted,
							bPaletted ? "1" : "0",
							szIniName);
		if (bInitialized && plogpalWnd) {
			for (i = 0 ; i < NUM_ELS ; ++i) {
				plogpalWnd->palPalEntry[i].peFlags = 0;
				wsprintf(szBuffer, "%06lX",
						plogpalWnd->palPalEntry[i]);
				WritePrivateProfileString(szIniSubColor,
							szIniKeyColor[i],
							szBuffer, szIniName);
			}
		}
		if (hbrushBkgnd)
			DeleteBrush(hbrushBkgnd);
		if (hpenRect)
			DeletePen(hpenRect);
		if (hpalWnd)
			DeletePalette(hpalWnd);
		if (plogpalWnd)
			free(plogpalWnd);
		break;
	}
	return TRUE;
}

/* Function to assert the current palette. */
int AssertPalette(HDC	hdc)
{
	HPALETTE	hpal;
	int		i;

	hpal = SelectPalette(hdc, hpalWnd, FALSE);
	i = RealizePalette(hdc);
	SelectPalette(hdc, hpal, FALSE);
	return i;
}


/* Initializes the Set Color dialog box. Stores the currently selected
   colors and sets up the controls. */
static BOOL CLR_OnInitDialog(HWND	hwnd,
			     HWND	hwndFocus,
			     LPARAM	lParam)
{
	CLRPALDATA*	pcpd;
	int		i;

	pcpd = malloc(sizeof(CLRPALDATA));
	SetWindowLong(hwnd, DWL_USER, (LONG)(UINT)pcpd);
	if (!pcpd) {
		DestroyWindow(hwnd);
		return FALSE;
	}

	CenterWindow(hwnd);
	SendDlgItemMessage(hwnd, IDC_COLOR, CLRM_SETPALETTE,
					(WPARAM)hpalWnd, FALSE);
	pcpd->lppalOrig = (LPPALETTEENTRY)lParam;
	for (i = 0 ; i < NUM_ELS ; ++i)
		pcpd->palEl[i] = pcpd->lppalOrig[i];
	for (i = 0 ; i < 3 ; ++i) {
		SetScrollRange(GetDlgItem(hwnd, IDC_RED + i),
						SB_CTL, 0, 255, FALSE);
		SetScrollRange(GetDlgItem(hwnd, IDC_HUE + i),
						SB_CTL, 0, 255, FALSE);
	}
	pcpd->idxEl = IDC_RADIO1ST - IDC_RADIO1ST;
	FORWARD_WM_NEXTDLGCTL(hwnd, GetDlgItem(hwnd, IDC_RADIO1ST), TRUE,
					SendMessage);
	CheckRadioButton(hwnd, IDC_RADIO1ST, IDC_RADIOLAST, IDC_RADIO1ST);
	UpdateColor(hwnd, pcpd->palEl, pcpd->idxEl,
					SCD_RGB | SCD_HLS | SCD_COLOR);
	return FALSE;
}

/* Keep track of whether or not we are running in the background. */
static void CLR_OnActivate(HWND	hwnd,
			   UINT	fState,
			   HWND	hwndActivate,
			   BOOL	bMinimize)
{
	bBackground = fState == WA_INACTIVE;
}

/* It's our turn to select colors from the system palette. Use the
   PC_RESERVED flag if possible, so that changes in the dialog will be
   reflected in the main window. */
static BOOL CLR_OnQueryNewPalette(HWND	hwnd)
{
	CLRPALDATA*	pcpd;
	int		i;

	pcpd = (CLRPALDATA*)(UINT)GetWindowLong(hwnd, DWL_USER);
	if (!pcpd)
		return FALSE;
	if (bPaletted && !(pcpd->palEl[0].peFlags & PC_RESERVED)) {
		for (i = 0 ; i < NUM_ELS ; ++i)
			pcpd->palEl[i].peFlags |= PC_RESERVED;
		SetPaletteEntries(hpalWnd, 0, NUM_ELS, pcpd->palEl);
		InvalidateRect(GetDlgItem(hwnd, IDC_COLOR), NULL, TRUE);
		InvalidateRect(hwndMain, NULL, TRUE);
	} else {
		if (SendDlgItemMessage(hwnd, IDC_COLOR, WM_QUERYNEWPALETTE,
							0, 0L))
			InvalidateRect(hwndMain, NULL, TRUE);
	}
	return TRUE;
}

/* The system palette is being reorganized. If we are not the foreground
   application, remove the PC_RESERVED flag from our palette entries. */
static void CLR_OnPaletteChanged(HWND	hwnd,
				 HWND	hwndPal)
{
	CLRPALDATA*	pcpd;
	int		i;

	if (hwndPal == hwnd)
		return;

	pcpd = (CLRPALDATA*)(UINT)GetWindowLong(hwnd, DWL_USER);
	if (!pcpd)
		return;
	if (bPaletted && hwndPal != hwndMain && GetParent(hwndPal) != hwnd &&
				(pcpd->palEl[0].peFlags & PC_RESERVED)) {
		for (i = 0 ; i < NUM_ELS ; ++i)
			pcpd->palEl[i].peFlags &= ~PC_RESERVED;
		SetPaletteEntries(hpalWnd, 0, NUM_ELS, pcpd->palEl);
		InvalidateRect(GetDlgItem(hwnd, IDC_COLOR), NULL, TRUE);
		InvalidateRect(hwndMain, NULL, TRUE);
	} else {
		if (SendDlgItemMessage(hwnd, IDC_COLOR, WM_PALETTECHANGED,
						(WPARAM)hwndPal, 0L))
			InvalidateRect(hwndMain, NULL, TRUE);
	}
}

/* Notification received from a dialog control. Update the colors and other
   controls as necessary. */
static void CLR_OnCommand(HWND	hwnd,
			  int	idCtl,
			  HWND	hwndCtl,
			  UINT	nCode)
{
	CLRPALDATA*	pcpd;
	int		i;

	pcpd = (CLRPALDATA*)(UINT)GetWindowLong(hwnd, DWL_USER);
	if (!pcpd)
		return;
	if (idCtl >= IDC_RADIO1ST && idCtl <= IDC_RADIOLAST) {
		pcpd->idxEl = idCtl - IDC_RADIO1ST;
		UpdateColor(hwnd, pcpd->palEl, pcpd->idxEl,
						SCD_RGB | SCD_HLS | SCD_COLOR);
		return;
	} else if (idCtl >= IDC_SETBTN1ST && idCtl <= IDC_SETBTNLAST) {
		pcpd->palEl[pcpd->idxEl] = pcpd->palEl[idCtl -
						IDC_SETBTN1ST];
		UpdateColor(hwnd, pcpd->palEl, pcpd->idxEl,
						SCD_RGB | SCD_HLS | SCD_COLOR);
		return;
	}

	switch (idCtl) {
		case IDOK:

		for (i = 0 ; i < NUM_ELS ; ++i)
			pcpd->lppalOrig[i] = pcpd->palEl[i];
		EndDialog(hwnd, TRUE);
		break;

		case IDCANCEL:

		EndDialog(hwnd, FALSE);
		break;

		case IDC_REVERT:

		pcpd->palEl[pcpd->idxEl] = pcpd->lppalOrig[pcpd->idxEl];
		UpdateColor(hwnd, pcpd->palEl, pcpd->idxEl, SCD_RGB | SCD_HLS);
		break;

		case IDC_COLOR:

		if (nCode == CLRN_DBLCLK)
			UpdateColor(hwnd, pcpd->palEl, pcpd->idxEl,
						SCD_RGB | SCD_HLS);
		break;
	}
}

/* Notification received from one of the dialog scroll bars. Update the
   colors and other controls as necessary. */
static void CLR_OnHScroll(HWND	hwnd,
			  HWND	hwndCtl,
			  UINT	fCode,
			  int	nPos)
{
	CLRPALDATA*	pcpd;
	UINT		id;
	int		n;

	pcpd = (CLRPALDATA*)(UINT)GetWindowLong(hwnd, DWL_USER);
	if (!pcpd)
		return;
	id = GetDlgCtrlID(hwndCtl);
	n = id >= IDC_RED && id <= IDC_BLU ? SCD_RGB : SCD_HLS;
	if (ScrollColor(hwnd, hwndCtl, id, fCode, nPos, n,
					&pcpd->palEl[pcpd->idxEl]))
		UpdateColor(hwnd, pcpd->palEl, pcpd->idxEl,
					(SCD_RGB + SCD_HLS) - n);
}

/* Discard our stored color data. */
static void CLR_OnDestroy(HWND	hwnd)
{
	CLRPALDATA*	pcpd;

	pcpd = (CLRPALDATA*)(UINT)SetWindowLong(hwnd, DWL_USER, 0L);
	if (pcpd)
		free(pcpd);
}

/* The Set Colors dialog procedure. */
BOOL _export CALLBACK ColorsDlgProc(HWND	hwnd,
				    UINT	message,
				    WPARAM	wParam,
				    LPARAM	lParam)
{
	switch (message) {
		HANDLE_DLGMSG(hwnd, WM_INITDIALOG, CLR_OnInitDialog);
		HANDLE_DLGMSG(hwnd, WM_ACTIVATE, CLR_OnActivate);
		HANDLE_DLGMSG(hwnd, WM_PALETTECHANGED, CLR_OnPaletteChanged);
		HANDLE_DLGMSG(hwnd, WM_QUERYNEWPALETTE, CLR_OnQueryNewPalette);
		HANDLE_DLGMSG(hwnd, WM_COMMAND, CLR_OnCommand);
		HANDLE_DLGMSG(hwnd, WM_HSCROLL, CLR_OnHScroll);
		HANDLE_DLGMSG(hwnd, WM_DESTROY, CLR_OnDestroy);
	}
	return FALSE;
}

/* Run the Set Colors dialog box and update anything the user changes. */
BOOL ColorPrompt(HWND	hwnd)
{
	DLGPROC		lpfnColorsDlg;
	PALETTEENTRY	palList[NUM_ELS];
	int		i;
	BOOL		bRet;

	hwndMain = hwnd;
	GetPaletteEntries(hpalWnd, 0, NUM_ELS, palList);
	if (bPaletted) {
		for (i = 0 ; i < NUM_ELS ; ++i) {
			palList[i].peFlags |= PC_RESERVED;
			SetColor(&palList[i], i, SET_ALTER);
		}
		InvalidateRect(hwnd, NULL, TRUE);
	}
	lpfnColorsDlg = MakeDlgProcInstance(ColorsDlgProc, hinstApp);
	bRet = DialogBoxParam(hinstApp, MAKEINTRESOURCE(IDD_COLORS), hwnd,
				lpfnColorsDlg,
				(LPARAM)(LPPALETTEENTRY)palList);
	FreeDlgProcInstance(lpfnColorsDlg);
	if (bPaletted) {
		for (i = 0 ; i < NUM_ELS ; ++i) {
			palList[i].peFlags &= ~PC_RESERVED;
			SetColor(&palList[i], i, SET_ALTER);
		}
		InvalidateRect(hwnd, NULL, TRUE);
	}
	hwndMain = NULL;
	return bRet;
}		    
