/* lifecalc.c: The functions that manage the actual Life world.		*/
/*									*/
/* (C) 1997 by Brian Raiter, under the terms of the GNU General Public	*/
/* License ver. 2 (or any later version, if you like).			*/

#define	STRICT
#include	<windows.h>
#include	<windowsx.h>
#include	<winmem32.h>
#include	<stdlib.h>	/*  rand & srand functions  */
#include	<string.h>	/*  _fmemcpy  */
#include	"life.h"
#include	"lifecalc.h"
#include	"lifegen.h"
#include	"lifedisp.h"
#include	"lifemain.h"


#pragma warning(disable: 4055 4704)

/* A macro for the assembly instruction "lss sp, [si]". */
#define LSS_SP_SI	__asm _emit 00Fh __asm _emit 0B2h __asm _emit 024h

/* What appears at the top of the 32-bit data segment. */
typedef	struct tagDATABLOCK {
		BYTE	IChing[256];
		LPVOID	LifeTick1stGear;
		LPVOID	LifeTickOverdrive;
		WORD	SS_ESP32[3];
		WORD	DS16;
		WORD	SS_SP16[2];
	} DATABLOCK, FAR* LPDATABLOCK;

BYTE			IChing[256];

LPWORLD			lpWorld = NULL;
DWORD			dwGodTime = 0;
UINT			generation = 0, population = 0, nTickBack = 0;
int			cxField = 0, cyField = 0;
int			yFirst = 0, cyActive = 0;
BOOL			bRealTime = FALSE;

/* INI file keys. */
static const char*	szIniKeySize[] = { "width", "height" };

/* 32-bit selectors. */
static WORD		selWorld = 0, selDLifeProc = 0, selCLifeProc = 0;


/* Fill the IChing array with the Life translation table. */
static void FillChangeTable(void)
{
	int	n;
	int	nNeighbors, nDefer;
	BOOL	fState;

	for (n = 0 ; n < 256 ; ++n) {
		nNeighbors = CellNeighbors(n);
		nDefer = CellDeferred(n);
		fState = CellAlive(n);
		if ((fState && (nNeighbors >= 2 && nNeighbors <= 3)) ||
		   (!fState && (nNeighbors >= 3 && nNeighbors <= 3)))
			IChing[n] = MakeCell(TRUE, nNeighbors + nDefer, 0);
		else
			IChing[n] = MakeCell(FALSE, nNeighbors + nDefer, 0);
	}
}

/* This function sets up and initializes all of the 32-bit selectors, and
   loads the 32-bit code into memory. */
static BOOL LoadLifeTick(void)
{
	HRSRC		hrsrc;
	HGLOBAL		hgmem;
	LPDATABLOCK	lpWorldData;
	LPWORD		lpProcData;
	int		cbProcData;

	hrsrc = FindResource(hinstApp, "LifeTickProc", "PROC32");
	if (!hrsrc)
		return FALSE;
	cbProcData = (int)SizeofResource(hinstApp, hrsrc) - sizeof(WORD);
	hgmem = LoadResource(hinstApp, hrsrc);
	if (!hgmem)
		return FALSE;
	lpProcData = LockResource(hgmem);
	_fmemcpy(MAKELP(selDLifeProc, 0), lpProcData + 1, cbProcData);

	lpWorldData = MAKELP(selWorld, 0);
	_fmemcpy(&lpWorldData->IChing, IChing, sizeof IChing);
	lpWorldData->SS_SP16[1] = SELECTOROF((LPCVOID)&lpWorldData);
	lpWorldData->SS_ESP32[2] = selDLifeProc;
	lpWorldData->SS_ESP32[1] = 0x0000;
	lpWorldData->SS_ESP32[0] = 0x07FC;
	lpWorldData->DS16 = SELECTOROF((LPCVOID)&lpWorld);
	lpWorldData->LifeTick1stGear = MAKELP(selCLifeProc, 0x0000);
	lpWorldData->LifeTickOverdrive = MAKELP(selCLifeProc, lpProcData[0]);

	UnlockResource(hgmem);
	FreeResource(hgmem);
	return TRUE;
}

/* Function to manage the Life world (and its 32-bit code). */
BOOL SetSpace(int	cx,
	      int	cy,
	      UINT	fAction)
{
	static BOOL	bInitialized = FALSE;

	switch (fAction) {
		case SET_INIT:
		/* One 32-bit selector contains the IChing, the data block
		   used to move between 32-bit and 16-bit code, and the
		   actual Life world. (The latter is also aliased with a
		   16-bit selector.) The other 32-bit selector contains
		   the 32-bit code and the 32-bit stack. */

		FillChangeTable();
		if (Global32Alloc(0x10600L, &selWorld, 0x10600L, 0))
			return FALSE;
		if (Global16PointerAlloc(selWorld, 0x0300L, (LPDWORD)&lpWorld,
								0x10000L, 0))
			return FALSE;
		if (Global32Alloc(0x800L, &selDLifeProc, 0x800L, 0))
			return FALSE;
		if (Global32CodeAlias(selDLifeProc, &selCLifeProc, 0))
			return FALSE;
		if (!LoadLifeTick())
			return FALSE;

		if (cx == NIL || cy == NIL) {
			cx = GetPrivateProfileInt(szIniSubWorld,
							szIniKeySize[0],
							200, szIniName);
			cy = GetPrivateProfileInt(szIniSubWorld,
							szIniKeySize[1],
							200, szIniName);
			bInitialized = TRUE;
		}
								/* fall thru */
		case SET_ALTER:
		/* Resize the Life world and take census. */

		cxField = minmax(MIN_WORLDSIDE, cx, MAX_WORLDSIDE);
		cyField = minmax(MIN_WORLDSIDE, cy, MAX_WORLDSIDE);
		TakeCensus();
		break;

		case SET_END:
		/* Free the 32-bit selectors. */

		if (selDLifeProc) {
			if (selCLifeProc) {
				Global32CodeAliasFree(selDLifeProc,
							selCLifeProc, 0);
				selCLifeProc = 0;
			}
			Global32Free(selDLifeProc, 0);
			selDLifeProc = 0;
		}
		if (selWorld) {
			if (lpWorld) {
				Global16PointerFree(selWorld, (DWORD)lpWorld,
									0);
				lpWorld = NULL;
			}
			Global32Free(selWorld, 0);
			selWorld = 0;
		}
		if (bInitialized) {
			wsprintf(szBuffer, "%d", cxField);
			WritePrivateProfileString(szIniSubWorld,
						szIniKeySize[0],
						szBuffer, szIniName);
			wsprintf(szBuffer, "%d", cyField);
			WritePrivateProfileString(szIniSubWorld,
						szIniKeySize[1],
						szBuffer, szIniName);
		}
		break;
	}

	/* Call the "friend function" in lifedisp.c */
	SetDisplaySpace(cxField, cyField, fAction);
	return TRUE;
}

/* Empty out all memory outside of the bounds of the current Life world. */
static void MarginalizeWorld(void)
{
	int	i, j;

	for (j = 0 ; j < cyField ; ++j)
		for (i = cxField ; i < 256 ; ++i)
			lpWorld[j][i] = MakeCell(FALSE, 0, 0);
	for ( ; j < 256 ; ++j)
		for (i = 0 ; i < 256 ; ++i)
			lpWorld[j][i] = MakeCell(FALSE, 0, 0);
}

/* Count the number of living cells and renormalize the neighbor counts. */
UINT TakeCensus(void)
{
	int	yLast = 0;
	int	i, j;

	population = 0;
	MarginalizeWorld();

	for (j = 0 ; j < cyField ; ++j)
		for (i = 0 ; i < cxField ; ++i)
			lpWorld[j][i] = MakeCell(CellAlive(lpWorld[j][i]),
							0, 0);

	for (j = 0 ; j < cyField ; ++j)
		for (i = 0 ; i < cxField ; ++i)
			if (CellAlive(lpWorld[j][i])) {
				yLast = j + 1 < cyField ? j + 1 : j;
				if (!population)
					yFirst = j ? j - 1 : j;
				++lpWorld[j - 1][i - 1];
				++lpWorld[j - 1][i];
				++lpWorld[j - 1][i + 1];
				++lpWorld[j][i - 1];
				++population;
				++lpWorld[j][i + 1];
				++lpWorld[j + 1][i - 1];
				++lpWorld[j + 1][i];
				++lpWorld[j + 1][i + 1];
			}

	cyActive = (yLast ? yLast - yFirst : 0) + 1;
	return population;
}

/* Set every cell to empty. */
UINT EmptyWorld(void)
{
	int	i, j;

	MarginalizeWorld();
	for (j = 0 ; j < cyField ; ++j)
		for (i = 0 ; i < cxField ; ++i)
			lpWorld[j][i] = MakeCell(FALSE, 0, 0);

	population = 0;
	return population;
}

/* Randomly set the cells to a density of nNum/nDenom. */
UINT RandomizeWorld(UINT	nNum,
		    UINT	nDenom)
{
	int	i, j;

	srand((unsigned)GetTickCount());
	for (j = 0 ; j < cyField ; ++j)
		for (i = 0 ; i < cxField ; ++i)
			if (((long)rand() * nDenom) < ((long)nNum << 15))
				Live(lpWorld[j][i]);
			else
				Die(lpWorld[j][i]);

	return TakeCensus();
}

/* Call the 32-bit Life function to run the Life world clock.
   Stop if the clock runs out, the Life pattern stagnates, or
   if we have a message in our queue. */
UINT LifeLoop1stGear(HDC	hdc)
{
	MSG	msg;
	DWORD	dwTime;
	UINT	gen0;
	BOOL	bActive;

	gen0 = generation;
	do {
		dwTime = GetTickCount();
		__asm {
			push	si
			push	di
			push	bp
			mov	bp, population
			mov	ax, cxField
			mov	cx, cyField
			mov	ds, selWorld
			mov	ds:[0]DATABLOCK.SS_SP16, sp
			lea	si, ds:[0]DATABLOCK.SS_ESP32
			_emit	066h
			LSS_SP_SI
			call	dword ptr ds:[0]DATABLOCK.LifeTick1stGear
			lea	si, ds:[0]DATABLOCK.SS_SP16
			LSS_SP_SI
			mov	ds, ds:[0]DATABLOCK.DS16
			mov	population, bp
			pop	bp
			mov	bActive, di
			pop	di
			pop	si
		}
		dwGodTime += GetTickCount() - dwTime;
		if (bActive) {
			++generation;
			TickUpdate(hdc);
			if (nTickBack)
				if (!--nTickBack) {
					bRealTime = FALSE;
					break;
				}
		} else {
			nTickBack = 0;
			bRealTime = FALSE;
			break;
		}
	} while (!PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE));

	return generation - gen0;
}

/* Call the faster 32-bit Life function to run the Life world clock.
   Stop if the clock runs out, the Life pattern stagnates, or
   if we have a message in our queue. */
UINT LifeLoopOverdrive(HDC	hdc)
{
	MSG		msg;
	DWORD		dwTime;
	UINT		gen0;
	BOOL		bActive;

	gen0 = generation;
	do {
		dwTime = GetTickCount();
		__asm {
			push	si
			push	di
			push	bp
			mov	bp, population
			mov	ax, cxField
			mov	bx, yFirst
			mov	cx, cyField
			mov	dx, cyActive
			mov	ds, selWorld
			mov	ds:[0]DATABLOCK.SS_SP16, sp
			lea	si, ds:[0]DATABLOCK.SS_ESP32
			_emit	066h
			LSS_SP_SI
			call	dword ptr ds:[0]DATABLOCK.LifeTickOverdrive
			lea	si, ds:[0]DATABLOCK.SS_SP16
			LSS_SP_SI
			mov	ds, ds:[0]DATABLOCK.DS16
			mov	yFirst, bx
			mov	cyActive, dx
			mov	population, bp
			pop	bp
			mov	bActive, di
			pop	di
			pop	si
		}
		dwGodTime += GetTickCount() - dwTime;
		if (bActive) {
			++generation;
			TickUpdateOverdrive(hdc);
			if (nTickBack)
				if (!--nTickBack) {
					bRealTime = FALSE;
					break;
				}
		} else {
			nTickBack = 0;
			bRealTime = FALSE;
			break;
		}
	} while (!PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE));

	return generation - gen0;
}
