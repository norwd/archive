/* life.c: The WinMain wrapper function.				*/
/*									*/
/* (C) 1997 by Brian Raiter, under the terms of the GNU General Public	*/
/* License ver. 2 (or any later version, if you like).			*/

#define	STRICT
#include	<windows.h>
#include	<windowsx.h>
#include	"life.h"
#include	"lifemain.h"


/* This is the only file compiled without 386 code. The WinMain function
   fails directly if we are not in 386-Enhanced mode. */
int PASCAL WinMain(HINSTANCE	hinst,
		   HINSTANCE	hinstPrev,
		   LPSTR	lpszCmdLine,
		   int		nCmdShow)
{
	hinstApp = hinst;
	if ((GetWinFlags() & (WF_PMODE | WF_ENHANCED)) !=
					(WF_PMODE | WF_ENHANCED)) {
		GetString(IDS_NEED386);
		MessageBox(NULL, szBuffer, "Life", MB_OK | MB_ICONSTOP);
		return 0;
	}
	return LifeMain(hinstPrev == NULL, lpszCmdLine, nCmdShow);
}
