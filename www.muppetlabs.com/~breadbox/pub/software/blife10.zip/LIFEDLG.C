/* lifedlg.c: The functions that run the application's dialog boxes.	*/
/*									*/
/* (C) 1997 by Brian Raiter, under the terms of the GNU General Public	*/
/* License ver. 2 (or any later version, if you like).			*/

#define	STRICT
#include	<windows.h>
#include	<windowsx.h>
#include	<commdlg.h>
#include	<stdlib.h>		/*  strtoul  */
#include	<string.h>
#include	"life.h"
#include	"lifedlg.h"
#include	"lifegen.h"
#include	"lifemain.h"


#pragma warning(disable: 4100)

/* INI file keys for the file name and type. */
static const char	szIniKeyFile[] = "filename",
			szIniKeyType[] = "type";


/* Generic do-nothing dialog procedure. */
BOOL _export CALLBACK DlgProc(HWND	hdlg,
			      UINT	message,
			      WPARAM	wParam,
			      LPARAM	lParam)
{
	if (message == WM_INITDIALOG)
		CenterWindow(hdlg);
	else if (message == WM_COMMAND &&
				(wParam == IDOK || wParam == IDCANCEL))
		EndDialog(hdlg, wParam == IDOK);
	else
		return FALSE;
	return TRUE;
}


/* Initializes the Resize dialog box. */
static BOOL SIZ_OnInitDialog(HWND	hwnd,
			     HWND	hwndFocus,
			     LPARAM	lParam)
{
	LPINT	lpnSize;

	SetWindowLong(hwnd, DWL_USER, lParam);
	lpnSize = (LPINT)lParam;
	SetDlgItemInt(hwnd, IDC_WIDTH, lpnSize[0], FALSE);
	SetDlgItemInt(hwnd, IDC_HEIGHT, lpnSize[1], FALSE);
	SetDlgItemInt(hwnd, IDC_MAG, lpnSize[2], FALSE);
	CenterWindow(hwnd);
	return TRUE;
}

/* Notification recieved from a control. If one of the edit fields changed
   contents, enable or disable the OK button appropriately. */
static void SIZ_OnCommand(HWND	hwnd,
			  int	idCtl,
			  HWND	hwndCtl,
			  UINT	nCode)
{
	LPINT	lpnSize;
	int	cx, cy;
	BOOL	bEnable;

	switch (idCtl) {
		case IDOK:

		lpnSize = (LPINT)GetWindowLong(hwnd, DWL_USER);
		lpnSize[0] = GetDlgItemInt(hwnd, IDC_WIDTH, NULL, FALSE);
		lpnSize[1] = GetDlgItemInt(hwnd, IDC_HEIGHT, NULL, FALSE);
		lpnSize[2] = GetDlgItemInt(hwnd, IDC_MAG, NULL, FALSE);
		EndDialog(hwnd, TRUE);
		break;

		case IDCANCEL:

		EndDialog(hwnd, FALSE);
		break;

		case IDC_WIDTH:
		case IDC_HEIGHT:

		if (nCode != EN_CHANGE)
			break;
		cx = cy = GetDlgItemInt(hwnd, IDC_WIDTH, &bEnable, FALSE);
		if (bEnable)
			cy = GetDlgItemInt(hwnd, IDC_HEIGHT, &bEnable, FALSE);
		if (bEnable && (cx < MIN_WORLDSIDE || cy < MIN_WORLDSIDE ||
				cx > MAX_WORLDSIDE || cy > MAX_WORLDSIDE))
			bEnable = FALSE;
		EnableWindow(GetDlgItem(hwnd, IDOK), bEnable);
		break;
	}
}

/* The Resize dialog procedure */
BOOL _export CALLBACK ResizeDlgProc(HWND	hwnd,
				    UINT	message,
				    WPARAM	wParam,
				    LPARAM	lParam)
{
	switch (message) {
		HANDLE_DLGMSG(hwnd, WM_INITDIALOG, SIZ_OnInitDialog);
		HANDLE_DLGMSG(hwnd, WM_COMMAND, SIZ_OnCommand);
	}
	return FALSE;
}

/* Runs the Resize dialog. Returns zero if nothing changed. */
BOOL ResizePrompt(HWND		hwnd,
		  LPINT		lpcxSize,
		  LPINT		lpcySize,
		  LPINT		lpnMag)
{
	DLGPROC	lpfnResizeDlg;
	int	nDlgArgs[3];
	BOOL	bRet;

	lpfnResizeDlg = MakeDlgProcInstance(ResizeDlgProc, hinstApp);
	nDlgArgs[0] = *lpcxSize;
	nDlgArgs[1] = *lpcySize;
	nDlgArgs[2] = *lpnMag;

	bRet = DialogBoxParam(hinstApp, MAKEINTRESOURCE(IDD_RESIZE), hwnd,
				lpfnResizeDlg, (LPARAM)(LPVOID)nDlgArgs);
	FreeDlgProcInstance(lpfnResizeDlg);

	if (!bRet)
		return FALSE;
	if (nDlgArgs[0] == *lpcxSize && nDlgArgs[1] == *lpcySize &&
					nDlgArgs[2] == *lpnMag)
		return FALSE;
	*lpcxSize = nDlgArgs[0];
	*lpcySize = nDlgArgs[1];
	*lpnMag = nDlgArgs[2];
	return TRUE;
}

/* Runs the About dialog box. */
void ShowAbout(HWND	hwnd)
{
	DLGPROC	lpfnDlg;

	lpfnDlg = MakeDlgProcInstance(DlgProc, hinstApp);
	DialogBox(hinstApp, MAKEINTRESOURCE(IDD_ABOUT), hwnd, lpfnDlg);
	FreeDlgProcInstance(lpfnDlg);
}

/* Runs the File Open and the File Save dialog boxes. If a file was
   successfully selected, returns an open file handle and the file's type. */
HFILE FilePrompt(HWND		hwnd,
		 UINT		fDirection,
		 LPINT		lpnExtType)
{
	HFILE		hfile;
	LPOPENFILENAME	lpofn;
	LPOFSTRUCT	lpofs;
	LPSTR		lpszFilename, lpszDir, lpszFilters, lpszTitle,
			lpszExts;
	int		nExt;

	lpofn = GlobalAllocPtr(GHND, sizeof(OPENFILENAME) + 5 * 256);
	if (!lpofn)
		return HFILE_ERROR;
	lpofs = (LPOFSTRUCT)lpofn;
	lpszDir = (LPSTR)&lpofn[1];
	lpszFilters = &lpszDir[512];
	lpszTitle = &lpszFilters[256];
	GetPrivateProfileString(szIniSubWorld, szIniKeyFile, "",
					lpszDir, 256, szIniName);
	nExt = GetPrivateProfileInt(szIniSubWorld, szIniKeyType, 1, szIniName);
	lpszFilename = _fstrrchr(lpszDir, '\\');
	if (lpszFilename) {
		if (lpszFilename == lpszDir) {
			lpszFilename = lpszDir + 256;
			_fstrcpy(lpszFilename, lpszDir + 1);
			lpszDir[1] = '.';
			lpszDir[2] = '\0';
		} else {
			*lpszFilename = '\0';
			++lpszFilename;
		}
	} else if (lpszDir[1] == ':') {
		lpszFilename = lpszDir + 256;
		_fstrcpy(lpszFilename, lpszDir + 2);
		lpszDir[2] = '.';
		lpszDir[3] = '\0';
	} else {
		lpszFilename = lpszDir;
		lpszDir = NULL;
	}
	lpszExts = lpszFilters + 1 +
			LoadString(hinstApp, IDS_FILTERS, lpszFilters, 256);
	lstrrpl(lpszFilters, '|', '\0');
	LoadString(hinstApp, IDS_EXTS, lpszExts,
			256 - (lpszExts - lpszFilters));
	lstrrpl(lpszExts, '|', '\0');
	LoadString(hinstApp, fDirection & WORLD_IN ? IDS_OPENFILE :
							IDS_SAVEFILE,
					lpszTitle, 256);

	lpofn->lStructSize		= sizeof(OPENFILENAME);
	lpofn->hwndOwner		= hwnd;
	lpofn->hInstance		= hinstApp;
	lpofn->lpstrFilter		= lpszFilters;
	lpofn->lpstrCustomFilter	= NULL;
	lpofn->nFilterIndex		= nExt;
	lpofn->lpstrFile		= lpszFilename;
	lpofn->nMaxFile			= 256;
	lpofn->lpstrFileTitle		= NULL;
	lpofn->lpstrInitialDir		= lpszDir;
	lpofn->lpstrTitle		= lpszTitle;
	lpofn->Flags			= OFN_OVERWRITEPROMPT |
						OFN_HIDEREADONLY;
	lpofn->lpstrDefExt		= NULL;

	if (fDirection & WORLD_IN) {
		lpofn->Flags |= OFN_FILEMUSTEXIST;
		if (GetOpenFileName(lpofn)) {
			nExt = (int)lpofn->nFilterIndex;
			hfile = OpenFile(lpszFilename, lpofs, OF_READ);
		} else
			hfile = NULL;
	} else {
		lpofn->Flags |= OFN_NOREADONLYRETURN | OFN_OVERWRITEPROMPT;
		if (GetSaveFileName(lpofn)) {
			nExt = (int)lpofn->nFilterIndex;
			hfile = OpenFile(lpszFilename, lpofs, OF_CREATE);
		} else
			hfile = NULL;
	}
	InvalidateRect(hwnd, NULL, TRUE);
	if (hfile && hfile != HFILE_ERROR) {
		if (lpnExtType)
			*lpnExtType = nExt ? nExt - 1 : EXT_UNKNOWN;
		if (lpofs->fFixedDisk) {
			WritePrivateProfileString(szIniSubWorld, szIniKeyFile,
						lpofs->szPathName, szIniName);
			wsprintf(szBuffer, "%d", nExt);
			WritePrivateProfileString(szIniSubWorld, szIniKeyType,
						szBuffer, szIniName);
		}
	}
	
	(void)GlobalFreePtr(lpofn);
	return hfile;
}
