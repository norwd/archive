/* lifemain.c: The application's main window procedure.			*/
/*									*/
/* (C) 1997 by Brian Raiter, under the terms of the GNU General Public	*/
/* License ver. 2 (or any later version, if you like).			*/

#define	STRICT
#include	<windows.h>
#include	<windowsx.h>
#include	"life.h"
#include	"lifemain.h"
#include	"lifegen.h"
#include	"lifectl.h"
#include	"lifecalc.h"
#include	"lifedisp.h"
#include	"lifeclr.h"
#include	"lifeio.h"
#include	"lifedlg.h"

#pragma warning(disable: 4100)

const char		szIniName[] = "Life.ini";
const char		szIniSubWorld[] = "world";
const char		szIniSubDisplay[] = "display";
const char		szIniSubColor[] = "color";

char			szBuffer[256];

HINSTANCE		hinstApp;
HMENU			hmenuBar;
BOOL			bBackground = TRUE;
BOOL			bPalatable;

/* Life INI file sections. */
static const char	szAppName[] = "Life";
static const char	szIniKeySpeed[] = "gear";

/* Pointer to the appropriate Life function in lifecalc.c. */
static UINT		(*LifeLoop)(HDC) = NULL;

/* Accumulators used when timing the Life functions. */
static DWORD		dwRealTime;
static UINT		nGodTick = 0;

/* Index of which speed the user has requested. */
static int		idxGear;


/* Function to manage the selected speed. */
static BOOL SetSpeed(HWND	hwnd,
		     UINT	fAction)
{
	static BOOL	bInitialized = FALSE;
	int		i;

	switch (fAction) {
		case SET_INIT:

		i = GetPrivateProfileInt(szIniSubWorld,
						szIniKeySpeed, 1, szIniName);
		FORWARD_WM_COMMAND(hwnd, IDM_1STGEAR + i - 1, NULL, 0,
					SendMessage);
		bInitialized = TRUE;
		break;

		case SET_END:

		if (bInitialized) {
			wsprintf(szBuffer, "%d", idxGear + 1);
			WritePrivateProfileString(szIniSubWorld,
						szIniKeySpeed, szBuffer,
						szIniName);
		}
		break;
	}
	return TRUE;
}

/* Called when the contents and/or size of the Life world has changed. */
static void WorldChange(HWND	hwnd,
			int	cxNew,
			int	cyNew)
{
	if (cxNew != NIL && cyNew != NIL)
		SetSpace(cxNew, cyNew, SET_ALTER);
	generation = 0;
	TakeCensus();
	if (cxNew != NIL && cyNew != NIL)
		SetWindow(hwnd, NIL, NIL, SET_ALTER);
	InvalidateRect(hwnd, NULL, TRUE);
}

/* Function called when a file is given on the command line. Determines
   the file type and reads in the file. */
static BOOL InitWithFile(HWND	hwnd,
			 LPCSTR	lpszFile)
{
	HFILE		hfile;
	OFSTRUCT	ofs;
	UINT		nHeader;
	int		i, j;
	BOOL		bRet;

	hfile = OpenFile(lpszFile, &ofs, OF_READ);
	if (hfile == HFILE_ERROR) {
		ErrorMsg(hwnd, IDS_FILEERR, IDS_CANTOPEN, FALSE);
		return FALSE;
	}
	if (_lread(hfile, &nHeader, 2) != 2)
		return FALSE;
	_llseek(hfile, 0, SEEK_SET);
	bRet = FileToWorld(lpWorld, &i, &j, hfile,
				nHeader == (UINT)'MB' ? EXT_BMP : EXT_TEXT);
	_lclose(hfile);
	if (bRet)
		WorldChange(hwnd, i, j);
	else
		ErrorMsg(hwnd, IDS_FILEERR, IDS_CANTREAD, FALSE);
	return bRet;
}

/* Creation of the main window. The other Set functions are initialized
   ("constructed"). */
static BOOL LIF_OnCreate(HWND		hwnd,
			 LPCREATESTRUCT	lpcs)
{
	HDC	hdc;
	HDWP	hdwp;

	hdc = GetDC(NULL);
	bPalatable = GetDeviceCaps(hdc, RASTERCAPS) & RC_PALETTE;
	ReleaseDC(NULL, hdc);
	hmenuBar = GetMenu(hwnd);
	if (!SetSpace(NIL, NIL, SET_INIT)) {
		ErrorMsg(hwnd, IDS_NOMEM, IDS_GMEMERR, TRUE);
		return FALSE;
	}
	hdwp = BeginDeferWindowPos(1);
	if (!SetWindow(hwnd, (int)hdwp, NIL, SET_INIT)) {
		ErrorMsg(hwnd, IDS_CANTINIT, IDS_GDIERR, TRUE);
		return FALSE;
	}
	SetView(hwnd, NIL, NIL, SET_INIT);
	SetMagnification(hwnd, NIL, SET_INIT);
	SetColor(NULL, NIL, SET_INIT);
	SetSpeed(hwnd, SET_INIT);
	EndDeferWindowPos(hdwp);
	return TRUE;
}

/* Keep track of whether or not we are running in the background. */
static void LIF_OnActivate(HWND	hwnd,
			   UINT	fState,
			   HWND	hwndActivate,
			   BOOL	bMinimize)
{
	bBackground = fState == WA_INACTIVE;
}

/* Called when the window changes size. */
static void LIF_OnSize(HWND	hwnd,
		       UINT	fState,
		       int	cxClient,
		       int	cyClient)
{
	SetWindow(hwnd, cxClient, cyClient, SET_ALTER);
	SetView(hwnd, xOrg, yOrg, SET_ALTER);
}

/* The vertical scroll bar changes the y-coordinate of the origin. */
static void LIF_OnVScroll(HWND	hwnd,
			  HWND	hwndCtl,
			  UINT	fCode,
			  int	nPos)
{
	int	yNew;

	switch (fCode) {
		case SB_LINEDOWN:	yNew = yOrg - 1;	break;
		case SB_LINEUP:		yNew = yOrg + 1;	break;
		case SB_PAGEDOWN:	yNew = yOrg - 16;	break;
		case SB_PAGEUP:		yNew = yOrg + 16;	break;
		case SB_THUMBTRACK:	yNew = -nPos;		break;
		default:		return;
	}
	SetView(hwnd, xOrg, yNew, SET_ALTER);
	ViewPaint(hwnd);
}

/* The horizontal scroll bar changes the x-coordinate of the origin. */
static void LIF_OnHScroll(HWND	hwnd,
			  HWND	hwndCtl,
			  UINT	fCode,
			  int	nPos)
{
	int	xNew;

	switch (fCode) {
		case SB_LINEUP:		xNew = xOrg - 1;	break;
		case SB_LINEDOWN:	xNew = xOrg + 1;	break;
		case SB_PAGEUP:		xNew = xOrg - 16;	break;
		case SB_PAGEDOWN:	xNew = xOrg + 16;	break;
		case SB_THUMBTRACK:	xNew = nPos;		break;
		default:		return;
	}
	SetView(hwnd, xNew, yOrg, SET_ALTER);
	ViewPaint(hwnd);
}

/* Map the arrow keys to scrollbar messages. */
static void LIF_OnKey(HWND	hwnd,
		      UINT	nVKey,
		      BOOL	bDown,
		      int	cRepeat,
		      UINT	fState)
{
	if (!bDown)
		return;
	switch (nVKey) {
		case VK_UP:

		FORWARD_WM_VSCROLL(hwnd, NULL, GetKeyState(VK_SHIFT) < 0 ?
						SB_PAGEUP : SB_LINEUP,
						0, SendMessage);
		break;

		case VK_DOWN:

		FORWARD_WM_VSCROLL(hwnd, NULL, GetKeyState(VK_SHIFT) < 0 ?
						SB_PAGEDOWN : SB_LINEDOWN,
						0, SendMessage);
		break;

		case VK_LEFT:

		FORWARD_WM_HSCROLL(hwnd, NULL, GetKeyState(VK_SHIFT) < 0 ?
						SB_PAGEUP : SB_LINEUP,
						0, SendMessage);
		break;

		case VK_RIGHT:

		FORWARD_WM_HSCROLL(hwnd, NULL, GetKeyState(VK_SHIFT) < 0 ?
						SB_PAGEDOWN : SB_LINEDOWN,
						0, SendMessage);
		break;
	}
}

/* At this time we assert our palette, and redraw if needed. */
static BOOL LIF_OnQueryNewPalette(HWND	hwnd)
{
	HDC	hdc;
	int	b = FALSE;

	if (hpalWnd) {
		hdc = GetDC(hwnd);
		b = AssertPalette(hdc);
		ReleaseDC(hwnd, hdc);
		if (b) {
			InvalidateRect(hwnd, NULL, TRUE);
			UpdateWindow(hwnd);
		}
	}
	return b;
}

/* Test to see if we need to re-assert our palette. */
static void LIF_OnPaletteChanged(HWND	hwnd,
				 HWND	hwndPal)
{
	if (hwndPal != hwnd && bBackground)
		LIF_OnQueryNewPalette(hwnd);
}

/* Paint the entire window. */
static void LIF_OnPaint(HWND	hwnd)
{
	PAINTSTRUCT	ps;

	BeginPaint(hwnd, &ps);
	PrepPaint(ps.hdc);
	if (ps.fErase)
		DoWindowDressing(ps.hdc);
	TickUpdate(ps.hdc);
	FinishPaint(ps.hdc);
	EndPaint(hwnd, &ps);
}

/* It's our turn to do background processing: run the Life world clock. */
static void LIF_OnSystemIdle(HWND	hwnd)
{
	HDC	hdc;

	hdc = GetDC(hwnd);
	PrepPaint(hdc);
	LifeLoop(hdc);
	FinishPaint(hdc);
	ReleaseDC(hwnd, hdc);
}

/* Run the Life world clock if necessary. */
static void LIF_OnEnterIdle(HWND	hwnd,
			    UINT	fWho,
			    HWND	hwndWho)
{
	if (bRealTime)
		LIF_OnSystemIdle(hwnd);
}

/* User-defined message to delete GDI objects after the fact. */
static void LIF_OnDeleteObject(HWND	hwnd,
			       HGDIOBJ	hgdiobj)
{
	if (hgdiobj)
		DeleteObject(hgdiobj);
}

/* Initialize the states of the menu items appropriately. */
static void LIF_OnInitMenuPopup(HWND	hwnd,
				HMENU	hmenu,
				int	nItemPos,
				BOOL	bSysMenu)
{
	switch (nItemPos) {
		case MENUPOS_PTAH:

		EnableMenuItem(hmenuBar, IDM_PASTE,
				       IsClipboardFormatAvailable(CF_DIB) ||
				       IsClipboardFormatAvailable(CF_BITMAP) ?
						MF_ENABLED : MF_GRAYED);
		EnableMenuItem(hmenuBar, IDM_LOWERMAG,	magnification ?
						MF_ENABLED : MF_GRAYED);
		break;

		case MENUPOS_RA:

		EnableMenuItem(hmenuBar, IDM_GO, bRealTime ?
						MF_GRAYED : MF_ENABLED);
		EnableMenuItem(hmenuBar, IDM_STOP, bRealTime ?
						MF_ENABLED : MF_GRAYED);
		break;
	}
}

/* Menu and accelerator commands are handled here. */
static void LIF_OnCommand(HWND	hwnd,
			  UINT	idCtl,
			  HWND	hwndCtl,
			  UINT	nCode)
{
	HFILE	hfile;
	int	i, j, n;
	BOOL	bRet;

	if (idCtl >= IDM_GEN0 && idCtl <= IDM_GENMAX) {
		nTickBack += idCtl - IDM_GEN0;
		bRealTime = TRUE;
		return;
	}

	switch (idCtl) {
		case IDM_ERASE:

		EmptyWorld();
		WorldChange(hwnd, NIL, NIL);
		break;

		case IDM_RANDOMFILL:

		RandomizeWorld(3, 11);
		WorldChange(hwnd, NIL, NIL);
		break;

		case IDM_RPENTOMINO:

		EmptyWorld();
		j = 3 * cyField / 5;
		i = 3 * cxField / 5;
		Live(lpWorld[j + 1][i - 1]);
		Live(lpWorld[j + 1][i]);
		Live(lpWorld[j][i]);
		Live(lpWorld[j][i + 1]);
		Live(lpWorld[j - 1][i]);
		WorldChange(hwnd, NIL, NIL);
		break;

		case IDM_ACORN:

		EmptyWorld();
		j = 2 * cyField / 5;
		i = 3 * cxField / 5;
		Live(lpWorld[j + 1][i - 2]);
		Live(lpWorld[j][i]);
		Live(lpWorld[j - 1][i - 3]);
		Live(lpWorld[j - 1][i - 2]);
		Live(lpWorld[j - 1][i + 1]);
		Live(lpWorld[j - 1][i + 2]);
		Live(lpWorld[j - 1][i + 3]);
		WorldChange(hwnd, NIL, NIL);
		break;

		case IDM_SAVE:

		hfile = FilePrompt(hwnd, WORLD_OUT, &n);
		if (!hfile)
			break;
		if (hfile == HFILE_ERROR) {
			ErrorMsg(hwnd, IDS_FILEERR, IDS_CANTOPEN, FALSE);
			break;
		}
		bRet = WorldToFile(hfile, n, lpWorld, cxField, cyField);
		_lclose(hfile);
		if (!bRet)
			ErrorMsg(hwnd, IDS_FILEERR, IDS_CANTWRITE, FALSE);
		break;

		case IDM_OPEN:

		hfile = FilePrompt(hwnd, WORLD_IN, &n);
		if (!hfile)
			break;
		if (hfile == HFILE_ERROR) {
			ErrorMsg(hwnd, IDS_FILEERR, IDS_CANTOPEN, FALSE);
			break;
		}
		bRet = FileToWorld(lpWorld, &i, &j, hfile, n);
		_lclose(hfile);
		if (bRet)
			WorldChange(hwnd, i, j);
		else
			ErrorMsg(hwnd, IDS_FILEERR, IDS_CANTREAD, FALSE);
		break;

		case IDM_COPY:

		OpenClipboard(hwnd);
		WorldToClipboard(lpWorld, cxField, cyField);
		CloseClipboard();
		break;

		case IDM_PASTE:

		OpenClipboard(hwnd);
		bRet = ClipboardToWorld(lpWorld, &i, &j);
		CloseClipboard();
		if (bRet)
			WorldChange(hwnd, i, j);
		break;

		case IDM_RESIZE:

		i = cxField;
		j = cyField;
		n = magnification;
		if (!ResizePrompt(hwnd, &i, &j, &n))
			break;
		if (i != cxField || j != cyField) {
			generation = 0;
			SetSpace(i, j, SET_ALTER);
		}
		SetMagnification(hwnd, n, SET_ALTER);
		InvalidateRect(hwnd, NULL, TRUE);
		break;

		case IDM_EXIT:

		FORWARD_WM_CLOSE(hwnd, SendMessage);
		break;

		case IDM_LOWERMAG:

		SetMagnification(hwnd, magnification - 1, SET_ALTER);
		InvalidateRect(hwnd, NULL, TRUE);
		break;

		case IDM_RAISEMAG:

		SetMagnification(hwnd, magnification + 1,  SET_ALTER);
		InvalidateRect(hwnd, NULL, TRUE);
		break;

		case IDM_SETCOLORS:

		if (ColorPrompt(hwnd))
			InvalidateRect(hwnd, NULL, TRUE);
		break;

		case IDM_PALETTED:

		if (SetColor(NULL, NIL, idCtl))
			InvalidateRect(hwnd, NULL, TRUE);
		break;

		case IDM_1STGEAR:

		LifeLoop = LifeLoop1stGear;
		idxGear = 0;
		CheckMenuItem(hmenuBar, IDM_1STGEAR, MF_CHECKED);
		CheckMenuItem(hmenuBar, IDM_OVERDRIVE, MF_UNCHECKED);
		break;

		case IDM_OVERDRIVE:

		TakeCensus();
		LifeLoop = LifeLoopOverdrive;
		idxGear = 1;
		CheckMenuItem(hmenuBar, IDM_1STGEAR, MF_UNCHECKED);
		CheckMenuItem(hmenuBar, IDM_OVERDRIVE, MF_CHECKED);
		break;

		case IDM_GO:

		bRealTime = TRUE;
		break;

		case IDM_STOP:

		nTickBack = 0;
		bRealTime = FALSE;
		break;

		case IDM_BENCHMARK:

		SetSpace(128, 80, SET_ALTER);
		FORWARD_WM_COMMAND(hwnd, IDM_RPENTOMINO, NULL, 0, SendMessage);
		UpdateWindow(hwnd);
		if (!SetTimer(hwnd, 1103, 500, NULL))
			MessageBeep(0);
		break;

		case IDM_TIME:

		if (!SetTimer(hwnd, 500, 500, NULL))
			MessageBeep(0);
		break;

		case IDM_ABOUT:

		ShowAbout(hwnd);
		break;
	}
}

/* A timer message indicates that we should start the Life world clock.
   The timer ID indicates the number of generations to run. */
static void LIF_OnTimer(HWND	hwnd,
			UINT	idTimer)
{
	KillTimer(hwnd, idTimer);
	nTickBack = idTimer;
	bRealTime = TRUE;
	dwGodTime = 0;
	nGodTick = generation + 1;
	dwRealTime = GetTickCount();
}

/* Message sent when the Life world clock has finished while doing a timing.
   The various timings are calculated and displayed. */
static void LIF_OnExitTime(HWND	hwnd)
{
	nGodTick = generation - nGodTick + 1;
	dwRealTime = GetTickCount() - dwRealTime;
	if (!dwGodTime)
		dwGodTime = 1;
	if (!dwRealTime)
		dwRealTime = 1;
	wsprintf(szBuffer, "%d generations in %d.%1d seconds (%d.%1d g/s);\n"
				"displayed in %d.%1d seconds (%d.%1d g/s).",
			(int)nGodTick,
			(int)(dwGodTime / 1000),
			(int)(dwGodTime / 100) % 10,
			(int)((nGodTick * 1000UL) / dwGodTime),
			(int)((nGodTick * 10000UL) / dwGodTime) % 10,
			(int)(dwRealTime / 1000),
			(int)(dwRealTime / 100) % 10,
			(int)((nGodTick * 1000UL) / dwRealTime),
			(int)((nGodTick * 10000UL) / dwRealTime) % 10);
	MessageBox(GetFocus(), szBuffer, "Test Results",
					MB_ICONINFORMATION | MB_OK);
	nGodTick = 0;
}

/* The Set functions are ended ("destructed"). */
static void LIF_OnDestroy(HWND	hwnd)
{
	SetSpace(NIL, NIL, SET_END);
	SetWindow(hwnd, NIL, NIL, SET_END);
	SetColor(NULL, 0, SET_END);
	SetView(hwnd, NIL, NIL, SET_END);
	SetMagnification(hwnd, NIL, SET_END);
	SetSpeed(hwnd, SET_END);
	PostQuitMessage(0);
}

/* The main window procedure. */
LRESULT _export CALLBACK WndProc(HWND	hwnd,
				 UINT	message,
				 WPARAM	wParam,
				 LPARAM	lParam)
{
	switch (message) {
		HANDLE_MSG(hwnd, WM_CREATE, LIF_OnCreate);
		HANDLE_MSG(hwnd, WM_ACTIVATE, LIF_OnActivate);
		HANDLE_MSG(hwnd, WM_SIZE, LIF_OnSize);
		HANDLE_MSG(hwnd, WM_VSCROLL, LIF_OnVScroll);
		HANDLE_MSG(hwnd, WM_HSCROLL, LIF_OnHScroll);
		HANDLE_MSG(hwnd, WM_KEYDOWN, LIF_OnKey);
		HANDLE_MSG(hwnd, WM_PALETTECHANGED, LIF_OnPaletteChanged);
		HANDLE_MSG(hwnd, WM_QUERYNEWPALETTE, LIF_OnQueryNewPalette);
		HANDLE_MSG(hwnd, WM_PAINT, LIF_OnPaint);
		HANDLE_MSG(hwnd, WM_ENTERIDLE, LIF_OnEnterIdle);
		HANDLE_MSG(hwnd, WM_SYSTEMIDLE, LIF_OnSystemIdle);
		HANDLE_MSG(hwnd, WM_DELETEOBJECT, LIF_OnDeleteObject);
		HANDLE_MSG(hwnd, WM_INITMENUPOPUP, LIF_OnInitMenuPopup);
		HANDLE_MSG(hwnd, WM_COMMAND, LIF_OnCommand);
		HANDLE_MSG(hwnd, WM_TIMER, LIF_OnTimer);
		HANDLE_MSG(hwnd, WM_EXITTIME, LIF_OnExitTime);
		HANDLE_MSG(hwnd, WM_DESTROY, LIF_OnDestroy);
	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}

/* The real WinMain function. The main window is created, and our message
   loop with background processing is entered. */
int LifeMain(BOOL	bFirstInstance,
	     LPSTR	lpszCmdLine,
	     int	nCmdShow)
{
	HWND	hwnd;
	HACCEL	haccel;
	MSG	msg;

	if (bFirstInstance) {
		WNDCLASS	wndcls;

		wndcls.style		= CS_HREDRAW | CS_VREDRAW |
						CS_BYTEALIGNCLIENT;
		wndcls.lpfnWndProc	= (WNDPROC)WndProc;
		wndcls.cbClsExtra	= 0;
		wndcls.cbWndExtra	= 0;
		wndcls.hInstance	= hinstApp;
		wndcls.hIcon		= LoadIcon(hinstApp, szAppName);
		wndcls.hCursor		= LoadCursor(NULL, IDC_ARROW);
		wndcls.hbrBackground	= NULL;
		wndcls.lpszMenuName	= szAppName;
		wndcls.lpszClassName	= szAppName;
		RegisterClass(&wndcls);

		RegisterCtlClasses(hinstApp);
	}

	hwnd = CreateWindow(szAppName, szAppName, WS_OVERLAPPEDWINDOW |
						WS_VSCROLL | WS_HSCROLL,
				CW_USEDEFAULT, CW_USEDEFAULT,
				CW_USEDEFAULT, CW_USEDEFAULT,
				NULL, NULL, hinstApp, NULL);
	if (!hwnd)
		return 0;
	if (*lpszCmdLine)
		InitWithFile(hwnd, lpszCmdLine);
	haccel = LoadAccelerators(hinstApp, szAppName);

	ShowWindow(hwnd, nCmdShow);
	UpdateWindow(hwnd);

	for (;;)
		if (!PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
			if (bRealTime)
				FORWARD_WM_SYSTEMIDLE(hwnd, SendMessage);
			else if (nGodTick)
				FORWARD_WM_EXITTIME(hwnd, SendMessage);
			else
				WaitMessage();
		} else if (msg.message != WM_QUIT) {
			if (!TranslateAccelerator(hwnd, haccel, &msg)) {
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
		} else
			break;

	return msg.wParam;
}
