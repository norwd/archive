/* (C) 1999 Brian Raiter (under the terms of the GPL) */

#ifndef	_score_h_
#define	_score_h_

/* Display the words that were found and were not found, and calculate
 * the player's statistics.
 */
extern void reportwords(void);

/* Display the latest statistics.
 */
extern void reportscore(void);

#endif
