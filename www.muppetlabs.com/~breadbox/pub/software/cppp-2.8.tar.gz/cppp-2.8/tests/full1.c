#ifdef foo
one
#ifndef bar
two
#endif
#else
#ifndef baz
three
#else
four
#endif /*comment*/
#endif
