/* Written by Brian Raiter, January 2001. Placed in the public domain. */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "gen.h"
#include "pnm.h"

static int readint(fileinfo *file, int *ptr)
{
    char ch;

    for (;;) {
        if (fscanf(file->fp, " %c", &ch) < 1)
            return FALSE;
        if (ch == '#') {
            if (fscanf(file->fp, "%*[^\n]") == EOF)
                return FALSE;
            continue;
        }
        if (ch < '0' && ch > '9')
            return FALSE;
        ungetc(ch, file->fp);
        return fscanf(file->fp, "%d", ptr) == 1;
    }
    return TRUE;
}

/*
 * pbm functions
 */

static int readpbmrawrow(fileinfo *file, imageinfo *image)
{
    uchar *line;
    int byte;
    int y, x, w;

    y = image->height - image->ypos;
    if (y <= 0)
        return 0;
    if (y > squaresize)
        y = squaresize;
    for (line = image->buf[0] ; y ; --y, line += image->width) {
        for (x = 0 ; x < image->width ; x += 8) {
            if ((byte = fgetc(file->fp)) == EOF) {
                fileerr(file);
                return -1;
            }
            for (w = 0 ; w < 8 && x + w < image->width ; ++w, byte <<= 1)
                line[x + w] = byte & 128 ? 0 : 1;
        }
    }
    return 1;
}

static int readpbmascrow(fileinfo *file, imageinfo *image)
{
    uchar *line;
    int pixel;
    int y, x;

    y = image->height - image->ypos;
    if (y <= 0)
        return 0;
    if (y > squaresize)
        y = squaresize;
    for (line = image->buf[0] ; y ; --y, line += image->width) {
        for (x = 0 ; x < image->width ; ++x) {
            if (fscanf(file->fp, "%1d", &pixel) < 1) {
                fileerr(file);
                return -1;
            }
            line[x] = !pixel;
        }
    }
    return 1;
}

/*
 * pgm functions
 */

static int readpgmrawrow(fileinfo *file, imageinfo *image)
{
    int y;

    y = image->height - image->ypos;
    if (y <= 0)
        return 0;
    if (y > squaresize)
        y = squaresize;
    if ((int)fread(image->buf[0], image->width, y, file->fp) != y) {
        fileerr(file);
        return -1;
    }
    return 1;
}

static int readpgmascrow(fileinfo *file, imageinfo *image)
{
    uchar *line;
    int pixel;
    int y, x;

    y = image->height - image->ypos;
    if (y <= 0)
        return 0;
    if (y > squaresize)
        y = squaresize;
    for (line = image->buf[0] ; y ; --y, line += image->width) {
        for (x = 0 ; x < image->width ; ++x) {
            if (fscanf(file->fp, "%d", &pixel) < 1) {
                fileerr(file);
                return -1;
            }
            line[x] = pixel;
        }
    }
    return 1;
}

/*
 * ppm functions
 */

static int readppmrawrow(fileinfo *file, imageinfo *image)
{
    uchar *rline, *gline, *bline;
    int r, g, b;
    int y, x;

    y = image->height - image->ypos;
    if (y <= 0)
        return 0;
    if (y > squaresize)
        y = squaresize;
    rline = image->buf[0];
    gline = image->buf[1];
    bline = image->buf[2];
    while (y--) {
        for (x = 0 ; x < image->width ; ++x) {
            if ((r = fgetc(file->fp)) == EOF || (g = fgetc(file->fp)) == EOF
                                             || (b = fgetc(file->fp)) == EOF) {
                fileerr(file);
                return -1;
            }
            rline[x] = r;
            gline[x] = g;
            bline[x] = b;
        }
        rline += image->width;
        gline += image->width;
        bline += image->width;
    }
    return 1;
}

static int readppmascrow(fileinfo *file, imageinfo *image)
{
    uchar *rline, *gline, *bline;
    int r, g, b;
    int y, x;

    y = image->height - image->ypos;
    if (y <= 0)
        return 0;
    if (y > squaresize)
        y = squaresize;
    rline = image->buf[0];
    gline = image->buf[1];
    bline = image->buf[2];
    while (y--) {
        for (x = 0 ; x < image->width ; ++x) {
            if (fscanf(file->fp, "%d%d%d", &r, &g, &b) < 3) {
                fileerr(file);
                return -1;
            }
            rline[x] = r;
            gline[x] = g;
            bline[x] = b;
        }
        rline += image->width;
        gline += image->width;
        bline += image->width;
    }
    return 1;
}

/*
 * exported functions
 */

int readpnmheader(fileinfo *file, imageinfo *image)
{
    int i, n;
    int ch;

    if ((ch = fgetc(file->fp)) == EOF)
        return err("invalid pnm file");
    if (ch != 'P')
        return err("invalid pnm file");
    if ((file->type = fgetc(file->fp)) == EOF)
        return err("invalid pnm file");
    if (!readint(file, &image->width) || !readint(file, &image->height))
        return err("invalid pnm file");
    if (image->width <= 0 || image->height <= 0)
        return err("invalid pnm file");
    if (file->type == pbmasc || file->type == pbmraw) {
        image->bits = 1;
        image->planes = 1;
    } else {
        if (!readint(file, &n) || n < 1)
            return err("invalid pnm file");
        if (n >= 256)
            return err("color values exceeding 255 unsupported");
        for (image->bits = 0, ++n ; !(n & 1) ; ++image->bits, n >>= 1) ;
        if (n != 1)
            return err("invalid pnm file");
        if (file->type == pgmasc || file->type == pgmraw)
            image->planes = 1;
        else
            image->planes = 3;
    }
    ch = fgetc(file->fp);
    if (!isspace(ch))
        return err("invalid pnm file");
    n = image->width * squaresize;
    if (!(image->buf[0] = calloc(n, image->planes)))
        return err(NULL);
    for (i = 1 ; i < image->planes ; ++i)
        image->buf[i] = image->buf[i - 1] + n;
    image->ypos = 0;
    return 1;
}

int readpnmrow(fileinfo *file, imageinfo *image)
{
    switch (file->type) {
      case pbmasc:  return readpbmascrow(file, image);
      case pgmasc:  return readpgmascrow(file, image);
      case ppmasc:  return readppmascrow(file, image);
      case pbmraw:  return readpbmrawrow(file, image);
      case pgmraw:  return readpgmrawrow(file, image);
      case ppmraw:  return readppmrawrow(file, image);
    }
    return -1;
}
