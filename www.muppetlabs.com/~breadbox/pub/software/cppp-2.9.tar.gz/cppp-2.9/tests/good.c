/*1*/#/*2*/ifdef/*3*/foo\
/*4*/
-Dfoo
  # else //\
5
-Ufoo
# \
    endif
