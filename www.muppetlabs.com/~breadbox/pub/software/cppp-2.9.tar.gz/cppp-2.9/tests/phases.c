#\
i\
f\
d\
e\
f\
 \
f\
o\
o  /* backslash-newline pairs within identifiers */
-Dfoo
%\
:\
e\
l\
s\
e  /* backslash-newline pair within digraph */
-Ufoo
#\
e\
n\
d\
i\
f  /* backslash-newline pair with MS-DOS newline sequence */
