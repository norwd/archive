/*  Copyright (C) 1997 Brian Raiter
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#define	STRICT
#include	<windows.h>
#include	<windowsx.h>
#include	<stdlib.h>
#include	<string.h>
#include	"gdiresqr.h"


#pragma warning(disable: 4705)


#define	SZCHARSET1	"!\"#$%&'()*+,-./0123456789:;<=>?@"		\
			"ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_"		\
			"abcdefghijklmnopqrstuvwxyz{|}~\x7F"
#define	SZCHARSET2	    "\x01\x02\x03\x04\x05\x06\x07"		\
			"\x08\x09\x0A\x0B\x0C\x0D\x0E\x0F"		\
			"\x10\x11\x12\x13\x14\x15\x16\x17"		\
			"\x18\x19\x1A\x1B\x1C\x1D\x1E\x1F"		\
			"\x80\x81\x82\x83\x84\x85\x86\x87"		\
			"\x88\x89\x8A\x8B\x8C\x8D\x8E\x8F"		\
			"\x90\x91\x92\x93\x94\x95\x96\x97"		\
			"\x98\x99\x9A\x9B\x9C\x9D\x9E\x9F"		\
			"\xA0\xA1\xA2\xA3\xA4\xA5\xA6\xA7"		\
			"\xA8\xA9\xAA\xAB\xAC\xAD\xAE\xAF"		\
			"\xB0\xB1\xB2\xB3\xB4\xB5\xB6\xB7"		\
			"\xB8\xB9\xBA\xBB\xBC\xBD\xBE\xBF"		\
			"\xC0\xC1\xC2\xC3\xC4\xC5\xC6\xC7"		\
			"\xC8\xC9\xCA\xCB\xCC\xCD\xCE\xCF"		\
			"\xD0\xD1\xD2\xD3\xD4\xD5\xD6\xD7"		\
			"\xD8\xD9\xDA\xDB\xDC\xDD\xDE\xDF"		\
			"\xE0\xE1\xE2\xE3\xE4\xE5\xE6\xE7"		\
			"\xE8\xE9\xEA\xEB\xEC\xED\xEE\xEF"		\
			"\xF0\xF1\xF2\xF3\xF4\xF5\xF6\xF7"		\
			"\xF8\xF9\xFA\xFB\xFC\xFD\xFE\xFF"
#define	CBCHARSET1	(sizeof SZCHARSET1 - 1)
#define	CBCHARSET2	(sizeof SZCHARSET2 - 1)


OBJINFO		gobjMine[16];
int		gcxMaxWnd, gcyMaxWnd;
int		gnMargin;


static void SizePenWindow(LOGPEN*, SIZE*);
static void SizeBrushWindow(LOGBRUSH*, SIZE*);
static void SizeFontWindow(LOGFONT*, SIZE*);
static void SizePaletteWindow(UINT*, SIZE*);
static void SizeBitmapWindow(BITMAP*, SIZE*);
static void SizeRegionWindow(RGNOBJ*, SIZE*);
static void SizeIconWindow(void*, SIZE*);

static void PaintPen(HDC, RECT*, HPEN, LOGPEN*, char*, int, SIZE*);
static void PaintBrush(HDC, RECT*, HBRUSH, LOGBRUSH*, char*, int, SIZE*);
static void PaintFont(HDC, RECT*, HFONT, LOGFONT*, char*, int, SIZE*);
static void PaintPalette(HDC, RECT*, HPALETTE, UINT*, char*, int, SIZE*);
static void PaintBitmap(HDC, RECT*, HBITMAP, BITMAP*, char*, int, SIZE*);
static void PaintRegion(HDC, RECT*, HRGN, RGNOBJ*, char*, int, SIZE*);
static void PaintIcon(HDC, RECT*, HICON, void*, char*, int, SIZE*);

OBJWNDSIZEPROC	pfnSizers[] = {
			NULL,
			(OBJWNDSIZEPROC)SizePenWindow,
			(OBJWNDSIZEPROC)SizeBrushWindow,
			(OBJWNDSIZEPROC)SizeFontWindow,
			(OBJWNDSIZEPROC)SizePaletteWindow,
			(OBJWNDSIZEPROC)SizeBitmapWindow,
			(OBJWNDSIZEPROC)SizeRegionWindow,
			NULL, NULL, NULL, NULL, NULL,
			(OBJWNDSIZEPROC)SizeIconWindow,
			(OBJWNDSIZEPROC)SizeIconWindow,
			NULL
		};
OBJPAINTPROC	pfnPainters[] = {
			NULL,
			(OBJPAINTPROC)PaintPen,
			(OBJPAINTPROC)PaintBrush,
			(OBJPAINTPROC)PaintFont,
			(OBJPAINTPROC)PaintPalette,
			(OBJPAINTPROC)PaintBitmap,
			(OBJPAINTPROC)PaintRegion,
			NULL, NULL, NULL, NULL, NULL,
			(OBJPAINTPROC)PaintIcon,
			(OBJPAINTPROC)PaintIcon,
			NULL
		};


void AddObjectToMyList(HGDIOBJ	hgdiobj,
		       int	fType,
		       BOOL	bAdd)
{
	int	i, j, n;

	n = sizeof gobjMine / sizeof *gobjMine;
	for (i = n - 1 ; i >= 0 ; --i)
		if (gobjMine[i].hgdiobj)
			break;
	if (bAdd) {
		++i;
		if (i == n) {
			DebugPrintf("Internal GDI object overflow.\r\n");
			return;
		}
		gobjMine[i].hgdiobj = hgdiobj;
		gobjMine[i].fType = fType;
		gobjMine[i].hOwner = GetCurrentTask();
	} else {
		for (j = 0 ; j <= i ; ++j)
			if (gobjMine[j].hgdiobj == hgdiobj)
				break;
		if (j > i) {
			DebugPrintf("Removal of object not on my list.\r\n");
			return;
		}
		if (j != i)
			gobjMine[j] = gobjMine[i];
		gobjMine[i].hgdiobj = NULL;
		gobjMine[i].fType = 0;
		gobjMine[i].hOwner = NULL;
	}	
}

BOOL IsObjectMine(HGDIOBJ	hgdiobj,
		  int		fType)
{
	int	i;

	for (i = 0 ; i < sizeof gobjMine / sizeof *gobjMine &&
					gobjMine[i].hgdiobj ; ++i)
		if (!gobjMine[i].hgdiobj)
			break;
		else if (gobjMine[i].hgdiobj == hgdiobj &&
				gobjMine[i].fType == fType)
			return TRUE;
	return FALSE;
}

static void SizePenWindow(LOGPEN*	plogpen,
			  SIZE*		psize)
{
	psize->cx += 2 * gnMargin + plogpen->lopnWidth.x;
	psize->cy += 2 * gnMargin + plogpen->lopnWidth.x;
	psize->cx *= 2;
	psize->cy *= 2;
}

static void SizeBrushWindow(LOGBRUSH*	plogbrush,
			    SIZE*	psize)
{
	psize->cx += 2 * gnMargin;
	psize->cy += 2 * gnMargin;
	psize->cx *= 2;
	psize->cy *= 2;
	(void)plogbrush;
}

static void SizeFontWindow(LOGFONT*	plogfont,
			   SIZE*	psize)
{
	int	cxChar, cyChar, cxLine;

	if (plogfont->lfWidth > 0)
		cxChar = plogfont->lfWidth;
	else
		cxChar = LOWORD(GetDialogBaseUnits());
	if (plogfont->lfHeight > 0)
		cyChar = plogfont->lfHeight;
	else if (plogfont->lfHeight < 0)
		cyChar = -plogfont->lfHeight + gnMargin;
	else
		cyChar = HIWORD(GetDialogBaseUnits());
	psize->cx += 2 * gnMargin;
	cxLine = CBCHARSET2 * cxChar;
	if (cxLine < gcxMaxWnd)
		psize->cx = max(psize->cx, cxLine) + 2 * gnMargin;
	else {
		cxLine = CBCHARSET1 * cxChar;
		psize->cx = max(psize->cx, cxLine) + 2 * gnMargin;
	}
	psize->cy += 6 * gnMargin + 2 * cyChar;
}

static void SizePaletteWindow(UINT*	pnEntries,
			      SIZE*	psize)
{
	int	cxPal;

	psize->cx += 2 * gnMargin;
	psize->cy += 2 * gnMargin;
	cxPal = 2 * *pnEntries;
	psize->cx = max(psize->cx, cxPal);
	psize->cx += *pnEntries - psize->cx % *pnEntries;
	psize->cy *= 8;
}

static void SizeBitmapWindow(BITMAP*	pbmp,
			     SIZE*	psize)
{
	psize->cx = max(psize->cx, pbmp->bmWidth);
	psize->cx += 2 * gnMargin;
	psize->cy += 3 * gnMargin + pbmp->bmHeight;
}

static void SizeRegionWindow(RGNOBJ*	prgn,
			     SIZE*	psize)
{
	int	cxRgn, cyRgn, cxWnd, cyWnd;

	if (prgn->fType == ERROR) {
		psize->cy += psize->cx / 4;
		return;
	}
	cxRgn = prgn->rcBox.right - prgn->rcBox.left;
	cyRgn = prgn->rcBox.bottom - prgn->rcBox.top;
	cxWnd = max(psize->cx, cxRgn) + 2 * gnMargin;
	cyWnd = psize->cy + cyRgn + 3 * gnMargin;
	while (cxWnd > gcxMaxWnd || cyWnd > gcyMaxWnd) {
		cxRgn /= 2;
		cyRgn /= 2;
		cxWnd = max(psize->cx, cxRgn) + 2 * gnMargin;
		cyWnd = psize->cy + cyRgn + 4 * gnMargin;
	}
	psize->cx = cxWnd;
	psize->cy = cyWnd;
}

static void SizeIconWindow(void*	pNull,
			   SIZE*	psize)
{
	psize->cx = GetSystemMetrics(SM_CXICON) * 3;
	psize->cy = GetSystemMetrics(SM_CYICON) * 3;
	(void)pNull;
}


static void PaintObjectText(HDC		hdc,
			    RECT*	prcWnd,
			    char*	szText,
			    int		cbText,
			    UINT	fPaint,
			    RECT*	prcText)
{
	RECT	rect;
	SIZE	size = *(SIZE*)&prcText->right;
	UINT	fAlign = fPaint & (DT_TOP | DT_CENTER | DT_BOTTOM);

	rect.left = (prcWnd->left + prcWnd->right - size.cx) / 2;
	rect.right = rect.left + size.cx;
	if (fAlign == DT_TOP) {
		rect.top = prcWnd->top + gnMargin;
		rect.bottom = rect.top + size.cy;
		prcText->left = prcWnd->left - 1;
		prcText->top = prcWnd->top - 1;
		prcText->right = prcWnd->right + 1;
		prcText->bottom = rect.bottom + gnMargin + 1;
		prcWnd->top = prcText->bottom + 1;
	} else if (fAlign == DT_BOTTOM) {
		rect.bottom = prcWnd->bottom - gnMargin;
		rect.top = rect.bottom - size.cy;
		prcText->left = prcWnd->left - 1;
		prcText->top = rect.top - gnMargin + 1;
		prcText->right = prcWnd->right + 1;
		prcText->bottom = prcWnd->bottom + 1;
		prcWnd->bottom = prcText->top;
	} else {
		rect.top = (prcWnd->top + prcWnd->bottom - size.cy) / 2;
		rect.bottom = rect.top + size.cy;
		prcText->left = rect.left - gnMargin - 1;
		prcText->top = rect.top - gnMargin - 1;
		prcText->right = rect.right + gnMargin + 1;
		prcText->bottom = rect.bottom + gnMargin + 1;
	}
	Rectangle(hdc, prcText->left, prcText->top,
			prcText->right, prcText->bottom);
	DrawText(hdc, szText, cbText, &rect, DT_CENTER | DT_NOCLIP);
	if (!(fPaint & DT_NOCLIP))
		ExcludeClipRect(hdc, prcText->left, prcText->top,
					prcText->right, prcText->bottom);
	++prcText->right;
	++prcText->bottom;
}

static void PaintPen(HDC	hdc,
		     RECT*	prcWnd,
		     HPEN	hpen,
		     LOGPEN*	plogpen,
		     char*	szObjText,
		     int	cbText,
		     SIZE*	psizeText)
{
	HPEN	hpenSave;
	RECT	rcText;

	rcText.left = rcText.top = 0;
	*(SIZE*)&rcText.right = *psizeText;
	PaintObjectText(hdc, prcWnd, szObjText, cbText, DT_CENTER, &rcText);
	hpenSave = SelectPen(hdc, hpen);
	Rectangle(hdc, (prcWnd->left + rcText.left) / 2,
			(prcWnd->top + rcText.top) / 2,
			(prcWnd->right + rcText.right) / 2,
			(prcWnd->bottom + rcText.bottom) / 2);
	SelectPen(hdc, hpenSave);
	SelectClipRgn(hdc, NULL);
	(void)plogpen;
}

static void PaintBrush(HDC		hdc,
		       RECT*		prcWnd,
		       HBRUSH		hbrush,
		       LOGBRUSH*	plogbrush,
		       char*		szObjText,
		       int		cbText,
		       SIZE*		psizeText)
{
	RECT	rcText;

	rcText.left = rcText.top = 0;
	*(SIZE*)&rcText.right = *psizeText;
	PaintObjectText(hdc, prcWnd, szObjText, cbText, DT_CENTER, &rcText);
	FillRect(hdc, prcWnd, hbrush);
	SelectClipRgn(hdc, NULL);
	(void)plogbrush;
}

static void PaintFont(HDC	hdc,
		      RECT*	prcWnd,
		      HFONT	hfont,
		      LOGFONT*	plogfont,
		      char*	szObjText,
		      int	cbText,
		      SIZE*	psizeText)
{
	HFONT		hfontSave;
	RECT		rcText;
	UINT		fAlignSave;
	int		cyFont;

	rcText.left = rcText.top = 0;
	*(SIZE*)&rcText.right = *psizeText;
	PaintObjectText(hdc, prcWnd, szObjText, cbText, DT_CENTER, &rcText);
	hfontSave = SelectFont(hdc, hfont);
	fAlignSave = SetTextAlign(hdc, TA_CENTER);
	if (plogfont->lfHeight > 0)
		cyFont = plogfont->lfHeight;
	else {
		TEXTMETRIC	tm;

		GetTextMetrics(hdc, &tm);
		cyFont = tm.tmHeight;
	}
	ExtTextOut(hdc, (prcWnd->left + prcWnd->right) / 2, prcWnd->top,
			0, NULL, SZCHARSET1, CBCHARSET1, NULL);
	ExtTextOut(hdc, (prcWnd->left + prcWnd->right) / 2,
			prcWnd->bottom - cyFont,
			0, NULL, SZCHARSET2, CBCHARSET2, NULL);
	SetTextAlign(hdc, fAlignSave);
	SelectFont(hdc, hfontSave);
	SelectClipRgn(hdc, NULL);
}

static void PaintPalette(HDC		hdc,
			 RECT*		prcWnd,
			 HPALETTE	hpal,
			 UINT*		pnEntries,
			 char*		szObjText,
			 int		cbText,
			 SIZE*		psizeText)
{
	HPALETTE	hpalSave;
	RECT		rcStripe, rcText;
	COLORREF	clrBkgndSave;
	UINT		i;
	int		cxStripe;

	hpalSave = SelectPalette(hdc, hpal, FALSE);
	RealizePalette(hdc);
	rcText.left = rcText.top = 0;
	*(SIZE*)&rcText.right = *psizeText;
	PaintObjectText(hdc, prcWnd, szObjText, cbText,
				DT_BOTTOM | DT_NOCLIP, &rcText);
	rcStripe.top = prcWnd->top;
	rcStripe.right = prcWnd->left;
	rcStripe.bottom = rcText.top;
	cxStripe = (prcWnd->right - prcWnd->left - 1) / *pnEntries;
	clrBkgndSave = GetBkColor(hdc);
	for (i = 0 ; i < *pnEntries ; ++i) {
		rcStripe.left = rcStripe.right;
		rcStripe.right += cxStripe;
		SetBkColor(hdc, PALETTEINDEX(i));
		ExtTextOut(hdc, 0, 0, ETO_OPAQUE, &rcStripe, NULL, 0, NULL);
		++rcStripe.right;
	}
	SetBkColor(hdc, clrBkgndSave);
	SelectPalette(hdc, hpalSave, FALSE);
}

static void PaintBitmap(HDC	hdc,
			RECT*	prcWnd,
			HBITMAP	hbmp,
			BITMAP*	pbmp,
			char*	szObjText,
			int	cbText,
			SIZE*	psizeText)
{
	HDC	hmdc;
	HBITMAP	hbmpSave;
	RECT	rcText;
	int	cxBmp, cyBmp;

	rcText.left = rcText.top = 0;
	*(SIZE*)&rcText.right = *psizeText;
	PaintObjectText(hdc, prcWnd, szObjText, cbText,
				DT_BOTTOM | DT_NOCLIP, &rcText);
	hmdc = CreateCompatibleDC(hdc);
	AddObjectToMyList(hmdc, OT_DC, TRUE);
	hbmpSave = SelectBitmap(hmdc, hbmp);
	cxBmp = min(prcWnd->right - prcWnd->left, pbmp->bmWidth);
	cyBmp = min(prcWnd->bottom - prcWnd->top, pbmp->bmHeight);
	BitBlt(hdc, (prcWnd->left + prcWnd->right - cxBmp) / 2,
			(prcWnd->top + prcWnd->bottom - cyBmp) / 2,
			cxBmp, cyBmp, hmdc, 0, 0, SRCCOPY);
	SelectBitmap(hmdc, hbmpSave);
	AddObjectToMyList(hmdc, OT_DC, FALSE);
	DeleteDC(hmdc);
}

static void PaintRegion(HDC	hdc,
			RECT*	prcWnd,
			HRGN	hrgn,
			RGNOBJ*	prgn,
			char*	szObjText,
			int	cbText,
			SIZE*	psizeText)
{
	RECT	rcText;
	SIZE	sizeViewExtSave, sizeWinExtSave;
	POINT	ptViewOrgSave, ptWinOrgSave;
	UINT	fMapSave;

	rcText.left = rcText.top = 0;
	*(SIZE*)&rcText.right = *psizeText;
	PaintObjectText(hdc, prcWnd, szObjText, cbText,
				DT_BOTTOM | DT_NOCLIP, &rcText);
	if (prgn->fType != ERROR && prgn->fType != NULLREGION) {
		fMapSave = SetMapMode(hdc, MM_ISOTROPIC);
		SetWindowExtEx(hdc, abs(prgn->rcBox.left - prgn->rcBox.right),
				abs(prgn->rcBox.top - prgn->rcBox.bottom),
				&sizeWinExtSave);
		SetViewportExtEx(hdc, prcWnd->right - prcWnd->left - 2,
				prcWnd->bottom - prcWnd->top - 2,
				&sizeViewExtSave);
		SetViewportOrgEx(hdc, 1, 1, &ptViewOrgSave);
		SetWindowOrgEx(hdc, prgn->rcBox.left, prgn->rcBox.top,
				&ptWinOrgSave);
		FillRgn(hdc, hrgn, GetStockBrush(DKGRAY_BRUSH));
		SetWindowOrgEx(hdc, ptWinOrgSave.x, ptWinOrgSave.y, NULL);
		SetViewportOrgEx(hdc, ptViewOrgSave.x, ptViewOrgSave.y, NULL);
		SetViewportExtEx(hdc, sizeViewExtSave.cx, sizeViewExtSave.cy,
				NULL);
		SetWindowExtEx(hdc, sizeWinExtSave.cx, sizeWinExtSave.cy,
				NULL);
		SetMapMode(hdc, fMapSave);
	}
}

static void PaintIcon(HDC	hdc,
		      RECT*	prcWnd,
		      HICON	hicon,
		      void*	pNull,
		      char*	szNull,
		      int	cbNull,
		      SIZE*	psizeNull)
{
	DrawIcon(hdc, (prcWnd->left + prcWnd->right -
				GetSystemMetrics(SM_CXICON)) / 2,
			(prcWnd->top + prcWnd->bottom -
				GetSystemMetrics(SM_CYICON)) / 2, hicon);
	(void)pNull;
	(void)szNull;
	(void)cbNull;
	(void)psizeNull;
}


HWND CreateDisplayWindow(HWND		hwndParent,
			 HGDIOBJ	hgdiobj,
			 int		fType,
			 int		xPos,
			 int		yPos)
{
	char	szTemp[32];

	wsprintf(szTemp, "%s %04X", (LPSTR)gszName[fType], (UINT)hgdiobj);
	*szTemp = (char)LOWORD(AnsiUpper((LPSTR)MAKELP(0, *szTemp)));
	return CreateWindow("GDIRescuer.Display", szTemp,
				WS_CAPTION | WS_SYSMENU | WS_THICKFRAME,
				xPos, yPos, 0, 0,
				hwndParent, NULL, ghinstApp,
				(LPVOID)MAKELONG(hgdiobj, fType));
}

LRESULT _export CALLBACK ObjectDisplayWndProc(HWND	hwnd,
					      UINT	message,
					      WPARAM	wParam,
					      LPARAM	lParam)
{
	HDC		hdc;
	PAINTSTRUCT	ps;
	RECT		rc;
	SIZE		size;
	LPCREATESTRUCT	lpcs;
	OBJDISPINFO*	pobjdi;
	LPARAM		lData;
	int		n;

	switch (message) {

		case WM_CREATE:

		lpcs = (LPCREATESTRUCT)lParam;
		lData = (LPARAM)lpcs->lpCreateParams;
		pobjdi = FillObjInfoStruct((HGDIOBJ)LOWORD(lData),
						HIWORD(lData));
		if (!pobjdi)
			return -1;
		SetWindowWord(hwnd, DSPXB(pobjdi), (WORD)pobjdi);

		if (pobjdi->fType == OT_MENU) {
			HMENU	hmenu;

			if (!SetMenu(hwnd, (HMENU)pobjdi->hgdiobj)) {
				ERRORBOX("The item in question isn't a menu.");
				PostMessage(hwnd, WM_CLOSE, 0, 0L);
				return 0;
			}
			hmenu = CreateMenu();
			if (AppendMenu(hmenu, MF_POPUP,
					(UINT)pobjdi->hgdiobj, "&Menu"))
				SetMenu(hwnd, hmenu);
			else
				DestroyMenu(hmenu);
			return 0;
		}

		hdc = GetDC(NULL);
		GetTextExtentPoint(hdc, lpcs->lpszName,
					lstrlen(lpcs->lpszName), &size);
		n = size.cx + 2 * gnMargin + GetSystemMetrics(SM_CXSIZE) * 3;
		ReleaseDC(NULL, hdc);
		size = pobjdi->sizeDesc;
		(pfnSizers[pobjdi->fType])(pobjdi->logobj, &size);
		size.cx = max(size.cx, n);
		size.cx = min(size.cx, gcxMaxWnd);
		size.cy = min(size.cy, gcyMaxWnd);
		rc.left = rc.top = 0;
		rc.right = size.cx;
		rc.bottom = size.cy;
		AdjustWindowRect(&rc, lpcs->style, FALSE);
		SetWindowPos(hwnd, NULL, 0, 0,
				rc.right - rc.left, rc.bottom - rc.top,
				SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
		GetWindowRect(hwnd, &rc);
		if (rc.right >= GetSystemMetrics(SM_CXSCREEN))
			SendMessage(GetWindowOwner(hwnd), DSPM_OUTOFROOM, 0,
						MAKELPARAM(TRUE, TRUE));
		else if (rc.bottom >= GetSystemMetrics(SM_CYSCREEN))
			SendMessage(GetWindowOwner(hwnd), DSPM_OUTOFROOM, 0,
						MAKELPARAM(FALSE, TRUE));
		return 0;

		case WM_ERASEBKGND:

		pobjdi = (OBJDISPINFO*)GetWindowWord(hwnd, DSPXB(pobjdi));
		if (pobjdi->fType == OT_ICON || pobjdi->fType == OT_CURSOR) {
			GetClientRect(hwnd, &rc);
			FillRect((HDC)wParam, &rc,
						GetStockBrush(DKGRAY_BRUSH));
			return 0;
		} else if (pobjdi->fType == OT_BRUSH)
			return 0;
		break;

		case WM_PAINT:

		pobjdi = (OBJDISPINFO*)GetWindowWord(hwnd, DSPXB(pobjdi));
		BeginPaint(hwnd, &ps);
		GetClientRect(hwnd, &rc);
		if (pobjdi->pfnPainter)
			(pobjdi->pfnPainter)(ps.hdc, &rc,
					pobjdi->hgdiobj, &pobjdi->logobj,
					pobjdi->szDesc, pobjdi->cbDesc,
					&pobjdi->sizeDesc);
		EndPaint(hwnd, &ps);
		return 0;

		case WM_PALETTECHANGED:

		if ((HWND)wParam == hwnd)
			return 0;

		case WM_QUERYNEWPALETTE:

		pobjdi = (OBJDISPINFO*)GetWindowWord(hwnd, DSPXB(pobjdi));
		if (pobjdi->fType == OT_PALETTE) {
			HDC		hdc;
			HPALETTE	hpal;

			hdc = GetDC(hwnd);
			hpal = SelectPalette(hdc, pobjdi->hgdiobj, FALSE);
			n = RealizePalette(hdc);
			SelectPalette(hdc, hpal, FALSE);
			ReleaseDC(hwnd, hdc);
			if (n)
				InvalidateRect(hwnd, NULL, FALSE);
			return n;
		} else
			return FALSE;

		case WM_COMMAND:

		if (wParam == IDM_DELETE)
			SetWindowWord(hwnd, DSPXB(bDelete), TRUE);
		return 0;

		case WM_DESTROY:

		pobjdi = (OBJDISPINFO*)GetWindowWord(hwnd, DSPXB(pobjdi));
		if (pobjdi->fType == OT_MENU) {
			HMENU	hmenu;

			hmenu = GetMenu(hwnd);
			SetMenu(hwnd, NULL);
			if (hmenu != pobjdi->hgdiobj) {
				RemoveMenu(hmenu, 0, MF_BYPOSITION);
				DestroyMenu(hmenu);
			}
		}
		if (GetWindowWord(hwnd, DSPXB(bDelete))) {
			UnmakeObject(pobjdi->hgdiobj, pobjdi->fType);
			lData = 0L;
		} else
			lData = MAKELPARAM(pobjdi->hgdiobj, pobjdi->fType);

		SendMessage(GetWindowOwner(hwnd), DSPM_DISPLAYCLOSE,
					(WPARAM)hwnd, lData);
		LocalFree((HLOCAL)pobjdi);
		return 0;

	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}
