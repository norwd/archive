/*  Copyright (C) 1997 Brian Raiter
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#define	STRICT
#include	<windows.h>
#include	<windowsx.h>
#include	<toolhelp.h>
#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>
#include	<ctype.h>
#include	<stdarg.h>
#include	"gdiresqr.h"


#define	SZUSAGE		"A list of undeleted objects is shown, with "	\
			"the htask/hmodule that created it at left. "	\
			"Highlight objects and use Open! to see them "	\
			"or Delete! to delete them.\n\n"		\
			"Command line: gdiresqr [ [!] <obj>[!] ...]\n"	\
			"where <obj> is the hex value of an object "	\
			"to display. Use a ! to automatically delete "	\
			"the object when the window is closed. A ! in "	\
			"front marks all objects without a ! to be deleted."


HINSTANCE	ghinstApp;
char		gszScratch[1024];
WORD		gsegGDI;

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);


void DebugPrintf(char	*szFormat, ...)
{
	va_list	pArgs;

	va_start(pArgs, szFormat);
	wvsprintf(gszScratch, szFormat, pArgs);
	OutputDebugString(gszScratch);
	va_end(pArgs);
}

void UnmakeObject(HGDIOBJ	hgdiobj,
		  int		fType)
{
	WINDEBUGINFO	wdi;

	if (GetWinDebugInfo(&wdi, WDI_OPTIONS) &&
			!(wdi.dwOptions & DBO_SILENT)) {
		wsprintf(gszScratch, "wn GDIRESQR GDI: Deleting %s: %04X\r\n",
					(LPSTR)gszName[fType], (UINT)hgdiobj);
		OutputDebugString(gszScratch);
	}
	if (fType == OT_MENU)
		DestroyMenu(hgdiobj);
	else if (fType == OT_CURSOR)
		DestroyCursor(hgdiobj);
	else if (fType == OT_ICON)
		DestroyIcon(hgdiobj);
	else
		DeleteObject(hgdiobj);
}


BOOL InitProgram(void)
{
	SYSHEAPINFO	sysheap;

	if (LOWORD(GetVersion()) != 0x0a03 || !GetSystemMetrics(SM_DEBUG)) {
		FATALERROR("This application requires Windows 3.1 Debug.");
		return FALSE;
	}

	sysheap.dwSize = sizeof(SYSHEAPINFO);
	if (!SystemHeapInfo(&sysheap)) {
		FATALERROR("Could not access Toolhelp information.");
		return FALSE;
	}
	gsegGDI = (WORD)sysheap.hGDISegment;

	gnMargin = GetSystemMetrics(SM_CXDLGFRAME);
	gcxMaxWnd = 2 * GetSystemMetrics(SM_CXSCREEN) / 3;
	gcyMaxWnd = 2 * GetSystemMetrics(SM_CYSCREEN) / 3;
	return TRUE;
}

int ReadCmdList(HWND	hwnd,
		LPSTR	lpszCmdLine)
{
	HGDIOBJ	hgdiobj;
	HLOCAL	hlmem;
	char	*szLine, *sz;
	int	i;
	BOOL	bDelete, bDefault;

	if (*lpszCmdLine == '?')
		return -1;
	if (*lpszCmdLine == '\0')
		return 0;

	i = lstrlen(lpszCmdLine) + 1;
	hlmem = LocalAlloc(LPTR, i);
	if (!hlmem)
		return 0;
	szLine = (char*)hlmem;
	lstrcpy(szLine, lpszCmdLine);
	if (*szLine == '!') {
		++szLine;
		bDefault = TRUE;
	} else
		bDefault = FALSE;

	for (i = 0 ; *szLine ; ++i) {
		hgdiobj = (HGDIOBJ)(UINT)strtol(szLine, &sz, 16);
		if (!sz || sz == szLine)
			break;
		szLine = sz;
		if (*szLine == '!') {
			bDelete = !bDefault;
			++szLine;
		} else
			bDelete = bDefault;
		if (hgdiobj)
			SendMessage(hwnd, LSTM_OPENOBJECT,
					(WPARAM)hgdiobj, bDelete);
	}
	LocalFree((HLOCAL)hlmem);
	return i;
}

int PASCAL WinMain(HINSTANCE	hInstance,
		   HINSTANCE	hPrevInstance,
		   LPSTR	lpszCmdLine,
		   int		nCmdShow)
{
	WNDCLASS	wndclass;
	MSG		msg;
	HWND		hwnd;

	ghinstApp = hInstance;
	if (!InitProgram())
		return 0;

	if (!hPrevInstance) {
		wndclass.style		= 0;
		wndclass.lpfnWndProc	= (WNDPROC)ObjectListWndProc;
		wndclass.cbClsExtra	= 0;
		wndclass.cbWndExtra	= CBLSTWNDEXTRA;
		wndclass.hInstance	= ghinstApp;
		wndclass.hIcon		= LoadIcon(ghinstApp,
						MAKEINTRESOURCE(IDR_ICON));
		wndclass.hCursor	= LoadCursor(NULL, IDC_ARROW);
		wndclass.hbrBackground	= NULL;
		wndclass.lpszMenuName	= MAKEINTRESOURCE(IDR_MENU);
		wndclass.lpszClassName	= "GDIRescuer.List";
		RegisterClass(&wndclass);

		wndclass.style		= CS_HREDRAW | CS_VREDRAW;
		wndclass.lpfnWndProc	= (WNDPROC)ObjectDisplayWndProc;
		wndclass.cbWndExtra	= CBDSPWNDEXTRA;
		wndclass.hbrBackground	= GetStockBrush(WHITE_BRUSH);
		wndclass.lpszMenuName	= NULL;
		wndclass.lpszClassName	= "GDIRescuer.Display";
		RegisterClass(&wndclass);
	}

	hwnd = CreateWindow("GDIRescuer.List", "GDI Rescuer",
				WS_OVERLAPPEDWINDOW, 0, 0, 0, 0,
				NULL, NULL, ghinstApp, NULL);
	ShowWindow(hwnd, nCmdShow);
	UpdateWindow(hwnd);
	lstrcpy(gszScratch, lpszCmdLine);
	if (ReadCmdList(hwnd, gszScratch) < 0)
		MessageBox(hwnd, SZUSAGE, "Usage", MB_OK);

	while (GetMessage(&msg, NULL, NULL, NULL)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return msg.wParam;
}
