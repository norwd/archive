/*  Copyright (C) 1997 Brian Raiter
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#define	STRICT
#include	<windows.h>
#include	<windowsx.h>
#include	<string.h>
#include	"gdiresqr.h"


#define	SZPENSTYLE(N)	(((N) == PS_SOLID) ? "Solid" :			\
			 ((N) == PS_DASH) ? "Dashed" :			\
			 ((N) == PS_DOT) ? "Dotted" :			\
			 ((N) == PS_DASHDOT) ? "Dash-dotted" :		\
			 ((N) == PS_DASHDOTDOT) ? "Dash-dot-dotted" :	\
			 ((N) == PS_NULL) ? "Null" :			\
			 ((N) == PS_INSIDEFRAME) ? "Inside-frame" : "?")

#define	SZBRUSHSTYLE(N)	(((N) == BS_SOLID) ? "Solid" :			\
			 ((N) == BS_NULL) ? "Null" :			\
			 ((N) == BS_HATCHED) ? "Hatched" :		\
			 ((N) == BS_PATTERN) ? "Pattern" :		\
			 ((N) == BS_INDEXED) ? "Indexed" :		\
			 ((N) == BS_DIBPATTERN) ? "DIB-Pattern" : "?")
#define	SZHATCHSTYLE(N)	(((N) == HS_HORIZONTAL) ? "Horizontal" :	\
			 ((N) == HS_VERTICAL) ? "Vertical" :		\
			 ((N) == HS_FDIAGONAL) ? "Forward-diagonal" :	\
			 ((N) == HS_BDIAGONAL) ? "Backward-diagonal" :	\
			 ((N) == HS_CROSS) ? "Crossed" :		\
			 ((N) == HS_DIAGCROSS) ? "Crossed-diagonal" : "?")
#define	SZPALTYPE(N)	(((N) == DIB_RGB_COLORS) ? "RGB color values" :	\
			 ((N) == DIB_PAL_COLORS) ? "Palette indices" : "?")

#define	SZFONTSET(N)	(((N) == ANSI_CHARSET) ? "ANSI" :		\
			 ((N) == DEFAULT_CHARSET) ? "Default" :		\
			 ((N) == SYMBOL_CHARSET) ? "Symbol" :		\
			 ((N) == SHIFTJIS_CHARSET) ? "ShiftJIS" :	\
			 ((N) == OEM_CHARSET) ? "OEM" : "?")
#define	SZFONTFAMILY(N)	(((N) == FF_SWISS) ? "Swiss" :			\
			 ((N) == FF_MODERN) ? "Modern" :		\
			 ((N) == FF_ROMAN) ? "Roman" :			\
			 ((N) == FF_SCRIPT) ? "Script" :		\
			 ((N) == FF_DECORATIVE) ? "Decorative" :	\
			 ((N) == FF_DONTCARE) ? "don't care" : "?")
#define	SZFONTWEIGHT(N)	(((N) == FW_DONTCARE) ? "don't care" :		\
			 ((N) == FW_THIN) ? "Thin" :			\
			 ((N) == FW_EXTRALIGHT) ? "Extra light" :	\
			 ((N) == FW_LIGHT) ? "Light" :			\
			 ((N) == FW_REGULAR) ? "Regular" :		\
			 ((N) == FW_MEDIUM) ? "Medium" :		\
			 ((N) == FW_DEMIBOLD) ? "Demibold" :		\
			 ((N) == FW_BOLD) ? "Bold" :			\
			 ((N) == FW_EXTRABOLD) ? "Extra bold" :		\
			 ((N) == FW_HEAVY) ? "Heavy" : "?")
#define	SZFONTPITCH(N)	(((N) == DEFAULT_PITCH) ? "Default" :		\
			 ((N) == FIXED_PITCH) ? "Fixed" :		\
			 ((N) == VARIABLE_PITCH) ? "Variable" : "?")
#define	SZQUALITY(N)	(((N) == DEFAULT_QUALITY) ? "Default" :		\
			 ((N) == DRAFT_QUALITY) ? "Draft" :		\
			 ((N) == PROOF_QUALITY) ? "Proof" : "?")
#define	SZOUTPRECIS(N)	(((N) == OUT_DEFAULT_PRECIS) ? "Default" :	\
			 ((N) == OUT_CHARACTER_PRECIS) ? "Character" :	\
			 ((N) == OUT_STRING_PRECIS) ? "String" :	\
			 ((N) == OUT_STROKE_PRECIS) ? "Stroke" :	\
			 ((N) == OUT_DEVICE_PRECIS) ? "Device" :	\
			 ((N) == OUT_RASTER_PRECIS) ? "Raster" :	\
			 ((N) == OUT_TT_PRECIS) ? "TrueType" :		\
			 ((N) == OUT_TT_ONLY_PRECIS) ? "TrueType Only" : "?")
#define	SZCLIPPRECIS(N)	(((N) == CLIP_DEFAULT_PRECIS) ? "Default" :	\
			 ((N) == CLIP_CHARACTER_PRECIS) ? "Character" :	\
			 ((N) == CLIP_STROKE_PRECIS) ? "Stroke" : "?")

#define	SZRGNTYPE(N)	(((N) == SIMPLEREGION) ? "Simple" :		\
			 ((N) == COMPLEXREGION) ? "Complex" :		\
			 ((N) == NULLREGION) ? "Empty" :		\
			 ((N) == ERROR) ? "Invalid" : "?")


static int DescribePen(char*, LOGPEN*);
static int DescribeBrush(char*, LOGBRUSH*);
static int DescribeFont(char*, LOGFONT*);
static int DescribePalette(char*, UINT*);
static int DescribeBitmap(char*, BITMAP*);
static int DescribeRegion(char*, RGNOBJ*);

static OBJDESCRIBEPROC	pfnDescribers[] = {
				NULL,
				(OBJDESCRIBEPROC)DescribePen,
				(OBJDESCRIBEPROC)DescribeBrush,
				(OBJDESCRIBEPROC)DescribeFont,
				(OBJDESCRIBEPROC)DescribePalette,
				(OBJDESCRIBEPROC)DescribeBitmap,
				(OBJDESCRIBEPROC)DescribeRegion,
				NULL, NULL, NULL
			};


int WINAPI GetRegion(HGDIOBJ	hrgn,
		     int	cbBuffer,
		     LPVOID	lpBuffer)
{
	RGNOBJ	rgnobj;
	int	cb;

	rgnobj.fType = GetRgnBox(hrgn, &rgnobj.rcBox);
	cb = min(sizeof(RGNOBJ), cbBuffer);
	_fmemcpy(lpBuffer, &rgnobj, cb);
	return cb;
}


static void MeasureText(HDC	hdc,
			char*	szText,
			int	cbText,
			SIZE*	psizeText)
{
	SIZE	size;
	int	cb, cb0;

	psizeText->cx = psizeText->cy = 0;
	cb0 = 0;
	while (cb0 < cbText) {
		for (cb = cb0 ; cb < cbText ; ++cb)
			if (szText[cb] == '\n')
				break;
		GetTextExtentPoint(hdc, &szText[cb0], cb - cb0, &size);
		psizeText->cx = max(psizeText->cx, size.cx);
		psizeText->cy += size.cy;
		cb0 = cb + 1;
	}
}

static int DescribeColorRef(char*	szText,
			    COLORREF	clr)
{
	if (clr & PALETTEINDEX(0))
		return wsprintf(szText, "Palette entry %d", LOWORD(clr));
	else if (clr & PALETTERGB(0, 0, 0))
		return wsprintf(szText, "Palette ref RGB(%d, %d, %d)",
					GetRValue(clr),
					GetGValue(clr),
					GetBValue(clr));
	else
		return wsprintf(szText, "RGB(%d, %d, %d)",
					GetRValue(clr),
					GetGValue(clr),
					GetBValue(clr));
}

static int DescribePen(char*	szText,
		       LOGPEN*	plogpen)
{
	char*	szLine = szText;

	szLine += wsprintf(szLine, "Width:  %d\nColor:  ",
				plogpen->lopnWidth.x);
	szLine += DescribeColorRef(szLine, plogpen->lopnColor);
	szLine += wsprintf(szLine, "\nStyle:  %s\n",
				(LPSTR)SZPENSTYLE(plogpen->lopnStyle));
	return szLine - szText;
}

static int DescribeBrush(char*		szText,
			 LOGBRUSH*	plogbrush)
{
	char*	szLine = szText;

	szLine += wsprintf(szLine, "Style:  %s\n",
				(LPSTR)SZBRUSHSTYLE(plogbrush->lbStyle));

	switch (plogbrush->lbStyle) {

		case BS_PATTERN:

		szLine += wsprintf(szLine, "Bitmap handle:  %04X\n",
					plogbrush->lbHatch);
		break;

		case BS_DIBPATTERN:

		szLine += wsprintf(szLine, "DIB handle:  %04X\n"
						"DIB palette:  %s\n",
					plogbrush->lbHatch,
					(LPSTR)SZPALTYPE(plogbrush->lbColor));
		break;

		case BS_HATCHED:

		szLine += wsprintf(szLine, "Hatching:  %s\n",
				(LPSTR)SZHATCHSTYLE(plogbrush->lbHatch));
		break;

		case BS_SOLID:

		szLine += wsprintf(szLine, "Color:  ");
		szLine += DescribeColorRef(szLine, plogbrush->lbColor);
		szLine += wsprintf(szLine, "\n");

		break;

	}
	return szLine - szText;
}

static int DescribeFont(char*		szText,
			LOGFONT*	plogfont)
{
	char*	szLine = szText;

	szLine += wsprintf(szLine, "Name:  %s\n"
					"Set:  %s\n"
					"Family:  %s\n"
					"Pitch:  %s\n",
			(LPSTR)plogfont->lfFaceName,
			(LPSTR)SZFONTSET(plogfont->lfCharSet),
			(LPSTR)SZFONTFAMILY(plogfont->lfPitchAndFamily & 0xF0),
			(LPSTR)SZFONTPITCH(plogfont->lfPitchAndFamily & 0x0F));

	if (plogfont->lfHeight == 0)
		szLine += wsprintf(szLine, "Default height\n");
	else if (plogfont->lfHeight < 0)
		szLine += wsprintf(szLine, "Character height:  %d\n",
				-plogfont->lfHeight);
	else
		szLine += wsprintf(szLine, "Cell height:  %d\n",
				plogfont->lfHeight);
	if (plogfont->lfWidth)
		szLine += wsprintf(szLine, "Average width:  %d\n",
				plogfont->lfWidth);

	if (plogfont->lfWeight != FW_NORMAL)
		szLine += wsprintf(szLine, "%s ",
				(LPSTR)SZFONTWEIGHT(plogfont->lfWeight));
	if (plogfont->lfItalic)
		szLine += wsprintf(szLine, "Italic ");
	if (plogfont->lfUnderline)
		szLine += wsprintf(szLine, "Underlined ");
	if (plogfont->lfStrikeOut)
		szLine += wsprintf(szLine, "Strike-out ");
	--szLine;
	szLine += wsprintf(szLine, "\n");

	if (plogfont->lfEscapement)
		szLine += wsprintf(szLine, "Escapement:  %d\n",
				plogfont->lfEscapement);
	if (plogfont->lfOrientation)
		szLine += wsprintf(szLine, "Orientation:  %d\n",
				plogfont->lfOrientation);

	if (plogfont->lfQuality != DEFAULT_QUALITY)
		szLine += wsprintf(szLine, "Output quality:  %s\n",
				(LPSTR)SZQUALITY(plogfont->lfQuality));
	if (plogfont->lfOutPrecision != OUT_DEFAULT_PRECIS)
		szLine += wsprintf(szLine, "Output precision:  %s\n",
				(LPSTR)SZOUTPRECIS(plogfont->lfOutPrecision));
	if (plogfont->lfClipPrecision != CLIP_DEFAULT_PRECIS)
		szLine += wsprintf(szLine, "Clipping precision:  %s\n",
				(LPSTR)SZOUTPRECIS(plogfont->lfClipPrecision &
							CLIP_MASK));
	if (plogfont->lfClipPrecision & ~CLIP_MASK) {
		szLine += wsprintf(szLine, "(");
		if (plogfont->lfClipPrecision & CLIP_EMBEDDED)
			szLine += wsprintf(szLine, "Embedded, ");
		if (plogfont->lfClipPrecision & CLIP_LH_ANGLES)
			szLine += wsprintf(szLine, "Left-hand angles, ");
		if (plogfont->lfClipPrecision & CLIP_TT_ALWAYS)
			szLine += wsprintf(szLine, "TrueType only, ");
		if (plogfont->lfClipPrecision & ~(CLIP_MASK | CLIP_EMBEDDED |
						CLIP_LH_ANGLES |
						CLIP_TT_ALWAYS))
			szLine += wsprintf(szLine, "?, ");
		szLine -= 2;
		szLine += wsprintf(szLine, "\n)\n");
	}
	return szLine - szText;
}

static int DescribePalette(char*	szText,
			   UINT*	pnPalColors)
{
	return wsprintf(szText, "%d %s\n", *pnPalColors,
		(LPSTR)(*pnPalColors == 1 ? "color" : "colors"));
}

static int DescribeBitmap(char*		szText,
			  BITMAP*	pbmp)
{
	HDC	hdc;
	char*	szLine = szText;

	szLine += wsprintf(szLine, "%d x %d", pbmp->bmWidth, pbmp->bmHeight);
	if (pbmp->bmPlanes == 1 && pbmp->bmBitsPixel == 1) {
		hdc = GetDC(NULL);
		if (GetDeviceCaps(hdc, PLANES) != 1 ||
				GetDeviceCaps(hdc, BITSPIXEL) != 1)
			szLine += wsprintf(szLine, " (monochrome)");
		ReleaseDC(NULL, hdc);
	}
	szLine += wsprintf(szLine, "\n");
	return szLine - szText;
}

static int DescribeRegion(char*		szText,
			  RGNOBJ*	prgn)
{
	return wsprintf(szText, "%s:  (%d, %d) - (%d, %d)\n",
				(LPSTR)SZRGNTYPE(prgn->fType), prgn->rcBox);
}


OBJDISPINFO* FillObjInfoStruct(HGDIOBJ	hgdiobj,
			       int	fType)
{
	static int	cbObjType[] = {
				0, sizeof(LOGPEN), sizeof(LOGBRUSH),
				sizeof(LOGFONT), sizeof(UINT), sizeof(BITMAP),
				0, 0, 0, 0
			};
	HDC		hdc;
	OBJDISPINFO*	pobjdi;
	int		cbLogInfo, cbDesc;

	if (cbObjType[fType])
		cbLogInfo = GetObject(hgdiobj, cbObjType[fType], gszScratch);
	else if (fType == OT_REGION)
		cbLogInfo = GetRegion(hgdiobj, sizeof(RGNOBJ), gszScratch);
	else
		cbLogInfo = 0;
	if (pfnDescribers[fType])
		cbDesc = (*pfnDescribers[fType])(gszScratch + cbLogInfo,
							gszScratch);
	else
		cbDesc = 0;
	pobjdi = (OBJDISPINFO*)LocalAlloc(LPTR, sizeof(OBJDISPINFO) +
						cbLogInfo + cbDesc);
	if (!pobjdi)
		return NULL;
	pobjdi->hgdiobj = hgdiobj;
	pobjdi->fType = fType;
	pobjdi->pfnPainter = pfnPainters[fType];
	pobjdi->szDesc = (char*)&pobjdi->logobj + cbLogInfo;
	pobjdi->cbDesc = cbDesc;
	hdc = GetDC(NULL);
	MeasureText(hdc, gszScratch + cbLogInfo, cbDesc, &pobjdi->sizeDesc);
	ReleaseDC(NULL, hdc);
	memcpy(&pobjdi->logobj, gszScratch, cbLogInfo + cbDesc);
	return pobjdi;
}
