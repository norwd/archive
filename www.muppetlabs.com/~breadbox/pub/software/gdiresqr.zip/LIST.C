/*  Copyright (C) 1997 Brian Raiter
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#define	STRICT
#include	<windows.h>
#include	<windowsx.h>
#include	<stdlib.h>
#include	<string.h>
#include	<toolhelp.h>
#include	"gdiresqr.h"


#define	LT_FIRST	LT_GDI_PEN
#define	LT_LAST		(LT_GDI_MAX+1)

#define	LMEM_CHUNK	(64 * sizeof(OBJINFO))

#define	SZHEXCHARS	"0123456789ABCDEF"
#define	SZMENULINE	"_Open!___Delete!___Exit!_"
#define	CBHEXCHARS	(sizeof SZHEXCHARS - 1)
#define	CBMENULINE	(sizeof SZMENULINE - 1)


const char	*gszName[] = {
			"", "pen", "brush", "font", "palette",
			"bitmap", "region", "DC", "disabled DC(?)",
			"meta DC", "metafile", "metafile DC",
			"cursor", "icon", "menu"
		};


int VerifyObject(WORD		segGDI,
		 HGDIOBJ	hgdiobj)
{
	LOCALENTRY	lentry;

	lentry.dwSize = sizeof(LOCALENTRY);
	if (!LocalFirst(&lentry, (HANDLE)segGDI))
		return 0;
	while (lentry.hHandle != hgdiobj)
		if (!LocalNext(&lentry))
			break;
	if (lentry.hHandle == hgdiobj && lentry.wType >= LT_FIRST &&
					lentry.wType <= LT_LAST)
		return lentry.wType;
	else
		return 0;
}

static HTASK GetUnlockedObjectOwner(WORD	segGDI,
				    HGDIOBJ	hgdiobj)
{
	HTASK	htask;

	_asm {
		push	ds
		mov	ds, segGDI
		push	hgdiobj
		call	far ptr LocalLock
		mov	bx, ax
		mov	ax, [bx + 12]
		mov	htask, ax
		push	hgdiobj
		call	far ptr LocalUnlock
		pop	ds
	}
	return htask;
}

static int ListTasks(HANDLE*	phtaskList)
{
	TASKENTRY	tentry;
	int		nTasks;
	BOOL		b;

	nTasks = 0;
	tentry.dwSize = sizeof(TASKENTRY);
	for (b = TaskFirst(&tentry) ; b ; b = TaskNext(&tentry)) {
		if (phtaskList)
			phtaskList[nTasks] = tentry.hTask;
		++nTasks;
	}
	return nTasks;
}

static int ListModules(HANDLE*	phmodList)
{
	MODULEENTRY	mentry;
	HINSTANCE	hinst;
	int		nMods;
	BOOL		b;

	nMods = 0;
	mentry.dwSize = sizeof(MODULEENTRY);
	for (b = ModuleFirst(&mentry) ; b ; b = ModuleNext(&mentry)) {
		if (phmodList)
			phmodList[nMods] = mentry.hModule;
		++nMods;
		if (*(WORD FAR*)MAKELP(mentry.hModule,
					NEFLAGS_OFFSET) & NEFLAG_DLL) {
			hinst = LoadLibrary(mentry.szExePath);
			if (hinst > HINSTANCE_ERROR) {
				FreeLibrary(hinst);
				if (phmodList)
					phmodList[nMods] = hinst;
				++nMods;
			}
		}
	}
	return nMods;
}

static void ExpandObjList(OBJINFO**	ppobjList,
			  int*		pnObjects)
{
	*pnObjects += LMEM_CHUNK;
	if (*ppobjList)
		*ppobjList = (OBJINFO*)LocalReAlloc(*ppobjList, *pnObjects,
							LMEM_MOVEABLE);
	else
		*ppobjList = (OBJINFO*)LocalAlloc(LPTR, *pnObjects);
}

static OBJINFO* ListUndeadGDIObjects(WORD	segGDI,
				     HANDLE*	phtaskList,
				     int*	pnObjects)
{
	LOCALENTRY	lentry;
	OBJINFO*	pobjList;
	HTASK*		phtask;
	HTASK		htaskGDI, htask;
	int		nObjects, nObjList;
	BOOL		b;

	nObjects = 0;
	nObjList = 0;
	pobjList = NULL;

	htaskGDI = GetUnlockedObjectOwner(segGDI, GetStockObject(NULL_BRUSH));
	lentry.dwSize = sizeof(LOCALENTRY);
	for (b = LocalFirst(&lentry, (HANDLE)segGDI) ; b ;
						b = LocalNext(&lentry))
		if (lentry.wType >= LT_FIRST && lentry.wType <= LT_LAST) {
			htask = GETOBJECTOWNER(segGDI, lentry.wAddress);
			if (!htask || htask == htaskGDI)
				continue;
			for (phtask = (HTASK*)phtaskList ; *phtask ; ++phtask)
				if (*phtask == htask)
					break;
			if (!*phtask) {
				if (htask == GetCurrentTask())
					if (IsObjectMine(lentry.hHandle,
								lentry.wType))
						continue;
				if (nObjects >= nObjList)
					ExpandObjList(&pobjList, &nObjList);
				pobjList[nObjects].hgdiobj = lentry.hHandle;
				pobjList[nObjects].fType = lentry.wType;
				pobjList[nObjects].hOwner = htask;
				++nObjects;
			}
		}

	if (pobjList)
		LocalReAlloc((HLOCAL)pobjList,
				(nObjects + 1) * sizeof(OBJINFO), 0);
	pobjList[nObjects].hgdiobj = NULL;
	pobjList[nObjects].fType = 0;
	pobjList[nObjects].hOwner = NULL;
	if (pnObjects)
		*pnObjects = nObjects;
	return pobjList;
}


void EstimateWindowSizes(HWND	hwnd,
			 DWORD	fStyle,
			 HWND	hwndListBox,
			 int	nEntries)
{
	HDC		hdc;
	RECT		rc;
	SIZE		size;
	int		nTabs[2];
	int		cxNum, cxText, cx;
	int		i;

	hdc = GetDC(NULL);
	GetTextExtentPoint(hdc, SZHEXCHARS, CBHEXCHARS, &size);
	cx = size.cx / 5;
	cxNum = size.cx / 4 + cx;
	cxText = 0;
	for (i = 0 ; i < sizeof gszName / sizeof *gszName ; ++i) {
		GetTextExtentPoint(hdc, gszName[i], strlen(gszName[i]), &size);
		cxText = max(cxText, size.cx);
	}
	cxText += cx;
	rc.right = 2 * cxNum + cxText;
	rc.bottom = size.cy * max(nEntries, 5) + size.cy / 2;
	GetTextExtentPoint(hdc, SZMENULINE, CBMENULINE, &size);
	rc.right = max(rc.right, size.cx);
	ReleaseDC(NULL, hdc);
	rc.right = min(rc.right, gcxMaxWnd);
	rc.bottom = min(rc.bottom, gcyMaxWnd);
	rc.left = rc.top = 0;
	AdjustWindowRect(&rc, fStyle | WS_VSCROLL, TRUE);
	rc.right += gnMargin - rc.left;
	rc.left = gnMargin;
	rc.bottom += gnMargin - rc.top;
	rc.top = gnMargin;

	SetWindowPos(hwnd, NULL, rc.left, rc.top,
				rc.right - rc.left, rc.bottom - rc.top,
				SWP_NOZORDER | SWP_NOACTIVATE);
	SetWindowWord(hwnd, LSTXB(xStart), (WORD)(rc.right - gnMargin));
	SetWindowWord(hwnd, LSTXB(xDisplay), (WORD)(rc.right - gnMargin));
	SetWindowWord(hwnd, LSTXB(yStart), (WORD)(rc.top + gnMargin));
	SetWindowWord(hwnd, LSTXB(yDisplay), (WORD)(rc.top + gnMargin));
	cx = LOWORD(GetDialogBaseUnits());
	nTabs[0] = 4 * cxNum / cx;
	nTabs[1] = 4 * (cxNum + cxText) / cx;
	SendMessage(hwndListBox, LB_SETTABSTOPS, 2, (LPARAM)(LPVOID)nTabs);
}

LRESULT _export CALLBACK ObjectListWndProc(HWND		hwnd,
					   UINT		message,
					   WPARAM	wParam,
					   LPARAM	lParam)
{
	HWND		hwndListBox, hwndDisplay;
	PAINTSTRUCT	ps;
	LPCREATESTRUCT	lpcs;
	HTASK*		htaskList;
	OBJINFO*	objinfoList;
	UINT*		idxList;
	DWORD		dwData;
	int		x, y;
	int		i, j, n;

	switch (message) {

		case WM_CREATE:

		lpcs = (LPCREATESTRUCT)lParam;
		hwndListBox = CreateWindow("ListBox", "", LBS_STANDARD |
						LBS_DISABLENOSCROLL |
						LBS_MULTIPLESEL |
						LBS_EXTENDEDSEL |
						LBS_WANTKEYBOARDINPUT |
						LBS_NOINTEGRALHEIGHT |
						LBS_USETABSTOPS |
						WS_CHILD | WS_VISIBLE,
					0, 0, 0, 0, hwnd, (HMENU)IDC_LIST,
					ghinstApp, NULL);
		if (!hwndListBox)
			return -1;

		AddObjectToMyList((HGDIOBJ)GetMenu(hwnd), OT_MENU, TRUE);
		AddObjectToMyList((HGDIOBJ)GetClassWord(hwnd, GCW_HICON),
							OT_ICON, TRUE);
		i = ListTasks(NULL) + ListModules(NULL);
		htaskList = (HTASK*)LocalAlloc(LPTR, (i + 1) * sizeof(HTASK));
		i = ListTasks((HANDLE*)htaskList);
		i += ListModules((HANDLE*)&htaskList[i]);
		htaskList[i] = NULL;
		objinfoList = ListUndeadGDIObjects(gsegGDI,
						(HANDLE*)htaskList, &n);
		LocalFree((HLOCAL)htaskList);

		EstimateWindowSizes(hwnd, lpcs->style, hwndListBox, n);

		while (n--) {
			wsprintf(gszScratch, " %04X:\t%s\t%04X",
					objinfoList[n].hOwner,
					(LPSTR)gszName[objinfoList[n].fType],
					objinfoList[n].hgdiobj);
			i = (int)SendMessage(hwndListBox, LB_ADDSTRING, 0,
						(LPARAM)(LPSTR)gszScratch);
			SendMessage(hwndListBox, LB_SETITEMDATA, i,
					MAKELPARAM(objinfoList[n].hgdiobj,
							objinfoList[n].fType));
		}
		if (objinfoList)
			LocalFree((HLOCAL)objinfoList);

		return 0;

		case WM_SIZE:

		SetWindowPos(GetDlgItem(hwnd, IDC_LIST), NULL, 0, 0,
				LOWORD(lParam) + 1, HIWORD(lParam) + 1,
				SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
		return 0;

		case WM_PAINT:

		BeginPaint(hwnd, &ps);
		EndPaint(hwnd, &ps);
		return 0;

		case WM_SETFOCUS:

		SetFocus(GetDlgItem(hwnd, IDC_LIST));
		return 0;

		case WM_COMMAND:

		switch (wParam) {

			case IDC_LIST:

			if (HIWORD(lParam) != LBN_DBLCLK)
				break;

			case IDM_OPEN:

			hwndListBox = GetDlgItem(hwnd, IDC_LIST);
			n = (int)SendMessage(hwndListBox, LB_GETSELCOUNT,
						0, 0L);
			if (n <= 0)
				break;
			idxList = (UINT*)LocalAlloc(LPTR, n * sizeof(UINT));
			SendMessage(hwndListBox, LB_GETSELITEMS, (WPARAM)n,
						(LPARAM)(LPVOID)idxList);
			x = GetWindowWord(hwnd, LSTXB(xDisplay));
			y = GetWindowWord(hwnd, LSTXB(yDisplay));
			j = GetWindowWord(hwnd, LSTXB(nDispWnds));
			for (i = 0 ; i < n ; ++i) {
				dwData = SendMessage(hwndListBox,
							LB_GETITEMDATA,
							idxList[i], 0L);
				if (!HIWORD(dwData)) {
					SetFocus((HWND)LOWORD(dwData));
					continue;
				}
				hwndDisplay = CreateDisplayWindow(hwnd,
						(HGDIOBJ)LOWORD(dwData),
						HIWORD(dwData), x, y);
				if (!hwndDisplay) {
					MessageBeep(0);
					continue;
				}
				++j;
				ShowWindow(hwndDisplay, SW_SHOW);
				UpdateWindow(hwndDisplay);
				SendMessage(hwndListBox, LB_SETITEMDATA,
						idxList[i],
						MAKELPARAM(hwndDisplay, 0));
				x = GetWindowWord(hwnd, LSTXB(xDisplay));
				y = GetWindowWord(hwnd, LSTXB(yDisplay));
				x += GetSystemMetrics(SM_CXFRAME);
				y += GetSystemMetrics(SM_CYFRAME) +
						GetSystemMetrics(SM_CYSIZE);
				SetWindowWord(hwnd, LSTXB(xDisplay), (WORD)x);
				SetWindowWord(hwnd, LSTXB(yDisplay), (WORD)y);
			}
			LocalFree((HLOCAL)idxList);
			SetWindowWord(hwnd, LSTXB(nDispWnds), (WORD)j);
			break;

			case IDM_DELETE:
			case IDM_MARKDELETE:

			hwndListBox = GetDlgItem(hwnd, IDC_LIST);
			n = (int)SendMessage(hwndListBox, LB_GETSELCOUNT,
						0, 0L);
			if (n <= 0)
				break;
			idxList = (UINT*)LocalAlloc(LPTR, n * sizeof(UINT));
			SendMessage(hwndListBox, LB_GETSELITEMS, (WPARAM)n,
						(LPARAM)(LPVOID)idxList);
			for (i = n - 1 ; i >= 0 ; --i) {
				dwData = SendMessage(hwndListBox,
							LB_GETITEMDATA,
							idxList[i], 0L);
				if (wParam == IDM_DELETE)
					SendMessage(hwndListBox,
							LB_DELETESTRING,
							idxList[i], 0L);
				if (!HIWORD(dwData)) {
					hwndDisplay = (HWND)LOWORD(dwData);
					SendMessage(hwndDisplay, WM_COMMAND,
							IDM_DELETE, lParam);
					if (wParam == IDM_DELETE)
						SendMessage(hwndDisplay,
								WM_CLOSE,
								0, 0L);
				} else
					UnmakeObject((HGDIOBJ)LOWORD(dwData),
							HIWORD(dwData));
			}
			LocalFree((HLOCAL)idxList);
			break;

			case IDM_ABOUT:

			MessageBox(hwnd, "GDI Object Rescuer  v1.0\n\r"
					"for Debug Windows 3.1\n\r\n\r"
					"(C) 1997 by Brian Raiter\n\r"
					"under the GNU General Public License",
					"About", MB_ICONINFORMATION | MB_OK);
			break;

		}
		return 0;

		case WM_VKEYTOITEM:

		if (wParam == VK_DELETE) {
			if (GetKeyState(VK_SHIFT) < 0) {
				SendMessage(hwnd, WM_COMMAND, IDM_OPEN, 0L);
				SendMessage(hwnd, WM_COMMAND,
						IDM_MARKDELETE, 0L);
			} else
				SendMessage(hwnd, WM_COMMAND, IDM_DELETE, 0L);
			return -2;
		} else if (wParam == VK_RETURN) {
			SendMessage(hwnd, WM_COMMAND, IDM_OPEN, 0L);
			return -2;
		} else
			return -1;

		case DSPM_DISPLAYCLOSE:

		hwndListBox = GetDlgItem(hwnd, IDC_LIST);
		n = (int)SendMessage(hwndListBox, LB_GETCOUNT, 0, 0L);
		for (i = 0 ; i < n ; ++i)
			if (LOWORD(SendMessage(hwndListBox, LB_GETITEMDATA,
						(WPARAM)i, 0L)) == wParam) {
				if (lParam)
					SendMessage(hwndListBox,
							LB_SETITEMDATA,
							(WPARAM)i, lParam);
				else
					SendMessage(hwndListBox,
							LB_DELETESTRING,
							(WPARAM)i, 0L);
				break;
			}

		n = GetWindowWord(hwnd, LSTXB(nDispWnds)) - 1;
		SetWindowWord(hwnd, LSTXB(nDispWnds), (WORD)n);
		if (!n) {
			x = GetWindowWord(hwnd, LSTXB(xStart));
			y = GetWindowWord(hwnd, LSTXB(yStart));
			SetWindowWord(hwnd, LSTXB(xDisplay), (WORD)x);
			SetWindowWord(hwnd, LSTXB(yDisplay), (WORD)y);
			SetFocus(hwnd);
		}
		break;

		case DSPM_OUTOFROOM:

		if (LOWORD(lParam)) {
			x = GetWindowWord(hwnd, LSTXB(xStart));
			x -= GetSystemMetrics(SM_CXFRAME);
			SetWindowWord(hwnd, LSTXB(xDisplay), (WORD)x);
		}
		if (HIWORD(lParam)) {
			y = GetWindowWord(hwnd, LSTXB(yStart));
			y -= GetSystemMetrics(SM_CYFRAME) +
					GetSystemMetrics(SM_CYSIZE);
			SetWindowWord(hwnd, LSTXB(yDisplay), (WORD)y);
		}
		return 0;

		case LSTM_OPENOBJECT:

		hwndListBox = GetDlgItem(hwnd, IDC_LIST);
		n = (int)SendMessage(hwndListBox, LB_GETCOUNT, 0, 0L);
		for (i = 0 ; i < n ; ++i)
			if (LOWORD(SendMessage(hwndListBox, LB_GETITEMDATA,
						(WPARAM)i, 0L)) == wParam) {
				SendMessage(hwndListBox, LB_SETSEL, FALSE, -1);
				SendMessage(hwndListBox, LB_SETSEL, TRUE, i);
				SendMessage(hwnd, WM_COMMAND, IDM_OPEN, 0L);
				if (lParam)
					SendMessage(hwnd, WM_COMMAND,
							IDM_MARKDELETE, 0L);
				break;
			}
		break;

		case WM_DESTROY:

		AddObjectToMyList((HGDIOBJ)GetMenu(hwnd), OT_MENU, FALSE);
		AddObjectToMyList((HGDIOBJ)GetClassWord(hwnd, GCW_HICON),
							OT_ICON, FALSE);
		PostQuitMessage(0);
		return 0;

	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}

