 * About This Program

Brain Jam is a solitaire card game. It is similar to soltaire games
like Freecell in that the entire deck is dealt out face up at the
start, so the player has full information. However, unlike many
solitaire programs, Brain Jam comes with a large but finite number of
initial orderings, all of which are guaranteed to be solvable. Thus
there is no luck factor in playing Brain Jam.

Once you have solved a given configuration, you can then go back and
work to find a new solution with fewer moves.


 * Prerequisites

Brain Jam depends on the following libraries:

* ncursesw
* SDL2
* SDL2_ttf
* libpng
* fontconfig

In order to compile Brain Jam, you will need to have installed these
libraries along with their include files. For most Linux users, this
means that you will need to have installed the development packages.
For example, on a Debian-based system, you would run something like:

  sudo apt install libsdl2-dev libsdl2-ttf-dev libpng-dev
                   libncursesw5-dev libfontconfig-dev

Brain Jam can be configured to remove its dependency on some but not
all of the above libraries, at the expense of removing program
functionality. See the "Configuration" section below for details.


 * Configuration

Run "./configure" to configure the build process to your system. You
can use "--prefix", "--exec-prefix", "--datarootdir", "--bindir",
and/or "--mandir" to control where the files will be installed. The
following flags can also be used to modify the nature of the program:

  --without-ncurses

This flag will remove the program's dependency on the ncursesw
library, at the expense of dropping the alternative text-based user
interface. (The default is "--with-ncurses".)

  --without-sdl

This flag will remove the program's dependency on the SDL2 library (as
well as SDL2_ttf and libpng), at the expense of leaving out the graphic
user interface. Only the text-based interface will be avaiable. (The
default is "--with-sdl".)

  --without-fontconfig

This flag will remove the program's dependency on the fontconfig
library. (The default is "--with-fontconfig".) If you remove
fontconfig support, you will need to supply the font's location
explicitly; see the "Font" section below for details.

  --enable-debug

If present, the program will be built with debugging symbols. The
default is "--disable-debug". 


 * Installing

Running "make install" with the necessary permissions will install the
brainjam executable and the man page. There are no external data files
that the program requires access to in order to run.


 * How to Play

Brain Jam comes with its own documentation. You can type "?" or F1 at
any time while the program is running to switch to the help display.
The documentation is also available in "Help.txt" in the top-level
directory, for those who prefer to read plain text files.


 * Files

Brain Jam creates a directory "~/.config/brainjam" for storing your
individual settings and game state. There are two files in this
directory. The file "brainjam.ini" stores your current settings, such
as the number of the most recent game. The file "brainjam.sol"
contains your best solutions for each game you've completed. Note that
these files intentionally use the same filename and format as the
original Windows program. If you used this program, you should be able
to copy your old files over and have all of your existing solutions
available in this program.

Brain Jam also creates a directory "~/.local/share/brainjam" for
storing your undo history for each game. These files are not
human-readable. (If you're curious to know more about them, see the
functions in "src/files/sessionio.c".)


 * Font

By default, Brain Jam attempts to choose a general-purpose serif font
from the available system-installed fonts. You can tell Brain Jam to
prefer a specific font by editing "brainjam.ini" and adding a line
giving a font family name, e.g.:

  font=inter

If you're not sure what family name to supply, you can use the
"fc-match" utility at the command line to see what a family name
resolves to. (Conversely, you can run "fc-query" on an explicit font
filename to see what its family name is.)

If you prefer, you can provide an explicit path to the font of your
choice, e.g.:

  font=/usr/share/fonts/truetype/lato/Lato-Regular.ttf

Note that if you're using a Brain Jam built without fontconfig
support, then this "option" is actually mandatory in order for the
program to run.

(Alternately, the path to your preferred font could be hard-coded into
the binary directly by editing "src/sdl/font.c" before compiling. Hey,
I don't judge.)


 * Websites

The home page for this program is at:

  http://www.muppetlabs.com/~breadbox/software/brainjam.html

From here you can download the latest source tree, as well as
pre-built Windows binaries.

The website for the original Brain Jam program is at:

  http://brainjam.ca/brainjam/

From there you can obtain the original 16-bit Windows binary, as well
as play a variant version that runs in the browser.


 * License

Brain Jam is copyright 2017 by Brian Raiter. This program is free
software; you can redistribute it and/or modify it under the terms of
the GNU General Public License as published by the Free Software
Foundation; either version 3 of the License, or (at your option) any
later version. This program is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
General Public License, included in this distribution in the file
COPYING, for more details.


 * Credits

This program is written by Brian Raiter. The original game comes from
the Brain Jam program for Windows, which was written by Peter Liepa.

The rules of Brain Jam are based on "Baker's Game", as described by
Martin Gardner in the June 1968 issue of Scientific American.

The deck configurations were created by Peter Liepa with assistance
from Bert van Oortmarssen, and are used here with their permission.

The graphics that appear in Brain Jam (with the exception of the
original Brain Jam icon), are either taken from public domain sources,
or have been explicitly placed in the public domain by their creators.


 * Bugs

Bug reports are always appreciated, and can be sent to the author at
<breadbox@muppetlabs.com>.
