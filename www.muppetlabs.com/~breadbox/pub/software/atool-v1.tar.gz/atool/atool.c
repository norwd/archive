#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <errno.h>
#include <getopt.h>
#include <SDL.h>
#include <SDL_syswm.h>
#include <SDL_image.h>

#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif

#define err(fmt, ...) \
    fprintf(stderr, "%s:%d: " fmt "\n", configfilename, lineno, __VA_ARGS__)

typedef struct imageinfo {
    int layer;
    SDL_Scancode scancode;
    SDL_Rect pos;
    SDL_Texture *texture;
    int visible;
} imageinfo;

static char const *configfilename = "./config.txt";
static int lineno;

static SDL_Window *window;
static SDL_Renderer *renderer;
static SDL_Point displaysize = { 1280, 768 };
static SDL_Color bkgndcolor = { 255, 255, 255, 255 };

static imageinfo *images;
static int imagecount;

/*
 *
 */

static int parseuntil(char **pline, char delim, char **pitem)
{
    char *item, *p;
    int found;

    p = *pline;
    while (*p == ' ')
        ++p;
    item = p;
    while (*p && *p != delim)
        ++p;
    found = *p;
    *pline = p + 1;
    while (item < p && isspace(item[0]))
        ++item;
    while (item < p && isspace(p[-1]))
        --p;
    *pitem = item;
    *p = '\0';
    return found ? p - item : 0;
}

static int readglobalvalue(char *line)
{
    char *key;
    int x, y, z;

    if (!parseuntil(&line, '=', &key)) {
        err("unrecognzied value name: \"%s\"", key);
        return FALSE;
    }
    if (!strcasecmp(key, "background")) {
        if (sscanf(line, " #%2X%2X%2X", &x, &y, &z) == 3) {
            bkgndcolor.r = x;
            bkgndcolor.g = y;
            bkgndcolor.b = z;
            return TRUE;
        }
        err("invalid color value: \"%s\"", line);
    } else if (!strcasecmp(key, "width")) {
        if (sscanf(line, "%d", &x) == 1 && x >= 0) {
            displaysize.x = x;
            return TRUE;
        }
        err("invalid width: \"%s\"", line);
    } else if (!strcasecmp(key, "height")) {
        if (sscanf(line, "%d", &y) == 1 && y >= 0) {
            displaysize.y = y;
            return TRUE;
        }
        err("invalid height: \"%s\"", line);
    }
    return FALSE;
}

static int readimagecoord(char const *value, int base)
{
    float f;
    int n;

    if (strchr(value, '.')) {
        if (sscanf(value, "%f", &f) < 1)
            return -1;
        if (f < 0.0 || f > 1.0)
            return -1;
        return (int)(f * base);
    } else {
        if (sscanf(value, "%d", &n) < 1)
            return -1;
        if (n < -16384 || n > +16384)
            return -1;
        if (*value == '+' || *value == '-')
            return base / 2 + n;
        else
            return n;
    }
}

static int readimageline(char *line, int layer)
{
    imageinfo imin;
    SDL_Surface *image;
    char *value;
    int n;

    if (!parseuntil(&line, '=', &value)) {
        err("%s", "syntax error");
        return FALSE;
    }
    n = SDL_GetScancodeFromName(value);
    if (n == SDLK_UNKNOWN) {
        err("unrecognized key name: \"%s\"", value);
        return FALSE;
    } else if (n == SDL_SCANCODE_ESCAPE) {
        err("%s", "Escape is a reserved key and cannot be used");
        return FALSE;
    }
    imin.scancode = n;
    imin.layer = layer;
    imin.visible = FALSE;
    parseuntil(&line, ':', &value);
    if (!strcasecmp(value, "empty")) {
        imin.pos.x = 0;
        imin.pos.y = 0;
        imin.pos.w = 0;
        imin.pos.h = 0;
        imin.texture = NULL;
    } else {
        image = IMG_Load(value);
        if (!image) {
            err("failed to read \"%s\": %s", value, IMG_GetError());
            return FALSE;
        }
        imin.pos.x = (displaysize.x - image->w) / 2;
        imin.pos.y = (displaysize.y - image->h) / 2;
        imin.pos.w = image->w;
        imin.pos.h = image->h;
        imin.texture = SDL_CreateTextureFromSurface(renderer, image);
        SDL_FreeSurface(image);
    }

    if (*line) {
        parseuntil(&line, ' ', &value);
        if (!*value) {
            err("%s", "missing coordinates after colon");
            return FALSE;
        }
        imin.pos.x = readimagecoord(value, displaysize.x);
        if (imin.pos.x < 0) {
            err("invalid coordinate: \"%s\"", value);
            return FALSE;
        }
        parseuntil(&line, ' ', &value);
        if (!*value) {
            err("%s", "missing coordinates after colon");
            return FALSE;
        }
        imin.pos.y = readimagecoord(value, displaysize.y);
        if (imin.pos.y < 0) {
            err("invalid coordinate: \"%s\"", value);
            return FALSE;
        }
    }

    ++imagecount;
    images = realloc(images, imagecount * sizeof *images);
    images[imagecount - 1] = imin;
    return TRUE;
}

static int readconfig(void)
{
    FILE *fp;
    char line[256];
    int layer, n;

    fp = fopen(configfilename, "r");
    if (!fp) {
        perror(configfilename);
        return FALSE;
    }
    layer = 0;
    lineno = 0;
    while (fgets(line, sizeof line, fp)) {
        ++lineno;
        if (*line == '\0' || *line == '\n' || *line == '#')
            continue;
        n = strlen(line);
        if (line[n - 1] == '\n')
            line[--n] = '\0';
        if (!strcasecmp(line, "[layer]")) {
            ++layer;
            if (layer > 255) {
                err("%s", "too many layers");
                return FALSE;
            }
        } else if (layer == 0) {
            if (!readglobalvalue(line))
                return FALSE;
        } else {
            if (!readimageline(line, layer))
                return FALSE;
        }
    }
    fclose(fp);
    return TRUE;
}

/*
 *
 */

static int processkey(SDL_Scancode scancode)
{
    char layers[256];
    int i;

    memset(layers, 0, sizeof layers);
    for (i = 0 ; i < imagecount ; ++i)
        if (images[i].scancode == scancode)
            layers[images[i].layer] = 1;
    for (i = 0 ; i < imagecount ; ++i)
        if (layers[images[i].layer])
            images[i].visible = images[i].scancode == scancode;
    return TRUE;
}

/*
 *
 */

static int fail(char const *title)
{
    SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, title,
			     SDL_GetError(), window);
    return EXIT_FAILURE;
}

static void reportwindowid(void)
{
    SDL_SysWMinfo info;
    char buf[64];

    *buf = '\0';
    SDL_VERSION(&info.version);
    if (SDL_GetWindowWMInfo(window, &info)) {
        if (info.subsystem == SDL_SYSWM_X11)
            sprintf(buf, "windowid=%lu", info.info.x11.window);
    }
    if (!*buf) {
        char const *id = getenv("WINDOWID");
        if (id && *id)
            sprintf(buf, "windowid=%s", id);
    }
    if (*buf) {
        puts(buf);
        SDL_SetWindowTitle(window, buf);
    } else {
        fprintf(stderr, "error: unable to retrieve window id\n");
    }
}

static void render(void)
{
    int i;

    SDL_SetRenderDrawColor(renderer, bkgndcolor.r, bkgndcolor.g, bkgndcolor.b,
                           SDL_ALPHA_OPAQUE);
    SDL_RenderClear(renderer);
    for (i = 0 ; i < imagecount ; ++i)
        if (images[i].visible)
            SDL_RenderCopy(renderer, images[i].texture, NULL, &images[i].pos);
    SDL_RenderPresent(renderer);
}

/*
 * The command line.
 */

static void yowzitch(void)
{
    printf("Usage: atool [OPTION]\n"
           "\n"
           "  -c, --config=FILE     Read config from FILE [config.txt]\n"
           "      --help            Display this help text and exit\n"
           "      --version         Display program version and exit\n"
           "\n"
           "FILE specifies the text file to read for text to display.\n");
}

static void vourzhon(void)
{
    printf("atool: version 1\n");
}

static void readcmdline(int argc, char *argv[])
{
    static char const *optstring = "C:";
    static struct option const options[] = {
        { "config", required_argument, NULL, 'c' },
        { "help", no_argument, NULL, 'H' },
        { "version", no_argument, NULL, 'V' },
        { 0, 0, 0, 0 }
    };

    int ch;

    while ((ch = getopt_long(argc, argv, optstring, options, NULL)) != EOF) {
        switch (ch) {
          case 'c':     configfilename = optarg;        break;
          case 'H':     yowzitch();                     exit(0);
          case 'V':     vourzhon();                     exit(0);
          default:
            fprintf(stderr, "(try \"--help\" for more information)\n");
            exit(EXIT_FAILURE);
        }
    }
    if (optind < argc) {
        fprintf(stderr, "atool: unrecognized option: \"%s\"\n", argv[optind]);
        exit(EXIT_FAILURE);
    }
}

/*
 * main()
 */

int main(int argc, char *argv[])
{
    SDL_Event event;
    int redraw;

    readcmdline(argc, argv);

    if (SDL_Init(SDL_INIT_VIDEO))
	return fail("SDL_Init");
    atexit(SDL_Quit);
    if (!IMG_Init(IMG_INIT_JPG | IMG_INIT_PNG))
	return fail("IMG_Init");
    atexit(IMG_Quit);

    window = SDL_CreateWindow("Animation tool",
                              SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                              displaysize.x, displaysize.y, SDL_WINDOW_HIDDEN);
    if (!window)
	return fail("SDL_CreateWindow");
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (!renderer)
	return fail("SDL_CreateRenderer");

    if (!readconfig())
        return EXIT_FAILURE;

    SDL_SetWindowSize(window, displaysize.x, displaysize.y);
    SDL_ShowWindow(window);

    reportwindowid();

    redraw = TRUE;
    for (;;) {
        if (redraw) {
            render();
            redraw = FALSE;
        }
        if (!SDL_WaitEvent(&event)) {
            fail("SDL_WaitEvent");
            break;
        }
        switch (event.type) {
          case SDL_KEYDOWN:
            if (event.key.keysym.scancode == SDL_SCANCODE_ESCAPE)
		goto done;
            if (processkey(event.key.keysym.scancode))
                redraw = TRUE;
            break;
          case SDL_WINDOWEVENT:
            if (event.window.event == SDL_WINDOWEVENT_EXPOSED)
                redraw = TRUE;
            break;
          case SDL_QUIT:
            goto done;
        }
    }

  done:
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    return 0;
}
