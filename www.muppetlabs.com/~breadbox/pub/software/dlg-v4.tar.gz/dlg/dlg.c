#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <errno.h>
#include <getopt.h>
#include "SDL.h"
#include "SDL_syswm.h"
#include "SDL_ttf.h"
#include <fontconfig/fontconfig.h>

#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif

#define colors4(color)  (color).r, (color).g, (color).b, (color).a

/*
 * The config file.
 */

typedef struct kvpair {
    char *key;
    char *value;
    int lineno;
} kvpair;

static char const *configfilename = "./config.txt";
static kvpair *config;
static int configsize = 0;

static kvpair *getpair(char const *key, int reportmissing)
{
    int i;

    for (i = 0 ; i < configsize ; ++i)
        if (!strcmp(config[i].key, key))
            return &config[i];
    if (reportmissing)
        fprintf(stderr, "%s: missing entry for \"%s\"\n", configfilename, key);
    return NULL;
}

static void addkvpair(char const *key, char const *value, int lineno)
{
    kvpair *pair;

    pair = getpair(key, FALSE);
    if (pair) {
        free(pair->value);
    } else {
        ++configsize;
        config = realloc(config, configsize * sizeof *config);
        pair = &config[configsize - 1];
        pair->key = strdup(key);
    }
    pair->value = strdup(value);
    pair->lineno = lineno;
}

static int readconfig(void)
{
    FILE *fp;
    char line[256];
    char key[256];
    int lineno, n;

    fp = fopen(configfilename, "r");
    if (!fp) {
        perror(configfilename);
        return 0;
    }
    lineno = 0;
    while (fgets(line, sizeof line, fp)) {
        ++lineno;
        if (*line == '\0' || *line == '\n' || *line == '#')
            continue;
        n = strlen(line);
        if (line[n - 1] == '\n')
            line[--n] = '\0';
        if (sscanf(line, "%[^= \t] = %n", key, &n) < 1) {
            fprintf(stderr, "%s:%d: syntax error\n", configfilename, lineno);
            continue;
        }
        addkvpair(key, line + n, lineno);
    }
    fclose(fp);
    return 1;
}

static char const *getvalue(char const *key)
{
    kvpair *pair;

    pair = getpair(key, TRUE);
    return pair ? pair->value : NULL;
}

static int getintvalue(char const *key)
{
    kvpair *pair;
    char *p;
    long n;

    pair = getpair(key, TRUE);
    if (!pair)
        return 0;
    n = strtol(pair->value, &p, 0);
    if (p == pair->value || !p || *p != '\0' ||
                ((n == LONG_MIN || n == LONG_MAX) && errno == ERANGE)) {
        fprintf(stderr, "%s:%d: invalid numerical value: \"%s\"\n",
                configfilename, pair->lineno, pair->value);
        return 0;
    } else if (n < INT_MIN || n > INT_MAX) {
        fprintf(stderr, "%s:%d: numerical value out of range: \"%s\"\n",
                configfilename, pair->lineno, pair->value);
        return 0;
    }
    return (int)n;
}

static SDL_Color getcolorvalue(char const *key)
{
    SDL_Color color = { .a = SDL_ALPHA_OPAQUE };
    kvpair *pair;
    int r, g, b;

    pair = getpair(key, TRUE);
    if (!pair)
        return color;
    if (sscanf(pair->value, "#%2X%2X%2X", &r, &g, &b) != 3) {
        fprintf(stderr, "%s:%d: invalid color definition: \"%s\"\n",
                configfilename, pair->lineno, pair->value);
        return color;
    }
    color.r = r;
    color.g = g;
    color.b = b;
    return color;
}

static void setconfigdefaults(void)
{
    addkvpair("font", "mono", 0);
    addkvpair("fontsize", "27", 0);
    addkvpair("width", "0", 0);
    addkvpair("height", "0", 0);
    addkvpair("columns", "0", 0);
    addkvpair("lines", "0", 0);
    addkvpair("framesize", "6", 0);
    addkvpair("marginsize", "24", 0);
    addkvpair("textcolor", "#FFFFFF", 0);
    addkvpair("bkgndcolor", "#000000", 0);
    addkvpair("speed", "25", 0);
    addkvpair("bloops", "", 0);
}

/*
 * Fontconfig interface.
 */

static char const *lookupfont(char const *fontname)
{
    FcPattern *pattern;
    FcPattern *match;
    FcFontSet *set;
    FcValue value;
    FcResult result;
    char const *filename;
    int i;

    if (!fontname)
        return NULL;
    if (strchr(fontname, '/'))
        return strdup(fontname);

    filename = NULL;
    pattern = NULL;
    set = NULL;
    FcInit();

    pattern = FcNameParse((FcChar8 const*)fontname);
    if (!pattern)
        goto done;
    result = FcConfigSubstitute(NULL, pattern, FcMatchPattern);
    if (!result)
        goto done;
    FcDefaultSubstitute(pattern);
    match = FcFontMatch(NULL, pattern, &result);
    if (!match)
        goto done;
    set = FcFontSetCreate();
    FcFontSetAdd(set, match);
    for (i = 0 ; i < set->nfont ; ++i) {
        FcPatternGet(set->fonts[i], "file", 0, &value);
        if (value.type == FcTypeString) {
            filename = strdup((char const*)value.u.s);
            break;
        }
    }

  done:
    if (set)
        FcFontSetDestroy(set);
    if (pattern)
        FcPatternDestroy(pattern);
    FcFini();
    return filename;
}

/*
 * SDL setup functions.
 */

static SDL_Window *window;
static SDL_Renderer *renderer;
static SDL_TimerID timerid;

static TTF_Font *font;
static SDL_Color textcolor, bkgndcolor;
static int textlinesize, framesize, marginsize;
static int linedisplaycount;
static int timerperiod;

static Uint32 timercallback(Uint32 interval, void *param)
{
    SDL_Event event;

    event.user.type = SDL_USEREVENT;
    event.user.code = interval;
    event.user.data1 = param;
    SDL_PushEvent(&event);
    return interval;
}

static void stoptimer(void)
{
    if (timerid)
        SDL_RemoveTimer(timerid);
    timerid = 0;
}

static void starttimer(void)
{
    if (timerid)
        stoptimer();
    timerid = SDL_AddTimer(timerperiod, timercallback, NULL);
}

/*
 * The script.
 */

typedef struct lineinfo {
    SDL_Texture*texture;
    int         w;
    int         h;
    char       *string;
    int         length;
    int        *widths;
} lineinfo;

typedef struct blockinfo {
    int         linecount;
    int         linesdisplayed;
    int         charsdisplayed;
    char const *prefix;
    lineinfo   *lines;
} blockinfo;

static blockinfo *scriptblocks;
static int scriptblockcount;
static int currentblock = -1;

static blockinfo *addscriptblock(char const *prefix)
{
    int n;

    n = scriptblockcount++;
    scriptblocks = realloc(scriptblocks,
                           scriptblockcount * sizeof *scriptblocks);
    scriptblocks[n].linecount = 0;
    scriptblocks[n].lines = NULL;
    scriptblocks[n].prefix = prefix;
    scriptblocks[n].linesdisplayed = 0;
    scriptblocks[n].charsdisplayed = 0;
    return &scriptblocks[n];
}

static int appendlinetoblock(blockinfo *block, char const *string)
{
    SDL_Surface *image;
    lineinfo *line;
    int ch, i;

    if (!string || !*string)
        return FALSE;

    ++block->linecount;
    block->lines = realloc(block->lines,
                           block->linecount * sizeof *block->lines);
    line = block->lines + block->linecount - 1;
    line->string = strdup(string);
    line->length = strlen(string);
    image = TTF_RenderUTF8_Shaded(font, string, textcolor, bkgndcolor);
    line->w = image->w;
    line->h = image->h;
    line->texture = SDL_CreateTextureFromSurface(renderer, image);
    SDL_FreeSurface(image);

    line->widths = malloc(line->length * sizeof *line->widths);
    line->widths[0] = 0;
    for (i = 1 ; i < line->length ; ++i) {
        ch = line->string[i];
        line->string[i] = '\0';
        TTF_SizeUTF8(font, line->string, &line->widths[i], NULL);
        line->string[i] = ch;
    }
    return TRUE;
}

static int readscript(char const *filename)
{
    blockinfo *block;
    char buf[256];
    FILE *fp;
    int n;

    fp = fopen(filename, "r");
    if (!fp) {
        perror(filename);
        return FALSE;
    }
    block = NULL;
    while (fgets(buf, sizeof buf, fp)) {
        n = strlen(buf);
        if (buf[n - 1] == '\n')
            buf[--n] = '\0';
        if (n == 0) {
            block = NULL;
            continue;
        }
        if (!block)
            block = addscriptblock(NULL);
        appendlinetoblock(block, buf);
    }
    fclose(fp);
    return TRUE;
}

static int getscriptlinecount(void)
{
    int count, i;

    count = 0;
    for (i = 0 ; i < scriptblockcount ; ++i)
        if (count < scriptblocks[i].linecount)
            count = scriptblocks[i].linecount;
    return count;
}

static int getscriptwidth(void)
{
    int width, i, j;

    width = 0;
    for (i = 0 ; i < scriptblockcount ; ++i)
        for (j = 0 ; j < scriptblocks[i].linecount ; ++j)
            if (width < scriptblocks[i].lines[j].w)
                width = scriptblocks[i].lines[j].w;
    return width;
}

static int advancescript(void)
{
    return ++currentblock < scriptblockcount;
}

static blockinfo *getcurrentblock(void)
{
    if (currentblock >= 0 && currentblock < scriptblockcount)
        return &scriptblocks[currentblock];
    else
        return NULL;
}

static void resetscript(void)
{
    int i;

    currentblock = -1;
    for (i = 0 ; i < scriptblockcount ; ++i) {
        scriptblocks[i].linesdisplayed = 0;
        scriptblocks[i].charsdisplayed = 0;
    }
}

static int isblockinprogress(void)
{
    blockinfo *block;

    block = getcurrentblock();
    return block && block->linesdisplayed < block->linecount;
}

static int advanceblocktext(void)
{
    blockinfo *block;

    block = getcurrentblock();
    if (!block || block->linesdisplayed >= block->linecount)
        return 0;
    ++block->charsdisplayed;
    if (block->charsdisplayed >= block->lines[block->linesdisplayed].length) {
        ++block->linesdisplayed;
        if (block->linesdisplayed >= block->linecount)
            return 0;
        block->charsdisplayed = 0;
    }
    return block->lines[block->linesdisplayed].string[block->charsdisplayed];
}

static int advancetoblockend(void)
{
    blockinfo *block;

    block = getcurrentblock();
    if (!block || block->linesdisplayed >= block->linecount)
        return FALSE;
    block->linesdisplayed = block->linecount;
    block->charsdisplayed = 0;
    return TRUE;
}

static int advancetonextblock(void)
{
    blockinfo *block;

    if (!advancescript())
        return FALSE;
    block = getcurrentblock();
    block->linesdisplayed = 0;
    block->charsdisplayed = 0;
    return TRUE;
}

/*
 * SDL rendering functions.
 */

static void renderblock(SDL_Rect const *textarea)
{
    blockinfo const *block;
    SDL_Rect r, s;
    int i;

    block = getcurrentblock();
    if (!block)
        return;
    SDL_RenderSetClipRect(renderer, textarea);
    r.x = textarea->x;
    r.y = textarea->y;
    i = block->linesdisplayed - linedisplaycount + 1;
    if (block->linesdisplayed < block->linecount)
        ++i;
    if (i < 0)
        i = 0;
    for ( ; i < block->linesdisplayed ; ++i) {
        r.w = block->lines[i].w;
        r.h = block->lines[i].h;
        SDL_RenderCopy(renderer, block->lines[i].texture, NULL, &r);
        r.y += textlinesize;
    }
    if (i < block->linecount && block->charsdisplayed > 0) {
        s.x = 0;
        s.y = 0;
        s.w = block->lines[i].widths[block->charsdisplayed];
        s.h = block->lines[i].h;
        r.w = s.w;
        r.h = s.h;
        SDL_RenderCopy(renderer, block->lines[i].texture, &s, &r);
    }
    SDL_RenderSetClipRect(renderer, NULL);
}

static void render(void)
{
    SDL_Rect r;

    r.x = 0;
    r.y = 0;
    SDL_GetWindowSize(window, &r.w, &r.h);
    linedisplaycount = r.h / textlinesize;

    SDL_SetRenderDrawColor(renderer, colors4(textcolor));
    SDL_RenderClear(renderer);
    r.x += framesize;
    r.y += framesize;
    r.w -= framesize * 2;
    r.h -= framesize * 2;
    SDL_SetRenderDrawColor(renderer, colors4(bkgndcolor));
    SDL_RenderFillRect(renderer, &r);

    r.x += marginsize;
    r.y += marginsize;
    r.w -= marginsize * 2;
    r.h -= marginsize * 2;
    renderblock(&r);

    SDL_RenderPresent(renderer);
}

/*
 * Audio functions.
 */

static SDL_AudioDeviceID audioid;
static Uint8 *audiodata;
static int audiodatalen;
static int audiopos;

static void audiocallback(void *data, Uint8 *buf, int bufsize)
{
    int n;

    (void)data;
    if (!audioid || !audiodata || audiopos < 0)
        return;
    if (audiopos >= (int)audiodatalen) {
        audiopos = -1;
        SDL_PauseAudioDevice(audioid, TRUE);
        return;
    }
    n = audiodatalen - audiopos;
    if (n > bufsize) {
        memcpy(buf, audiodata + audiopos, bufsize);
        audiopos += bufsize;
    } else {
        memcpy(buf, audiodata + audiopos, n);
        audiopos += n;
        memset(buf + n, 0, bufsize - n);
    }
}

static void initsound(char const *wavfilename)
{
    SDL_AudioSpec audiospec;
    SDL_AudioSpec desired = { };
    Uint32 len;

    if (!wavfilename || !*wavfilename)
        return;
    desired.freq = 44100;
    desired.format = AUDIO_S16;
    desired.samples = 4096;
    desired.channels = 1;
    desired.callback = audiocallback;
    desired.userdata = NULL;
    audioid = SDL_OpenAudioDevice(NULL, 0, &desired, &audiospec, 0);
    if (audioid == 0)
        return;
    if (!SDL_LoadWAV(wavfilename, &audiospec, &audiodata, &len)) {
        fprintf(stderr, "%s: %s\n", wavfilename, SDL_GetError());
        SDL_CloseAudioDevice(audioid);
        audioid = 0;
    }
    audiodatalen = len;
    audiopos = -1;
}

static void playsound(void)
{
    audiopos = 0;
    SDL_PauseAudioDevice(audioid, FALSE);
}

/*
 *
 */

static void resizewindow(void)
{
    int w, h;

    w = getintvalue("width");
    if (w == 0) {
        w = getintvalue("columns");
        if (w)
            w = w * textlinesize / 2;
        else
            w = getscriptwidth();
        w += 2 * marginsize + 2 * framesize;
    }
    h = getintvalue("height");
    if (h == 0) {
        h = getintvalue("lines");
        if (h == 0) {
            h = getscriptlinecount();
            if (h < 3)
                h = 3;
        }
        h = h * textlinesize;
        h += 2 * marginsize + 2 * framesize;
    }
    SDL_SetWindowSize(window, w, h);
}

static void reportwindowid(void)
{
    SDL_SysWMinfo info;
    char buf[64];

    *buf = '\0';
    SDL_VERSION(&info.version);
    if (SDL_GetWindowWMInfo(window, &info)) {
        if (info.subsystem == SDL_SYSWM_X11)
            sprintf(buf, "windowid=%lu", info.info.x11.window);
    }
    if (!*buf) {
        char const *id = getenv("WINDOWID");
        if (id && *id)
            sprintf(buf, "windowid=%s", id);
    }
    if (*buf) {
        puts(buf);
        SDL_SetWindowTitle(window, buf);
    } else {
        fprintf(stderr, "error: unable to retrieve window id\n");
    }
}

static int fail(char const *title)
{
    SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, title,
			     SDL_GetError(), window);
    return EXIT_FAILURE;
}

/*
 * The command line.
 */

static void yowzitch(void)
{
    printf("Usage: dlg [OPTION] FILE ...\n"
           "\n"
           "  -c, --config=FILE     Read config from FILE [config.txt]\n"
           "      --help            Display this help text and exit\n"
           "      --version         Display program version and exit\n"
           "\n"
           "FILE specifies the text file to read for text to display.\n");
}

static void vourzhon(void)
{
    printf("dlg: version 4\n");
}

static char **readcmdline(int argc, char *argv[])
{
    static char const *optstring = "C:";
    static struct option const options[] = {
        { "config", required_argument, NULL, 'c' },
        { "help", no_argument, NULL, 'H' },
        { "version", no_argument, NULL, 'V' },
        { 0, 0, 0, 0 }
    };

    int ch;

    while ((ch = getopt_long(argc, argv, optstring, options, NULL)) != EOF) {
        switch (ch) {
          case 'c':     configfilename = optarg;        break;
          case 'H':     yowzitch();                     exit(0);
          case 'V':     vourzhon();                     exit(0);
          default:
            fprintf(stderr, "(try \"--help\" for more information)\n");
            exit(EXIT_FAILURE);
        }
    }
    return argv + optind;
}

/*
 * main()
 */

int main(int argc, char *argv[])
{
    SDL_Event event;
    char **scriptfiles;
    int redraw;
    int ch;

    setconfigdefaults();
    scriptfiles = readcmdline(argc, argv);
    if (!readconfig())
        return EXIT_FAILURE;

    textcolor = getcolorvalue("textcolor");
    bkgndcolor = getcolorvalue("bkgndcolor");
    framesize = getintvalue("framesize");
    marginsize = getintvalue("marginsize");
    timerperiod = 1000 / getintvalue("speed");

    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_TIMER))
	return fail("SDL_Init");
    atexit(SDL_Quit);
    if (TTF_Init())
	return fail("TTF_Init");
    atexit(TTF_Quit);

    font = TTF_OpenFont(lookupfont(getvalue("font")), getintvalue("fontsize"));
    if (!font)
	return fail("TTF_OpenFont");
    textlinesize = TTF_FontLineSkip(font);

    initsound(getvalue("bloops"));

    window = SDL_CreateWindow("Dialog",
                              SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                              576, 156, SDL_WINDOW_SHOWN);
    if (!window)
	return fail("SDL_CreateWindow");
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (!renderer)
	return fail("SDL_CreateRenderer");

    while (*scriptfiles)
        if (!readscript(*scriptfiles++))
            return EXIT_FAILURE;
    if (!scriptblockcount) {
        fprintf(stderr, "no script -- nothing to do\n");
        return EXIT_FAILURE;
    }

    resizewindow();
    reportwindowid();

    redraw = TRUE;
    for (;;) {
        if (redraw) {
            render();
            redraw = FALSE;
        }
        if (!SDL_WaitEvent(&event)) {
            fail("SDL_WaitEvent");
            break;
        }
        switch (event.type) {
          case SDL_KEYDOWN:
            if (event.key.keysym.sym == SDLK_ESCAPE) {
		goto done;
            } else if (event.key.keysym.sym == SDLK_r) {
                resetscript();
            } else if (event.key.keysym.sym == SDLK_SPACE) {
                if (isblockinprogress()) {
                    advancetoblockend();
                    stoptimer();
                    redraw = TRUE;
                    break;
                }
                if (!advancetonextblock())
                    goto done;
                starttimer();
                redraw = TRUE;
            }
            break;
          case SDL_USEREVENT:
            ch = advanceblocktext();
            if (!ch)
                stoptimer();
            redraw = TRUE;
            if (ch && ch != ' ')
                playsound();
            break;
          case SDL_WINDOWEVENT:
            if (event.window.event == SDL_WINDOWEVENT_EXPOSED)
                redraw = TRUE;
            break;
          case SDL_QUIT:
            goto done;
        }
    }

  done:
    if (timerid)
	SDL_RemoveTimer(timerid);
    TTF_CloseFont(font);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    return 0;
}
