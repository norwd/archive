
  Welcome to Tile World

Tile World is an emulation of the game "Chip's Challenge" for the Atari
Lynx, created by Chuck Sommerville, and later ported to MS Windows by
Microsoft (among other ports).

This is a beta release of Tile World, meaning that I consider the program
to be "feature-complete". However, the amount of work that needs to be done
before official release remains to be seen.

For directions on getting the program set up and running, see the INSTALL
file.

Tile World is an emulation of the game engines only. It does not come with
the chips.dat level file, which is copyrighted and cannot be freely
distributed. If you do not own a copy of the MS game, however, you can
still play Tile World with the many freely available level files created by
fans of the original game.

  License

Tile World is copyright (C) 2001 by Brian Raiter. This program is free
software; you can redistribute it and/or modify it under the terms of the
GNU General Public License as published by the Free Software Foundation;
either version 2 of the License, or (at your option) any later version.
This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License,
included in this distribution in the file COPYING, for more details.

  Some Notes on the External Resource Files

Tile World loads most of its resource data at runtime from external files.
(The one exception is the program icon, which is hard-coded.) These files
are stored in the res directory. You can specify a different directory at
runtime using the -R command-line option.

The rc file in this directory lists the actual file names for each
resource. Different files can be used for any or all resources depending on
whether the Lynx or the MS ruleset is in effect. The first section of the
rc file specifies resources used with either. Then follows two sections,
prefixed with a line containing either [MS] or [Lynx], containing files
specific to the given ruleset.

The TileImages resource names the bitmap file containing the complete set
of tiles. The tiles in this bitmap are organized in the same fashion as the
bitmap resource embedded in the Windows executable chips.exe. If you have
this program and a resource editor, you can obtain this bitmap and use it
as the TileImages resource to make the game appear more like the MS
version. (Note that this bitmap contains three unused tiles. These
positions are used by Tile World to provide tiles that only appear in the
Lynx ruleset. So, if you wish to use this bitmap for playing under both
rulesets, it is strongly advised that you supply non-blank images for
these.)

Most of the resources are sound files. The Tile World resource names for
the sounds in the MS ruleset have been chosen to match the keys that are
used in the entpack.ini file. This permits you to take the sound files that
are included with the MS version of the game, copy them to Tile World's
resource directory, and then cut-and-paste the lines identifying the sound
files from MS's entpack.ini to Tile World's rc file, if you so choose.

  Bugs

Bug reports are always appreciated, and should be sent to me at the address
below. Check the current BUGS file before doing so to make sure the bug has
not already been documented.

Brian Raiter
<breadbox@muppetlabs.com>
November 2001
