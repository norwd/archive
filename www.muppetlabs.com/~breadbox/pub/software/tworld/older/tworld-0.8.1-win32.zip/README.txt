Welcome to Tile World
---------------------

Tile World is an emulation of the game "Chip's Challenge" for the
Atari Lynx, created by Chuck Sommerville, and later ported to MS
Windows by Microsoft (among other ports).

This is an alpha release of Tile World. The program works quite well
as it now stands, but is missing a couple of features that are needed
before a beta release.

Note that Tile World makes use of the SDL library, a copy of which is
included in this distribution (version 1.2.2). SDL also can be
downloaded from http://www.libsdl.org/download.html.

See the INSTALL.txt file for further directions on getting the program
set up and running.

Tile World is an emulation of the game engines only. It does not come
with the chips.dat level file, which is copyrighted and cannot be
freely distributed. If you do not own a copy of chips.dat, however,
you can still play Tile World with the freely available level files
created by fans of the original game.

Bugs
----

At this time I am unaware of any bugs in the support code (e.g., the
code that finds and lists the available data files, calculates scores,
and so on). The bugs in the game logic that are known to me are
relatively minor. See the BUGS.txt file for details.

Bug reports are always appreciated, and should be sent to me at
<breadbox@muppetlabs.com>.

License
-------

Tile World is copyright (C) 2001 by Brian Raiter. This program is free
software; you can redistribute it and/or modify it under the terms of
the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any
later version. This program is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
General Public License, included in this distribution in the file
COPYING, for more details.

(NOTE: Until the program is officially in beta, I request that you
voluntarily refrain from giving out copies of this program. You are
legally permitted to do so, but I would prefer that the distribution
of this version of the program be kept to a small, known group of
people until it is in a more acceptable state.)

Brian Raiter
<breadbox@muppetlabs.com>
October 2001
