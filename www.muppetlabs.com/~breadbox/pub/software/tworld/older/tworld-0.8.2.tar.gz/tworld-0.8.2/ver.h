#define	VERSION		"0.8.2"
