/* Copyright (C) 1997 Brian Raiter under the GNU General Public License */

#include	"code.h"
#include	"coderc.h"
#include	"main.h"
#include	"game.h"
#include	"eyecon.h"
#include	"dlgs.h"


#define HANDLE_DLGMSG(hwnd, message, fn)				\
		case (message): return (BOOL)HANDLE_##message((hwnd),	\
					(wParam), (lParam), (fn))

static BOOL	bLegal[3];


static BOOL OPT_OnInitDialog(HWND	hwnd,
			     HWND	hwndFocus,
			     LPARAM	lParam)
{
	ShowWindow(GetDlgItem(hwnd, IDC_COLORTEXT),
				bRoundPegs ? SW_SHOWNORMAL : SW_HIDE);
	ShowWindow(GetDlgItem(hwnd, IDC_SHAPETEXT),
				bRoundPegs ? SW_HIDE : SW_SHOWNORMAL);

	bLegal[0] = bLegal[1] = bLegal[2] = TRUE;
	SetDlgItemInt(hwnd, IDC_MAXROWS, nMaxRows, FALSE);
	SetDlgItemInt(hwnd, IDC_MAXCOLS, nMaxCols, FALSE);
	SetDlgItemInt(hwnd, IDC_MAXPEGS, nMaxPegs, FALSE);
	SetDlgItemInt(hwnd, IDC_NUMROWS, nRows, FALSE);
	SetDlgItemInt(hwnd, IDC_NUMCOLS, nCols, FALSE);
	SetDlgItemInt(hwnd, IDC_NUMPEGS, nPegs, FALSE);

	CheckDlgButton(hwnd, IDC_COMMIT, bCanCommit ? 1 : 0);

	if (!bGameInProgress) {
		RECT	rect;
		int	i;

		GetWindowRect(GetDlgItem(hwnd, IDC_WARNING), &rect);
		i = rect.top;
		GetWindowRect(hwnd, &rect);
		SetWindowPos(hwnd, NULL, rect.left, rect.top,
				rect.right - rect.left, i - rect.top,
				SWP_NOZORDER | SWP_NOACTIVATE | SWP_NOREDRAW);
	}

	return TRUE;
}

static void OPT_OnCommand(HWND	hwnd,
			  int	idCtl,
			  HWND	hwndCtl,
			  UINT	nCode)
{
	if (idCtl == IDOK) {
		BOOL	bTemp;

		nRows = GetDlgItemInt(hwnd, IDC_NUMROWS, &bTemp, FALSE);
		nCols = GetDlgItemInt(hwnd, IDC_NUMCOLS, &bTemp, FALSE);
		nPegs = GetDlgItemInt(hwnd, IDC_NUMPEGS, &bTemp, FALSE);
		bCanCommit = IsDlgButtonChecked(hwnd, IDC_COMMIT) ? 1 : 0;
		EndDialog(hwnd, TRUE);
	} else if (idCtl == IDCANCEL)
		EndDialog(hwnd, FALSE);
	else if (nCode == EN_UPDATE) {
		int	nVal, nMax;
		BOOL	bValid;

		nMax = GetDlgItemInt(hwnd, idCtl + IDC_MAXROWS - IDC_NUMROWS,
						&bValid, FALSE);
		nVal = GetDlgItemInt(hwnd, idCtl, &bValid, FALSE);
		bLegal[idCtl - IDC_NUMROWS] = bValid &&
						nVal >= 3 && nVal <= nMax;
		EnableWindow(GetDlgItem(hwnd, IDOK),
				bLegal[0] && bLegal[1] && bLegal[2]);
		return;
	}
}

BOOL __export CALLBACK OptionsDlgProc(HWND	hwnd,
				      UINT	message,
				      WPARAM	wParam,
				      LPARAM	lParam)
{
	switch (message) {
		HANDLE_DLGMSG(hwnd, WM_INITDIALOG, OPT_OnInitDialog);
		HANDLE_DLGMSG(hwnd, WM_COMMAND, OPT_OnCommand);
	}
	return FALSE;
}

static BOOL AB1_OnInitDialog(HWND	hwnd,
			     HWND	hwndFocus,
			     LPARAM	lParam)
{
	HWND	hwndEyecon;

	hwndEyecon = GetDlgItem(hwnd, IDC_EYEICON);
	SendMessage(hwndEyecon, EYE_SETICON, 0, (LPARAM)IDI_MAIN);
	if (!bMonochrome) {
		SendMessage(hwndEyecon, EYE_SETTIMINGS, 0,
						MAKELPARAM(3000, 128));
		SendMessage(hwndEyecon, EYE_SETEYECON, FALSE,
						(LPARAM)IDB_EYEICONS);
	}
	return TRUE;
}

static void AB1_OnCommand(HWND	hwnd,
			  int	idCtl,
			  HWND	hwndCtl,
			  UINT	nCode)
{
	switch (idCtl) {
		case IDOK:
		case IDCANCEL:
			EndDialog(hwnd, idCtl);
			break;

		case IDC_EYEICON:
			if (nCode == BN_DOUBLECLICKED) {
				DLGPROC	lpfnAbout;

				lpfnAbout = MakeDlgProcInstance(About2Proc,
						GetWindowInstance(hwnd));
				DialogBox(GetWindowInstance(hwnd), IDD_ABOUT2,
						hwnd, lpfnAbout);
				FreeDlgProcInstance(lpfnAbout);
			}
			break;
	}
}

BOOL __export CALLBACK About1Proc(HWND		hwnd,
				  UINT		message,
				  WPARAM	wParam,
				  LPARAM	lParam)
{
	switch (message) {
		HANDLE_DLGMSG(hwnd, WM_INITDIALOG, AB1_OnInitDialog);
		HANDLE_DLGMSG(hwnd, WM_COMMAND, AB1_OnCommand);
	}
	return FALSE;
}


BOOL __export CALLBACK About2Proc(HWND		hwnd,
				  UINT		message,
				  WPARAM	wParam,
				  LPARAM	lParam)
 {
	if (message == WM_INITDIALOG) {
		HWND	hwndCtl;
		char	szTemp[80], *sz;

		hwndCtl = GetFirstChild(hwnd);
		for ( ; hwndCtl ; hwndCtl = GetNextSibling(hwndCtl)) {
			GetWindowText(hwndCtl, szTemp, sizeof szTemp);
			for (sz = szTemp ; *sz ; ++sz)
				*sz ^= 0x0F;
			SetWindowText(hwndCtl, szTemp);
		}
		return TRUE;
	} else if (message == WM_COMMAND && HIWORD(lParam) == BN_CLICKED) {
		EndDialog(hwnd, wParam);
		return TRUE;
	} else
		return FALSE;
}
