/* Copyright (C) 1997 Brian Raiter under the GNU General Public License */

#include	<stdlib.h>
#include	"code.h"
#include	"main.h"
#include	"game.h"
#include	"gdi.h"


static HBITMAP	hbmpPegs = NULL, hbmpPegHilite = NULL, hbmpRow = NULL;
static HBRUSH	*hbrushColors = NULL;
static HBRUSH	hbrushBoard = NULL;
static HPEN	hpenShade = NULL, hpenHilite = NULL;
static int	xSelect;
static BOOL	bPegHilite;

static COLORREF	clrPegs[] = {
			RGB(128, 128, 128),
			RGB(0,   0,   0),	RGB(255, 255, 255),
			RGB(255, 0,   0),	RGB(0,   255, 0),
			RGB(0,   0,   255),	RGB(255, 255, 0),
			RGB(255, 0,   255),	RGB(0,   255, 255),
			RGB(166, 202, 240),	RGB(255, 128, 0)
		};


static BOOL MakeRowBitmap(void)
{
	HDC	hdc, hdcMem;
	HBITMAP	hbmp;
	RECT	rect;
	int	i;

	rect.left = 0;
	rect.top = 0;
	rect.right = cxUnit;
	rect.bottom = cyUnit * nCols;
	hdc = GetDC(NULL);
	hdcMem = CreateCompatibleDC(hdc);
	hbmpRow = CreateCompatibleBitmap(hdc, rect.right, rect.bottom);
	ReleaseDC(NULL, hdc);
	if (!hdcMem)
		return FALSE;
	if (!hbmpRow) {
		DeleteDC(hdcMem);
		return FALSE;
	}
	hbmp = SelectBitmap(hdcMem, hbmpRow);
	FillRect(hdcMem, &rect, hbrushBoard);
	SelectPeg(hdcMem, 0);
	for (i = 0 ; i < nCols ; ++i)
		DrawPeg(hdcMem, 0, i * cxUnit);
	SelectPeg(hdcMem, NIL);
	SelectBitmap(hdcMem, hbmp);
	DeleteDC(hdcMem);
	return TRUE;
}

BOOL MakeWindowGDI(BOOL	bFirst)
{
	if (bFirst) {
		hbrushColors = calloc(nMaxPegs + 1, sizeof(HBRUSH));
		if (!hbrushColors)
			return FALSE;
	}
	clrPegs[0] = GetSysColor(COLOR_BTNSHADOW);
	hbrushBoard = CreateSolidBrush(GetSysColor(COLOR_BTNFACE));
	if (!hbrushBoard)
		return FALSE;
	hpenShade = CreatePen(PS_SOLID, 0, GetSysColor(COLOR_BTNSHADOW));
	if (!hpenShade)
		return FALSE;
	hpenHilite = CreatePen(PS_SOLID, 0, GetSysColor(COLOR_BTNHIGHLIGHT));
	if (!hpenHilite)
		return FALSE;
	if (hbrushColors) {
		hbrushColors[0] = CreateSolidBrush(clrPegs[0]);
		if (!hbrushColors[0])
			return FALSE;
	}
	if (hbmpRow) {
		DeleteBitmap(hbmpRow);
		MakeRowBitmap();
	}
	return TRUE;
}

BOOL MakePegGDI(void)
{
	HDC	hdc, hdcMem;
	HBITMAP	hbmp;
	HBRUSH	hbrush, hbrushStipple;
	HPEN	hpen;
	HCURSOR	hcursor;
	int	i, n;

	if (!hbrushColors)
		return FALSE;
	hcursor = SetCursor(LoadCursor(NULL, IDC_WAIT));

	if (bMonochrome) {
		hbrushColors[0] = CreateSolidBrush(clrPegs[0]);
		for (i = 0 ; i < nPegs ; ++i) {
			n = (255 * i) / (nPegs - 1);
			hbrushColors[i + 1] = CreateSolidBrush(RGB(n, n, n));
			if (!hbrushColors[i + 1])
				return FALSE;
		}
	} else {
		for (i = 1 ; i <= nMaxPegs ; ++i) {
			hbrushColors[i] = CreateSolidBrush(clrPegs[i]);
			if (!hbrushColors[i])
				return FALSE;
		}
	}

	if (bRoundPegs) {
		hbmpPegs = CreateBitmap(cxUnit * 2, cyUnit * 2, 1, 1, NULL);
		if (!hbmpPegs)
			return FALSE;
		hbrushStipple = CreateSolidBrush(RGB(128, 128, 128));
		if (!hbrushStipple)
			return FALSE;
		hdc = GetDC(NULL);
		hdcMem = CreateCompatibleDC(hdc);
		ReleaseDC(NULL, hdc);
		if (!hdcMem) {
			DeleteBrush(hbrushStipple);
			return FALSE;
		}
		hbmp = SelectBitmap(hdcMem, hbmpPegs);
		PatBlt(hdcMem, 0, 0, cxUnit * 2, cyUnit * 2, WHITENESS);
		hpen = SelectPen(hdcMem, GetStockPen(NULL_PEN));
		hbrush = SelectBrush(hdcMem, GetStockBrush(BLACK_BRUSH));
		Ellipse(hdcMem, cx8th * 2, cy8th * 2,
				cx8th * 6, cy8th * 6);
		Ellipse(hdcMem, cxUnit + cx8th, cy8th,
				cxUnit * 2 - cx8th, cyUnit - cy8th);
		UnrealizeObject(hbrushStipple);
		SetBrushOrg(hdcMem, 1, 0);
		SelectBrush(hdcMem, hbrushStipple);
		Ellipse(hdcMem, cx8th * 2, cyUnit + cy8th * 2,
				cx8th * 6, cyUnit + cy8th * 6);
		Ellipse(hdcMem, cxUnit + cx8th, cyUnit + cy8th,
				cxUnit * 2 - cx8th, cyUnit * 2 - cy8th);
		SetROP2(hdcMem, R2_WHITE);
		Ellipse(hdcMem, cx8th * 3, cyUnit + cy8th * 3,
				cx8th * 6, cyUnit + cy8th * 6);
		Ellipse(hdcMem, cxUnit + cx8th, cyUnit + cy8th,
				cxUnit + cx8th * 6, cyUnit + cy8th * 6);
		SetROP2(hdcMem, R2_COPYPEN);
		SelectPen(hdcMem, GetStockPen(BLACK_PEN));
		SelectBrush(hdcMem, GetStockBrush(NULL_BRUSH));
		Ellipse(hdcMem, cxUnit + cx8th, cyUnit + cy8th,
				cxUnit * 2 - cx8th, cyUnit * 2 - cy8th);
		SelectBitmap(hdcMem, hbmp);
		SelectBrush(hdcMem, hbrush);
		SelectPen(hdcMem, hpen);
		DeleteBrush(hbrushStipple);
		DeleteDC(hdcMem);
		hbmpPegHilite = LoadBitmap(hinstThis, IDB_COLORHILITE);
		if (!hbmpPegHilite)
			return FALSE;
	} else {
		hbmpPegs = LoadBitmap(hinstThis, IDB_PEGS);
		if (!hbmpPegs)
			return FALSE;
		hbmpPegHilite = LoadBitmap(hinstThis, IDB_SHAPEHILITE);
		if (!hbmpPegHilite)
			return FALSE;
	}

	if (hbmpRow)
		DeleteBitmap(hbmpRow);
	MakeRowBitmap();

	SetCursor(hcursor);
	return TRUE;
}

void ClearPegGDI(void)
{
	int	i;

	if (hbrushColors)
		for (i = 1 ; i <= nMaxPegs ; ++i)
			if (hbrushColors[i]) {
				DeleteBrush(hbrushColors[i]);
				hbrushColors[i] = NULL;
			}
	if (hbmpPegs) {
		DeleteBitmap(hbmpPegs);
		hbmpPegs = NULL;
	}
	if (hbmpPegHilite) {
		DeleteBitmap(hbmpPegHilite);
		hbmpPegHilite = NULL;
	}
	if (hbmpRow) {
		DeleteBitmap(hbmpRow);
		hbmpRow = NULL;
	}
}

void ClearWindowGDI(BOOL	bLast)
{
	if (hbrushBoard) {
		DeleteBrush(hbrushBoard);
		hbrushBoard = NULL;
	}
	if (hpenHilite) {
		DeletePen(hpenHilite);
		hpenHilite = NULL;
	}
	if (hpenShade) {
		DeletePen(hpenShade);
		hpenShade = NULL;
	}
	if (hbrushColors && hbrushColors[0]) {
		DeleteBrush(hbrushColors[0]);
		hbrushColors[0] = NULL;
	}
	if (bLast) {
		if (hbrushColors) {
			free((void*)hbrushColors);
			hbrushColors = NULL;
		}
	}
}

void SelectPeg(HDC	hdc,
	       int	nPeg)
{
	static HBRUSH	hbrush = NULL;

	if (nPeg == NIL) {
		bPegHilite = FALSE;
		if (hbrush) {
			SelectBrush(hdc, hbrush);
			hbrush = NULL;
		}
	} else {
		if (hbrush)
			SelectBrush(hdc, hbrushColors[nPeg]);
		else
			hbrush = SelectBrush(hdc, hbrushColors[nPeg]);
		if (bRoundPegs) {
			xSelect = nPeg ? cxUnit : 0;
			bPegHilite = nPeg != 0;
		} else {
			xSelect = nPeg * cxUnit;
			bPegHilite = nPeg == 1;
		}
	}
}

void DrawPeg(HDC	hdc,
	     int	x,
	     int	y)
{
	HDC	hdcMem;
	HBITMAP	hbmp;

	hdcMem = CreateCompatibleDC(hdc);
	if (!hdcMem)
		return;
	hbmp = SelectBitmap(hdcMem, hbmpPegs);
	BitBlt(hdc, x, y, cxUnit, cyUnit, hdcMem, xSelect, 0, 0xB8074AL);
	BitBlt(hdc, x, y, cxUnit, cyUnit, hdcMem, xSelect, cyUnit, SRCAND);
	if (bPegHilite) {
		SelectBitmap(hdcMem, hbmpPegHilite);
		BitBlt(hdc, x, y, cxUnit, cyUnit, hdcMem, 0, 0, MERGEPAINT);
	}
	SelectBitmap(hdcMem, hbmp);
	DeleteDC(hdcMem);
}

void DrawPegOnBoard(HDC	hdc,
		    int	i,
		    int	j)
{
	RECT	rect;

	rect.left = cx8th + i * (cxUnit + cx8th);
	rect.top = cy8th + j * cyUnit;
	rect.right = rect.left + cxUnit;
	rect.bottom = rect.top + cyUnit;
	FillRect(hdc, &rect, hbrushBoard);
	if (PegBoard[i][j] != NIL) {
		SelectPeg(hdc, PegBoard[i][j]);
		DrawPeg(hdc, rect.left, rect.top);
		SelectPeg(hdc, NIL);
	}
}

void DrawChipRow(HDC	hdc,
		 int	nRow)
{
	HBRUSH	hbrush;
	HPEN	hpen;
	int	x, y;
	int	nBlack, nWhite, i;

	SetWindowOrgEx(hdc, -(cxUnit + cx8th) * nRow, 0, NULL);
	hpen = SelectPen(hdc, GetStockPen(BLACK_PEN));
	hbrush = SelectBrush(hdc, GetStockBrush(WHITE_BRUSH));
	x = cx8th * 2;
	y = -cy8th * 2;
	SetROP2(hdc, bMonochrome ? R2_BLACK : R2_NOTCOPYPEN);
	nBlack = ChipBoard[nRow][0];
	nWhite = ChipBoard[nRow][1];
	for (i = 0 ; i < nBlack + nWhite ; ++i) {
		if (i == nBlack)
			SetROP2(hdc, R2_COPYPEN);
		Rectangle(hdc, x, y - cy8th * 3 + 1,
						x + cx8th * 3 - 1, y);
		x += i % 2 ? -(cx8th * 3 + 1) : cx8th * 3 + 1;
		y += i % 2 ? -(cy8th * 3 + 1) : 0;
	}
	SelectBrush(hdc, hbrush);
	SelectPen(hdc, hpen);
	SetWindowOrgEx(hdc, 0, 0, NULL);
}

void DrawBoard(HDC	hdc,
	       int	cxBoard,
	       int	cyChipBoard,
	       int	cyPegBoard)
{
	HDC	hdcMem;
	HBITMAP	hbmp;
	HPEN	hpen;
	RECT	rect;
	int	i;

	rect.left = 0;
	rect.top = -cyChipBoard;
	rect.right = cxBoard + 1;
	rect.bottom = cyPegBoard + 1;
	FillRect(hdc, &rect, hbrushBoard);
	hpen = SelectPen(hdc, hpenHilite);
	MoveToEx(hdc, cxBoard - 2, -cyChipBoard, NULL);
	LineTo(hdc, 0, -cyChipBoard);
	LineTo(hdc, 0, cyPegBoard - 1);
	SelectPen(hdc, hpenShade);
	MoveToEx(hdc, 1, cyPegBoard - 1, NULL);
	LineTo(hdc, cxBoard - 1, cyPegBoard - 1);
	LineTo(hdc, cxBoard - 1, -cyChipBoard);
	MoveToEx(hdc, 1, 0, NULL);
	LineTo(hdc, cxBoard - 1, 0);
	SetWindowOrgEx(hdc, -cx8th / 2, cyChipBoard, NULL);
	for (i = 1 ; i <= nRows ; ++i) {
		SelectPen(hdc, hpenShade);
		MoveTo(hdc, i * (cxUnit + cx8th), 1);
		LineTo(hdc, i * (cxUnit + cx8th),
				cyChipBoard + cyPegBoard - 1);
		SelectPen(hdc, hpenHilite);
		MoveTo(hdc, i * (cxUnit + cx8th) - 1, 1);
		LineTo(hdc, i * (cxUnit + cx8th) - 1,
				cyChipBoard + cyPegBoard - 1);
	}
	SetWindowOrgEx(hdc, 0, 0, NULL);
	MoveTo(hdc, 1, -1);
	LineTo(hdc, cxBoard - 1, -1);
	SelectPen(hdc, hpen);

	if (hbmpRow) {
		hdcMem = CreateCompatibleDC(hdc);
		hbmp = SelectBitmap(hdcMem, hbmpRow);
	}
	for (i = 0 ; i < nRows ; ++i) {
		int	j;

		if (hbmpRow) {
			if (PegBoard) {
				for (j = 0 ; j < nCols ; ++j)
					if (PegBoard[i][j])
						break;
			} else
				j = nCols;
		} else
			j = 0;
		if (j)
			BitBlt(hdc, (cxUnit + cx8th) * i + cx8th, cy8th,
					cxUnit, cyUnit * j,
					hdcMem, 0, 0, SRCCOPY);
		for ( ; j < nCols ; ++j) {
			SelectPeg(hdc, PegBoard[i][j]);
			DrawPeg(hdc, (cxUnit + cx8th) * i + cx8th,
					cyUnit * j + cy8th);
		}
		SelectPeg(hdc, NIL);
		DrawChipRow(hdc, i);
	}
	if (hbmpRow) {
		SelectBitmap(hdcMem, hbmp);
		DeleteDC(hdcMem);
	}
	if (!bGameInProgress) {
		for (i = 0 ; i < nCols ; ++i) {
			SelectPeg(hdc, Answer[i]);
			DrawPeg(hdc, cx8th * 5 + (cxUnit + cx8th) * nRows,
						cy8th + cyUnit * i);
		}
	}
	SelectPeg(hdc, NIL);

	SetWindowOrgEx(hdc, 0, 0, NULL);
}

void DrawPegMove(int	nPeg,
		 int	xNew,
		 int	yNew,
		 int	nPegUnder,
		 int	mode)
{
	static HBITMAP	hbmpUnder;
	static int	xOld, yOld;
	HDC		hdc, hdcUnder, hdcBoth;
	HBITMAP		hbmpBoth;
	HBRUSH		hbrush;
	int		xDiff, yDiff;
	BOOL		bOverlap;

	hdc = GetDC(NULL);
	hdcUnder = CreateCompatibleDC(hdc);
	if (mode == pegGrab) {
		hbmpUnder = CreateCompatibleBitmap(hdc, cxUnit, cyUnit);
		xOld = xNew;
		yOld = yNew;
	}
	SelectBitmap(hdcUnder, hbmpUnder);
	if (mode != pegLose) {
		xDiff = xNew - xOld;
		yDiff = yNew - yOld;
		bOverlap = (abs(xDiff) < cxUnit || abs(yDiff) < cyUnit);
		if (!bOverlap) {
			xDiff = cxUnit;
			yDiff = 0;
		}
		hdcBoth = CreateCompatibleDC(hdc);
		hbmpBoth = CreateCompatibleBitmap(hdc, cxUnit + abs(xDiff),
							cyUnit + abs(yDiff));
		SelectBitmap(hdcBoth, hbmpBoth);
		if (bOverlap)
			BitBlt(hdcBoth, 0, 0,
				cxUnit + abs(xDiff), cyUnit + abs(yDiff), hdc,
				min(xNew, xOld), min(yNew, yOld), SRCCOPY);
		else
			BitBlt(hdcBoth, xDiff, yDiff, cxUnit, cyUnit,
						hdc, xNew, yNew, SRCCOPY);
		if (mode != pegGrab)
			BitBlt(hdcBoth, max(0, -xDiff), max(0, -yDiff),
				cxUnit, cyUnit, hdcUnder, 0, 0, SRCCOPY);
		if (nPegUnder != NIL) {
			hbrush = SelectBrush(hdcBoth, hbrushBoard);
			PatBlt(hdcBoth, max(0, xDiff), max(0, yDiff),
					cxUnit, cyUnit, PATCOPY);
			SelectBrush(hdcBoth, hbrush);
			SelectPeg(hdcBoth, nPegUnder);
			DrawPeg(hdcBoth, max(0, xDiff), max(0, yDiff));
		}
		if (mode != pegDrop)
			BitBlt(hdcUnder, 0, 0, cxUnit, cyUnit, hdcBoth,
					max(0, xDiff), max(0, yDiff), SRCCOPY);
		SelectPeg(hdcBoth, nPeg);
		DrawPeg(hdcBoth, max(0, xDiff), max(0, yDiff));
		if (bOverlap)
			BitBlt(hdc, min(xNew, xOld), min(yNew, yOld),
				cxUnit + abs(xDiff), cyUnit + abs(yDiff),
				hdcBoth, 0, 0, SRCCOPY);
		else {
			BitBlt(hdc, xNew, yNew, cxUnit, cyUnit, hdcBoth,
							xDiff, yDiff, SRCCOPY);
			BitBlt(hdc, xOld, yOld, cxUnit, cyUnit, hdcBoth,
							0, 0, SRCCOPY);
		}
		SelectPeg(hdcBoth, NIL);
		DeleteDC(hdcBoth);
		DeleteBitmap(hbmpBoth);
		xOld = xNew;
		yOld = yNew;
	} else
		BitBlt(hdc, xOld, yOld, cxUnit, cyUnit,
				hdcUnder, 0, 0, SRCCOPY);
	DeleteDC(hdcUnder);
	ReleaseDC(NULL, hdc);
	if (mode == pegDrop || mode == pegLose)
		DeleteBitmap(hbmpUnder);
}

void DrawEndGame(HWND	hwnd,
		 int	xButton,
		 int	yButton,
		 int	cxButton,
		 int	cyButton)
{
	HDC	hdc, hdcSlide, hdcUnder, hdcEdge;
	HBITMAP	hbmpSlide, hbmpUnder, hbmpEdge;
	int	x;
	int	i;

	hdc = GetDC(hwnd);
	hdcSlide = CreateCompatibleDC(hdc);
	hdcUnder = CreateCompatibleDC(hdc);
	hdcEdge = CreateCompatibleDC(hdc);
	hbmpSlide = CreateCompatibleBitmap(hdc, cxButton, cyButton);
	hbmpUnder = CreateCompatibleBitmap(hdc, cxButton, cyButton);
	hbmpEdge = CreateCompatibleBitmap(hdc, cx8th, cyButton);
	SelectBitmap(hdcSlide, hbmpSlide);
	SelectBitmap(hdcUnder, hbmpUnder);
	SelectBitmap(hdcEdge, hbmpEdge);
	BitBlt(hdcSlide, 0, 0, cxButton, cyButton,
				hdc, xButton, yButton, SRCCOPY);
	BitBlt(hdcEdge, 0, 0, 5, cyButton,
				hdc, xButton, yButton, SRCCOPY);
	SelectBrush(hdcUnder, hbrushBoard);
	PatBlt(hdcUnder, 0, 0, cxButton, cyButton, PATCOPY);
	for (i = 0 ; i < nCols ; ++i) {
		SelectPeg(hdcUnder, Answer[i]);
		DrawPeg(hdcUnder, cx8th * 2, cyUnit * i);
	}
	SelectPeg(hdcUnder, NIL);
	for (x = 0 ; x < cxButton - cx8th * 2 ; ++x) {
		BitBlt(hdcSlide, x, 0, 1, cyButton,
					hdcUnder, x, 0, SRCCOPY);
		BitBlt(hdcSlide, x + 1, 0, cx8th, cyButton,
					hdcEdge, 0, 0, SRCCOPY);
		BitBlt(hdc, xButton, yButton, cxButton, cyButton,
					hdcSlide, 0, 0, SRCCOPY);
	}
	BitBlt(hdc, xButton, yButton, cxButton, cyButton,
					hdcUnder, 0, 0, SRCCOPY);
	ReleaseDC(hwnd, hdc);
	DeleteDC(hdcSlide);
	DeleteDC(hdcUnder);
	DeleteDC(hdcEdge);
	DeleteBitmap(hbmpSlide);
	DeleteBitmap(hbmpUnder);
	DeleteBitmap(hbmpEdge);
}
