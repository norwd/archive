/* Copyright (C) 1997 Brian Raiter under the GNU General Public License */

#include	<stdlib.h>
#include	"code.h"
#include	"eyecon.h"


#define	MakeTimerProcInstance(timerproc, hinst)				\
		(TIMERPROC)MakeProcInstance((FARPROC)timerproc, hinst);
#define	FreeTimerProcInstance(timerproc)				\
		FreeProcInstance((FARPROC)timerproc);

static const int	idTimerBase = 10;

typedef	struct EYECONDATA {
		TIMERPROC	lpfnEyeconTimer;
		HBITMAP		hbmpEyecons;
		HBITMAP		hbmpEyeMask;
		COLORREF	clrBkgnd;
		HBITMAP		hbmpWnd;
		HICON		hicon;
		int		nCel;
		int		nCels;
		UINT		nTime0;
		UINT		nTime1;
		BOOL		bAnimating;
		BOOL		bBounce;
	} EYECONDATA;

#define	GetEyeconData(hwnd)	((EYECONDATA*)GetWindowWord((hwnd), 0))
#define	SetEyeconData(hwnd, pData)	\
		((EYECONDATA*)SetWindowWord((hwnd), 0, (WORD)(pData)));


void __export CALLBACK EyeconTimerProc(HWND	hwnd,
				       UINT	message,
				       UINT	idTimer,
				       DWORD	dwTime)
{
	EYECONDATA	*pData = GetEyeconData(hwnd);

	if (!pData) {
		KillTimer(hwnd, idTimer);
		return;
	}

	if (idTimer & 1) {
		++pData->nCel;
		InvalidateRect(hwnd, NULL, FALSE);
		if (pData->nCel == pData->nCels) {
			pData->nCel = -pData->nCel;
			if (!pData->bBounce) {
				KillTimer(hwnd, idTimer);
				pData->bAnimating = FALSE;
				SetTimer(hwnd, idTimer - 1, pData->nTime0,
						pData->lpfnEyeconTimer);
			}
		} else if (!pData->nCel) {
			KillTimer(hwnd, idTimer);
			pData->bAnimating = FALSE;
			SetTimer(hwnd, idTimer - 1, pData->nTime0,
					pData->lpfnEyeconTimer);
		}
	} else if (rand() < 8192) {
		KillTimer(hwnd, idTimer);
		pData->bAnimating = TRUE;
		SetTimer(hwnd, idTimer + 1, pData->nTime1,
				pData->lpfnEyeconTimer);
	}
}

static int GetEyeconBitmaps(HINSTANCE	hinst,
			    LPCSTR	lpszResource,
			    EYECONDATA	*pData)
{
	HDC	hdc, hdcBmps, hdcTemp;
	HBITMAP	hbmp, hbmpTemp;
	BITMAP	bmp;

	hbmpTemp = LoadBitmap(hinst, lpszResource);
	if (!hbmpTemp)
		return 0;
	GetObject(hbmpTemp, sizeof(BITMAP), &bmp);
	hdc = GetDC(NULL);
	hdcBmps = CreateCompatibleDC(hdc);
	hdcTemp = CreateCompatibleDC(hdc);
	hbmpTemp = SelectBitmap(hdcTemp, hbmpTemp);
	hbmp = CreateCompatibleBitmap(hdc, bmp.bmWidth - 1, bmp.bmHeight);
	ReleaseDC(NULL, hdc);
	hbmp = SelectBitmap(hdcBmps, hbmp);
	BitBlt(hdcBmps, 0, 0, bmp.bmWidth - 1, bmp.bmHeight,
			hdcTemp, 1, 0, SRCCOPY);
	pData->hbmpEyecons = SelectBitmap(hdcBmps, hbmp);
	hbmp = CreateBitmap(bmp.bmWidth - 1, bmp.bmHeight, 1, 1, NULL);
	hbmp = SelectBitmap(hdcBmps, hbmp);
	pData->clrBkgnd = GetPixel(hdcTemp, 0, 0);
	SetBkColor(hdcTemp, pData->clrBkgnd);
	BitBlt(hdcBmps, 0, 0, bmp.bmWidth - 1, bmp.bmHeight,
			hdcTemp, 1, 0, SRCCOPY);
	DeleteBitmap(SelectBitmap(hdcTemp, pData->hbmpEyecons));
	SetBkColor(hdcTemp, RGB(0, 0, 0));
	SetTextColor(hdcTemp, RGB(255, 255, 255));
	BitBlt(hdcTemp, 0, 0, bmp.bmWidth - 1, bmp.bmHeight,
			hdcBmps, 0, 0, SRCAND);
	pData->hbmpEyecons = SelectBitmap(hdcTemp, hbmpTemp);
	pData->hbmpEyeMask = SelectBitmap(hdcBmps, hbmp);
	DeleteDC(hdcTemp);
	DeleteDC(hdcBmps);
	return bmp.bmWidth - 1;
}

static BOOL EYE_OnCreate(HWND		hwnd,
			 LPCREATESTRUCT	lpcs)
{
	HDC		hdc;
	EYECONDATA	*pData;
	int		cxWnd, cyWnd;

	pData = calloc(sizeof(EYECONDATA), 1);
	if (!pData)
		return FALSE;
	SetEyeconData(hwnd, pData);

	cxWnd = GetSystemMetrics(SM_CXICON);
	cyWnd = GetSystemMetrics(SM_CYICON);
	hdc = GetDC(NULL);
	pData->hbmpWnd = CreateCompatibleBitmap(hdc, cxWnd, cyWnd);
	ReleaseDC(NULL, hdc);
	pData->hicon = LoadIcon(lpcs->hInstance, IDI_MAIN);
	SetWindowPos(hwnd, NULL, 0, 0, cxWnd, cyWnd,
				SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
	return TRUE;
}

static void EYE_OnPaint(HWND	hwnd)
{
	HDC		hdc;
	PAINTSTRUCT	ps;
	EYECONDATA	*pData;

	pData = GetEyeconData(hwnd);
	hdc = BeginPaint(hwnd, &ps);
	if (pData->hbmpEyecons) {
		HDC	hdcMem, hdcEyecon;
		HBITMAP	hbmpMem, hbmp;
		HBRUSH	hbrush;
		int	cxWnd, cyWnd;

		cxWnd = GetSystemMetrics(SM_CXICON);
		cyWnd = GetSystemMetrics(SM_CYICON);
		hdcMem = CreateCompatibleDC(hdc);
		hbmpMem = SelectBitmap(hdcMem, pData->hbmpWnd);
		hbrush = (HBRUSH)GetClassWord(GetParent(hwnd),
						GCW_HBRBACKGROUND);
		if (hbrush) {
			hbrush = SelectBrush(hdcMem, hbrush);
			PatBlt(hdcMem, 0, 0, cxWnd, cyWnd, PATCOPY);
			SelectBrush(hdcMem, hbrush);
		} else
			BitBlt(hdcMem, 0, 0, cxWnd, cyWnd, hdc, 0, 0, SRCCOPY);
		SetTextColor(hdcMem, RGB(0, 0, 0));
		SetBkColor(hdcMem, RGB(255, 255, 255));
		hdcEyecon = CreateCompatibleDC(hdc);
		hbmp = SelectBitmap(hdcEyecon, pData->hbmpEyeMask);
		BitBlt(hdcMem, 0, 0, cxWnd, cyWnd, hdcEyecon,
				abs(pData->nCel) * cxWnd, 0, SRCAND);
		SelectBitmap(hdcEyecon, pData->hbmpEyecons);
		BitBlt(hdcMem, 0, 0, cxWnd, cyWnd, hdcEyecon,
				abs(pData->nCel) * cxWnd, 0, SRCPAINT);
		SelectBitmap(hdcEyecon, hbmp);
		DeleteDC(hdcEyecon);
		BitBlt(hdc, 0, 0, cxWnd, cyWnd, hdcMem, 0, 0, SRCCOPY);
		SelectBitmap(hdcMem, hbmpMem);
		DeleteDC(hdcMem);
	} else if (pData->hicon)
		DrawIcon(hdc, 0, 0, pData->hicon);
	EndPaint(hwnd, &ps);
}

static UINT EYE_OnGetDlgCode(HWND	hwnd,
			     LPMSG	lpmsg)
{
	if (lpmsg && lpmsg->message >= WM_MOUSEFIRST &&
				lpmsg->message <= WM_MOUSELAST)
		return DLGC_WANTMESSAGE;
	else
		return DLGC_STATIC;
}

static void EYE_OnLButtonDown(HWND	hwnd,
			      BOOL	bDblClk,
			      int	x,
			      int	y,
			      UINT	fKeys)
{
	FORWARD_WM_COMMAND(GetParent(hwnd), GetDlgCtrlID(hwnd), hwnd,
				bDblClk ? BN_DOUBLECLICKED : BN_CLICKED,
				SendMessage);
}

static void EYE_OnDestroy(HWND	hwnd)
{
	EYECONDATA	*pData;

	pData = SetEyeconData(hwnd, NULL);
	if (!pData)
		return;

	if (pData->hbmpEyecons)
		DeleteBitmap(pData->hbmpEyecons);
	if (pData->hbmpEyeMask)
		DeleteBitmap(pData->hbmpEyeMask);
	if (pData->hbmpWnd)
		DeleteBitmap(pData->hbmpWnd);
	if (pData->lpfnEyeconTimer) {
		if (pData->bAnimating)
			KillTimer(hwnd, idTimerBase + 1);
		else
			KillTimer(hwnd, idTimerBase);
		FreeTimerProcInstance(pData->lpfnEyeconTimer);
	}
	if (pData->hicon)
		DestroyIcon(pData->hicon);
	free(pData);
}

static LRESULT EYE_OnGetTimings(HWND	hwnd)
{
	EYECONDATA	*pData = GetEyeconData(hwnd);

	return MAKELRESULT(pData->nTime0, pData->nTime1);
}

static void EYE_OnSetTimings(HWND	hwnd,
			     UINT	nTime0,
			     UINT	nTime1)
{
	EYECONDATA	*pData = GetEyeconData(hwnd);

	pData->nTime0 = nTime0;
	pData->nTime1 = nTime1;
}

static BOOL EYE_OnSetIcon(HWND		hwnd,
			  LPCSTR	lpszIcon)
{
	EYECONDATA	*pData = GetEyeconData(hwnd);

	if (pData->hicon)
		DestroyIcon(pData->hicon);
	if (!lpszIcon) {
		pData->hicon = NULL;
		return TRUE;
	}

	pData->hicon = LoadIcon(GetWindowInstance(hwnd), lpszIcon);
	if (!pData->hicon)
		return FALSE;
	InvalidateRect(hwnd, NULL, TRUE);
	return TRUE;
}

static BOOL EYE_OnSetEyecon(HWND	hwnd,
			    BOOL	bBounce,
			    LPCSTR	lpszEyecon)
{
	HINSTANCE	hinst;
	EYECONDATA	*pData;
	int		cxBmp;

	pData = GetEyeconData(hwnd);
	if (pData->hbmpEyecons) {
		DeleteBitmap(pData->hbmpEyecons);
		pData->hbmpEyecons = NULL;
	}
	if (pData->hbmpEyeMask) {
		DeleteBitmap(pData->hbmpEyeMask);
		pData->hbmpEyeMask = NULL;
	}
	if (!lpszEyecon) {
		if (pData->lpfnEyeconTimer) {
			if (pData->bAnimating) {
				KillTimer(hwnd, idTimerBase + 1);
				pData->bAnimating = FALSE;
			} else
				KillTimer(hwnd, idTimerBase);
			FreeTimerProcInstance(pData->lpfnEyeconTimer);
			pData->lpfnEyeconTimer = NULL;
		}
		return TRUE;
	}

	hinst = GetWindowInstance(hwnd);
	cxBmp = GetEyeconBitmaps(hinst, lpszEyecon, pData);
	if (!cxBmp)
		return FALSE;
	pData->bBounce = bBounce;
	pData->nCels = cxBmp / GetSystemMetrics(SM_CXICON);
	pData->lpfnEyeconTimer = MakeTimerProcInstance(EyeconTimerProc, hinst);
	SetTimer(hwnd, idTimerBase, pData->nTime0, pData->lpfnEyeconTimer);
	return TRUE;
}

LRESULT __export CALLBACK EyeconProc(HWND	hwnd,
				     UINT	message,
				     WPARAM	wParam,
				     LPARAM	lParam)
{
	switch (message) {
		HANDLE_MSG(hwnd, WM_CREATE, EYE_OnCreate);
		HANDLE_MSG(hwnd, WM_PAINT, EYE_OnPaint);
		HANDLE_MSG(hwnd, WM_GETDLGCODE, EYE_OnGetDlgCode);
		HANDLE_MSG(hwnd, WM_LBUTTONDOWN, EYE_OnLButtonDown);
		HANDLE_MSG(hwnd, WM_LBUTTONDBLCLK, EYE_OnLButtonDown);
		HANDLE_MSG(hwnd, WM_DESTROY, EYE_OnDestroy);

		case EYE_GETTIMINGS:
			return EYE_OnGetTimings(hwnd);

		case EYE_SETTIMINGS:
			EYE_OnSetTimings(hwnd, LOWORD(lParam), HIWORD(lParam));
			return 0;

		case EYE_GETICON:
			return (LRESULT)(UINT)GetEyeconData(hwnd)->hicon;

		case EYE_GETEYECON:
			return (LRESULT)(UINT)GetEyeconData(hwnd)->hbmpEyecons;

		case EYE_SETICON:
			return EYE_OnSetIcon(hwnd, (LPCSTR)lParam);

		case EYE_SETEYECON:
			return EYE_OnSetEyecon(hwnd, wParam, (LPCSTR)lParam);
	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}
