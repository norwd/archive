/* Copyright (C) 1997 Brian Raiter under the GNU General Public License */

#include	<stdlib.h>
#include	"code.h"
#include	"mirror.h"


typedef	struct MIRRORDATA {
		HBITMAP	hbmpWnd;
		HFONT	hfont;
	} MIRRORDATA;

#define	GetMirrorData(hwnd)	((MIRRORDATA*)GetWindowWord((hwnd), 0))
#define	SetMirrorData(hwnd, pData)	\
		((MIRRORDATA*)SetWindowWord((hwnd), 0, (WORD)(pData)));


static BOOL CreateForwardBitmap(HWND	hwnd,
				LPCSTR	lpszText)
{
	HDC		hdcMem;
	HBITMAP		hbmp;
	HFONT		hfont;
	RECT		rect;
	MIRRORDATA	*pData;
	char		*szText;
	DWORD		fStyle;
	UINT		fDT;
	int		cb;

	pData = GetMirrorData(hwnd);
	if (pData->hbmpWnd) {
		DeleteBitmap(pData->hbmpWnd);
		pData->hbmpWnd = NULL;
	}
	if (!lpszText) {
		cb = GetWindowTextLength(hwnd);
		szText = malloc(cb + 1);
		if (!szText)
			return FALSE;
		GetWindowText(hwnd, szText, cb + 1);
	}

	hdcMem = CreateCompatibleDC(NULL);
	if (!hdcMem) {
		if (!lpszText)
			free(szText);
		return FALSE;
	}
	GetClientRect(hwnd, &rect);
	pData->hbmpWnd = CreateBitmap(rect.right, rect.bottom, 1, 1, NULL);
	if (!pData->hbmpWnd) {
		DeleteDC(hdcMem);
		if (!lpszText)
			free(szText);
		return FALSE;
	}
	hbmp = SelectBitmap(hdcMem, pData->hbmpWnd);
	PatBlt(hdcMem, 0, 0, rect.right, rect.bottom, WHITENESS);
	fStyle = GetWindowStyle(hwnd) & 0x00FF;
	if (fStyle & SS_NOPREFIX) {
		fDT |= DT_NOPREFIX;
		fStyle &= ~SS_NOPREFIX;
	}
	fDT = DT_EXPANDTABS;
	if (fStyle == SS_LEFTNOWORDWRAP)
		fDT |= DT_RIGHT | DT_SINGLELINE;
	else if (fStyle == SS_RIGHT)
		fDT |= DT_LEFT;
	else if (fStyle == SS_CENTER)
		fDT |= DT_CENTER;
	else
		fDT |= DT_RIGHT;
	hfont = SelectFont(hdcMem, pData->hfont);
	if (lpszText)
		DrawText(hdcMem, lpszText, -1, &rect, fDT);
	else
		DrawText(hdcMem, szText, cb, &rect, fDT);
	SelectFont(hdcMem, hfont);
	SelectBitmap(hdcMem, hbmp);
	DeleteDC(hdcMem);
	if (!lpszText)
		free(szText);
	return TRUE;
}

static BOOL MIR_OnCreate(HWND		hwnd,
			 LPCREATESTRUCT	lpcs)
{
	MIRRORDATA	*pData;

	pData = calloc(sizeof(MIRRORDATA), 1);
	if (!pData)
		return FALSE;
	SetMirrorData(hwnd, pData);
	pData->hfont = GetStockFont(SYSTEM_FONT);
	CreateForwardBitmap(hwnd, lpcs->lpszName);
	return TRUE;
}

static void MIR_OnSize(HWND	hwnd,
		       UINT	nState,
		       int	cxWnd,
		       int	cyWnd)
{
	if (nState == SIZE_RESTORED || nState == SIZE_MAXIMIZED)
		CreateForwardBitmap(hwnd, NULL);
}

static HFONT MIR_OnGetFont(HWND	hwnd)
{
	return GetMirrorData(hwnd)->hfont;
}

static void MIR_OnSetFont(HWND	hwnd,
			  HFONT	hfont,
			  BOOL	bRedraw)
{
	MIRRORDATA	*pData;

	pData = GetMirrorData(hwnd);
	pData->hfont = hfont;
	CreateForwardBitmap(hwnd, NULL);
	if (bRedraw)
		InvalidateRect(hwnd, NULL, TRUE);
}

static void MIR_OnSetText(HWND		hwnd,
			  LPCSTR	lpszText)
{
	FORWARD_WM_SETTEXT(hwnd, lpszText, DefWindowProc);
	CreateForwardBitmap(hwnd, lpszText);
}

static void MIR_OnPaint(HWND	hwnd)
{
	HDC		hdc, hdcMem;
	HBITMAP		hbmp;
	PAINTSTRUCT	ps;
	MIRRORDATA	*pData;
	int		cx, cy;

	pData = GetMirrorData(hwnd);
	hdc = BeginPaint(hwnd, &ps);
	if (!pData->hbmpWnd) {
		EndPaint(hwnd, &ps);
		return;
	}
	hdcMem = CreateCompatibleDC(hdc);
	hbmp = SelectBitmap(hdcMem, pData->hbmpWnd);
	cx = ps.rcPaint.right - ps.rcPaint.left;
	cy = ps.rcPaint.bottom - ps.rcPaint.top;
	StretchBlt(hdc, ps.rcPaint.left, ps.rcPaint.top, cx, cy, hdcMem,
			ps.rcPaint.right - 1, ps.rcPaint.top, -cx, cy, SRCAND);
	SelectBitmap(hdcMem, hbmp);
	DeleteDC(hdcMem);
	EndPaint(hwnd, &ps);
}

static void MIR_OnDestroy(HWND	hwnd)
{
	MIRRORDATA	*pData;

	pData = SetMirrorData(hwnd, NULL);
	if (pData) {
		if (pData->hbmpWnd)
			DeleteBitmap(pData->hbmpWnd);
		free(pData);
	}
}

LRESULT __export CALLBACK MirrorProc(HWND	hwnd,
				     UINT	message,
				     WPARAM	wParam,
				     LPARAM	lParam)
{
	switch (message) {
		HANDLE_MSG(hwnd, WM_CREATE, MIR_OnCreate);
		HANDLE_MSG(hwnd, WM_SIZE, MIR_OnSize);
		HANDLE_MSG(hwnd, WM_GETFONT, MIR_OnGetFont);
		HANDLE_MSG(hwnd, WM_SETFONT, MIR_OnSetFont);
		HANDLE_MSG(hwnd, WM_SETTEXT, MIR_OnSetText);
		HANDLE_MSG(hwnd, WM_PAINT, MIR_OnPaint);
		HANDLE_MSG(hwnd, WM_DESTROY, MIR_OnDestroy);
	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}
