/* Copyright (C) 1997 Brian Raiter under the GNU General Public License */

#include	<stdlib.h>
#include	<string.h>
#include	"code.h"
#include	"main.h"
#include	"game.h"


int		nRows, nCols, nPegs;
int		**PegBoard = NULL,
		(*ChipBoard)[2] = NULL,
		*Answer = NULL,
		*Commital = NULL;

static int	*PegBoardCol = NULL;

BOOL CreateBoard(void)
{
	int	i;

	if (!PegBoard) {
		PegBoard = malloc(nRows * sizeof(int*));
		if (!PegBoard)
			return FALSE;
		PegBoardCol = calloc(nRows * nCols, sizeof(int));
		if (!PegBoardCol)
			return FALSE;
		for (i = 0 ; i < nRows ; ++i)
			PegBoard[i] = PegBoardCol + i * nCols;
	}
	if (!ChipBoard) {
		ChipBoard = calloc(nRows * 2, sizeof(int));
		if (!ChipBoard)
			return FALSE;
	}
	if (!Answer) {
		Answer = calloc(nCols, sizeof(int));
		if (!Answer)
			return FALSE;
	}
	if (!Commital) {
		Commital = calloc(nCols, sizeof(int));
		if (!Commital)
			return FALSE;
	}

	return TRUE;
}

void ClearBoard(void)
{
	if (PegBoard) {
		free(PegBoard);
		PegBoard = NULL;
	}
	if (PegBoardCol) {
		free(PegBoardCol);
		PegBoardCol = NULL;
	}
	if (ChipBoard) {
		free(ChipBoard);
		ChipBoard = NULL;
	}
	if (Answer) {
		free(Answer);
		Answer = NULL;
	}
	if (Commital) {
		free(Commital);
		Commital = NULL;
	}
}

int ScoreRow(int	nRow)
{
	int	i, j;

	ChipBoard[nRow][0] = ChipBoard[nRow][1] = 0;
	for (i = 0 ; i < nCols ; ++i)
		if (PegBoard[nRow][i] == Answer[i])
			++ChipBoard[nRow][0];
		else
			for (j = 0 ; j < nCols ; ++j)
				if (PegBoard[nRow][j] == Answer[i]) {
					++ChipBoard[nRow][1];
					break;
				}
	return ChipBoard[nRow][0];
}

BOOL DoCommital(int	nRow)
{
	int	i;

	for (i = 0 ; i < nCols ; ++i) {
		Commital[i] = PegBoard[nRow][i];
		if (Commital[i] && Commital[i] != Answer[i])
			return FALSE;
	}
	return TRUE;
}

int GetNewPeg(int	nRow)
{
	int	*NewPegs;
	int	i, j, n;

	if (nRow < 0)
		return Rnd(nPegs) + 1;
	NewPegs = malloc(nPegs * sizeof(int));
	if (!NewPegs)
		return Rnd(nPegs) + 1;

	for (i = 1, n = 0 ; i <= nPegs ; ++i) {
		for (j = 0 ; j < nCols && PegBoard[nRow][j] != i ; ++j) ;
		if (j == nCols)
			NewPegs[n++] = i;
	}
	n = n ? NewPegs[Rnd(n)] : Rnd(nPegs) + 1;
	free(NewPegs);
	return n;
}

BOOL TestRowFull(int	nRow)
{
	int	i;

	if (!PegBoard || nRow >= nRows)
		return FALSE;
	for (i = 0 ; i < nCols ; ++i)
		if (!PegBoard[nRow][i])
			return FALSE;
	return TRUE;
}

BOOL TestRowChanged(int	nRow)
{
	int	i;

	if (!PegBoard || nRow >= nRows)
		return FALSE;
	for (i = 0 ; i < nCols ; ++i)
		if (PegBoard[nRow][i] != Commital[i])
			return TRUE;
	return FALSE;
}

BOOL StartGame(void)
{
	int	i;

	if (!CreateBoard())
		return FALSE;

	memset(PegBoardCol, 0, nRows * nCols * sizeof(int));
	memset(ChipBoard, 0, nRows * 2 * sizeof(int));
	memset(Commital, 0, nCols * sizeof(int));
	for (i = 0 ; i < nCols ; ++i)
		Answer[i] = Rnd(nPegs) + 1;
	bGameInProgress = TRUE;

	return TRUE;
}

void EndGame(void)
{
	bGameInProgress = FALSE;
}
