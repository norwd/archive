/* Copyright (C) 1997 Brian Raiter under the GNU General Public License */

#include	<stdlib.h>
#include	"code.h"
#include	"main.h"
#include	"gdi.h"
#include	"game.h"
#include	"pegbox.h"


static HPEN		hpenKey = NULL,
			hpenBorder = NULL;
static HBRUSH		hbrushBkgnd = NULL;
static HICON		hiconDie = NULL;
static int		nKeyPeg = 0;
static BOOL		bShowKeyPeg = FALSE;


static void MakeGDI(void)
{
	hpenBorder = CreatePen(PS_SOLID, 0, GetSysColor(COLOR_WINDOWFRAME));
	hpenKey = CreatePen(PS_DOT, 0, GetSysColor(COLOR_WINDOWFRAME));
	hbrushBkgnd = CreateSolidBrush(GetSysColor(COLOR_WINDOW));
}

static void ClearGDI(void)
{
	if (hpenBorder) {
		DeletePen(hpenBorder);
		hpenBorder = NULL;
	}
	if (hpenKey) {
		DeletePen(hpenKey);
		hpenKey = NULL;
	}
	if (hbrushBkgnd) {
		DeleteBrush(hbrushBkgnd);
		hbrushBkgnd = NULL;
	}
}

static BOOL BOX_OnCreate(HWND		hwnd,
			 LPCREATESTRUCT	lpcs)
{
	HMENU	hmenuSys;
	int	j;

	hmenuSys = GetSystemMenu(hwnd, FALSE);
	for (j = GetMenuItemCount(hmenuSys) - 1 ; j >= 0 ; --j)
		if (GetMenuItemID(hmenuSys, j) != SC_MOVE)
			DeleteMenu(hmenuSys, j, MF_BYPOSITION);
	MakeGDI();
	hiconDie = LoadIcon(GetWindowInstance(hwnd), IDI_DIE);
	SetFocus(GetParent(hwnd));
	return TRUE;
}

static void BOX_OnPaint(HWND	hwnd)
{
	HDC		hdc;
	HPEN		hpen;
	HBRUSH		hbrush;
	PAINTSTRUCT	ps;
	int		i;

	hdc = BeginPaint(hwnd, &ps);
	hpen = SelectPen(hdc, hpenBorder);
	hbrush = SelectBrush(hdc, hbrushBkgnd);
	for (i = 0 ; i <= nPegs ; ++i) {
		if (bShowKeyPeg && nKeyPeg == i)
			SelectPen(hdc, hpenKey);
		Rectangle(hdc, cxUnit * i, 0, cxUnit * (i + 1), cyUnit);
		if (bShowKeyPeg && nKeyPeg == i)
			SelectPen(hdc, hpenBorder);
	}
	SelectPen(hdc, hpen);
	SelectBrush(hdc, hbrush);
	DrawIcon(hdc, (cxUnit - GetSystemMetrics(SM_CXICON)) / 2,
			(cyUnit - GetSystemMetrics(SM_CYICON)) / 2, hiconDie);
	for (i = 1 ; i <= nPegs ; ++i) {
		SelectPeg(hdc, i);
		DrawPeg(hdc, cxUnit * i, 0);
	}
	SelectPeg(hdc, NIL);
	EndPaint(hwnd, &ps);
}

static void BOX_OnMove(HWND	hwnd,
		       int	x,
		       int	y)
{
	SetFocus(GetParent(hwnd));
}

static int BOX_OnMouseActivate(HWND	hwnd,
			       HWND	hwndTop,
			       UINT	nHitTest,
			       UINT	msg)
{
	if (nHitTest == HTCLIENT)
		return MA_NOACTIVATE;
	FORWARD_WM_MOUSEACTIVATE(hwnd, hwndTop, nHitTest, msg, DefWindowProc);
}

static void BOX_OnLButtonDown(HWND	hwnd,
			      BOOL	bDoubleClick,
			      int	x,
			      int	y,
			      UINT	fKeys)
{
	MOUSETRAP	mouse;
	int		n;

	if (!bGameInProgress)
		return;
	n = x / cxUnit;
	if (n != nKeyPeg)
		SendMessage(hwnd, WM_SHOWKEYPEG, FALSE, 0L);
	mouse.pos.x = x;
	mouse.pos.y = y;
	mouse.off.cx = x % cxUnit;
	mouse.off.cy = y;
	ClientToScreen(hwnd, &mouse.pos);
	if (n == 0 && GetKeyState(VK_SHIFT) >= 0)
		n = Rnd(nPegs) + 1;
	SendMessage(GetParent(hwnd), WM_PEGBOXHIT, n,
					(LPARAM)(LPMOUSETRAP)&mouse);
}

static void BOX_OnKey(HWND	hwnd,
		      UINT	nVKey,
		      BOOL	bDown,
		      int	nRepeat,
		      UINT	fState)
{
	if (!bDown)
		return;
	switch (nVKey) {
		case VK_SPACE:
			if (!bShowKeyPeg) {
				SendMessage(hwnd, WM_SHOWKEYPEG, TRUE, 0L);
				break;
			}
			FORWARD_WM_LBUTTONDOWN(hwnd, FALSE, cxUnit * nKeyPeg,
						0, 0, SendMessage);
			break;

		case VK_LEFT:
		case VK_RIGHT:
		case VK_HOME:
		case VK_END:
			if (!bShowKeyPeg) {
				SendMessage(hwnd, WM_SHOWKEYPEG, TRUE, 0L);
				break;
			}
			SendMessage(hwnd, WM_SHOWKEYPEG, FALSE, 0L);
			if (nVKey == VK_LEFT || nVKey == VK_RIGHT) {
				nKeyPeg += nVKey == VK_LEFT ? nPegs : 1;
				nKeyPeg %= nPegs + 1;
			} else
				nKeyPeg = nVKey == VK_HOME ? 0 : nPegs;
			SendMessage(hwnd, WM_SHOWKEYPEG, TRUE, 0L);
			break;

		case VK_TAB:
			if (GetKeyState(VK_CONTROL) >= 0)
				break;
		case VK_F6:
			SetFocus(GetParent(hwnd));
			break;
	}
}

static void WND_OnSysColorChange(HWND	hwnd)
{
	ClearGDI();
	MakeGDI();
	InvalidateRect(hwnd, NULL, TRUE);
}

static void BOX_OnClose(HWND	hwnd)
{
	FORWARD_WM_CLOSE(GetParent(hwnd), SendMessage);
}

static void BOX_OnDestroy(HWND	hwnd)
{
	ClearGDI();
	if (hiconDie) {
		DestroyIcon(hiconDie);
		hiconDie = NULL;
	}
}

static void BOX_OnShowKeyPeg(HWND	hwnd,
			     BOOL	bShow)
{
	HDC	hdc;
	HPEN	hpen;
	HBRUSH	hbrush;

	if (bShowKeyPeg == bShow)
		return;

	bShowKeyPeg = !bShowKeyPeg;
	hdc = GetDC(hwnd);
	if (bShowKeyPeg)
		hpen = SelectPen(hdc, hpenKey);
	else
		hpen = SelectPen(hdc, hpenBorder);
	hbrush = SelectBrush(hdc, GetStockBrush(NULL_BRUSH));
	Rectangle(hdc, cxUnit * nKeyPeg, 0, cxUnit * (nKeyPeg + 1), cyUnit);
	SelectBrush(hdc, hbrush);
	SelectPen(hdc, hpen);
	ReleaseDC(hwnd, hdc);
}

LRESULT __export CALLBACK PegBoxProc(HWND	hwnd,
				     UINT	message,
				     WPARAM	wParam,
				     LPARAM	lParam)
{
	switch (message) {
		HANDLE_MSG(hwnd, WM_CREATE, BOX_OnCreate);
		HANDLE_MSG(hwnd, WM_PAINT, BOX_OnPaint);
		HANDLE_MSG(hwnd, WM_MOVE, BOX_OnMove);
		HANDLE_MSG(hwnd, WM_MOUSEACTIVATE, BOX_OnMouseActivate);
		HANDLE_MSG(hwnd, WM_LBUTTONDOWN, BOX_OnLButtonDown);
		HANDLE_MSG(hwnd, WM_KEYDOWN, BOX_OnKey);
		HANDLE_MSG(hwnd, WM_SYSCOLORCHANGE, WND_OnSysColorChange);
		HANDLE_MSG(hwnd, WM_CLOSE, BOX_OnClose);
		HANDLE_MSG(hwnd, WM_DESTROY, BOX_OnDestroy);

		case WM_SHOWKEYPEG:
			BOX_OnShowKeyPeg(hwnd, (BOOL)wParam);
			return 0;
	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}
