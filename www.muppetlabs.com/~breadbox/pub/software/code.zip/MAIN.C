/* Copyright (C) 1997 Brian Raiter under the GNU General Public License */

#include	<stdlib.h>
#include	<string.h>
#include	<time.h>
#include	<stdarg.h>
#include	"code.h"
#include	"game.h"
#include	"pegbox.h"
#include	"eyecon.h"
#include	"mirror.h"
#include	"mainwnd.h"
#include	"main.h"


HINSTANCE		hinstThis = NULL;
HWND			hwndPegBox = NULL;
int			cxUnit, cyUnit, cx8th, cy8th;
int			nMaxRows, nMaxCols, nMaxPegs;
BOOL			bMonochrome, bMouse;
BOOL			bGameInProgress = FALSE, bCanCommit = FALSE;
BOOL			bRoundPegs;

static const char	szAppName[] = "CodeBreaker",
			szPegBoxClass[] = "CodeBreakerPegBox",
			szNumRows[] = "NumberOfGuesses",
			szNumCols[] = "NumberOfPegsPerGuess",
			szNumPegs[] = "NumberOfPegColors",
			szPegType[] = "TypesOfPegs",
			szCanCommit[] = "CanCommit";
static const int	nDefNumRows = 10,
			nDefNumCols = 4,
			nDefNumPegs = 6;

#ifdef _DEBUG
void _cdecl DebugPrintf(LPCSTR	szFormat, ...)
{
	va_list	arg;
	LPSTR	lpsz;

	va_start(arg, szFormat);
	lpsz = GlobalAllocPtr(GHND, 1024);
	wvsprintf(lpsz, szFormat, arg);
	OutputDebugString(lpsz);
	(void)GlobalFreePtr(lpsz);
	va_end(arg);
}
#endif

int PASCAL WinMain(HINSTANCE	hinst,
		   HINSTANCE	hinstPrev,
		   LPSTR	lpszCmdLine,
		   int		nCmdShow)
{
	HWND	hwndMain, hwndButton;
	HACCEL	haccel;
	HDC	hdc;
	HGLOBAL	hgmem;
	MSG	msg;
	char	szBuff[16];
	LPLONG	lplValues;

	hinstThis = hinst;

	hgmem = LoadResource(hinstThis, FindResource(hinstThis,
						IDR_RCVALUES, RT_RCDATA));
	lplValues = LockResource(hgmem);
	cxUnit = (int)lplValues[0];
	cyUnit = (int)lplValues[1];
	nMaxPegs = (int)lplValues[2];
	UnlockResource(hgmem);
	FreeResource(hgmem);
	cx8th = cxUnit / 8;
	cy8th = cyUnit / 8;

	hdc = GetDC(NULL);
	bMonochrome = GetDeviceCaps(hdc, NUMCOLORS) == 2;
	ReleaseDC(NULL, hdc);
	bMouse = GetSystemMetrics(SM_MOUSEPRESENT);

	nMaxRows = GetSystemMetrics(SM_CXSCREEN) / (cxUnit + cx8th) - 2;
	nMaxCols = (GetSystemMetrics(SM_CYSCREEN) -
			GetSystemMetrics(SM_CYMENU) -
			GetSystemMetrics(SM_CYCAPTION)) /
						(cyUnit + cy8th * 2) - 1;

	nRows = (int)GetProfileInt(szAppName, szNumRows, nDefNumRows);
	nRows = max(3, min(nMaxRows, nRows));
	nCols = (int)GetProfileInt(szAppName, szNumCols, nDefNumCols);
	nCols = max(3, min(nMaxCols, nCols));
	nPegs = (int)GetProfileInt(szAppName, szNumPegs, nDefNumPegs);
	nPegs = max(3, min(nMaxPegs, nPegs));
	GetProfileString(szAppName, szPegType, "x", szBuff, sizeof szBuff);
	*szBuff = (char)LOWORD(AnsiLower((LPSTR)MAKELONG(*szBuff, 0)));
	if (*szBuff == 'r' || *szBuff == 's')
		bRoundPegs = (*szBuff == 'r');
	else
		bRoundPegs = !bMonochrome;
	bCanCommit = GetProfileInt(szAppName, szCanCommit, bCanCommit);

	srand(LOWORD(time(NULL) ^ GetTickCount()));

	if (!hinstPrev) {
		WNDCLASS	wndclass;

		wndclass.style		= CS_HREDRAW | CS_VREDRAW;
		wndclass.lpfnWndProc	= (WNDPROC)WndProc;
		wndclass.cbClsExtra	= 0;
		wndclass.cbWndExtra	= 0;
		wndclass.hInstance	= hinstThis;
		wndclass.hIcon		= LoadIcon(hinstThis, IDI_MAIN);
		wndclass.hCursor	= LoadCursor(NULL, IDC_ARROW);
		wndclass.hbrBackground	= (HBRUSH)(COLOR_BTNFACE + 1);
		wndclass.lpszMenuName	= IDR_MAIN;
		wndclass.lpszClassName	= szAppName;
		RegisterClass(&wndclass);

		wndclass.style		= CS_DBLCLKS;
		wndclass.lpfnWndProc	= (WNDPROC)EyeconProc;
		wndclass.cbWndExtra	= sizeof(void*);
		wndclass.hIcon		= NULL;
		wndclass.hbrBackground	= (HBRUSH)(COLOR_WINDOW + 1);
		wndclass.lpszMenuName	= NULL;
		wndclass.lpszClassName	= CLASS_EYECON;
		RegisterClass(&wndclass);

		wndclass.style		= CS_HREDRAW | CS_VREDRAW;
		wndclass.lpfnWndProc	= (WNDPROC)MirrorProc;
		wndclass.lpszClassName	= CLASS_MIRROR;
		RegisterClass(&wndclass);

		wndclass.style		= 0;
		wndclass.lpfnWndProc	= (WNDPROC)PegBoxProc;
		wndclass.cbWndExtra	= 0;
		wndclass.hbrBackground	= NULL;
		wndclass.lpszClassName	= szPegBoxClass;
		RegisterClass(&wndclass);
	}

	hwndMain = CreateWindow(szAppName, "Code Breaker",
			WS_OVERLAPPED | WS_MINIMIZEBOX | WS_CAPTION |
				WS_SYSMENU | WS_CLIPCHILDREN,
			CW_USEDEFAULT, CW_USEDEFAULT, 0, 0,
			NULL, NULL, hinstThis, NULL);
	hwndPegBox = CreateWindow(szPegBoxClass, "Peg Box", WS_POPUP |
				WS_BORDER | WS_CAPTION | WS_SYSMENU,
			0, 0, 0, 0, hwndMain, NULL, hinstThis, NULL);
	hwndButton = CreateWindow("button", "OK", WS_CHILD | WS_CLIPSIBLINGS |
				WS_DISABLED | BS_DEFPUSHBUTTON,
			0, 0, 0, 0, hwndMain, (HMENU)IDOK, hinstThis, NULL);
	hwndButton = CreateWindow("button", "&commit", WS_CHILD |
				WS_CLIPSIBLINGS | WS_DISABLED | BS_PUSHBUTTON,
			0, 0, 0, 0, hwndMain, (HMENU)IDYES, hinstThis, NULL);
	SendMessage(hwndButton, WM_SETFONT,
			(WPARAM)GetStockFont(ANSI_VAR_FONT), FALSE);
	PlaceWindows(hwndMain, FALSE);
	ShowWindow(hwndMain, nCmdShow);
	ShowWindow(hwndPegBox, SW_SHOWNOACTIVATE);

	PostMessage(hwndMain, WM_COMMAND, IDM_START, 0L);

	haccel = LoadAccelerators(hinstThis, IDR_MAIN);
	while (GetMessage(&msg, NULL, 0, 0))
		if (!TranslateAccelerator(hwndMain, haccel, &msg)) {
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}

	wsprintf(szBuff, "%d", nRows);
	WriteProfileString(szAppName, szNumRows, szBuff);
	wsprintf(szBuff, "%d", nCols);
	WriteProfileString(szAppName, szNumCols, szBuff);
	wsprintf(szBuff, "%d", nPegs);
	WriteProfileString(szAppName, szNumPegs, szBuff);
	WriteProfileString(szAppName, szPegType,
					bRoundPegs ? "Round" : "Shaped");
	WriteProfileString(szAppName, szCanCommit, bCanCommit ? "1" : "0");

	return msg.wParam;
}
