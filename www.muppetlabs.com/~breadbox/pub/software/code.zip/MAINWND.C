/* Copyright (C) 1997 Brian Raiter under the GNU General Public License */

#include	<stdlib.h>
#include	<string.h>
#include	"code.h"
#include	"codehelp.h"
#include	"main.h"
#include	"game.h"
#include	"gdi.h"
#include	"pegbox.h"
#include	"dlgs.h"
#include	"mainwnd.h"


#define	WM_KIBITZING	(WM_USER + 42)

typedef	struct DRAGDROPINFO {
		int	nPegInHand;
		int	xOffset;
		int	yOffset;
		int	iFrom;
		int	jFrom;
		int	nCount;
	} DRAGDROPINFO;

static const char	szHelpFile[] = "code.hlp";

static DRAGDROPINFO	*pddinfo = NULL;
static HWND		hwndKibitz = NULL;
static int		nCurrentRow = 0;
static int		xBoard, yBoard, cxBoard, cyPegBoard, cyChipBoard;


static void DisableWindow(HWND	hwnd,
			  HWND	hwndChild)
{
	if (GetFocus() == hwndChild)
		SetFocus(hwnd);
	EnableWindow(hwndChild, FALSE);
}

static HDC GetBoardDC(HWND	hwnd)
{
	HDC	hdc;

	hdc = GetDC(hwnd);
	SetViewportOrgEx(hdc, xBoard, yBoard, NULL);
	return hdc;
}

void PlaceWindows(HWND	hwndMain,
		  BOOL	bDraw)
{
	HWND	hwndButton;
	RECT	rect;
	UINT	fSWP = SWP_NOZORDER | SWP_NOACTIVATE;
	int	cxBorders = GetSystemMetrics(SM_CXBORDER) * 2,
		cyBorders = GetSystemMetrics(SM_CYBORDER) * 2;
	int	cxClient, cyClient, cxWindow, cyWindow,
		xPegBox, yPegBox, cxPegBox, cyPegBox,
		xButton, yButton, cxButton, cyButton;

	if (!bDraw)
		fSWP |= SWP_NOREDRAW;
	cxBoard = (cxUnit + cx8th) * (nRows + 1) + cxUnit;
	cyPegBoard = cyUnit * nCols + cy8th * 2;
	cyChipBoard = (cyUnit / 2) * ((nCols + 1) / 2) + cy8th * 2;
	xBoard = 0;
	yBoard = cyChipBoard;
	xButton = xBoard + (cxUnit + cx8th) * nRows + cx8th * 3;
	yButton = yBoard + cy8th;
	cxButton = 3 * cxUnit / 2;
	cyButton = cyPegBoard - cy8th * 2;
	cxPegBox = cxUnit * (nPegs + 1) + cxBorders;
	cyPegBox = cyUnit + cyBorders / 2 + GetSystemMetrics(SM_CYCAPTION);
	cxClient = xBoard + cxBoard;
	cyClient = yBoard + cyPegBoard;
	cxWindow = cxClient + cxBorders;
	cyWindow = cyClient + cyBorders + GetSystemMetrics(SM_CYCAPTION) +
						GetSystemMetrics(SM_CYMENU);
	GetWindowRect(hwndPegBox, &rect);
	xPegBox = rect.left;
	yPegBox = rect.top;

	hwndButton = GetDlgItem(hwndMain, IDOK);
	SetWindowPos(hwndButton, NULL, xButton, yButton,
				cxButton, cyButton, fSWP);
	SetWindowPos(hwndButton, NULL, 0, 0, 0, 0,
				fSWP | SWP_NOMOVE | SWP_NOSIZE |
					(bGameInProgress ? SWP_SHOWWINDOW :
							SWP_HIDEWINDOW));
	yButton = cy8th;
	cyButton = yBoard - cy8th * 2;
	hwndButton = GetDlgItem(hwndMain, IDYES);
	SetWindowPos(hwndButton, NULL, xButton, yButton,
				cxButton, cyButton, fSWP);
	SetWindowPos(hwndButton, NULL, 0, 0, 0, 0,
				fSWP | SWP_NOMOVE | SWP_NOSIZE |
					(bCanCommit ? SWP_SHOWWINDOW :
							SWP_HIDEWINDOW));
	GetWindowRect(hwndMain, &rect);
	SetWindowPos(hwndMain, NULL, rect.left, rect.top,
				cxWindow, cyWindow, fSWP);

	if (!xPegBox && !yPegBox) {
		xPegBox = rect.left + (cxWindow - cxPegBox) / 2;
		yPegBox = rect.top + cyWindow + cyUnit;
	}
	SetWindowPos(hwndPegBox, NULL, xPegBox, yPegBox,
				cxPegBox, cyPegBox, fSWP);
}

static void SetButtons(HWND	hwnd)
{
	HWND	hwndButton;

	hwndButton = GetDlgItem(hwnd, IDOK);
	if (bGameInProgress) {
		ShowWindow(hwndButton, SW_SHOWNOACTIVATE);
		if (TestRowFull(nCurrentRow))
			EnableWindow(hwndButton, TRUE);
		else
			DisableWindow(hwnd, hwndButton);
		ShowWindow(hwndButton, SW_SHOWNOACTIVATE);
	} else {
		DisableWindow(hwnd, hwndButton);
		ShowWindow(hwndButton, SW_HIDE);
	}
	hwndButton = GetDlgItem(hwnd, IDYES);
	if (bCanCommit) {
		ShowWindow(hwndButton, SW_SHOWNOACTIVATE);
		if (bGameInProgress && TestRowChanged(nCurrentRow))
			EnableWindow(hwndButton, TRUE);
		else
			DisableWindow(hwnd, hwndButton);
	} else {
		DisableWindow(hwnd, hwndButton);
		ShowWindow(hwndButton, SW_HIDE);
	}
}

static int GetCursorCol(HWND		hwnd,
			LPMOUSETRAP	lpmouse)
{
	int	cx, cy;

	GetCursorPos(&lpmouse->pos);
	ScreenToClient(hwnd, &lpmouse->pos);
	cx = lpmouse->pos.x - xBoard - cx8th - nCurrentRow * (cxUnit + cx8th);
	cy = lpmouse->pos.y - yBoard - cy8th;
	lpmouse->off.cx = cx;
	lpmouse->off.cy = cy % cxUnit;
	lpmouse->pos.x -= lpmouse->off.cx;
	lpmouse->pos.y -= lpmouse->off.cy;
	if (cx >= 0 && cx < cxUnit && cy >= 0 && cy < nCols * cyUnit)
		return cy / cyUnit;
	else
		return NIL;
}

static void PeekAtBoard(HWND	hwnd,
			int	nRowsToSee)
{
	ATOM	aBoard, aNames;
	char	*szGame, *szBoard;
	int	i, j;

	szGame = (char*)malloc(nRows * nCols + 5);
	szGame[0] = (char)('a' + nPegs);
	szGame[1] = (char)('a' + nCols);
	szGame[2] = (char)('a' + nRowsToSee);
	szGame[3] = ':';
	szBoard = szGame + 4;
	for (i = 0 ; i < nRowsToSee ; ++i) {
		for (j = 0 ; j < nCols ; ++j)
			szBoard[j] = (char)('A' + PegBoard[i][j]);
		szBoard[j] = (char)('a' + ChipBoard[i][0]);
		szBoard[j + 1] = (char)('a' + ChipBoard[i][1]);
		szBoard += j + 2;
	}
	aBoard = GlobalAddAtom(szGame);
	if (bRoundPegs)
		if (bMonochrome) {
			strcpy(szGame, "black peg");
			for (i = 1 ; i < nPegs - 1 ; ++i) {
				strcat(szGame, "/gray peg *");
				_itoa(i, strchr(szGame, '*'), 10);
			}
			strcat(szGame, "/white peg");
		} else
			LoadString(hinstThis, IDS_COLORS, szGame, 128);
	else
		LoadString(hinstThis, IDS_SHAPES, szGame, 128);
	strcat(szGame, ":black chip/white chip");
	aNames = GlobalAddAtom(szGame);
	free(szGame);
	SendMessage(hwndKibitz, WM_KIBITZING, (WPARAM)hwnd,
						MAKELONG(aBoard, aNames));
}

static BOOL WND_OnCreate(HWND		hwnd,
			 LPCREATESTRUCT	lpcs)
{
	MakeWindowGDI(TRUE);
	MakePegGDI();
	return TRUE;
}

static void WND_OnSetFocus(HWND	hwnd,
			   HWND	hwndFocus)
{
	if (!bMouse)
		ShowCursor(TRUE);
}

static void WND_OnKillFocus(HWND	hwnd,
			    HWND	hwndFocus)
{
	if (!bMouse)
		ShowCursor(FALSE);
}

static void WND_OnPaint(HWND	hwnd)
{
	HDC		hdc;
	PAINTSTRUCT	ps;

	hdc = BeginPaint(hwnd, &ps);
	SetViewportOrgEx(hdc, xBoard, yBoard, NULL);
	DrawBoard(hdc, cxBoard, cyChipBoard, cyPegBoard);
	EndPaint(hwnd, &ps);
}

static void WND_OnPegBoxHit(HWND	hwnd,
			    int		nPeg,
			    LPMOUSETRAP	lpmouse)
{
	if (!pddinfo) {
		pddinfo = malloc(sizeof(DRAGDROPINFO));
		if (!pddinfo)
			return;
	}

	pddinfo->nPegInHand = nPeg ? nPeg : GetNewPeg(nCurrentRow);
	pddinfo->xOffset = lpmouse->off.cx;
	pddinfo->yOffset = lpmouse->off.cy;
	pddinfo->iFrom = NIL;
	pddinfo->jFrom = NIL;
	pddinfo->nCount = 0;
	DrawPegMove(pddinfo->nPegInHand, lpmouse->pos.x - pddinfo->xOffset,
					lpmouse->pos.y - pddinfo->yOffset,
					NIL, pegGrab);
	SetFocus(hwnd);
	SetCapture(hwnd);
}

static void WND_OnLButtonDown(HWND	hwnd,
			      BOOL	bDoubleClick,
			      int	xMouse,
			      int	yMouse,
			      UINT	fKeys)
{
	POINT	pt;
	int	i, j, x, y;
	int	nPeg, nPegInHand;

	if (!bGameInProgress)
		return;
	x = xMouse - xBoard - cx8th;
	y = yMouse - yBoard - cy8th;
	if (x < 0 || y < 0)
		return;
	i = x / (cxUnit + cx8th);
	j = y / cyUnit;
	if (i >= nRows || j >= nCols)
		return;
	nPegInHand = PegBoard[i][j];
	nPeg = 0;
	if (!nPegInHand && i == nCurrentRow && nCurrentRow > 0) {
		nPegInHand = PegBoard[i - 1][j];
		nPeg = NIL;
	}
	if (!nPegInHand)
		return;
	pddinfo = malloc(sizeof(DRAGDROPINFO));
	if (!pddinfo)
		return;
	pddinfo->nPegInHand = nPegInHand;
	pddinfo->xOffset = x % (cxUnit + cx8th);
	pddinfo->yOffset = y % cyUnit;
	pddinfo->nCount = 0;
	if (i < nCurrentRow) {
		pddinfo->iFrom = NIL;
		pddinfo->jFrom = NIL;
		nPeg = NIL;
	} else {
		pddinfo->iFrom = i;
		pddinfo->jFrom = j;
	}
	if (i >= nCurrentRow)
		PegBoard[i][j] = 0;
	pt.x = xMouse - pddinfo->xOffset;
	pt.y = yMouse - pddinfo->yOffset;
	ClientToScreen(hwnd, &pt);
	DrawPegMove(nPegInHand, pt.x, pt.y, nPeg, pegGrab);
	SetCapture(hwnd);
}

static void WND_OnMouseMove(HWND	hwnd,
			    int		xMouse,
			    int		yMouse,
			    UINT	fKeys)
{
	POINT	pt;

	if (!pddinfo)
		return;
	pt.x = xMouse - pddinfo->xOffset;
	pt.y = yMouse - pddinfo->yOffset;
	ClientToScreen(hwnd, &pt);
	DrawPegMove(pddinfo->nPegInHand, pt.x, pt.y, NIL, pegDrag);
	++pddinfo->nCount;
}

static void WND_OnLButtonUp(HWND	hwnd,
			    int		xMouse,
			    int		yMouse,
			    UINT	fKeys)
{
	POINT	pt;
	int	i, j, x, y;

	if (!pddinfo)
		return;

	ReleaseCapture();
	x = xMouse - xBoard - cx8th + cxUnit / 2 - pddinfo->xOffset;
	y = yMouse - yBoard - cy8th + cyUnit / 2 - pddinfo->yOffset;
	i = x / (cxUnit + cx8th);
	j = y / cyUnit;
	if (x >= 0 && y >= 0 && j < nCols && i >= nCurrentRow && i < nRows) {
		pt.x = xBoard + cx8th + i * (cxUnit + cx8th);
		pt.y = yBoard + cy8th + j * cyUnit;
		ClientToScreen(hwnd, &pt);
		DrawPegMove(pddinfo->nPegInHand, pt.x, pt.y,
					PegBoard[i][j] ? 0 : NIL, pegDrop);
		if (pddinfo->iFrom != NIL && PegBoard[i][j]) {
			HDC	hdc;

			PegBoard[pddinfo->iFrom][pddinfo->jFrom] =
							PegBoard[i][j];
			hdc = GetBoardDC(hwnd);
			DrawPegOnBoard(hdc, pddinfo->iFrom, pddinfo->jFrom);
			ReleaseDC(hwnd, hdc);
		}
		PegBoard[i][j] = pddinfo->nPegInHand;
		if (!bMouse && !TestRowFull(nCurrentRow)) {
			int	jj = j;

			do {
				FORWARD_WM_KEYDOWN(hwnd, VK_DOWN, 1, 0,
							SendMessage);
				jj = (jj + 1) % nCols;
			} while (jj != j && PegBoard[i][jj]);
		}
	} else if (pddinfo->iFrom == NIL && pddinfo->nCount < 3 &&
					!TestRowFull(nCurrentRow)) {
		for (j = 0 ; PegBoard[nCurrentRow][j] ; ++j) ;
		pt.x = xBoard + cx8th + nCurrentRow * (cxUnit + cx8th);
		pt.y = yBoard + cy8th + j * cyUnit;
		ClientToScreen(hwnd, &pt);
		DrawPegMove(pddinfo->nPegInHand, pt.x, pt.y, NIL, pegDrop);
		PegBoard[nCurrentRow][j] = pddinfo->nPegInHand;
	} else
		DrawPegMove(0, 0, 0, 0, pegLose);
	free(pddinfo);
	pddinfo = NULL;
	SetButtons(hwnd);
}

static void WND_OnKey(HWND	hwnd,
		      UINT	nVKey,
		      BOOL	bDown,
		      int	nRepeat,
		      UINT	fState)
{
	if (!bGameInProgress || !bDown)
		return;

	switch (nVKey) {
		case VK_LEFT:
		case VK_RIGHT:
		case VK_HOME:
		case VK_END:
			FORWARD_WM_KEYDOWN(hwndPegBox, nVKey, nRepeat, fState,
						SendMessage);
			break;

		case VK_UP:
		case VK_DOWN:
		case VK_PRIOR:
		case VK_NEXT:
		{
			MOUSETRAP	mouse;
			POINT		pt;
			int		nCol;

			nCol = GetCursorCol(hwnd, &mouse);
			if (nCol == NIL)
				break;
			if (nVKey == VK_UP || nVKey == VK_DOWN) {
				nCol += nVKey == VK_DOWN ? 1 : nCols - 1;
				nCol %= nCols;
			} else
				nCol = nVKey == VK_NEXT ? nCols - 1 : 0;
			ClientToScreen(hwnd, &pt);
			SetCursorPos(pt.x, pt.y);
			break;
		}
		case VK_DELETE:
		{
			MOUSETRAP	mouse;
			int		nCol;

			nCol = GetCursorCol(hwnd, &mouse);
			if (nCol == NIL)
				break;
			if (pddinfo)
				FORWARD_WM_LBUTTONUP(hwnd, 0, 0,
						0, SendMessage);
			else if (PegBoard[nCurrentRow][nCol]) {
				FORWARD_WM_LBUTTONDOWN(hwnd, FALSE,
						mouse.pos.x, mouse.pos.y, 0,
						SendMessage);
				FORWARD_WM_LBUTTONUP(hwnd, 0, 0, 0,
						SendMessage);
			}
			break;
		}
		case VK_INSERT:
		{
			MOUSETRAP	mouse;
			int		nCol;

			nCol = GetCursorCol(hwnd, &mouse);
			if (nCol == NIL)
				break;
			if (pddinfo)
				FORWARD_WM_LBUTTONUP(hwnd, 0, 0,
						0, SendMessage);
			if (PegBoard[nCurrentRow][nCol]) {
				FORWARD_WM_LBUTTONDOWN(hwnd, FALSE,
						mouse.pos.x + cxUnit / 2,
						mouse.pos.y + cyUnit / 2,
						0, SendMessage);
				FORWARD_WM_MOUSEMOVE(hwnd,
						mouse.pos.x + mouse.off.cx,
						mouse.pos.y + mouse.off.cy,
						0, SendMessage);
			} else if (nCurrentRow) {
				FORWARD_WM_LBUTTONDOWN(hwnd, FALSE,
						mouse.pos.x, mouse.pos.y, 0,
						SendMessage);
				FORWARD_WM_LBUTTONUP(hwnd,
						mouse.pos.x, mouse.pos.y, 0,
						SendMessage);
			}
			break;
		}
		case VK_SPACE: {
			MOUSETRAP	mouse;

			if (GetCursorCol(hwnd, &mouse) == NIL)
				break;
			if (!pddinfo)
				FORWARD_WM_KEYDOWN(hwndPegBox, nVKey, nRepeat,
							fState, SendMessage);
			FORWARD_WM_LBUTTONUP(hwnd, mouse.pos.x, mouse.pos.y, 0,
							SendMessage);
			break;
		}
		case VK_TAB:
			if (GetKeyState(VK_CONTROL) >= 0)
				break;
		case VK_F6:
			SetFocus(hwndPegBox);
			break;
	}
}

static void WND_OnSysChar(HWND	hwnd,
			  UINT	nChar,
			  int	nRepeat,
			  UINT	fState)
{
	if (nChar == '-' && GetFocus() == hwnd) {
		SetFocus(hwndPegBox);
		FORWARD_WM_SYSCOMMAND(hwndPegBox, SC_KEYMENU, ' ', 0,
							PostMessage);
		return;
	}
	FORWARD_WM_SYSCHAR(hwnd, nChar, nRepeat, fState, DefWindowProc);
}

static void WND_OnInitMenuPopup(HWND	hwnd,
				HMENU	hmenu,
				int	nPopup,
				BOOL	bSysMenu)
{
	if (bSysMenu)
		return;
	if (nPopup == 0)
		EnableMenuItem(hmenu, IDM_GIVEUP,
				bGameInProgress ? MF_ENABLED : MF_GRAYED);
	else if (nPopup == 1) {
		CheckMenuItem(hmenu, IDM_COLORS,
				bRoundPegs ? MF_CHECKED : MF_UNCHECKED);
		CheckMenuItem(hmenu, IDM_SHAPES,
				bRoundPegs ? MF_UNCHECKED : MF_CHECKED);
	}
}

static void WND_OnCommand(HWND	hwnd,
			  int	idCtl,
			  HWND	hwndCtl,
			  UINT	nCode)
{
	switch (idCtl) {
		case IDOK:
		{
			HWND	hwndButton;
			HDC	hdc;
			POINT	pt;
			int	nBlack;

			if (!bGameInProgress || !TestRowFull(nCurrentRow))
				return;
			nBlack = ScoreRow(nCurrentRow);
			hdc = GetBoardDC(hwnd);
			DrawChipRow(hdc, nCurrentRow);
			ReleaseDC(hwnd, hdc);
			++nCurrentRow;
			if (!bMouse) {
				GetCursorPos(&pt);
				pt.x += cxUnit + cx8th;
				SetCursorPos(pt.x, pt.y);
				FORWARD_WM_KEYDOWN(hwnd, VK_PRIOR,
						1, 0, SendMessage);
			}
			if (nBlack == nCols) {
				RECT	rect;

				EndGame();
				hwndButton = GetDlgItem(hwnd, IDOK);
				FORWARD_WM_SETREDRAW(hwndButton, FALSE,
							SendMessage);
				ShowWindow(hwndButton, SW_HIDE);
				GetWindowRect(hwndButton, &rect);
				MapWindowPoints(NULL, hwnd, (POINT*)&rect, 2);
				DrawEndGame(hwnd, rect.left, rect.top,
						rect.right - rect.left,
						rect.bottom - rect.top);
			} else if (nCurrentRow < nRows) {
				HDC	hdc;
				int	j;

				hdc = GetBoardDC(hwnd);
				for (j = 0 ; j < nCols ; ++j)
					if (Commital[j]) {
						PegBoard[nCurrentRow][j] =
								Commital[j];
						DrawPegOnBoard(hdc,
								nCurrentRow,
								j);
					}
				ReleaseDC(hwnd, hdc);
			} else
				EndGame();
			SetButtons(hwnd);
			if (hwndKibitz)
				PeekAtBoard(hwnd, nCurrentRow);
			break;
		}
		case IDYES:
			if (!bGameInProgress || !bCanCommit ||
						!TestRowChanged(nCurrentRow))
				return;
			if (!DoCommital(nCurrentRow))
				EndGame();
			else if (TestRowFull(nCurrentRow))
				FORWARD_WM_COMMAND(hwnd, IDOK,
						GetDlgItem(hwnd, IDOK),
						BN_CLICKED, SendMessage);
			SetButtons(hwnd);
			break;

		case IDM_START:
		{
			POINT	pt;

			StartGame();
			nCurrentRow = 0;
			if (!bMouse) {
				SendMessage(hwndPegBox, WM_SHOWKEYPEG,
						TRUE, 0L);
				pt.x = xBoard + cxUnit;
				pt.y = yBoard + cyUnit;
				ClientToScreen(hwnd, &pt);
				SetCursorPos(pt.x, pt.y);
			}
			SetButtons(hwnd);
			UpdateWindow(GetDlgItem(hwnd, IDYES));
			InvalidateRect(hwnd, NULL, FALSE);
			break;
		}
		case IDM_GIVEUP:
			if (bGameInProgress) {
				EndGame();
				SetButtons(hwnd);
			}
			break;

		case IDM_EXIT:
			FORWARD_WM_CLOSE(hwnd, SendMessage);
			break;

		case IDM_COLORS:
		case IDM_SHAPES:
			if (bRoundPegs != (idCtl == IDM_COLORS)) {
				bRoundPegs = !bRoundPegs;
				ClearPegGDI();
				MakePegGDI();
				InvalidateRect(hwnd, NULL, FALSE);
				InvalidateRect(hwndPegBox, NULL, TRUE);
			}
			break;

		case IDM_DESIGN:
		{
			DLGPROC	lpfnOptions;
			int	r = nRows, c = nCols, p = nPegs;
			BOOL	b = bCanCommit;

			lpfnOptions = MakeDlgProcInstance(OptionsDlgProc,
								hinstThis);
			if (DialogBox(hinstThis, IDD_OPTIONS, hwnd,
							lpfnOptions)) {
				ClearBoard();
				CreateBoard();
				if ((bMonochrome && p != nPegs) ||
							c != nCols) {
					ClearPegGDI();
					MakePegGDI();
					InvalidateRect(hwndPegBox, NULL, TRUE);
				}
				PlaceWindows(hwnd, TRUE);
				FORWARD_WM_COMMAND(hwnd, IDM_START, NULL, 0,
							SendMessage);
			}
			FreeDlgProcInstance(lpfnOptions);
			break;
		}
		case IDM_PLAYHELP:
			WinHelp(hwnd, szHelpFile, HELP_CONTEXT, BasicConcepts);
			return;

		case IDM_MOUSEHELP:
			WinHelp(hwnd, szHelpFile, HELP_CONTEXT, HowToUseMouse);
			break;

		case IDM_KEYHELP:
			WinHelp(hwnd, szHelpFile, HELP_CONTEXT,
						HowToUseKeyboard);
			break;

		case IDM_MENUHELP:
			WinHelp(hwnd, szHelpFile, HELP_CONTEXT, GameMenu);
			break;

		case IDM_HELPIDX:
			WinHelp(hwnd, szHelpFile, HELP_INDEX, 0);
			break;

		case IDM_HELPHELP:
			WinHelp(hwnd, szHelpFile, HELP_HELPONHELP, 0);
			break;

		case IDM_ABOUT:
		{
			DLGPROC	lpfnAbout;

			lpfnAbout = MakeDlgProcInstance(About1Proc, hinstThis);
			DialogBoxParam(hinstThis, IDD_ABOUT, hwnd,
							lpfnAbout, FALSE);
			FreeDlgProcInstance(lpfnAbout);
			break;
		}
	}
}

static void WND_OnSysColorChange(HWND	hwnd)
{
	ClearWindowGDI(FALSE);
	MakeWindowGDI(FALSE);
	FORWARD_WM_SYSCOLORCHANGE(hwndPegBox, SendMessage);
	InvalidateRect(hwnd, NULL, TRUE);
}

static void WND_OnDestroy(HWND	hwnd)
{
	if (hwndKibitz) {
		SendMessage(hwndKibitz, WM_KIBITZING, (WPARAM)hwnd, 0xDeface);
		hwndKibitz = NULL;
	}
	ClearPegGDI();
	ClearWindowGDI(TRUE);
	ClearBoard();
	WinHelp(hwnd, szHelpFile, HELP_QUIT, 0);
	PostQuitMessage(0);
}

static void WND_OnKibitzing(HWND	hwnd,
			    HWND	hwndOther,
			    LPARAM	lKey)
{
	if (lKey == 0xDecade) {
		hwndKibitz = hwndOther;
		if (bGameInProgress)
			PeekAtBoard(hwnd, nCurrentRow);
	} else if (lKey == 0xDeface)
		hwndKibitz = NULL;
}

LRESULT __export CALLBACK WndProc(HWND		hwnd,
				  UINT		message,
				  WPARAM	wParam,
				  LPARAM	lParam)
{
	switch (message) {
		HANDLE_MSG(hwnd, WM_CREATE, WND_OnCreate);
		HANDLE_MSG(hwnd, WM_SETFOCUS, WND_OnSetFocus);
		HANDLE_MSG(hwnd, WM_KILLFOCUS, WND_OnKillFocus);
		HANDLE_MSG(hwnd, WM_PAINT, WND_OnPaint);
		HANDLE_MSG(hwnd, WM_LBUTTONDOWN, WND_OnLButtonDown);
		HANDLE_MSG(hwnd, WM_MOUSEMOVE, WND_OnMouseMove);
		HANDLE_MSG(hwnd, WM_LBUTTONUP, WND_OnLButtonUp);
		HANDLE_MSG(hwnd, WM_KEYDOWN, WND_OnKey);
		HANDLE_MSG(hwnd, WM_SYSCHAR, WND_OnSysChar);
		HANDLE_MSG(hwnd, WM_INITMENUPOPUP, WND_OnInitMenuPopup);
		HANDLE_MSG(hwnd, WM_COMMAND, WND_OnCommand);
		HANDLE_MSG(hwnd, WM_SYSCOLORCHANGE, WND_OnSysColorChange);
		HANDLE_MSG(hwnd, WM_DESTROY, WND_OnDestroy);

		case WM_PEGBOXHIT:
			WND_OnPegBoxHit(hwnd, (int)wParam,
						(LPMOUSETRAP)lParam);
			return 0;

		case WM_KIBITZING:
			WND_OnKibitzing(hwnd, (HWND)wParam, lParam);
			return 0;
	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}
