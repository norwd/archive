/* vi:set wm=0 ai tabstop=4 shiftwidth=4: */

/*
 * sctl - Bearcat scanner control program
 * Copyright (C) 2001 Ian Johnston <reaper@muppetlabs.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef _MAIN_H_
#define _MAIN_H_

/***********************************************************************
 * main program #defines, not global
 ***********************************************************************/

/***********************************************************************
 * command codes
 ***********************************************************************/

#define C_NONE			-1
#define C_STATUS		0
#define C_MEM			1
#define C_HELP			2
#define C_SCAN			3
#define C_MUTE			4
#define C_DELAY			5
#define C_LOCKOUT		6
#define C_TALKGROUP		7

/***********************************************************************
 * prototypes
 ***********************************************************************/

int get_cmd(char * cmd);

#endif /* _MAIN_H_ */
