/* vi:set wm=0 ai tabstop=4 shiftwidth=4: */

/*
 * sctl - Bearcat scanner control program
 * Copyright (C) 2001 Ian Johnston <reaper@muppetlabs.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef _COMMANDS_H_
#define _COMMANDS_H_

/***********************************************************************
 * config for scanner commands, etc.
 ***********************************************************************/

/***********************************************************************
 * keycodes for the KEY command
 ***********************************************************************/

#define K_SCAN			"KEY00"
#define K_MANUAL		"KEY01"
#define K_0				"KEY02 0"
#define K_1				"KEY02 1"
#define K_2				"KEY02 2"
#define K_3				"KEY02 3"
#define K_4				"KEY02 4"
#define K_5				"KEY02 5"
#define K_6				"KEY02 6"
#define K_7				"KEY02 7"
#define K_8				"KEY02 8"
#define K_9				"KEY02 9"
#define K_DOT			"KEY03"
#define K_ENTER			"KEY04"
#define K_PRI			"KEY05"
#define K_LO			"KEY06"
#define K_HOLD_UP		"KEY07"
#define K_LIMIT_DN		"KEY08"
#define K_SRC			"KEY09"
#define K_WX			"KEY10"
#define K_DATA			"KEY11"
#define K_DELAY			"KEY12"
#define K_TRUNK			"KEY13"
#define K_DIM			"KEY14"
#define K_STEP			"KEY15"
#define K_AUX			"KEY16"
#define K_ALERT_REMOTE	"KEY17"
#define K_SEND			"KEY18"
#define K_AUTO			"KEY19"
#define K_CTCSS			"KEY20"
#define K_A				"KEY21 A"
#define K_B				"KEY21 B"
#define K_C				"KEY21 C"
#define K_D				"KEY21 D"
#define K_E				"KEY21 E"
#define K_F				"KEY21 F"
#define K_G				"KEY21 G"
#define K_H				"KEY21 H"
#define K_I				"KEY21 I"
#define K_J				"KEY21 J"
#define K_FREQ_CHAN		"KEY22"
#define K_LOCK			"KEY23"

/***********************************************************************
 * mode codes
 ***********************************************************************/

#define M_CHAN_SCAN			0
#define M_MANUAL			1
#define M_LIMIT_SRC			2
#define M_LIMIT_SRC_HOLD	3
#define M_WX_SCAN			4
#define M_WX_SCAN_HOLD		5
#define M_PROGRAM_TRUNK		6
#define M_ID_SRC			7
#define M_ID_SRC_HOLD		8
#define M_ID_SCAN			9
#define M_ID_MANUAL			10
#define M_ID_LO				11
#define M_SRC_CONT_CHAN		12
#define M_PROG_CTCSS		13
#define M_WX_ALERT			14
#define M_FREQ_SEND			15
#define M_AUTO_STORE		16
#define M_ROT_TUNE			17

/***********************************************************************
 ***********************************************************************/

typedef int mode;

int mem(int fd, int channel, double freq, int force, int set);
mode get_mode(int fd);
int set_mode(int fd, int mode_var, char bank);
int press_key(int fd, char * key);
int scan(int fd, char * banks);
int set_scan_banks(int fd, char * banks);
int scan_trunk(int fd, char * banks);
int mute(int fd, int mute);
int delay(int fd, int delay);
int lockout(int fd, int lockout, int force);
int talkgroup(int fd, char * memloc, int groupid, char bank);
int talkgroup_all(int fd, char bank);

#endif /* _COMMANDS_H_ */
