/* vi:set wm=0 ai tabstop=4 shiftwidth=4: */

/*
 * sctl - Bearcat scanner control program
 * Copyright (C) 2001 Ian Johnston <reaper@muppetlabs.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include <stdio.h>
#include <stdlib.h>

#include "utils.h"

/***********************************************************************
 ***********************************************************************/
double bc2human_freq(char * freq_string)
{
	int temp_freq;
	double real_freq;

	temp_freq = atoi(freq_string);
	real_freq = (double)temp_freq / 10000;

	return(real_freq);
}

/***********************************************************************
 ***********************************************************************/
int human2bc_freq(char * freq_string)
{
	double temp_freq1;
	int temp_freq2;

	temp_freq1 = atof(freq_string);
	temp_freq2 = (int)(temp_freq1 * 10000);
	snprintf(freq_string, 9, "%08d", temp_freq2);

	return(1);
}

/***********************************************************************
 ***********************************************************************/
int bc2human_onoff(char status, char * result)
{
	if (status == 'F')
	{
		snprintf(result, 4, "off");
		return(1);
	}
	else if (status == 'N')
	{
		snprintf(result, 3, "on");
		return(1);
	}

	return(-1);
}

/***********************************************************************
 ***********************************************************************/
void complain(char * message)
{
	fprintf(stderr, "*** Error: %s\n", message);
}
