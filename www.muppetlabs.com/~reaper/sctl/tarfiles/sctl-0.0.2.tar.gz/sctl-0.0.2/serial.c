/* vi:set wm=0 ai tabstop=4 shiftwidth=4: */
/*
 * sctl - Bearcat scanner control program
 * Copyright (C) 2001 Ian Johnston <reaper@muppetlabs.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/* from the serial programming guide for POSIX systms */

#include <stdio.h>   /* Standard input/output definitions */
#include <string.h>  /* String function definitions */
#include <unistd.h>  /* UNIX standard function definitions */
#include <fcntl.h>   /* File control definitions */
#include <errno.h>   /* Error number definitions */
#include <termios.h> /* POSIX terminal control definitions */
#include <time.h>	 /* for nanosleep */

#include "config.h"
#include "serial.h"
#include "utils.h"

/***********************************************************************
 * 'open_port()' - Open serial port 0.
 * Returns the file descriptor on success or -1 on error.
 ***********************************************************************/
int open_port(char * port)
{
	int fd; /* File descriptor for the port */
	char errorstr[1024];

	fd = open(port, O_RDWR | O_NOCTTY | O_NDELAY);
	if (fd == -1)
	{
		/* Could not open the port.  */
		snprintf(errorstr, 1023, "open_port: unable to open %s ", port);
		perror(errorstr);
		exit(1);
	}
	else
	fcntl(fd, F_SETFL, 0); /* set the port to block on no data */

	return (fd);
}

/***********************************************************************
 * this function reads an already open serial port, getting whatever
 * data is present on the line.  it will block until data is present.
 * returns number of bytes read, takes a file descriptor and a pointer
 * to a char array in.
 ***********************************************************************/
int read_serial(int fd, char * string)
{
	ssize_t bytes;
	char errstring[1024];
	int finished;
	char data[MAXLINELEN];

	bzero(data, MAXLINELEN);
	finished = 0;
	while (!finished)
	{
		bytes = read(fd, data, MAXLINELEN);
		strncat(string, data, bytes);
		if (strncmp(&data[bytes-1], "\n", 1) == 0)
		{ 
			finished = 1; 
		}
	}

	if (bytes < 0)
	{
		snprintf(errstring, 1023, "read_serial returned error code: ");
		perror(errstring);
		exit(1);
	}

	return(bytes);
}


/***********************************************************************
 * write data to the serial port, catching errors and returning the
 * number of bytes written.
 ***********************************************************************/
int write_serial(int fd, char * string)
{
	ssize_t bytes, chars;
	char errstring[1024];

	chars = strlen(string);
	bytes = write(fd, string, chars);

	if (bytes < 0)
	{
		snprintf(errstring, 1023, "write_serial returned error code: ");
		perror(errstring);
		exit(1);
	}

	return(bytes);
}


/***********************************************************************
 * setup the serial port with the baud rate and stuff we want to have.
 ***********************************************************************/
int setup_port(int fd)
{
	struct termios port;

	tcgetattr(fd, &port);

	cfsetispeed(&port, B9600);
	cfsetospeed(&port, B9600);

	port.c_cflag &= ~CSIZE; /* Mask the character size bits */
	port.c_cflag |= CS8;    /* Select 8 data bits */

	/* set port to 8N1 */
	port.c_cflag &= ~PARENB;
	port.c_cflag &= ~CSTOPB;
	port.c_cflag &= ~CSIZE;
	port.c_cflag |= CS8;

	port.c_cflag |= (CLOCAL | CREAD);
	port.c_cflag &= ~CRTSCTS; /* this should turn off hdwr flow ctl */

	port.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);

	tcsetattr(fd, TCSAFLUSH, &port);

	return(1);
}

/***********************************************************************
 * get data from the serial port one line at a time instead of one
 * character at a time.
 ***********************************************************************/
int get_line(int fd, char * line)
{
	int i, bytes;
	char data[3];

	i = 0;
	bzero(data, 3);

	while (1)
	{
		bytes = read_serial(fd, data);

		/* if the line is finished, do something with it */
		if (strncmp(&data[0], "\r", 1) == 0)
		{
			return(bytes);
		}
		else
		{
			line[i++] = data[0];
			bytes = write_serial(fd, &data[0]);
			if (bytes != 1)
			{
				printf("something is amiss: %d\n", bytes);
			}
			bzero(data, 3);
		}
	}
}


/***********************************************************************
 ***********************************************************************/
int do_command(int fd, char * command, char * answer)
{
	int cmd_len = strlen(command);
	int r_bytes;
	char errorstr[100];
	char l_command[100];
	struct timespec sleeptime;
	struct timespec remaintime;

	/* pause a little, so we don't overwhelm the skanner */
	sleeptime.tv_nsec = 100000;
	sleeptime.tv_sec = 0;
	nanosleep(&sleeptime, &remaintime);

	snprintf(l_command, 99, "%s\r", command);
	r_bytes = write_serial(fd, l_command);
	if (r_bytes != cmd_len+1)
	{
		snprintf(errorstr, 99, "Didn't manage to get entire command out: %d",
			r_bytes);
		complain(errorstr);
		return(-1);
	}

	r_bytes = read_serial(fd, answer);

	return(r_bytes);
}
