/* vi:set wm=0 ai tabstop=4 shiftwidth=4: */

/*
 * sctl - Bearcat scanner control program
 * Copyright (C) 2001 Ian Johnston <reaper@muppetlabs.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "config.h"
#include "serial.h"
#include "commands.h"
#include "human_commands.h"
#include "usage.h"
#include "main.h"

/***********************************************************************
 * the main function.  ain't it grand?
 ***********************************************************************/
int main(int argc, char ** argv)
{
	int fd, i, cmd_argc, cmd_loc, cmd_arg_loc;
	char ** cmd_argv;
	char serial_port[20];
	
	bzero(serial_port, 20);

	cmd_loc = 1;
	cmd_arg_loc = 2;
	strncat(serial_port, DEFAULT_PORT, 20);

	/* process global options first */

	for (i=1; i<argc; i++)
	{
		if (strcmp(argv[i], "-p") == 0)
		{
			bzero(serial_port, 20);
			strncat(serial_port, argv[++i], 20);
			cmd_loc += 2;
			cmd_arg_loc += 2;
		}
	}

	/* now set our clever variables that can be passed in to human functions */

	cmd_argv = malloc(sizeof(char**) * (argc - cmd_arg_loc));
	cmd_argc = argc - cmd_arg_loc;

	for (i=cmd_arg_loc; i<argc; i++)
	{
		cmd_argv[i-cmd_arg_loc] = argv[i];
	}
	
	fd = open_port(serial_port);
	setup_port(fd);

	if (argv[cmd_loc] == NULL)
	{
		usage(C_NONE);
		return(1);
	}

	switch (get_cmd(argv[cmd_loc]))
	{
		case C_DELAY:
			human_do_delay(fd, cmd_argc, cmd_argv);
			break;

		case C_HELP:
			human_help(fd, cmd_argc, cmd_argv);
			break;

		case C_LOCKOUT:
			human_do_lockout(fd, cmd_argc, cmd_argv);
			break;

		case C_MEM:
			human_do_mem(fd, cmd_argc, cmd_argv);
			break;

		case C_MUTE:
			human_do_mute(fd, cmd_argc, cmd_argv);
			break;

		case C_SCAN:
			human_do_scan(fd, cmd_argc, cmd_argv);
			break;

		case C_STATUS:
			human_do_status(fd, cmd_argc, cmd_argv);
			break;

		case C_TALKGROUP:
			human_do_talkgroup(fd, cmd_argc, cmd_argv);
			break;

		default: /* invalid command specified... */
			usage(C_NONE);
			break;
	}

	return(0);
}


/***********************************************************************
 ***********************************************************************/
int get_cmd(char * cmd)
{
	/* strncmp is used to get as many chars as necessary to uniquely
	 * identify the command -- the the user can say "me", "mem", or
	 * "memory" equally well. */

	if (strncmp(cmd, "d", 1) == 0)
	{
		return(C_DELAY);
	}
	else if (strncmp(cmd, "h", 1) == 0)
	{
		return(C_HELP);
	}
	else if (strncmp(cmd, "l", 1) == 0)
	{
		return(C_LOCKOUT);
	}
	else if (strncmp(cmd, "me", 2) == 0)
	{
		return(C_MEM);
	}
	else if (strncmp(cmd, "mu", 2) == 0)
	{
		return(C_MUTE);
	}
	else if (strncmp(cmd, "sc", 2) == 0)
	{
		return(C_SCAN);
	}
	else if (strncmp(cmd, "st", 2) == 0)
	{
		return(C_STATUS);
	}
	else if (strncmp(cmd, "t", 1) == 0)
	{
		return(C_TALKGROUP);
	}
	
	/* if we get this far, something's wrong */
	return(-1);
}

