/* vi:set wm=0 ai tabstop=4 shiftwidth=4: */

/*
 * sctl - Bearcat scanner control program
 * Copyright (C) 2001 Ian Johnston <reaper@muppetlabs.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include <stdio.h>
#include <string.h>

#include "human_commands.h"
#include "commands.h"
#include "config.h"
#include "usage.h"
#include "utils.h"
#include "serial.h"
#include "main.h"

/***********************************************************************
 **********************************************************************/
void human_do_status(int fd, int argc, char ** args)
{
	extern char * mode_desc[];
	int status, i_temp;
	char c_temp[100], c_temp2[100], answer[100];
	double d_temp;

	bzero(c_temp, 100);
	bzero(c_temp2, 100);
	bzero(answer, 100);

	status = get_mode(fd);

	printf("Current status: %s\n", mode_desc[status]);

	switch(status)
	{
		case M_MANUAL:
			mem(fd, -1, -1, 0, 1);

			bzero(answer,100);
			bzero(c_temp, 100);
			bzero(c_temp2, 100);
			do_command(fd, "SG", answer);
			sscanf(answer, "S%3s F%8s", c_temp, c_temp2);
			d_temp = bc2human_freq(c_temp2);
			printf("Listening to %.4f MHz, at S %s\n", d_temp,
				c_temp);
			break;

		case M_CHAN_SCAN:
			do_command(fd, "SB", answer);
			sscanf(answer, "SB %s", c_temp);
			printf("Scanning banks %s\n", c_temp);
			
			bzero(answer,100);
			bzero(c_temp, 100);
			bzero(c_temp2, 100);
			do_command(fd, "SG", answer);
			sscanf(answer, "S%3s F%8s", c_temp, c_temp2);
			d_temp = bc2human_freq(c_temp2);
			printf("Listening to %.4f MHz, at S %s\n", d_temp,
				c_temp);
			break;

		case M_LIMIT_SRC:
		case M_LIMIT_SRC_HOLD:
			do_command(fd, "LL", answer);
			sscanf(answer, "LL%8s", c_temp);
			d_temp = bc2human_freq(c_temp);
			printf("Lower scan edge: %f\n", d_temp);

			d_temp = 0;
			bzero(c_temp, 100);
			bzero(answer, 100);
			do_command(fd, "LU", answer);
			sscanf(answer, "LU%8s", c_temp);
			d_temp = bc2human_freq(c_temp);
			printf("Upper scan edge: %f\n", d_temp);
			break;

		case  M_ID_SRC:
		case  M_ID_SRC_HOLD:
		case  M_ID_SCAN:
		case  M_ID_MANUAL:
			do_command(fd, "IC", answer);
			if (sscanf(answer, "IC %2s %6d", c_temp, &i_temp) == 2)
			{
				printf("Listening to ID memory %s, talkgroup ID %d\n", c_temp,
					i_temp);
			}
			else if (sscanf(answer, "IC %2s ------", c_temp) == 1)
			{
				printf("Listening to ID memory %s, talkgroup ID unset\n",
					c_temp);
			}
			bzero(answer, 100);
			bzero(c_temp, 100);
			bzero(c_temp2, 100);
			do_command(fd, "SG", answer);
			sscanf(answer, "S%3s F%8s", c_temp, c_temp2);
			d_temp = bc2human_freq(c_temp2);
			printf("Listening to %.4f MHz, at S %s\n", d_temp,
				c_temp);
			break;

		default:
			printf("Additional information not available.\n");
			break;
	}

}

/***********************************************************************
 **********************************************************************/
void human_do_mem(int fd, int argc, char ** args)
{
	int mem_no, i, force, mult, mem_upper, mem_lower, set;
	double freq;
	char errstring[100];

	mem_upper = 0;
	mem_lower = 0;
	mult = 0;
	force = 0;
	set = 1;
	mem_no = -1;
	freq = -1;

	for (i=0; i<argc; i++)
	{
		if (strcmp(args[i], "-f") == 0)
		{
			force = 1;
			continue;
		}
		
		if (strcmp(args[i], "-q") == 0)
		{
			set = 0;
			continue;
		}
		
		if (strcmp(args[i], "-s") == 0)
		{
			if (sscanf(args[++i], "%lf", &freq))
				continue;
		}

		if (strcmp(args[i], "-m") == 0)
		{
			sscanf(args[++i], "%d-%d", &mem_lower, &mem_upper);
			mult = 1;
			set = 0;
			continue;
		}

		if (sscanf(args[i], "%d", &mem_no))
		{
			if (mem_no > MAXMEM)
			{
				snprintf(errstring, 99, "Must select a memory between 1 and %d",
					MAXMEM);
				complain(errstring);
				usage(C_MEM);
			}
			else if (mem_no < 1)
			{
				snprintf(errstring, 99, "Must select a memory between 1 and %d",
					MAXMEM);
				complain(errstring);
				usage(C_MEM);
			}
			else
			{
				continue;
			}
		}

		if (strcmp(args[i], "all") == 0)
		{
			mem_lower = 1;
			mem_upper = MAXMEM;
			mult = 1;
			continue;
		}

		/* if we get this far the user has included funky options */
		usage(C_MEM);
	}

	if (mult == 0)
	{
		if (set == 0 && mem_no == -1)
		{
			complain("Query mode requires a channel number (give no args to check\ncurrent memory)");
			usage(C_MEM);
		}

		mem(fd, mem_no, freq, force, set);
	}
	else
	{
		if (mem_no != -1 || freq != -1)
		{
			complain("Cannot set frequency or specify a single freq with multiple option");
			usage(C_MEM);
		}

		for (i=mem_lower; i<=mem_upper; i++)
		{
			mem(fd, i, -1, force, 0);
		}
	}
}


/***********************************************************************
 **********************************************************************/
void human_do_scan(int fd, int argc, char ** args)
{
	char banks[11], temp_bank;
	int i, do_trunk, bank_i;

	bank_i = 0;
	do_trunk = 0;

	for (i=0; i<argc; i++)
	{
		if (strcmp(args[i], "-t") == 0)
		{
			do_trunk = 1;
			continue;
		}

		if (sscanf(args[i], "%c", &temp_bank))
		{
			if (('a' - 1) < temp_bank && temp_bank < 'k') 
			{
				/* capitalize the variable */
				temp_bank -= 32;
				banks[bank_i++] = temp_bank;
				continue;
			}
			else if (('A' - 1) < temp_bank && temp_bank < 'K')
			{
				banks[bank_i++] = temp_bank;
				continue;
			}
			else
			{
				complain("Banks must be between A and J");
			}
		}
	}

	/* "terminate" the "string" so we can find the end */
	banks[bank_i] = '\0';

	if (!banks[0])
	{
		complain("Must include at least one valid bank letter");
		usage(C_SCAN);
	}

	if (do_trunk)
	{
		scan_trunk(fd, banks);
	}
	else
	{
		scan(fd, banks);
	}

}

/***********************************************************************
 **********************************************************************/
void human_do_mute(int fd, int argc, char ** args)
{
	int mute_val;

	if (args[0] == NULL)
	{
		mute_val = -1;
	}
	else if (strncmp(args[0], "o", 1) == 0) /* aka "off" */
	{
		mute_val = 0;
	}
	else if (strncmp(args[0], "a", 1) == 0) /* aka "all" */
	{
		mute_val = 1;
	}
	else if (strncmp(args[0], "n", 1) == 0) /* aka "normal" */
	{
		mute_val = 2;
	}
	else
	{
		usage(C_MUTE);
	}

	mute(fd, mute_val);
}

/***********************************************************************
 **********************************************************************/
void human_do_delay(int fd, int argc, char ** args)
{
	if (args[0] == NULL)
	{
		delay(fd, -1);
	}
	else if (strcmp(args[0], "on") == 0)
	{
		delay(fd, 1);
	}
	else if (strcmp(args[0], "off") == 0)
	{
		delay(fd, 0);
	}
	else
	{
		usage(C_DELAY);
	}
}


/***********************************************************************
 **********************************************************************/
void human_do_lockout(int fd, int argc, char ** args)
{
	int i, cmd, force;

	force = 0;
	cmd = -1;

	if (args[0] == NULL)
	{
		cmd = -1;
	}
	else
	{
		for (i=0; i<argc; i++)
		{
			if (strcmp(args[i], "on") == 0)
			{
				cmd = 1;
				continue;
			}

			if (strcmp(args[i], "off") == 0)
			{
				cmd = 0;
				continue;
			}

			if (strcmp(args[i], "-f") == 0)
			{
				force = 1;
				continue;
			}

			usage(C_LOCKOUT);
		}
	}

	lockout(fd, cmd, force);
}


/***********************************************************************
 **********************************************************************/
void human_help(int fd, int argc, char ** args)
{
	if (args[0] == NULL)
	{
		usage(C_NONE);
	}

	if (strncmp(args[0], "d", 1) == 0)
	{
		usage(C_DELAY);
	}
	else if (strncmp(args[0], "h", 1) == 0)
	{
		usage(C_HELP);
	}
	else if (strncmp(args[0], "l", 1) == 0)
	{
		usage(C_LOCKOUT);
	}
	else if (strncmp(args[0], "me", 2) == 0)
	{
		usage(C_MEM);
	}
	else if (strncmp(args[0], "mu", 2) == 0)
	{
		usage(C_MUTE);
	}
	else if (strncmp(args[0], "sc", 2) == 0)
	{
		usage(C_SCAN);
	}
	else if (strncmp(args[0], "st", 2) == 0)
	{
		usage(C_STATUS);
	}
	else if (strncmp(args[0], "t", 1) == 0)
	{
		usage(C_TALKGROUP);
	}
	else
	{
		usage(C_NONE);
	}
}


/***********************************************************************
 **********************************************************************/
void human_do_talkgroup(int fd, int argc, char ** args)
{
	/* sctl talk J C7 -s 1774 */
	int i, loc, groupid, all;
	char bank, scanbank;
	char memloc[3];

	groupid = -1;
	loc = -1;
	all = 0;
	bank = '\0';
	scanbank = 'Z';
	bzero(memloc, 3);

	for (i=0; i<argc; i++)
	{
		if (strcmp(args[i], "-s") == 0)
		{
			if (i+1 <= argc && sscanf(args[++i], "%d", &groupid))
			{
				continue;
			}
			else
			{
				complain("-s not followed by a talkgroup id");
				usage(C_TALKGROUP);
			}
		}

		if (sscanf(args[i], "%c%d", &bank, &loc) == 2)
		{
			if ('a' <= bank && bank <= 'e') 
			{
				/* capitalize the variable */
				bank -= 32;
				snprintf(memloc, 3, "%c%d", bank, loc);
				continue;
			}
			else if ('A' <= bank && bank <= 'E')
			{
				snprintf(memloc, 3, "%c%d", bank, loc);
				continue;
			}
			else
			{
				complain("Memory banks must be between A and E");
				usage(C_TALKGROUP);
			}
		}

		if (strcmp(args[i], "all") == 0)
		{
			all = 1;
			continue;
		}

		if (sscanf(args[i], "%c ", &scanbank) == 1)
		{
			if ('a' <= scanbank && scanbank <= 'j') 
			{
				/* capitalize the variable */
				scanbank -= 32;
				continue;
			}
			else if ('A' <= scanbank && scanbank <= 'J')
			{
				continue;
			}
			else
			{
				complain("Scan banks must be between A and J");
				usage(C_TALKGROUP);
			}
		}

		usage(C_TALKGROUP);
	}

	if (all == 0)
	{
		talkgroup(fd, memloc, groupid, scanbank);
	}
	else
	{
		talkgroup_all(fd, scanbank);
	}
}
