/* vi:set wm=0 ai tabstop=4 shiftwidth=4: */

/*
 * sctl - Bearcat scanner control program
 * Copyright (C) 2001 Ian Johnston <reaper@muppetlabs.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef _HUMAN_COMMANDS_H_
#define _HUMAN_COMMANDS_H_

void human_do_status(int fd, int argc, char ** args);
void human_do_mem(int fd, int argc, char ** args);
void human_do_scan(int fd, int argc, char ** args);
void human_do_mute(int fd, int argc, char ** args);
void human_do_delay(int fd, int argc, char ** args);
void human_do_lockout(int fd, int argc, char ** args);
void human_do_talkgroup(int fd, int argc, char ** args);
void human_help(int fd, int argc, char ** args);

#endif /* _HUMAN_COMMANDS_H_ */
