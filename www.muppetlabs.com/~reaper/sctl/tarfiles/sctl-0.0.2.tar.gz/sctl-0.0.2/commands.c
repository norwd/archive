/* vi:set wm=0 ai tabstop=4 shiftwidth=4: */

/*
 * sctl - Bearcat scanner control program
 * Copyright (C) 2001 Ian Johnston <reaper@muppetlabs.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/***********************************************************************
 * commands for the scanner go in here.
 ***********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "config.h"
#include "serial.h"
#include "commands.h"
#include "utils.h"

/***********************************************************************
 * data initializations
 ***********************************************************************/

char * keypad_nums[] =
{
	K_0,
	K_1,
	K_2,
	K_3,
	K_4,
	K_5,
	K_6,
	K_7,
	K_8,
	K_9
};

char * mode_desc[] =
{
	"Channel memory scan mode",
	"Manual mode",
	"Limit search mode",
	"Limit search hold mode",
	"Weather (WX) scan mode",
	"Weather (WX) scan hold mode",
	"Program trunking frequency mode",
	"ID (trunking) search mode",
	"ID (trunking) search hold mode",
	"ID (trunking) scan mode",
	"ID (trunking) manual mode",
	"ID (trunking) lockout review mode",
	"Search control channel mode",
	"Program CTCSS mode",
	"Weather (WX) alert mode",
	"Frequency send mode",
	"Auto store mode",
	"Rotary tuned freq. mode"
};

/***********************************************************************
 ***********************************************************************/
int mem(int fd, int channel, double freq, int force, int set)
{
	char answer[255], command[255], errorstr[100];
	double human_freq;
	char r_chan[4], r_freq[9], freq_string[10];
	char human_trunk[4], human_delay[4], human_lockout[4], human_record[4];
	int r_ctcss;
	char r_trunk, r_delay, r_lockout, r_record;
	mode curr_mode = get_mode(fd); 
	double maxfreq = MAXFREQ;
	double minfreq = MINFREQ;

	bzero(answer, 255);
	bzero(command, 255);
	bzero(errorstr, 100);
	bzero(r_chan, 4);
	bzero(r_freq, 9);
	bzero(freq_string, 10);
	bzero(human_trunk, 4);
	bzero(human_delay, 4);
	bzero(human_lockout, 4);
	bzero(human_record, 4);

	if (set == 0)
	{
		snprintf(command, 254, "PM%03d", channel);
		do_command(fd, command, answer);

		sscanf(answer, "C%3s F%8s T%c D%c L%c AF R%c N%2i", r_chan, r_freq,
			&r_trunk, &r_delay, &r_lockout, &r_record, &r_ctcss);

		human_freq = bc2human_freq(r_freq);
		bc2human_onoff(r_trunk, human_trunk);
		bc2human_onoff(r_delay, human_delay);
		bc2human_onoff(r_lockout, human_lockout);
		bc2human_onoff(r_record, human_record);

		printf("Memory %i: %.4f  Trunk: %s  Delay: %s  LO: %s  AutoRec: %s\n",
			atoi(r_chan), human_freq, human_trunk, human_delay, human_lockout,
			human_record);
		return(1);
	}

	if (curr_mode != M_MANUAL && !force)
	{
		complain("Radio is not in manual mode.  Use -f to override.");
		return(-1);
	}
	else if (curr_mode != M_MANUAL && force)
	{
		set_mode(fd, M_MANUAL, 'Z'); 
	}

	if (freq == -1) /* aka, don't set the freq */
	{
		if (channel != -1)
		{
			snprintf(command, 255, "MA%03d", channel);
			do_command(fd, command, answer);
			printf("Setting current memory channel to %03d\n", channel);
		}
		else
		{
			do_command(fd, "MA", answer);
		}

		/* C001 F00532900 TF DN LF AF RF N00 */
		if (strcmp(answer, "ERR") == 0)
		{
			complain("Radio won't set manual channel");
			return(-1);
		}

		sscanf(answer, "C%3s F%8s T%c D%c L%c AF R%c N%2i", r_chan, r_freq,
			&r_trunk, &r_delay, &r_lockout, &r_record, &r_ctcss);

		human_freq = bc2human_freq(r_freq);
		bc2human_onoff(r_trunk, human_trunk);
		bc2human_onoff(r_delay, human_delay);
		bc2human_onoff(r_lockout, human_lockout);
		bc2human_onoff(r_record, human_record);

		printf("Memory %i: %.4f  Trunk: %s  Delay: %s  LO: %s  AutoRec: %s\n",
			atoi(r_chan), human_freq, human_trunk, human_delay, human_lockout,
			human_record);
		return(1);
	}
	else
	{
		if (freq > maxfreq)
		{
			snprintf(errorstr, 99, "Can't set frequencies above %f MHz", 
				maxfreq);
			complain(errorstr);
			return(-1);
		}

		if (freq < minfreq && freq != 0)
		{
			snprintf(errorstr, 99, "Can't set frequencies below %f MHz", 
				minfreq);
			complain(errorstr);
			return(-1);
		}

		snprintf(freq_string, 9, "%f", freq);
		human2bc_freq(freq_string);

		bzero(answer, 255);
		bzero(command, 100);
		snprintf(command, 100, "PM%03d %s", channel, freq_string);
		do_command(fd, command, answer);
		
		if(sscanf(answer, "C%3s F%8s", r_chan, r_freq))
		{
			printf("Memory channel %i set to %f\n", channel, freq);
			return(1);
		}
		else
		{
			complain("Unable to set the frequency for some reason");
			printf("response was: %s\n", answer);
			return(-1);
		}
	}
}


/***********************************************************************
 ***********************************************************************/
mode get_mode(int fd)
{
	char answer[100];
	char modenum[3];
	mode curr_mode;

	bzero(answer, 100);
	do_command(fd, "MD", answer);

	if (strcmp(answer, "ERR") != 0)
	{
		sscanf(answer, "MD%s", modenum);
		curr_mode = (mode)atoi(modenum);
		return(curr_mode);
	}
	else
	{
		complain("Couldn't get mode number");
		return(-1);
	}
}


/***********************************************************************
 ***********************************************************************/
int set_mode(int fd, int new_mode, char bank)
{
	int old_mode = get_mode(fd);
	char keystroke[10];

	bzero(keystroke, 10);

	/* switch to mode 01 first, then go to our new mode */
	/* except 3, 5, 8, which need to stay in their mode to work */
	/* assumption currently seems to be that if we're going from a
	 * non-trunk mode to a non-trunk mode, a trunk mode to a trunk
	 * mode, or a trunk mode to a non-trunk mode, it'll work, but there 
	 * seems to be no provision for going from non-trunk to trunk.
	 */
	switch (old_mode)
	{
		case M_LIMIT_SRC:
			if (new_mode == M_LIMIT_SRC_HOLD)
				break; /* don't fallthrough if we need to hold this mode*/
			/* otherwise fallthrough to hitting K_MANUAL */

		case M_WX_SCAN:
			if (new_mode == M_WX_SCAN_HOLD)
				break; /* don't fallthrough if we need to hold this mode*/
			/* otherwise fallthrough to hitting K_MANUAL */

		case M_MANUAL:
		case M_CHAN_SCAN:
		case M_LIMIT_SRC_HOLD:
		case M_WX_SCAN_HOLD:
		case M_PROG_CTCSS:
		case M_WX_ALERT:
		case M_ROT_TUNE:
			if (new_mode == M_PROGRAM_TRUNK || new_mode == M_ID_SRC_HOLD
				|| new_mode == M_ID_SCAN || new_mode == M_ID_MANUAL ||
				new_mode == M_ID_LO || new_mode == M_SRC_CONT_CHAN)
			{
				/* ie, we're going into a trunk mode from a non-trunk */
				if (bank < 'A' || bank > 'J')
				{
					complain("Must specify a bank between A and J when switching from normal mode to trunk mode");
					return(-1);
				}

				press_key(fd, K_MANUAL);
				press_key(fd, K_TRUNK);
				snprintf(keystroke, 10, "KEY21 %c", bank);
				press_key(fd, keystroke);
				sleep(2);
			}
			else
			{
				/* otherwise going into a non-trunk */
				press_key(fd, K_MANUAL);
			}
			break;

		case M_ID_SRC:
			if (new_mode == M_ID_SRC_HOLD)
				break; /* don't fallthrough if we need to hold this mode*/

		case M_PROGRAM_TRUNK:
		case M_ID_SRC_HOLD:
		case M_ID_SCAN:
		case M_ID_MANUAL:
		case M_ID_LO:
		case M_SRC_CONT_CHAN:
			/* if we're going to another trunk mode, do nothing */
			if (new_mode == M_PROGRAM_TRUNK || new_mode == M_ID_SRC_HOLD
				|| new_mode == M_ID_SCAN || new_mode == M_ID_MANUAL ||
				new_mode == M_ID_LO || new_mode == M_SRC_CONT_CHAN)
			{
				if (bank == 'Z')
				{
					/* don't change the bank if we get Z, since that's
					 * the "no nothing" value */
					break;
				}
				else
				{
					if (bank < 'A' || bank > 'J')
					{
						complain("Can't use bank numbers other than A-J");
						return(-1);
					}

					/* left off here.  this sequence is wrong. */
					press_key(fd, K_TRUNK);
					press_key(fd, K_MANUAL);
					press_key(fd, K_TRUNK);
					snprintf(keystroke, 10, "KEY21 %c", bank);
					press_key(fd, keystroke);
					sleep(2);
				}
			}
			else
			{
				/* get us back out of trunk mode */
				press_key(fd, K_TRUNK);
				break;
			}

		default:
			break;
	}

	switch (new_mode)
	{
		case M_CHAN_SCAN:
			press_key(fd, K_SCAN);
			break;

		case M_MANUAL:
			break;

		case M_LIMIT_SRC:
			press_key(fd, K_SRC);
			break;

		case M_LIMIT_SRC_HOLD: /* already in search mode */
			press_key(fd, K_HOLD_UP);
			break;

		case M_WX_SCAN:
			press_key(fd, K_WX);
			break;

		case M_WX_SCAN_HOLD: /* already in search mode */
			press_key(fd, K_HOLD_UP);
			break;

		case M_PROGRAM_TRUNK:
			/* no clue, skip for now */
			complain("This mode is not possible in computer control mode");
			break;

		case M_ID_SRC:
			/* press_key(fd, K_SRC); */
			break;

		case M_ID_SRC_HOLD: /* already in search mode */
			press_key(fd, K_HOLD_UP);
			break;
		
		case M_ID_SCAN:
			press_key(fd, K_SCAN);
			break;

		case M_ID_MANUAL:
			press_key(fd, K_MANUAL);
			break;

		case M_ID_LO:
			press_key(fd, K_LO);
			break;

		case M_SRC_CONT_CHAN:
			complain("This mode cannot be set");
			break;

		case M_PROG_CTCSS:
			complain("This mode is not yet supported");
			break;

		case M_WX_ALERT:
			press_key(fd, K_WX);
			press_key(fd, K_ALERT_REMOTE);
			break;

		case M_FREQ_SEND:
			complain("This mode is not yet supported");
			break;

		case M_AUTO_STORE:
			/* to do this right, we have to know which banks to store,
			 * so let's skip it for now. */
			complain("This mode is not yet supported");
			break;

		case M_ROT_TUNE:
			complain("This mode may not be set in computer control mode");
			break;
	}

	return(1);
}

/***********************************************************************
 ***********************************************************************/
int press_key(int fd, char * key)
{
	int returnval;
	char result[80];
	char errstring[80];

	bzero(result, 80);
	returnval = do_command(fd, key, result);

	if (strcmp(result, "OK\n") == 0)
	{
		return(1);
	}
	else
	{
		snprintf(errstring, 80, "Trying to press %s failed: %s", key, result);
		complain(errstring);
		return(-1);
	}
}


/***********************************************************************
 ***********************************************************************/
int scan(int fd, char * banks)
{
	if (set_scan_banks(fd, banks) != 1)
	{
		return(-1);
	}
	
	set_mode(fd, M_CHAN_SCAN, 'Z');
	return(1);
}


/***********************************************************************
 ***********************************************************************/
int set_scan_banks(int fd, char * banks)
{
	char cmd_string[15], likely_answer[15], answer[100], errorstr[100];

	bzero(answer, 100);
	bzero(errorstr, 100);
	bzero(cmd_string, 15);
	bzero(likely_answer, 15);

	snprintf(cmd_string, 14, "SB %s\r", banks);
	snprintf(likely_answer, 14, "SB %s\n", banks);

	do_command(fd, cmd_string, answer);

	printf("Setting radio to scan banks %s\n", banks);

	if (strcmp(answer, likely_answer) != 0)
	{
		snprintf(errorstr, 99, "Can't set banks %s for some reason", banks);
		complain(errorstr);
		printf("response was: %s\n", answer);
		return(-1);
	}

	return(1);
}


/***********************************************************************
 ***********************************************************************/
int scan_trunk(int fd, char * banks)
{
	char answer[100], cmd[10], errorstr[100];

	set_mode(fd, M_MANUAL, 'Z');

	if (banks[1] != '\0')
	{
		complain("Can't trunk scan more than one bank");
		return(-1);
	}

	printf("Setting radio to scan trunk bank %c\n", banks[0]);
	bzero (answer, 100);
	do_command(fd, K_TRUNK, answer);

	if (strncmp(answer, "OK", 2) != 0)
	{
		snprintf(errorstr, 99, "Couldn't press trunk key: %s", answer);
		complain(errorstr);
		return(-1);
	}

	bzero (answer, 100);
	snprintf(cmd, 9, "KEY21 %c", banks[0]);
	do_command(fd, cmd, answer);

	if (strncmp(answer, "OK", 2) != 0)
	{
		complain("Couldn't press bank key");
		return(-1);
	}

	bzero (answer, 100);
	do_command(fd, K_SCAN, answer);

	if (strncmp(answer, "OK", 2) != 0)
	{
		complain("Couldn't press scan key");
		return(-1);
	}

	return(1);
}


/***********************************************************************
 ***********************************************************************/
int mute(int fd, int mute_var)
{
	char answer[100], status[10];

	bzero(answer, 100);
	bzero(status, 10);
	if (mute_var == 0)
	{
		do_command(fd, "MUF", answer);
		if (strcmp(answer, "OK\n") != 0)
		{
			complain("Couldn't set muting off");
			return(-1);
		}
		puts("Setting mute OFF\n");
	}
	else if (mute_var == 1)
	{
		do_command(fd, "MUN", answer);
		if (strcmp(answer, "OK\n") != 0)
		{
			complain("Couldn't set muting to all");
			return(-1);
		}
		puts("Setting mute to ALL\n");
	}
	else if (mute_var == 2)
	{
		do_command(fd, "MUA", answer);
		if (strcmp(answer, "OK\n") != 0)
		{
			complain("Couldn't set muting to normal");
			return(-1);
		}
		puts("Setting mute to NORMAL\n");
	}
	else if (mute_var == -1)
	{
		do_command(fd, "MU", answer);
		if (strncmp(answer, "MUF", 3) == 0)
		{
			strcpy(status, "OFF");
		}
		else if (strncmp(answer, "MUN", 3) == 0)
		{
			strcpy(status, "ALL");
		}
		else if (strncmp(answer, "MUA", 3) == 0)
		{
			strcpy(status, "NORMAL");
		}

		fprintf(stdout, "Speaker muting mode is: %s\n", status);
	}

	return(1);
}


/***********************************************************************
 ***********************************************************************/
int delay(int fd, int delay_var)
{
	char answer[100], errorstr[100];

	bzero(answer, 100);
	bzero(errorstr, 100);

	if (delay_var == -1)
	{
		do_command(fd, "DL", answer);

		if (strcmp(answer, "DLN\n") == 0)
		{
			puts("Delay function is ON for this channel");
			return(1);
		}
		else if (strcmp(answer, "DLF\n") == 0)
		{
			puts("Delay function is OFF for this channel");
			return(1);
		}
		else if (strcmp(answer, "NG\n") == 0)
		{
			complain("Radio can only check delay when paused on a channel");
			return(-1);
		}
		else
		{
			snprintf(errorstr, 99, "Can't read delay status: %s", answer);
			complain(errorstr);
			return(-1);
		}
	}
	else if (delay_var == 0)
	{
		do_command(fd, "DLF", answer);

		if (strcmp(answer, "OK\n") != 0)
		{
			complain("Can't turn off delay");
			return(-1);
		}
		puts("Setting delay OFF for this channel\n");
	}
	else if (delay_var == 1)
	{
		do_command(fd, "DLN", answer);

		if (strcmp(answer, "OK\n") != 0)
		{
			complain("Can't turn on delay");
			return(-1);
		}
		puts("Setting delay ON for this channel\n");
	}

	return(1);
}


/***********************************************************************
 ***********************************************************************/
int lockout(int fd, int lockout_var, int force)
{
	char answer[100], errorstr[100];

	bzero(answer, 100);
	bzero(errorstr, 100);

	if (lockout_var == -1)
	{
		if (force)
		{
			set_mode(fd, M_MANUAL, 'Z');
		}

		bzero(answer, 100);
		do_command(fd, "LO", answer);

		if (strcmp(answer, "LON\n") == 0)
		{
			puts("Lockout function is ON for this channel");
			return(1);
		}
		else if (strcmp(answer, "LOF\n") == 0)
		{
			puts("Lockout function is OFF for this channel");
			return(1);
		}
		else if (strcmp(answer, "NG\n") == 0)
		{
			complain("Radio cannot check lockout when scanning (-f to force-stop scan)");
			return(-1);
		}
		else
		{
			snprintf(errorstr, 99, "Can't read lockout status: %s", answer);
			complain(errorstr);
			return(-1);
		}
	}
	else if (lockout_var == 0)
	{
		do_command(fd, "LOF", answer);

		if (strcmp(answer, "OK\n") != 0)
		{
			complain("Can't turn off lockout");
			return(-1);
		}
		puts("Lockout turned OFF for this channel\n");
	}
	else if (lockout_var == 1)
	{
		do_command(fd, "LON", answer);

		if (strcmp(answer, "OK\n") != 0)
		{
			complain("Can't turn on lockout");
			return(-1);
		}
		puts("Lockout turned ON for this channel\n");
	}

	return(1);
}


/***********************************************************************
 ***********************************************************************/
int talkgroup(int fd, char * memloc, int groupid, char bank)
{
	char answer[100], command[100], l_memloc[3], errorstr[100], l_gid[15];
	int l_groupid, i;

	bzero(answer, 100);
	bzero(command, 100);
	bzero(l_memloc, 3);
	bzero(errorstr, 100);
	bzero(l_gid, 15);


	/* for some reason, IC is switching us to manual mode.  must fix. */
	if (groupid == -1)
	{
		set_mode(fd, M_ID_MANUAL, bank);

		if (memloc[0] == '\0')
		{
			snprintf(command, 99, "IC");
		}
		else
		{
			snprintf(command, 99, "IC %s", memloc);
			printf("Setting radio to talkgroup memory %s\n", memloc);
		}

		do_command(fd, command, answer);
	}
	else
	{
		set_mode(fd, M_ID_MANUAL, bank);
		snprintf(command, 99, "IC %s", memloc);
		do_command(fd, command, answer);

		if (sscanf(answer, "IC %2s %d", l_memloc, &l_groupid) != 2)
		{
			if (sscanf(answer, "IC %2s ------", l_memloc) == 1)
			{
				/* all is well, the memory just hasn't been set */
			}
			else
			{
				if (strcmp(answer, "NG\n") == 0)
				{
					complain("The radio must be in trunk mode if the bank is omitted");
					return(-1);
				}
				snprintf(errorstr, 99, "Didn't get both mem and groupid: %s", answer);
				complain(errorstr);
				return(-1);
			}
		}

		snprintf(l_gid, 14, "%d", groupid);

		/* press each number key in turn */
		for (i=0; l_gid[i] != '\0'; i++)
		{
			snprintf(command, 99, "KEY02 %c", l_gid[i]);
			if (press_key(fd, command) == -1)
			{
				snprintf(errorstr, 99, "Couldn't press number %c, giving up", 
					l_gid[i]);
				complain(errorstr);
				return(-1);
			}
		}

		if (press_key(fd, K_ENTER) == -1)
		{
			complain("Couldn't press enter, giving up");
			return(-1);
		}

		sleep(1);
		bzero(answer, 99);
		snprintf(command, 99, "IC %s", memloc);
		printf("Setting radio to talkgroup memory %s\n", l_memloc);
		do_command(fd, command, answer);
	}

	if (sscanf(answer, "IC %2s %d", l_memloc, &l_groupid) != 2)
	{
		if (sscanf(answer, "IC %2s ------", l_memloc) == 1)
		{
			if (groupid == -1)
			{
				printf("Talkgroup memory %s is empty (no value set)\n", 
					l_memloc);
			}
			else
			{
				printf("Talkgroup memory %s has been set to empty\n", 
					l_memloc);
			}
			return(1);
		}

		if (strcmp(answer, "NG\n") == 0)
		{
			complain("Radio must be paused in a trunking mode to use this function");
			return(-1);
		}
		snprintf(errorstr, 99, "Didn't get both mem and groupid: %s", answer);
		complain(errorstr);
		return(-1);
	}

	if (groupid == -1)
	{
		printf("Talkgroup in memory %s is %d\n", l_memloc, l_groupid);
	}
	else
	{
		printf("Talkgroup in memory %s has been set to %d\n", l_memloc, 
			l_groupid);
	}
		
	return(1);
}



/***********************************************************************
 * trying to use the regular talkgroup command to list all memories was
 * painfully slow, so i added this one.
 ***********************************************************************/
int talkgroup_all(int fd, char bank)
{
	char answer[100], command[100], l_memloc[3], errorstr[100], l_gid[15];
	char b;
	int l_groupid, i;

	set_mode(fd, M_ID_MANUAL, bank);

	for (b='A'; b<'F'; b++)
	{
		for (i=0; i<10; i++)
		{
			bzero(answer, 100);
			bzero(command, 100);
			bzero(l_memloc, 3);
			bzero(errorstr, 100);
			bzero(l_gid, 15);

			snprintf(command, 99, "IC %c%d", b, i);

			do_command(fd, command, answer);

			if (sscanf(answer, "IC %2s %d", l_memloc, &l_groupid) != 2)
			{
				if (sscanf(answer, "IC %2s ------", l_memloc) == 1)
				{
					printf("Talkgroup memory %s is empty (no value set)\n", 
						l_memloc);
					continue;
				}

				if (strcmp(answer, "NG\n") == 0)
				{
					complain("Radio must be paused in a trunking mode to use this function");
					return(-1);
				}
				snprintf(errorstr, 99, "Didn't get both mem and groupid: %s", answer);
				complain(errorstr);
				return(-1);
			}

			printf("Talkgroup in memory %s is %d\n", l_memloc, l_groupid);
		}
	}
		
	return(1);
}
