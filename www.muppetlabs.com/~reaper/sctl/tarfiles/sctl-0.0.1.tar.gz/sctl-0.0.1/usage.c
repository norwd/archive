/* vi:set wm=0 ai tabstop=4 shiftwidth=4: */

/*
 * sctl - Bearcat scanner control program
 * Copyright (C) 2000 Ian Johnston <reaper@muppetlabs.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include <stdio.h>

#include "config.h"
#include "main.h"
#include "usage.h"

/***********************************************************************
 ***********************************************************************/
void usage(int cmd)
{
	switch(cmd)
	{
		case C_DELAY:
			usage_delay();
			break;

		case C_LOCKOUT:
			usage_lockout();
			break;

		case C_MEM:
			usage_mem();
			break;

		case C_MUTE:
			usage_mute();
			break;

		case C_SCAN:
			usage_scan();
			break;

		case C_STATUS:
			usage_status();
			break;

		case C_TALKGROUP:
			usage_talkgroup();
			break;

		default:
			fprintf(stderr, "  Usage: sctl [-p port] command options\n");
			fprintf(stderr, "  Currently supported commands are:\n\n");
			fprintf(stderr, "  delay     - sets or queries delay setting\n");
			fprintf(stderr, "  help      - displays a little help message\n");
			fprintf(stderr, "  lockout   - sets or queries lockout setting\n");
			fprintf(stderr, "  mem       - sets or queries memory channel\n");
			fprintf(stderr, "  mute      - sets the current muting mode\n");
			fprintf(stderr, "  scan      - sets scanning mode\n");
			fprintf(stderr, "  status    - shows the current status of the scanner\n");
			fprintf(stderr, "  talkgroup - sets or queries the current talkgroup\n\n");
			fprintf(stderr, "  Commands need only be specified by enough letters to uniquely identify the\n");
			fprintf(stderr, "  particular option.  Use 'help cmdname' to get more information on cmdname.\n");
			break;
	}

	exit (0);
}

/***********************************************************************
 ***********************************************************************/
void usage_mem(void)
{
	int maxmem = MAXMEM;
	fprintf(stderr, "Usage: sctl mem [-f] [-q] [channel] [-m channels] [-s freq]\n");
	fprintf(stderr, "The command by itself will return information about the current memory\n");
	fprintf(stderr, "channel.  Usage of options modifies the behavior:\n\n");
	fprintf(stderr, "  channel     - specify a memory number between 1 and %d to switch to\n", maxmem);
	fprintf(stderr, "  -m channels - list multiple channels\n");
	fprintf(stderr, "  -s freq     - sets the indicated memory to xxxx.yyyy MHz\n");
	fprintf(stderr, "  -f          - forces the radio to manual mode if necessary\n");
	fprintf(stderr, "  -q          - only queries the given memory location, rather than setting\n");
	fprintf(stderr, "                that as the current memory.\n\n");
	fprintf(stderr, "  IE, 'sctl mem 7 -s 150.5' would set memory channel 7 to 150.5 MHz\n");
}


/***********************************************************************
 ***********************************************************************/
void usage_mute(void)
{
	fprintf(stderr, "Usage: sctl mute [on|off|auto]\n");
	fprintf(stderr, "This command sets or queries the speaker muting mode.  With no argument it\n");
	fprintf(stderr, "queries, and with the following options sets the mode:\n\n");
	fprintf(stderr, "  on   - turn on speaker muting\n");
	fprintf(stderr, "  off  - turn off speaker muting\n");
	fprintf(stderr, "  auto - set speaker muting to automatic mode\n");
}


/***********************************************************************
 ***********************************************************************/
void usage_scan(void)
{
	fprintf(stderr, "Usage: sctl scan [-t] bank [bank bank ...]\n");
	fprintf(stderr, "This command sets the scanning mode, including which banks are being scanned.\n");
	fprintf(stderr, "Options are as follows:\n\n");
	fprintf(stderr, "  -t   - scan a trunking bank (note that only a one bank at a time\n");
	fprintf(stderr, "       can be trunk-scanned)\n");
	fprintf(stderr, "  bank - a single letter (upper or lower case) to indicate a bank\n");
}

/***********************************************************************
 ***********************************************************************/
void usage_delay(void)
{
	fprintf(stderr, "Usage: sctl delay [on|off]\n");
	fprintf(stderr, "This command sets or queries the delay setting on the current channel.\n");
	fprintf(stderr, "Note that delay can only be set or queried when the scanner is stopped on\n");
	fprintf(stderr, "a channel, and not when it's actively scanning.  Specifying no option\n");
	fprintf(stderr, "queries the current delay setting.\n\n");
	fprintf(stderr, "  on  - turns on the delay setting for the current channel\n");
	fprintf(stderr, "  off - turns off the current channel's delay setting\n");
}

/***********************************************************************
 ***********************************************************************/
void usage_lockout(void)
{
	fprintf(stderr, "Usage: sctl lockout [on|off]\n");
	fprintf(stderr, "The lockout command is used to set or check whether the current channel\n");
	fprintf(stderr, "is locked out or not.  The status can be changed whenever the scanner is\n");
	fprintf(stderr, "stopped on a channel, but can only be checked when the scanner is in\n");
	fprintf(stderr, "manual mode.  Specifying no option queries the status.\n\n");
	fprintf(stderr, "  on  - turns on the lockout setting for the current channel\n");
	fprintf(stderr, "  off - turns off the current channel's lockout setting\n");
}

/***********************************************************************
 ***********************************************************************/
void usage_status(void)
{
	fprintf(stderr, "Usage: sctl status\n");
	fprintf(stderr, "This command shows the current status of the radio, including the mode\n");
	fprintf(stderr, "(scanning, trunk-tracking, manual mode, etc.) and possibly more information,\n");
	fprintf(stderr, "depending upon which mode it's in.  There are no options to this command.\n");
}

/***********************************************************************
 ***********************************************************************/
void usage_talkgroup(void)
{
	fprintf(stderr, "Usage: sctl talkgroup [all|memory] [bank] [-s talkgroup]\n");
	fprintf(stderr, "The talkgroup command will display the talkgroup to which the scanner is\n");
	fprintf(stderr, "is currently listening, or optionally set a talkgroup to listen to.  With\n");
	fprintf(stderr, "no options, it will report the current talkgroup.  Other options:\n\n");
	fprintf(stderr, "  all          - specifying 'all' lists all talkgroup memories\n");
	fprintf(stderr, "  memory       - (in the form A0 or E6) switch to that ID location\n");
	fprintf(stderr, "  bank         - specify bank number (if not already in trunk mode)\n");
	fprintf(stderr, "  -s talkgroup - set the specified memory to talkgroup (0 means 'empty')\n\n");
	fprintf(stderr, "  IE, 'sctl talkgroup E6 F -s 1775' would set memory location E6 in bank F to\n");
	fprintf(stderr, "  talkgroup number 1775. You must specify a bank letter if not in trunk mode.\n");
	fprintf(stderr, "  Specifying a bank letter in trunk mode will switch to that trunk bank.\n");
}
