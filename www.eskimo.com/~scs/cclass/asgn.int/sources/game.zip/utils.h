#include <stdio.h>
extern int getline(char [], int);
extern int fgetline(FILE *, char [], int);
extern int getwords(char *, char *[], int);
