extern void *chkmalloc(size_t);
extern char *chkstrdup(char *);
