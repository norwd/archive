	// asm.cpp: 
	extern int asm_ (FILE *pfdoc, FILE *pnfile);