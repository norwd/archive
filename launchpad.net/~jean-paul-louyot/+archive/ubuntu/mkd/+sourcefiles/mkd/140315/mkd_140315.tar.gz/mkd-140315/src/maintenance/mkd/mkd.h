     
	// asm.c, asm.cpp:
	extern int asm_(FILE *pfdoc, FILE *pnfile);
     
	// File: basic.c
	void basic_ (FILE * pfdoc, FILE * pnfile);
     
	// File: cpp.c
	extern int cpp_ (FILE * pfdoc, FILE * pnfile);     
	// File: fortran.c
	void fortran_ (FILE * pfdoc, FILE * pnfil     
	// File: mkd.c
	//// internal functions
	// int main (int argc, char * argv[]);
	// int tolower(int c);
	// int toupper(int c);
	// int getch(stdin);
	//// external special functions in internationalisation.h
	// char * gettext (const char * msgid);     
	// File: pascal.c (Comments for UTF-8 text editor)
	void pascal_ (FILE * pfdoc, FILE * pnfile);
     
	// File: shell.c (Comments for UTF-8 text editor)
	void shell_ (FILE * pfdoc, FILE * pnfile);
     
	// File: tri.c
	void tri_ (FILE * pfdoc, FILE * pnfile);                                             
                                             
                                             
                                             
                                             
                                             
                                             
                                             
                           
                                                               
                            find_ ne reconnaît pas: .s .f .p .sh .csh  
                           
                           
                           
                           
                               find_ ne reconnaît pas: .BAS .PAS .FOR ... 
                           
                           
    #D ************************************************************************************
    *** #Define OPTIONS DE COMPILATION:  options par défaut, redéfinissables: **************
          (#D pour l'extraction des options de compilation en ligne avec l'option CD3='#') 
   ****************** #Define 'l' (ligne) commence par #define en 1ère colonne : **********
                      #Define Option CD1 en 1ère colonne  prend fin avec NL                
                      #Define Option CD2 en 1ère colonne  prend fin avec NL                
                      #Define Option CD3 dans la ligne    prend fin avec NL                
                      #Define Option '!' commentaire Fortran 90 et ultérieurs              
                      #Define Option '%' commentaire postcript                             
                      #Define Option '#' commentaire shell ou pour Makefile voir option S
                                     ( le commentaire se termine avec new_line )           
                      #Define Option '\'' commentaires Basic                               
                      #Define Option ';'  commentaires assembleur                          
    ***************** #Define Option 'p' (dans la page) #define en 1ère colonne : *********
                      #Define Option CD4 = "  debut de commentaire                         
                      #Define Option CD5 = "  fin de commentaire                           
                      #Define *************************************************************
                      #Define Option de compil. copier toute la ligne                      
    #D ************************************************************************************
				   
	                           
				   
		                      longueur des buffers des path source et doc 
		                       Start Text 
		                     
				   
			            
		                     
		                       
			                  
				         
			               Microsoft Visual C 10.- 
		                        ISO C++ 
		                        ISO C++ 
		                          ISO C++ 
				         
				   
			                 
			                   SVr4, 4.3BSD, C89, C99.
		                      
				         
				   
			              
                                   
			                   SVr4, 4.3BSD, C89, C99.
		                        
		                      
		                        
		                      
				         
