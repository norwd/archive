     
//	cpp.cpp:
	extern int cpp_ (FILE *pfdoc, FILE *pnfile);

