     
	// asm.cpp:
	extern int asm_(FILE *pfdoc, FILE *pnfile);
     
	// File: basic.c
	void basic_ (FILE * pfdoc, FILE * pnfile);
     
	// File: cpp.c
	extern int cpp_ (FILE * pfdoc, FILE * pnfile);
     
	// File: fortran.c
	void fortran_ (FILE * pfdoc, FILE * pnfile);
     
	// File: pascal.c (Comments for UTF-8 text editor)
	void pascal_ (FILE * pfdoc, FILE * pnfile);
     
	// File: shell.c (Comments for UTF-8 text editor)
	void shell_ (FILE * pfdoc, FILE * pnfile);
     
	// File: tri.c
	void tri_ (FILE * pfdoc, FILE * pnfile);

