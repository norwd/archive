     
	// File: basic.c
	void basic_ (FILE * pfdoc, FILE * pnfile);

