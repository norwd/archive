#!/bin/bash
# File INSTALL.sh in src-mkddocu
make -d install
