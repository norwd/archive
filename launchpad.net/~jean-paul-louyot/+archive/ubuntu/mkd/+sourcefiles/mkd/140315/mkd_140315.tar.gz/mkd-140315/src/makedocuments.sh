#!/bin/sh
# File : makedocuments
# Author : Stephane
# Date : 09/02/2001
# Update by JPL 28/02/2014
rm *.c~ # ATTENTION !
./mkddocu -s mkd # mkd nécessaire pour le fichier d'entête global mkd.h
