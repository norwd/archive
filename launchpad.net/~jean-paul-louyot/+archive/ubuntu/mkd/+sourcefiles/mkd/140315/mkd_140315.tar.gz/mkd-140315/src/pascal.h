    
	// File: pascal.c (Comments for UTF-8 text editor)
	void pascal_ (FILE * pfdoc, FILE * pnfile);

