
	// File: shell.c (Comments for UTF-8 text editor)
	void shell_ (FILE * pfdoc, FILE * pnfile);

