     
	// File: tri.c
	void tri_ (FILE * pfdoc, FILE * pnfile);

