#!/bin/bash
# File copy2locale.sh
# This shell command copy all .mo file to locale directory
cp -f *.mo ../../locale/.
