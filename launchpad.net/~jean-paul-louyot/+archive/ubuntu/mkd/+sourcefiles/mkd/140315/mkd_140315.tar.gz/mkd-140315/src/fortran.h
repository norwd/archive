
     
	// File: fortran.c
	void fortran_ (FILE * pfdoc, FILE * pnfile);

