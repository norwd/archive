/*
 *  simu - Microprocessor simulator.
 * 
 *  Copyright (c) 1995 Fabrice Bellard
 *
 *  Contact addresses:
 *  mail: Fabrice Bellard, 451 chemin du mas de Matour, 34790 Grabels, France
 *  email: bellard@email.enst.fr
 *  url: http://www.enst.fr/~bellard
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include <stdlib.h>
#include <stdio.h>
#include <strings.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
 
/* you may change this value if your computer is too slow or too fast */

#define DELAY_BETWEEN_INSTR 20

Display *display;
GC gc;
Window window;
int screen;
int bg,fg; 

KeySym GetKey(void)   {
   
      char buf[80];
      XEvent xev;
      KeySym keysym;
      XComposeStatus status;
   
   while (1)   {
      
            XNextEvent(display,&xev);
      if (xev.type==KeyPress)   {
	 
	          XLookupString((XKeyEvent *)&xev,buf,80,&keysym,&status);
	          return keysym;
      }
   }
}
 


void SetGraphMode(int sx,int sy) {
	
   XSizeHints hint;
   XEvent      xev;
	 
   display=XOpenDisplay("");
   if (display==NULL)   {
      fprintf(stderr,"Can't open display\n");
      exit(-2);
   }
   
   screen = DefaultScreen (display);
   hint.x = 0;
   hint.y = 0;
   hint.width = sx;
   hint.height = sy;
   hint.flags = PPosition | PSize;
   bg = BlackPixel (display, screen);
   fg = WhitePixel (display, screen);
   
   window = XCreateSimpleWindow (display,
				 DefaultRootWindow (display),
				 hint.x, hint.y,
				 hint.width, hint.height,
				 4, fg, bg);
   
   XSelectInput(display, window, StructureNotifyMask);
   XSetStandardProperties (display, window, "test", "test", None, NULL, 0, &hint);
   XMapWindow(display, window);
   
   while(1)   {
      XNextEvent(display, &xev);
      if(xev.type == MapNotify && xev.xmap.event == window) break;
	 }
 
	 XSelectInput(display, window, KeyPressMask | KeyReleaseMask);

	 gc = XCreateGC(display, window, 0, 0);

	 XSetForeground(display,gc,fg);
}  

#define MEMSIZE 32768
#define NBREG 7

typedef unsigned char uchar;

int x_size,y_size;
uchar mem[MEMSIZE];

/* state of the microprocessor */
ushort pc;
uchar r[NBREG];
uchar acc;
uint Z,C;

void ExecInstr(void) {
	 uchar opcode;
	 uint n,t;
	 
	 opcode=mem[pc++];
	 n=opcode & 0x0F;
	 
	 switch (opcode & 0xF0) {
		case 0x00:
			switch(n) {
			 case 0x00:
				 if (!Z) pc+=(char)acc;
				 break;
			 case 0x01:
				 if (Z) pc+=(char)acc;
				 break;
			 case 0x02:
				 if (!C) pc+=(char)acc;
				 break;
			 case 0x03:
				 if (C) pc+=(char)acc;
				 break;
			 case 0x04:
				 r[0]=(pc-1) & 0xFF;
				 r[1]=(pc-1) >> 8;
				 break;
			 case 0x05:
				 pc=r[1]*256+r[0];
				 break;
			 case 0x06:
				 acc=mem[r[1]*256+r[0]];
				 break;
			 case 0x07:
				 mem[r[1]*256+r[0]]=acc;
				 break;
			 case 0xF:
				 printf("%c",r[0]);
				 break;
			}
			break;
		case 0x10:
			r[n]=acc;
			Z=(r[n]==0);
			break;
		case 0x20:
			acc=r[n];
			Z=(acc==0);
			break;
		case 0x30:
			if (n<8) acc=n; else acc=256-16+n;
			break;
		case 0x40:
			acc=(acc & 0x0F) | ( n << 4);
			break;
		case 0x50:
			break;
		case 0x60:
			t=(uint)acc + (uint) r[n] + C;
			acc=t & 0xFF;
			Z=(acc==0);
			C=(t>=0x100);
			break;
		case 0x70:
			t=(uint)acc + (uint) r[n] + C;
			r[n]=t & 0xFF;
			Z=(r[n]==0);
			C=(t>=0x100);
			break;
		case 0x80:
			t=(uint)(acc ^ 0xFF) + (uint) r[n] + C;
			acc=t & 0xFF;
			Z=(acc==0);
			C=(t>=0x100);
			break;
		case 0x90:
			t=(uint)(acc ^ 0xFF) + (uint) r[n] + C;
			r[n]=t & 0xFF;
			Z=(r[n]==0);
			C=(t>=0x100);
			break;
		case 0xA0:
			acc=r[n] & acc;
			Z=(acc==0);
			break;
		case 0xB0:
			r[n]=r[n] & acc;
			Z=(r[n]==0);
			break;
		case 0xC0:
			acc=r[n] | acc;
			Z=(acc==0);
			break;
		case 0xD0:
			r[n]=r[n] | acc;
			Z=(r[n]==0);
			break;
		case 0xE0:
			acc=r[n] ^ acc;
			Z=(acc==0);
			C=0;
			break;
		case 0xF0:
			r[n]=r[n] ^ acc;
			Z=(r[n]==0);
			C=0;
			break;
	 }
}
	

#define MIPS 300000

/* fast update every 100 �s */
#define UPDATE_COUNT1 (MIPS / 10000)

/* screen update every 20 ms */
#define UPDATE_COUNT2 200

#define MIN_VISIBLE  (UPDATE_COUNT1 / 5)
#define AXSIZE 40
#define AYSIZE 80
#define EXSIZE 5

#define AFFSEL 4
#define AFFLED 5
#define KBD    6


uchar col[4]= {
	 0xFF,0xFF,0xFF,0xFF
};


int tab_key[]= {
	 XK_1,0,0, XK_2,1,0, XK_3,2,0, XK_a,3,0,
	 XK_4,0,1, XK_5,1,1, XK_6,2,1, XK_b,3,1,
	 XK_7,0,2, XK_8,1,2, XK_9,2,2, XK_c,3,2,
	 XK_0,0,3, XK_f,1,3, XK_e,2,3, XK_d,3,3,
	 -1
};
	 

int disp_count[6][8];
int update_count1,update_count2;

void UpdateFast(void) 
{
  int i,j,a;
  
  for(i=0;i<6;i++) {
    if ((r[AFFSEL] & (1<<i)) != 0) {
      a=r[AFFLED];
      for(j=0;j<8;j++) if ( (a & (1<<j)) == 0) disp_count[i][j]++;
    }
  }

  
  r[KBD]=0xFF;
  for(i=0;i<4;i++) if (r[AFFSEL] & (1<<i)) r[KBD]&=col[i];
}


void UpdatePeriph(void) {
  int a,c,i,j,y1,y2,y3,x1,x2;
  char buf[80];
  XEvent xev;
  KeySym keysym;
  XComposeStatus status;
  int *p;
  
  y1=20;
  y2=y1+(AYSIZE/2);
  y3=y1+AYSIZE;
  
  
  for(i=0;i<6;i++) {
    x1=20+(AXSIZE+EXSIZE)*i;
    x2=x1+AXSIZE;
    a=0;
    
    for(j=0;j<8;j++) {
      if (disp_count[i][j] >= MIN_VISIBLE) a|=1 << j;
      disp_count[i][j]=0;
    }

    if (a & 0x01) c=fg; else c=bg;
    XSetForeground(display,gc,c);
    XDrawLine(display,window,gc,x1,y1,x2,y1);
    
    if (a & 0x02) c=fg; else c=bg;
    XSetForeground(display,gc,c);
    XDrawLine(display,window,gc,x2,y1,x2,y2);
    
    if (a & 0x04) c=fg; else c=bg;
    XSetForeground(display,gc,c);
    XDrawLine(display,window,gc,x2,y2,x2,y3);
    
    if (a & 0x08) c=fg; else c=bg;
    XSetForeground(display,gc,c);
    XDrawLine(display,window,gc,x2,y3,x1,y3);
    
    if (a & 0x10) c=fg; else c=bg;
    XSetForeground(display,gc,c);
    XDrawLine(display,window,gc,x1,y3,x1,y2);
    
    if (a & 0x20) c=fg; else c=bg;
    XSetForeground(display,gc,c);
    XDrawLine(display,window,gc,x1,y2,x1,y1);
    
    if (a & 0x40) c=fg; else c=bg;
    XSetForeground(display,gc,c);
    XDrawLine(display,window,gc,x1,y2,x2,y2);
  }
  
  XFlush(display);
  if (XPending(display)!=0) {
    XNextEvent(display,&xev);
    if (xev.type==KeyPress || xev.type==KeyRelease)   {
      XLookupString((XKeyEvent *)&xev,buf,80,&keysym,&status);
      p=tab_key;
      while (p[0] != -1 && p[0] != keysym) p+=3;
      if (xev.type==KeyPress) {
	col[p[1]]&=~(1<<p[2]);
      } else {
	col[p[1]]|=(1<<p[2]);
      }
    }
    /*			printf("%X %X %X %X\n",col[0],col[1],col[2],col[3]); */
  }
}

								
int main(int argc,char *argv[]) {
  
  FILE *f;
  int i;
  
  int pc;
	 
  if (argc != 2) {
    fprintf(stderr,"Microprocessor Simulator (c) 1995 Fabrice Bellard\n"
	    "usage: simu binary_file\n");
    exit(0);
  }
	   
  x_size=320;
  y_size=200;
  SetGraphMode(x_size,y_size);
  
    
  /* program loading */
  for(i=0;i<MEMSIZE;i++) mem[i]=0;
  f=fopen(argv[1],"r");
  if (f==NULL) {
    perror(argv[1]);
    exit(1);
  }
  fread(mem,1,MEMSIZE,f);
  fclose(f);
  
  pc=0;
  acc=0;
  Z=0;
  C=0;
  for(i=0;i<NBREG;i++) r[i]=0;
  r[4]=0xFF;
  update_count1=0;
  update_count2=0;
  
  while (1) {
    
    for(i=0;i<DELAY_BETWEEN_INSTR;i++) ;

    ExecInstr();

    if (++update_count1 == UPDATE_COUNT1) {
      update_count1=0;
      UpdateFast();
      if (++update_count2 == UPDATE_COUNT2) {
	update_count2=0;
	UpdatePeriph();
      }
    }
  }

  return 0;
}
	 
	 
	 
	 
	 
