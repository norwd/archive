/*
 * Compression utilities
 * 
 * Copyright (c) 2018-2019 Fabrice Bellard
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <inttypes.h>
#include <assert.h>
#include <time.h>
#include <getopt.h>
#include <stdarg.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#ifdef _WIN32
#include <direct.h>
#else
#include <termios.h>
#endif

#include "cutils.h"
#include "libnc.h"
#include "cp_utils.h"

void fatal_error(const char *fmt, ...)
{
    va_list ap;
    
    va_start(ap, fmt);
    fprintf(stderr, "Fatal error: ");
    vfprintf(stderr, fmt, ap);
    fprintf(stderr, "\n");
    exit(1);
}

int64_t get_time_ms(void)
{
#ifdef _WIN32
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (int64_t)tv.tv_sec * 1000 + (tv.tv_usec / 1000U);
#else
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (int64_t)ts.tv_sec * 1000 + (ts.tv_nsec / 1000000U);
#endif
}

void fput_u8(FILE *f, uint8_t v)
{
    fputc(v, f);
}

int fget_u8(FILE *f, uint8_t *pv)
{
    int c;
    c = fgetc(f);
    if (c < 0)
        return -1;
    *pv = c;
    return 0;
}

void fput_be16(FILE *f, uint16_t v)
{
    fputc(v >> 8, f);
    fputc(v >> 0, f);
}

int fget_be16(FILE *f, uint16_t *pv)
{
    uint8_t buf[2];
    if (fread(buf, 1, sizeof(buf), f) != sizeof(buf))
        return -1;
    *pv = (buf[0] << 8) |
        (buf[1] << 0);
    return 0;
}

void fput_be32(FILE *f, uint32_t v)
{
    fputc(v >> 24, f);
    fputc(v >> 16, f);
    fputc(v >> 8, f);
    fputc(v >> 0, f);
}

void fput_be64(FILE *f, uint64_t v)
{
    fput_be32(f, v >> 32);
    fput_be32(f, v);
}

int fget_be32(FILE *f, uint32_t *pv)
{
    uint8_t buf[4];
    if (fread(buf, 1, sizeof(buf), f) != sizeof(buf))
        return -1;
    *pv = get_be32(buf);
    return 0;
}

void fput_sgd_opt(FILE *f, const SGDOptParams *p)
{
    fput_u8(f, p->algo);
    switch(p->algo) {
    case SGD_OPT_BASIC:
        break;
    case SGD_OPT_ADAM:
        fput_f32(f, p->u.adam.beta1);
        fput_f32(f, p->u.adam.beta2);
        fput_f32(f, p->u.adam.eps);
        fput_f32(f, p->u.adam.gradient_clip);
        break;
    default:
        abort();
    }
}

int fget_sgd_opt(FILE *f, SGDOptParams *p)
{
    uint8_t v8;
    
    if (fget_u8(f, &v8))
        return -1;
    p->algo = v8;
    switch(p->algo) {
    case SGD_OPT_BASIC:
        break;
    case SGD_OPT_ADAM:
        if (fget_f32(f, &p->u.adam.beta1))
            return -1;
        if (fget_f32(f, &p->u.adam.beta2))
            return -1;
        if (fget_f32(f, &p->u.adam.eps))
            return -1;
        if (fget_f32(f, &p->u.adam.gradient_clip))
            return -1;
        break;
    default:
        return -1;
    }
    return 0;
}

void dump_sgd_opt_params(FILE *f, const SGDOptParams *p)
{
    switch(p->algo) {
    case SGD_OPT_BASIC:
        fprintf(f, " sgd_opt=%s", 
               "none");
        break;
    case SGD_OPT_ADAM:
        fprintf(f, " sgd_opt=%s beta1=%g beta2=%g eps=%g gclip=%g wdecay=%g",
               "adam",
                p->u.adam.beta1,
                p->u.adam.beta2,
                p->u.adam.eps,
                p->u.adam.gradient_clip,
                p->u.adam.weight_decay);
        break;
    default:
        abort();
    }
}

typedef union {
    float f;
    uint32_t u32;
} f32;

void fput_f32(FILE *f, float v)
{
    f32 u;
    u.f = v;
    fput_be32(f, u.u32);
}

int fget_f32(FILE *f, float *pv)
{
    f32 u;
    if (fget_be32(f, &u.u32))
        return -1;
    *pv = u.f;
    return 0;
}

void write_sym(PutBitState *pb, const float *prob_table, int n_symb, int sym)
{
    int start, range, prob0, bit, range0;
    float p, p0;
    
    start = 0;
    range = n_symb;
    p = 1.0; /* invariant: p=sum(prob_table[start...start + range]) */
    while (range > 1) {
        range0 = range >> 1;
        p0 = vec_sum_f32(prob_table + start, range0);
        prob0 = lrintf(p0 * PROB_UNIT / p);
        prob0 = clamp_int(prob0, 1, PROB_UNIT - 1);
        bit = sym >= (start + range0);
        put_bit(pb, prob0, bit);
        if (bit) {
            start += range0;
            range = range - range0;
            p = p - p0;
        } else {
            p = p0;
            range = range0;
        }
    }
}

int read_sym(GetBitState *gb, const float *prob_table, int n_symb)
{
    int start, range, prob0, bit, range0;
    float p, p0;
    
    start = 0;
    range = n_symb;
    p = 1.0; /* invariant: p=sum(prob_table[start...start + range]) */
    while (range > 1) {
        range0 = range >> 1;
        p0 = vec_sum_f32(prob_table + start, range0);
        prob0 = lrintf(p0 * PROB_UNIT / p);
        prob0 = clamp_int(prob0, 1, PROB_UNIT - 1);
        bit = get_bit(gb, prob0);
        if (bit) {
            start += range0;
            range = range - range0;
            p = p - p0;
        } else {
            p = p0;
            range = range0;
        }
    }
    return start;
}

void create_debug_dir(char *debug_dir, size_t debug_dir_size,
                      const char *debug_path, const char *prefix)
{
    char name1[1024];
    struct tm *tm;
    time_t ti;
    
    snprintf(name1, sizeof(name1), "%s/%s", debug_path, prefix);
#ifdef _WIN32
    _mkdir(name1);
#else
    mkdir(name1, 0777);
#endif
    
    ti = time(NULL);
    tm = localtime(&ti);
    snprintf(debug_dir, debug_dir_size, "%s/%04u%02u%02u-%02u%02u%02u",
             name1,
             tm->tm_year + 1900, tm->tm_mon + 1, tm->tm_mday,
             tm->tm_hour, tm->tm_min, tm->tm_sec);
#ifdef _WIN32
    _mkdir(debug_dir);
#else
    mkdir(debug_dir, 0777);
#endif
}

/**************************************************************/
/* piece-wise linear interpolation + optional power decay */
float get_interp_param(const InterpParams *p, int64_t pos)
{
    int i;
    float lr, t;
    int64_t pos0;

    pos0 = 0;
    for(i = 0; i < p->n_steps; i++) {
        if (pos < p->pos[i]) {
            if (i == 0)
                pos0 = 0;
            else
                pos0 = p->pos[i - 1];
            t = (float)(pos - pos0) / (float)(p->pos[i] - pos0);
            lr = p->val[i] + t * (p->val[i + 1] - p->val[i]);
            return lr;
        }
    }
    if (p->decay_power == 0.0f || p->n_steps == 0) {
        return p->val[p->n_steps];
    } else if (p->decay_power == 0.5f) {
        /* special case to be independant of pow() rounding */
        return p->val[p->n_steps] /
            sqrtf((float)pos / (float)p->pos[p->n_steps - 1]);
    } else {
        /* XXX: use libc independant pow() implementation to avoid
           rounding differences */
        return p->val[p->n_steps] *
            pow((float)pos / (float)p->pos[p->n_steps - 1], -p->decay_power);
    }
}

void dump_interp_param(FILE *f, const InterpParams *p)
{
    int i;
    fprintf(f, "%g", p->val[0]);
    for(i = 0; i < p->n_steps; i++) {
        fprintf(f, ",%" PRIu64 ",%g",
                p->pos[i], p->val[i + 1]);
    }
    if (p->decay_power != 0) {
        fprintf(f, ",p%g", p->decay_power);
    }
}

void skip_c(const char **pp, int c)
{
    const char *p;
    p = *pp;
    if (*p != c) {
        fprintf(stderr, "expecting '%c'\n", c);
        exit(1);
    }
    p++;
    *pp = p;
}

void parse_interp_param(InterpParams *p, const char *r)
{
    float lr;
                    
    lr = strtod(r, (char **)&r);
    p->n_steps = 0;
    p->val[0] = lr;
    p->decay_power = 0.0;
    if (*r != '\0') {
        skip_c(&r, ',');
        for(;;) {
            if (*r == 'p') {
                r++;
                p->decay_power = strtod(r, (char **)&r);
                if (*r != '\0')
                    fatal_error("extranous characters");
                break;
            } else {
                if (p->n_steps >= INTERP_MAX_STEPS)
                    fatal_error("too many steps");
                p->pos[p->n_steps] =
                    lrint(strtod(r, (char **)&r));
                
                skip_c(&r, ',');
                p->val[++p->n_steps] =
                    strtod(r, (char **)&r);
                if (*r == '\0')
                    break;
                skip_c(&r, ',');
            }
        }
    }
}

#ifdef _WIN32
void term_init(void)
{
}
int term_get_key(void)
{
    return 0;
}
#else
static struct termios oldtty;
static int old_fd0_flags;

static void term_exit(void)
{
    tcsetattr (0, TCSANOW, &oldtty);
    fcntl(0, F_SETFL, old_fd0_flags);
}

void term_init(void)
{
    struct termios tty;

    memset(&tty, 0, sizeof(tty));
    tcgetattr (0, &tty);
    oldtty = tty;
    old_fd0_flags = fcntl(0, F_GETFL);

    tty.c_iflag &= ~(IGNBRK|BRKINT|PARMRK|ISTRIP
                          |INLCR|IGNCR|ICRNL|IXON);
    tty.c_oflag |= OPOST;
    tty.c_lflag &= ~(ECHO|ECHONL|ICANON|IEXTEN);
    tty.c_cflag &= ~(CSIZE|PARENB);
    tty.c_cflag |= CS8;
    tty.c_cc[VMIN] = 1;
    tty.c_cc[VTIME] = 0;

    tcsetattr (0, TCSANOW, &tty);
    fcntl(0, F_SETFL, O_NONBLOCK);

    atexit(term_exit);
}

/* return 0 if no key */
int term_get_key(void)
{
    uint8_t ch;
    if (read(0, &ch, 1) == 1)
        return ch;
    else
        return 0;
}
#endif /* !_WIN32 */

uint8_t *load_file(size_t *psize, const char *filename)
{
    FILE *f;
    size_t size;
    uint8_t *buf;
    
    f = fopen(filename, "rb");
    if (!f) {
        perror(filename);
        exit(1);
    }
    fseek(f, 0, SEEK_END);
    size = ftell(f);
    fseek(f, 0, SEEK_SET);
    buf = malloc(size + 1);
    if (fread(buf, 1, size, f) != size) {
        fprintf(stderr, "%s: I/O error\n", filename);
        exit(1);
    }
    buf[size] = '\0';
    fclose(f);
    if (psize)
        *psize = size;
    return buf;
}

int get_random_seed(void)
{
    struct timeval tv;
    int seed;

    gettimeofday(&tv, NULL);
    seed = tv.tv_sec + tv.tv_usec;
    return seed;
}

