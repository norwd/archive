Here is the original source code of LZEXE 0.91 (MIT license, see the
accompanying LICENSE file). It was compiled with Turbo Pascal 5.0 and
A86.COM (for the two .ASM files). The sources use the cp437 charset
(437 DOS codepage).

Fabrice Bellard.
