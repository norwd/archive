The following patches are not part of RISCVEMU. They were used to
build the boot loader and the Linux kernel.

git versions:
riscv-pk    ac2c910b18c3e36cfd85080472e78ad2fe484325
riscv-linux a3b1e7acc6a181e04e9a943942084395df4498dd
