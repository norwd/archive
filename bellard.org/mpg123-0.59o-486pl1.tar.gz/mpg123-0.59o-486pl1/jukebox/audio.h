
typedef struct 
{
	int bitrate;
	int frequency;
	int stereo;
	int type;
	int sample;
} AudioInfo;

