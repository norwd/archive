/*
 * Routines pour le calcul sur de tr�s grands nombres
 * par F. Bellard
 */

typedef unsigned int UINT;
typedef unsigned int FFTWORD;

typedef unsigned long long ull;
typedef unsigned long long MDWORD;

/* d�fini dans fft_mul.c */

void FFTMul_Init(void);
void FFTMul(int k,FFTWORD *result,FFTWORD *op1,FFTWORD *op2,FFTWORD base);

void FFTMul1(int k,int n1,int n2,FFTWORD *res,FFTWORD *op1,FFTWORD *op2,
						 FFTWORD base);


/* d�fini dans big_int.c */

void SlowMul(FFTWORD *result,int op1_size,FFTWORD *op1,
						 int op2_size,FFTWORD *op2,FFTWORD base);

void BigAdd(int n,FFTWORD *res,FFTWORD *op1,FFTWORD *op2,FFTWORD base);

void BigSub(int n,FFTWORD *res,FFTWORD *op1,FFTWORD *op2,FFTWORD base);

void BigMulAdd(FFTWORD *res,int op1_size,FFTWORD *op1,
							 FFTWORD op2,FFTWORD base);

FFTWORD BigMul(FFTWORD *res,int op1_size,FFTWORD *op1,
							 FFTWORD op2,FFTWORD base);

void BigDiv(int op1_size,FFTWORD *op1,FFTWORD op2,FFTWORD base);


void TestPrint(int n,FFTWORD *res);


/* d�fini dans big_real.c */


/*
 * - La mantisse a une taille de 2^k+4 mots
 * - La pr�cision garantie est de 2^k mots significatifs
 * - Pour l'instant aucun d�bodement n'est g�r� 
 * - Pour l'instant, pas de r�els n�gatifs
 */

typedef struct {
	 int k;
	 int exp;
	 int mant_size;
	 FFTWORD *mant;
} BIGFLOAT;

BIGFLOAT *bigfloat_New(int mant,int exp,int k);
void bigfloat_Free(BIGFLOAT *a);
void bigfloat_Move(BIGFLOAT *res,BIGFLOAT *op);

void bigfloat_Print(BIGFLOAT *a);

void bigfloat_Add(BIGFLOAT *res,BIGFLOAT *op1,BIGFLOAT *op2);
void bigfloat_Sub(BIGFLOAT *res,BIGFLOAT *op1,BIGFLOAT *op2);
void bigfloat_DivInt(BIGFLOAT *res,FFTWORD op);
void bigfloat_MulInt(BIGFLOAT *res,FFTWORD op);


void bigfloat_Mul(BIGFLOAT *res,BIGFLOAT *op1,BIGFLOAT *op2);
void bigfloat_Inv(BIGFLOAT *res,BIGFLOAT *A);
void bigfloat_InvSqrt(BIGFLOAT *res,BIGFLOAT *B);
void bigfloat_SqrtInt(BIGFLOAT *res,FFTWORD a);








