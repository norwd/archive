#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include "big_calc.h"

#define BASE 1000000000

/*
 * Calcul de pi par la m�thode de salamin
 * On n'a pas d�montr� ici la vitesse de convergence de la suite:
 * on suppose qu'elle calcule 2^k mots � l'�tape k
 */

void CalcPI(int k) {
	 int i;
	 BIGFLOAT *SQRT2,*B,*D,*T,*U,*S;
	 clock_t tim;
	 float timecalc;
	 
	 tim=clock();
	 
	 /* SQRT2=sqrt(2) */
	 SQRT2=bigfloat_New(2,0,k);
	 bigfloat_SqrtInt(SQRT2,2);
	 
/*	 printf("sqrt2= "); bigfloat_Print(SQRT2); */
	 
	 /* D=sqrt(2)/2 */
	 D=bigfloat_New(1,0,k);
	 bigfloat_Move(D,SQRT2);
	 bigfloat_DivInt(D,2);

	 /* B=D */
	 B=bigfloat_New(1,0,k);
	 bigfloat_Move(B,D);
	 
	 /* T=1 */
	 T=bigfloat_New(1,0,k);
	 
	 /* U=0 */
	 U=bigfloat_New(0,0,k);

	 /* S=0 */
	 S=bigfloat_New(0,0,k);
	 
	 for(i=1;i<=(k+3);i++) {
			fprintf(stderr,"it�ration: %d\n",i);
			
			/* U=(T+B)/2 */
			bigfloat_Add(U,T,B);
			bigfloat_DivInt(U,2);
			
			/* T=(U+B)/2 */
			bigfloat_Add(T,U,B);
			bigfloat_DivInt(T,2);
	 
			/* B=sqrt(U*B) */
			
			bigfloat_Mul(B,U,B);
		
 			bigfloat_Inv(S,B);

			bigfloat_InvSqrt(B,S);
			
			/* S=T-B */
			
			bigfloat_Sub(S,T,B);
			bigfloat_MulInt(S,(1<<i));
			
			bigfloat_Sub(D,D,S);
/*
			printf("S= "); bigfloat_Print(S);
			
			printf("T= "); bigfloat_Print(T);
			printf("B= "); bigfloat_Print(B);

			printf("U= "); bigfloat_Print(U);
			printf("D= "); bigfloat_Print(D);
*/			
	 }			

	 /* pi=2*sqrt(2)*T/D */
	 
	 bigfloat_MulInt(T,2);
	 bigfloat_Mul(T,SQRT2,T);
	 
	 bigfloat_Inv(S,D);
	 
	 bigfloat_Mul(T,T,S);
	 

	 tim=clock()-tim;
	 if (tim==0) tim=1;
	 timecalc=(float)tim/CLOCKS_PER_SEC;


	 /* T=pi !!! */

	 printf("PI= ");
	 bigfloat_Print(T);
	 fprintf(stderr,"Time Calc= %0.2f s\n",timecalc);
}



int main(int argc,char *argv[])
{
	 int K;
	 
	 FFTMul_Init();

   K=atoi(argv[1]);

	 CalcPI(K);
	 return 0; 
}
	 
