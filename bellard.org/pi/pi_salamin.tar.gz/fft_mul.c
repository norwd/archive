/*
 * Multiplication de 2 nombres par la m�thode de Pollard 
 * Version optimis�e pour la vitesse
 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include "big_calc.h"


/*
 * calcul de K=(y0+m0*(y1+m1*y2))+a0+a1*2^32 
 * a1:a0=K/base
 * return K % base
 */

FFTWORD BaseCvt(FFTWORD *a0,FFTWORD *a1,FFTWORD base,
						 FFTWORD y0,FFTWORD y1,FFTWORD y2,FFTWORD m0,FFTWORD m1)
{
	 ull t1,t2,t3,t4;
	 
	 t1=y1+(ull)m1*(ull)y2;
	 t2=(t1 & 0xFFFFFFFFL) * (ull)m0 + y0 + *a0;
	 t3=(t1>>32) * (ull)m0 + (t2>>32) + *a1;

	 *a1=t3/base;
	 t4=((t3%base)<<32)+(t2 & 0xFFFFFFFFL);
	 *a0=t4/base;

	 return t4 % base;
}


/*
 * Op�rations modulaires
 */

/*
inline FFTWORD add_mod(FFTWORD a,FFTWORD b,FFTWORD modulo)  {
	 FFTWORD c;
	 c=a+b;
	 if (c>=modulo) c-=modulo;
	 return c;
}

inline FFTWORD sub_mod(FFTWORD a,FFTWORD b,FFTWORD modulo)  {
	 FFTWORD c;
	 if (a>=b) {
			c=a-b;
	 } else {
			c=a-b+modulo;
	 }
	 return c;
}
*/

inline FFTWORD add_mod(FFTWORD a,FFTWORD b,FFTWORD modulo)  {
	 int c,d;
	 c=a+b-modulo;
	 d=c >> 31;
	 c=c + (d & modulo); 
	 return c;
}

inline FFTWORD sub_mod(FFTWORD a,FFTWORD b,FFTWORD modulo)  {
	 int c,d;
	 c=a-b;
	 d=c >> 31;
	 c=c + (d & modulo);
	 return c;
}


#ifndef ASM_386

inline FFTWORD mul_mod(FFTWORD a,FFTWORD b,FFTWORD modulo)  {
	 FFTWORD c;
	 c=((ull)a*(ull)b) % modulo;
	 return c;
}

#else

inline FFTWORD mul_mod(FFTWORD a,FFTWORD b,FFTWORD modulo)  {
	 FFTWORD c;
	 asm(" movl %1,%%eax ; mull %2 ; divl %3 ; movl %%edx,%0 "
			 : "=g" (c)
			 : "g" (a) , "g" (b) , "g" (modulo)
			 : "%eax" , "%edx"
			 );
	 return c;
}

#endif

/*
 * inversion de x mod y
 */
FFTWORD inv_mod(FFTWORD x,FFTWORD y) {
	 FFTWORD q,u,v,a,c,t;
	 u=x;
	 v=y;
	 c=1;
	 a=0;
	 while (u!=0) {
			q=v/u;
			
			t=c;
			c=sub_mod(a,mul_mod(q,c,y),y);
			a=t;
			
			t=u;
			u=v-q*u;
			v=t;
	 }
	 return a;
}

#define PRIM_PRECALC_BITS  9
#define PRIM_PRECALC_NB     (1<<PRIM_PRECALC_BITS)


/* FFT Pass m on 2^n FFTWORD */
static void FFTPass_NoPre(int n,int m,FFTWORD *tab,FFTWORD *tabpow,FFTWORD modulo) 
{
	 int i,j,k,l;
	 FFTWORD a,b,*p,*q,cpow,mpow;
	 
	 mpow=tabpow[n-m];
	 k=1 << (n-m-1);
	 l=1 << m;
	 
	 p=tab;
	 q=tab+k;
	 for(i=0;i<l;i++)  {
				 
			a=*p;
			b=*q;
			*p=add_mod(a,b,modulo);
			*q=sub_mod(a,b,modulo);
			p++;
			q++;
				 
			cpow=mpow;
			j=k-1;
			while(1) {
				 a=*p;
				 b=*q;
				 *p=add_mod(a,b,modulo);
				 *q=mul_mod(sub_mod(a,b,modulo),cpow,modulo);
				 p++;
				 q++;
				 j--;
				 if (j==0) break;
				 cpow=mul_mod(cpow,mpow,modulo);
			}

			p+=k;
			q+=k;
	 }
}

/* idem but with cpow precalculated */

static void FFTPass_Pre(int n,int m,FFTWORD *tab,FFTWORD *tabpowpre,FFTWORD modulo) 
{
	 int i,j,k,l,s;
	 FFTWORD a,b,*p,*q,*r;
	 
	 k=1 << (n-m-1);
	 l=1 << m;
	 s=1 << (PRIM_PRECALC_BITS+m+1-n);
	 
	 p=tab;
	 q=tab+k;
	 for(i=0;i<l;i++)  {
				 
				 a=*p;
				 b=*q;
				 *p=add_mod(a,b,modulo);
				 *q=sub_mod(a,b,modulo);
				 p++;
				 q++;

				 r=tabpowpre+s;
				 j=k-1;
				 do {
						a=*p;
						b=*q;
						*p=add_mod(a,b,modulo);
						*q=mul_mod(sub_mod(a,b,modulo),*r,modulo);
						p++;
						q++;
						r+=s;
				 } while (--j!=0);

				 p+=k;
				 q+=k;
	 }
}

/* last pass */

static void FFTPass_Last(int n,FFTWORD *tab,FFTWORD modulo)
{
	 int i,l;
	 FFTWORD a,b,*p;
	 
	 p=tab;
	 l=1<<(n-1);
	 for(i=0;i<l;i++) {
			a=p[0];
			b=p[1];
			p[0]=add_mod(a,b,modulo);
			p[1]=sub_mod(a,b,modulo);
			p+=2;
	 }
}


/* 
 * FFT sur 2**n FFTWORD 
 * Note: Le r�sultat est dans un tableau � parcourir avec un index � bits
 * invers�s
 */
void FFT(int n,FFTWORD *tab,FFTWORD *tabpowpre,FFTWORD *tabpow,FFTWORD modulo)
{
	 int pass,pass1,pass2;
	 
	 pass1=n-1-PRIM_PRECALC_BITS;
	 if (pass1<0) pass1=0;
	 pass2=n-1;
	 
	 for(pass=0;pass<pass1;pass++) 
	 	FFTPass_NoPre(n,pass,tab,tabpow,modulo);

	 for(pass=pass1;pass<pass2;pass++) 
	 	FFTPass_Pre(n,pass,tab,tabpowpre,modulo);
	 
	 FFTPass_Last(n,tab,modulo);
}

/*
 * Pr�calcul du tableau d'inversion de taille 2**k
 */

UINT *tabrev=NULL;
UINT tabrev_k=0;

void PreReverse(UINT k) {
	 UINT a,c,i,j,nb_word;
	 
	 if (k!=tabrev_k) {
			nb_word=1 << k;
			tabrev=realloc( tabrev, nb_word * sizeof(UINT) );
			tabrev_k=k;
			for(i=0;i<nb_word;i++) {
				 a=i;
				 c=0;
				 for(j=0;j<k;j++) {
						c=(c<<1) | (a & 1);
						a=a >> 1;
				 }
				 tabrev[i]=c;
			}
	 }
}


/* 
 * Reconstruction d'un tableau de taille 2**k en renversant l'ordre des 
 * bits de l'index. 
 */

void FFTReverse(UINT k,FFTWORD *tab) {
	 UINT i,j,m,mask,mask1,nb_word;
	 FFTWORD tmp;
	 
	 nb_word=1 << k;
	 m=k / 2;
	 PreReverse(m);
	 mask= (1 << m) - 1;

	 if ( (k&1)==0 ) {
			/* cas o� n est pair */
			for(i=1;i<nb_word;i++)  {
				 j=(tabrev[i & mask] << m) + tabrev[i>>m];
				 if (j<i) {
						tmp=tab[i];
						tab[i]=tab[j];
						tab[j]=tmp;
				 }
			}
	 } else {
			/* cas o� n est impair */
			mask1=1 << m;
			m++;
			for(i=1;i<nb_word;i++)  {
				 j=(tabrev[i & mask] << m) + tabrev[i>>m] + (i & mask1);
				 if (j<i) {
						tmp=tab[i];
						tab[i]=tab[j];
						tab[j]=tmp;
				 }
			}
	 }
}
			
/*
 * Etape a effectuer avant la FFT inverse: tab[u]<->tab[N-u] (u=1..N/2)
 */
void FFTNegate(UINT k,FFTWORD *tab) {
	 UINT i,n,m,tmp;
	 
	 m=1 << (k-1);
	 n=1 << k;
	 for(i=1;i<m;i++) {
			tmp=tab[i];
			tab[i]=tab[n-i];
			tab[n-i]=tmp;
	 }
}

/*
 * Impl�mentation de la multiplication
 */

#define NB_FFTWORD 3
#define PRIM_ORDER 25

/* nombres premiers pour le reste chinois, dans l'ordre croissant */
FFTWORD prem[NB_FFTWORD]= { 
	 1711276033, /* 51*2^25+1 */
	 1811939329, /* 27*2^26+1 */
	 2013265921, /* 15*2^27+1 */
};

/* racines principales de l'unit� d'ordre PRIM_ORDER */
FFTWORD prim[NB_FFTWORD]= {
	 40,
	 103,
	 170
};

/* puissances du type 2^k des racines principales */
FFTWORD tabpow[NB_FFTWORD][PRIM_ORDER+1];
/* pr�calcul des puissances des racines principales */
FFTWORD tabpowpre[NB_FFTWORD][PRIM_PRECALC_NB];
	 
/*
 * Init FFTMul
 */

void FFTMul_Init(void) {
	 FFTWORD a,b,*p;
	 int i,j;
	 
	 /* Initialisation des puissances des racines principales */
	 
	 for(i=0;i<NB_FFTWORD;i++) {
			a=prim[i];
			for(j=PRIM_ORDER;j>=1;j--) {
				 tabpow[i][j]=a;
				 a=mul_mod(a,a,prem[i]);
			}
			a=tabpow[i][PRIM_PRECALC_BITS+1];
			b=1;
			p=&tabpowpre[i][0];
			for(j=0;j<PRIM_PRECALC_NB;j++) {
				 *p++=b;
				 b=mul_mod(b,a,prem[i]);
			}
	 }
}

/*
 * Multiplication de 2 nombres de 2^k mots. R�sultat dans un nombre de
 * 2^(k+1) mots.
 * Si op1==op2, alors un carr� est calcul�.
 */

void FFTMul(int k,FFTWORD *result,FFTWORD *op1,FFTWORD *op2,FFTWORD base) {
	 
	 FFTWORD *tmp[NB_FFTWORD],*p,*q;
	 int res_size,op_size;
	 UINT i,j;
	 FFTWORD y[NB_FFTWORD],u[NB_FFTWORD],c01,c02,c12;
	 FFTWORD a0,a1,a;
	 
	 
/* allocation du stockage interm�diaire: NB_FFTWORD nombres de 2^(k+1) mots */	 
	 res_size=1<<(k+1);
	 op_size=1 << k;
	 for(i=0;i<NB_FFTWORD;i++) {
			tmp[i]=malloc(res_size * sizeof(FFTWORD));
	 }
			
/* Calcul des NB_FFTWORD convolutions */

	 for(i=0;i<NB_FFTWORD;i++) {

			/* stockage des 2 nombres */
			
			p=tmp[i];
			for(j=0;j<op_size;j++) {
				 *p= op1[j] % prem[i];
				 p++;
			}
			for(j=0;j<op_size;j++) *p++= 0;

			if (op2!=op1) {
				 p=result;
				 for(j=0;j<op_size;j++) {
						*p= op2[j] % prem[i];
						p++;
				 }
				 for(j=0;j<op_size;j++) *p++= 0;
			}

			/* calcul de la convolution de op1 & op2 par FFT */

			FFT(k+1,tmp[i],tabpowpre[i],tabpow[i],prem[i]);
			
			if (op1!=op2) {
				 FFT(k+1,result,tabpowpre[i],tabpow[i],prem[i]);
			
				 p=tmp[i];
				 q=result;
				 for(j=0;j<res_size;j++) {
						*p=mul_mod(*p,*q,prem[i]);
						p++;
						q++;
				 }
			} else {
				 p=tmp[i];
				 for(j=0;j<res_size;j++) {
						a=*p;
						*p=mul_mod(a,a,prem[i]);
						p++;
				 }
			}
			
			FFTReverse(k+1,tmp[i]);
			FFTNegate(k+1,tmp[i]);
			
			FFT(k+1,tmp[i],tabpowpre[i],tabpow[i],prem[i]);
			
			FFTReverse(k+1,tmp[i]);
	 }

	 
	 /* rassemblement des NB_FFTWORD convolutions, reste
		* chinois, et propagation des retenues 
		* on a "hardcod�" NB_FFTWORD=3
		*/
	 for(i=0;i<NB_FFTWORD;i++) u[i]=inv_mod(1<<(k+1),prem[i]);
	 c01=inv_mod(prem[0],prem[1]);
	 c02=inv_mod(prem[0],prem[2]);
	 c12=inv_mod(prem[1],prem[2]);
	 
	 /* init retenues */
	 a0=a1=0;
	 
	 for(j=0;j<res_size;j++) {
			
			/* division par 2^(k+1) */
			
			y[0]=mul_mod(u[0],tmp[0][j],prem[0]);
			y[1]=mul_mod(u[1],tmp[1][j],prem[1]);
			y[2]=mul_mod(u[2],tmp[2][j],prem[2]);
			
			/* calcul de la repr�sentation "mixed radix" */ 

			y[1]=mul_mod(sub_mod(y[1],y[0],prem[1]),c01,prem[1]);
			y[2]=mul_mod(sub_mod(y[2],y[0],prem[2]),c02,prem[2]);
			y[2]=mul_mod(sub_mod(y[2],y[1],prem[2]),c12,prem[2]);
	
			/* conversion dans la base de sortie */
						
			result[j]=BaseCvt(&a0,&a1,base,y[0],y[1],y[2],prem[0],prem[1]);

	 }

/*
 * Lib�ration m�moire
 */
	 for(i=0;i<NB_FFTWORD;i++) {
			free(tmp[i]);
	 }

}

