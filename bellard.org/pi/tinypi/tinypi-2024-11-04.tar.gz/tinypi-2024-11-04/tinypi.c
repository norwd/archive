/*
 * Tiny PI computation with near linear running time
 * 
 * Copyright (c) 2017-2024 Fabrice Bellard
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#include <stdlib.h>
#include <stdio.h>
#include <inttypes.h>
#include <string.h>
#include <assert.h>

#if INTPTR_MAX >= INT64_MAX
/* Use 64 bit integers. __int128 must be supported by the compiler. */
#define LIMB_BITS 64
#else
/* Use 32 bit integers. */
#define LIMB_BITS 32
#endif

/* use faster small modulo reduction */
#define USE_MUL_MOD_FAST

#define no_inline __attribute__((noinline))
//#define inline __attribute__((always_inline))
#define __maybe_unused __attribute__((unused))
#define countof(x) (sizeof(x) / sizeof(x[0]))

#if LIMB_BITS == 64

typedef unsigned __int128 uint128_t;
typedef int64_t slimb_t;
typedef uint64_t limb_t;
typedef uint128_t dlimb_t;
#define BASE_EXP 19
#define BASE UINT64_C(10000000000000000000)
#define FMT_LIMB1 "%" PRIu64 
#define FMT_LIMB "%019" PRIu64 
#define FMT_EXP "%" PRId64 

#define NTT_MUL_THRESHOLD 75 /* in limbs of the smallest factor */

#else

typedef int32_t slimb_t;
typedef uint32_t limb_t;
typedef uint64_t dlimb_t;
#define BASE_EXP 9
#define BASE 1000000000U
#define FMT_LIMB1 "%u"
#define FMT_LIMB "%09u"
#define FMT_EXP "%d"

#define NTT_MUL_THRESHOLD 75 /* in limbs of the smallest factor */

#endif

#define BITS_PER_DIGIT 3.32192809488736234786

/* zero is represented with exp = 0 and len = 0 */
typedef struct {
    int sign;
    slimb_t exp;
    limb_t len;
    limb_t *tab;
} bd_t;

typedef void bd_op2_func_t(bd_t *r, const bd_t *a, const bd_t *b, limb_t prec);

static void bd_add(bd_t *r, const bd_t *a, const bd_t *b, limb_t prec);
static void bd_mul(bd_t *r, const bd_t *a, const bd_t *b, limb_t prec);
static void bd_mul_si(bd_t *r, const bd_t *a, int64_t b1, limb_t prec);
static void ntt_mul(bd_t *r, const limb_t *taba, limb_t a_len,
                    const limb_t *tabb, limb_t b_len);

static inline slimb_t max(slimb_t a, slimb_t b)
{
    if (a > b)
        return a;
    else
        return b;
}

static inline slimb_t min(slimb_t a, slimb_t b)
{
    if (a < b)
        return a;
    else
        return b;
}

/* could leading zeros */
static inline int clz(limb_t a)
{
    if (a == 0) {
        return LIMB_BITS;
    } else {
#if LIMB_BITS == 64
        return __builtin_clzll(a);
#else
        return __builtin_clz(a);
#endif
    }
}

static inline int ceil_log2(limb_t a)
{
    if (a <= 1)
        return 0;
    else
        return LIMB_BITS - clz(a - 1);
}

static no_inline void bd_init(bd_t *r)
{
    r->sign = 0;
    r->exp = 0;
    r->len = 0;
    r->tab = NULL;
}

static void bd_delete(bd_t *r)
{
    free(r->tab);
}

static void bd_resize(bd_t *r, limb_t len)
{
    if (len != r->len) {
        r->tab = realloc(r->tab, len * sizeof(limb_t));
        r->len = len;
    }
}

static void bd_set_si(bd_t *r, int64_t a1)
{
    uint64_t a;
    if (a1 == 0) {
        r->sign = 0;
        r->exp = 0;
        bd_resize(r, 0);
    } else {
        if (a1 >= 0) {
            r->sign = 0;
            a = a1;
        } else {
            r->sign = 1;
            a = -a1;
        }
#if LIMB_BITS == 32
        if (a >= (uint64_t)BASE * BASE) {
            bd_resize(r, 3);
            r->exp = 3;
            r->tab[0] = a % BASE;
            a /= BASE;
            r->tab[1] = a % BASE;
            r->tab[2] = a;
        } else if (a >= BASE) {
            bd_resize(r, 2);
            r->exp = 2;
            r->tab[0] = a % BASE;
            r->tab[1] = a / BASE;
        } else
#endif
        {
            bd_resize(r, 1);
            r->exp = 1;
            r->tab[0] = a;
        }
    }
}

static void bd_set(bd_t *r, const bd_t *a)
{
    r->sign = a->sign;
    r->exp = a->exp;
    bd_resize(r, a->len);
    memcpy(r->tab, a->tab, a->len * sizeof(limb_t));
}

static limb_t get_limbz(const bd_t *a, limb_t idx)
{
    if (idx >= a->len)
        return 0;
    else
        return a->tab[idx];
}

static void bd_renorm(bd_t *r, limb_t prec)
{
    limb_t l, i;
    l = r->len;
    while (l > 0 && r->tab[l - 1] == 0)
        l--;
    if (l == 0) {
        /* zero */
        r->exp = 0;
    } else {
        r->exp -= (r->len - l);
        /* trunc to prec limbs */
        i = max(0, l - prec);
        /* remove trailing zeros */
        while (r->tab[i] == 0)
            i++;
        if (i > 0) {
            l -= i;
            memmove(r->tab, r->tab + i, l * sizeof(limb_t));
        }
    }
    bd_resize(r, l);
}

/* max_digits = -1: print all the digits */
static void bd_print(FILE *f, const bd_t *a, slimb_t max_digits)
{
    slimb_t i, e_start;
    int l;
    char buf[20];
    
    if (a->sign)
        fputc('-', f);
    if (a->len == 0) {
        fputc('0', f);
    } else {
        /* print the integer part */
        e_start = a->exp - a->len;
        i = max(a->exp - 1, 0);
        fprintf(f, FMT_LIMB1, get_limbz(a, i - e_start));
        i--;
        for(; i >= 0; i--) {
            fprintf(f, FMT_LIMB, get_limbz(a, i - e_start));
        }
        if (max_digits < 0)
            max_digits = max(-e_start, 0) * BASE_EXP;
        if (max_digits != 0)
            fputc('.', f);
        while (max_digits != 0) {
            l = min(max_digits, BASE_EXP);
            sprintf(buf, FMT_LIMB, get_limbz(a, i - e_start));
            fwrite(buf, 1, l, f);
            max_digits -= l;
            i--;
        }
    }
}

static void bd_print_exp(FILE *f, const bd_t *a)
{
    slimb_t i;
    if (a->sign)
        fputc('-', f);
    if (a->len == 0) {
        fputc('0', f);
    } else {
        fprintf(f, "0.");
        for(i = a->len - 1; i >= 0; i--) {
            fprintf(f, FMT_LIMB, get_limbz(a, i));
        }
        fprintf(f, "e" FMT_EXP, a->exp * BASE_EXP);
    }
}

static __maybe_unused void bd_print_str(const char *str, const bd_t *a)
{
    printf("%s=", str);
    bd_print_exp(stdout, a);
    printf("\n");
}

static int bd_cmpu(const bd_t *a, const bd_t *b)
{
    slimb_t res, i;
    limb_t len, v1, v2;
    
    res = a->exp - b->exp;
    if (res != 0)
        return res;
    len = max(a->len, b->len);
    for(i = len - 1; i >= 0; i--) {
        v1 = get_limbz(a, a->len - len + i);
        v2 = get_limbz(b, b->len - len + i);
        if (v1 != v2) {
            if (v1 < v2)
                return -1;
            else
                return 1;
        }
    }
    return 0;
}

static void __bd_add(bd_t *r, const bd_t *a, const bd_t *b, limb_t prec)
{
    const bd_t *tmp;
    slimb_t d;
    limb_t carry, v1, v2, u, i, r_len;
    int is_sub;

    if (bd_cmpu(a, b) < 0) {
        tmp = a;
        a = b;
        b = tmp;
    }
    /* abs(a) >= abs(b) */
    if (b->len == 0) {
        bd_set(r, a);
    } else {
        r->sign = a->sign;
        r->exp = a->exp;
        d = a->exp - b->exp;
        is_sub = a->sign ^ b->sign;
        r_len = min(prec, max(a->len, b->len + d));
        bd_resize(r, r_len);
        carry = is_sub;
        for(i = 0; i < r_len; i++) {
            v1 = get_limbz(a, a->len - r_len + i);
            v2 = get_limbz(b, b->len - r_len + d + i);
            if (is_sub)
                v2 = BASE - 1 - v2;
            u = v1 + v2 + carry - BASE;
            carry = u <= v1;
            if (!carry)
                u += BASE;
            r->tab[i] = u;
        }
        /* carry is only possible in add case */
        if (!is_sub && carry) {
            bd_resize(r, r_len + 1);
            r->tab[prec] = 1;
            r->exp++;
        }
        bd_renorm(r, prec);
    }
}

#if LIMB_BITS == 64
/* WARNING: hardcoded for b = 1e19. It is assumed that:
   0 <= a1 < 2^63 */
#define divdq_base(q, r, a)                    \
do {\
    uint64_t __a0, __a1, __t0, __b = BASE;                 \
    uint128_t __a;                              \
    __a = a;                                      \
    __t0 = __a >> 63;\
    q = ((uint128_t)__t0 * UINT64_C(17014118346046923173)) >> 64;       \
    __a = __a - (uint128_t)q * __b - (uint128_t)__b * 2;                    \
    __a1 = __a >> 64;\
    __t0 = (int64_t)__a1 >> 1; \
    q += 2 + __t0;\
    __a += __b & __t0;\
    __a0 = __a;\
    __a1 = __a >> 64;\
    q += __a1;                  \
    __a0 += __b & __a1;           \
    r = __a0;\
} while(0)

#else

/* WARNING: hardcoded for b = 1e9. It is assumed that:
   0 <= a1 < 2^29 */
#define divdq_base(q, r, a)\
do {\
    uint32_t __t0, __t1, __b = BASE, a0 = a, a1 = (a) >> 32; \
    __t0 = a1;\
    __t1 = a0;\
    __t0 = (__t0 << 3) | (__t1 >> (32 - 3));    \
    q = ((uint64_t)__t0 * 2305843009U) >> 32;   \
    r = a0 - q * __b;\
    __t1 = (r >= __b);\
    q += __t1;\
    if (__t1)\
        r -= __b;\
} while(0)

#endif

static limb_t mp_add_mul1_dec(limb_t *tabr, const limb_t *taba, limb_t n,
                              limb_t b)
{
    limb_t i, l, q, r;
    dlimb_t t;
    
    l = 0;
    for(i = 0; i < n; i++) {
        t = (dlimb_t)taba[i] * (dlimb_t)b + l + tabr[i];
        divdq_base(q, r, t);
        tabr[i] = r;
        l = q;
    }
    return l;
}

static void __bd_mul(bd_t *r, const bd_t *a, const bd_t *b, limb_t prec)
{
    limb_t i;
    
    if (a->len < b->len) {
        const bd_t *tmp = a;
        a = b;
        b = tmp;
    }
    /* here b->len <= a->len */
    if (b->len == 0) {
        bd_set_si(r, 0);
    } else {
        if (b->len >= NTT_MUL_THRESHOLD) {
            ntt_mul(r, a->tab, a->len, b->tab, b->len);
        } else {
            bd_resize(r, a->len + b->len);
            memset(r->tab, 0, sizeof(limb_t) * a->len);
            
            for(i = 0; i < b->len; i++) {
                r->tab[i + a->len] = mp_add_mul1_dec(r->tab + i, a->tab, a->len,
                                                     b->tab[i]);
            }
        }
        r->sign = a->sign ^ b->sign;
        r->exp = a->exp + b->exp;
        bd_renorm(r, prec);
    }
}

/* NTT multiplication */

typedef limb_t NTTLimb;

#if LIMB_BITS == 64

/* we must have: modulo >= 1 << MUL_MOD_FAST_L */
#define MUL_MOD_FAST_L 62

#define NB_MODS 3
#define NTT_PROOT_2EXP 53
#define NTT_MAX_LOG2 188

static const limb_t ntt_mods[NB_MODS] = { 0x60a0000000000001, 0x68e0000000000001, 0x7720000000000001,
};

static const limb_t ntt_proot[2][NB_MODS] = {
    { 0x224a66bc6972d98a, 0x54243eb0e750fb29, 0x5d83c3f108c563c3, },
    { 0x06016593410095a3, 0x1ae79ade6c456e39, 0x2ba4ed5e61d70844, },
};

static const limb_t ntt_mods_cr[NB_MODS * (NB_MODS - 1) / 2] = {
 0x6749364d9364d944, 0x0747a4fa4fa4fa55,
 0x4a311f7047dc1200,
};

#else

/* we must have: modulo >= 1 << MUL_MOD_FAST_L */
#define MUL_MOD_FAST_L 29

#define NB_MODS 3
#define NTT_PROOT_2EXP 22
#define NTT_MAX_LOG2 89

static const limb_t ntt_mods[NB_MODS] = { 0x0000000028c00001, 0x0000000037c00001, 0x0000000045400001,
};

static const limb_t ntt_proot[2][NB_MODS] = {
    { 0x000000000e1f4c18, 0x000000000525cf27, 0x000000001ae9f800, },
    { 0x00000000081fa80a, 0x000000002e0a378e, 0x0000000033d2f3fa, },
};

static const limb_t ntt_mods_cr[NB_MODS * (NB_MODS - 1) / 2] = {
 0x000000002d87777c, 0x00000000423674c9,
 0x0000000027c12f6e,
};

#endif /* LIMB_BITS == 32 */

/* used for mul_mod_fast() */
static limb_t ntt_mods_div[NB_MODS];

/* ntt_proot^(2^n) */
static limb_t ntt_proot_pow[2][NB_MODS][NTT_PROOT_2EXP];

/* add modulo with up to LIMB_BITS bit modulo */
static inline limb_t add_mod(limb_t a, limb_t b, limb_t m)
{
    limb_t r;
    r = a + b - m;
    if (r > a)
        r += m;
    return r;
}

/* sub modulo with up to LIMB_BITS bit modulo */
static inline limb_t sub_mod(limb_t a, limb_t b, limb_t m)
{
    limb_t r;
    r = a - b;
    if (r > a)
        r += m;
    return r;
}

/* slow but generic version */
static inline limb_t mul_mod(limb_t a, limb_t b, limb_t m)
{
    dlimb_t t;
    t = (dlimb_t)a * (dlimb_t)b;
    return t % m;
}

#ifdef USE_MUL_MOD_FAST

/* return (r0+r1*2^LIMB_BITS) mod m */
static inline limb_t mod_fast(dlimb_t r, limb_t m, limb_t m_inv)
{
    limb_t a1, q, t0, r1, r0;
    
    a1 = r >> MUL_MOD_FAST_L;
    
    q = ((dlimb_t)a1 * m_inv) >> LIMB_BITS;
    r = r - (dlimb_t)q * m - m * 2;
    r1 = r >> LIMB_BITS;
    t0 = (slimb_t)r1 >> 1;
    r += m & t0;
    r0 = r;
    r1 = r >> LIMB_BITS;
    r0 += m & r1;
    return r0;
}

/* faster version using precomputed modulo inverse. 
 precondition: 0 <= a * b < 2^(LIMB_BITS+MUL_MOD_FAST_L) */
static inline limb_t mul_mod_fast(limb_t a, limb_t b, 
                                  limb_t m, limb_t m_inv)
{
    dlimb_t r;
    r = (dlimb_t)a * (dlimb_t)b;
    return mod_fast(r, m, m_inv);
}

static inline limb_t init_mul_mod_fast(limb_t m)
{
    dlimb_t t;
    assert(m >= (limb_t)1 << MUL_MOD_FAST_L);
    t = (dlimb_t)1 << (LIMB_BITS + MUL_MOD_FAST_L);
    return t / m;
}

#else

static inline limb_t mod_fast(dlimb_t r, 
                                limb_t m, limb_t m_inv)
{
    return r % m;
}

#define mul_mod_fast(a, b, m, m_inv) mul_mod(a, b, m)

#endif

static void *ntt_malloc(size_t size)
{
    return malloc(size);
}

static void ntt_fft(NTTLimb *out_buf, NTTLimb *in_buf, int fft_len_log2,
                    limb_t p_root, limb_t m, limb_t m_inv)
{
    limb_t nb_blocks, fft_per_block, p, k, n, stride_in, i, j;
    NTTLimb *tab_in, *tab_out, *tmp, a0, a1, b0, b1, c, c_mul;
    
    n = (limb_t)1 << fft_len_log2;
    c_mul = p_root;
    nb_blocks = n;
    fft_per_block = 1;
    stride_in = n / 2;
    tab_in = in_buf;
    tab_out = out_buf;
    while (nb_blocks != 1) {
        nb_blocks >>= 1;
        /* the last pass can use the same input & output buffer */
        if (nb_blocks == 1)
            tab_out = out_buf; 
        p = 0;
        k = 0;
        c = 1;
        for(i = 0; i < nb_blocks; i++) {
            for(j = 0; j < fft_per_block; j++) {
                a0 = tab_in[k + j];
                a1 = tab_in[k + j + stride_in];
                b0 = add_mod(a0, a1, m);
                b1 = sub_mod(a0, a1, m);
                b1 = mul_mod_fast(b1, c, m, m_inv);
                tab_out[p + j] = b0;
                tab_out[p + j + fft_per_block] = b1;
            }
            c = mul_mod_fast(c, c_mul, m, m_inv);
            k += fft_per_block;
            p += 2 * fft_per_block;
        }
        c_mul = mul_mod_fast(c_mul, c_mul, m, m_inv);
        fft_per_block <<= 1;
        tmp = tab_in;
        tab_in = tab_out;
        tab_out = tmp;
    }
}

static void ntt_vec_mul(NTTLimb *tab1, NTTLimb *tab2, int fft_len_log2,
                        int k_tot, limb_t m, limb_t m_inv)
{
    limb_t i, c_inv, c_inv2, a, n;
    int j;
    
    /* compute 1/fft_len modulo m */
    /* could precompute but not really worth the effort */
    c_inv2 = (m + 1) / 2; /* 1/2 */
    c_inv = 1;
    for(j = 0; j < k_tot; j++)
        c_inv = mul_mod_fast(c_inv, c_inv2, m, m_inv);

    n = (limb_t)1 << fft_len_log2;
    for(i = 0; i < n; i++) {
        a = mul_mod_fast(tab1[i], tab2[i], m, m_inv);
        a = mul_mod_fast(a, c_inv, m, m_inv);
        tab1[i] = a;
    }
}

/* dst = buf1, src = buf2, tmp = buf3 */
static void ntt_conv(NTTLimb *buf1, NTTLimb *buf2, NTTLimb *buf3,
                     int k, limb_t m_idx)
{
    limb_t m, m_inv;
    
    m = ntt_mods[m_idx];
    m_inv = ntt_mods_div[m_idx];

    ntt_fft(buf3, buf1, k,
            ntt_proot_pow[0][m_idx][NTT_PROOT_2EXP - k], m, m_inv);
    ntt_fft(buf1, buf2, k,
            ntt_proot_pow[0][m_idx][NTT_PROOT_2EXP - k], m, m_inv);
    ntt_vec_mul(buf3, buf1, k, k, m, m_inv);
    ntt_fft(buf1, buf3, k,
            ntt_proot_pow[1][m_idx][NTT_PROOT_2EXP - k], m, m_inv);
}

static void limb_to_ntt(NTTLimb *tabr, limb_t fft_len,
                        const limb_t *taba, limb_t a_len, int m_idx)
{
    slimb_t i;
    for(i = 0; i < a_len; i++) {
        tabr[i] = mod_fast(taba[i], ntt_mods[m_idx],
                           ntt_mods_div[m_idx]);
    }
    memset(tabr + a_len, 0, sizeof(tabr[0]) * (fft_len - a_len));
}

static no_inline void ntt_to_limb(limb_t *tabr, slimb_t r_len,
                                  const NTTLimb *buf, int fft_len_log2)
{
    limb_t y[NB_MODS], u[NB_MODS], carry[NB_MODS], c, fft_len;
    slimb_t i;
    int j, k, l;

    for(j = 0; j < NB_MODS; j++) 
        carry[j] = 0; /* the last element is always zero */
    fft_len = (limb_t)1 << fft_len_log2;
    for(i = 0;i < r_len; i++) {
        for(j = 0; j < NB_MODS; j++)  {
            y[j] = buf[i + fft_len * j];
        }

        /* Chinese remainder to get mixed radix representation */
        l = 0;
        for(j = 0; j < NB_MODS - 1; j++) {
            for(k = j + 1; k < NB_MODS; k++) {
                limb_t m;
                m = ntt_mods[k];
                /* Note: there is no overflow in the sub_mod() because
                   the modulos are sorted by increasing order */
                y[k] = mul_mod_fast(sub_mod(y[k], y[j], m), 
                                    ntt_mods_cr[l], m, ntt_mods_div[k]);
                l++;
            }
        }
        
        /* back to normal representation */
        u[0] = y[NB_MODS - 1];
        l = 1;
        for(j = NB_MODS - 2; j >= 0; j--) {
            limb_t r, r1;
            dlimb_t t;
            r = y[j];
            for(k = 0; k < l; k++) {
                t = (dlimb_t)u[k] * ntt_mods[j] + r;
                divdq_base(r, r1, t);
                u[k] = r1;
            }
            u[l] = r;
            l++;
        }
        
#if 0
        printf("%" PRId64 ": ", i);
        for(j = NB_MODS - 1; j >= 0; j--) {
            printf(" %019" PRIu64, u[j]);
        }
        printf("\n");
#endif
        
        /* add the carry */
        c = 0;
        for(j = 0; j < NB_MODS; j++) {
            limb_t v1, v;
            v1 = u[j];
            v = v1 + carry[j] + c - BASE;
            c = (v <= v1);
            if (!c)
                v += BASE;
            u[j] = v;
        }
        tabr[i] = u[0];
        /* shift by dpl digits and set the carry */
        for(j = 0; j < NB_MODS - 1; j++)
            carry[j] = u[j + 1];
    }
}

static void bd_static_init(void)
{
    int inverse, i, j;
    limb_t c;
    
#ifdef USE_MUL_MOD_FAST
    for(i = 0; i < NB_MODS; i++)
        ntt_mods_div[i] = init_mul_mod_fast(ntt_mods[i]);
#endif
    for(inverse = 0; inverse < 2; inverse++) {
        for(j = 0; j < NB_MODS; j++) {
            c = ntt_proot[inverse][j];
            for(i = 0; i < NTT_PROOT_2EXP; i++) {
                ntt_proot_pow[inverse][j][i] = c;
                c = mul_mod_fast(c, c, ntt_mods[j], ntt_mods_div[j]);
            }
        }
    }
}

static void ntt_mul(bd_t *r, const limb_t *taba, limb_t a_len,
                    const limb_t *tabb, limb_t b_len)
{
    int dpl, fft_len_log2, j;
    slimb_t len, fft_len;
    NTTLimb *buf1, *buf2, *buf3;

    len = a_len + b_len;
    dpl = BASE_EXP;
    fft_len_log2 = ceil_log2((len * BASE_EXP + dpl - 1) / dpl);
    assert(fft_len_log2 <= NTT_PROOT_2EXP);
    
    fft_len = (limb_t)1 << fft_len_log2;
    //    printf("len=%" PRId64 " fft_len_log2=%d\n", (int64_t)len, fft_len_log2);

    buf1 = ntt_malloc(sizeof(NTTLimb) * fft_len * NB_MODS);
    buf2 = ntt_malloc(sizeof(NTTLimb) * fft_len);
    buf3 = ntt_malloc(sizeof(NTTLimb) * fft_len);
    for(j = 0; j < NB_MODS; j++) {
        limb_to_ntt(buf1 + fft_len * j, fft_len, taba, a_len, j);
        limb_to_ntt(buf2, fft_len, tabb, b_len, j);
        ntt_conv(buf1 + fft_len * j, buf2, buf3,
                 fft_len_log2, j);
    }
    free(buf2);
    free(buf3);
    bd_resize(r, len); /* done here to reduce peak memory usage */
    ntt_to_limb(r->tab, len, buf1, fft_len_log2);
    free(buf1);
#if 0
    { 
        int i;
        printf("tabr:\n");
        for(i = 0; i < len; i++) {
            printf("%d: %019" PRIu64 "\n", i, tabr[i]);
        }
    }
#endif
}

static void __bd_recip(bd_t *a, const bd_t *x, limb_t prec1, int step0)
{
    bd_t c1, t0;
    limb_t prec;

    if (prec1 <= 2) {
        if (step0 == 0) {
            limb_t b1, h;
            /* initial approximation: use division by single limb */
            assert(x->len >= 1);
            b1 = x->tab[x->len - 1];
            bd_resize(a, 3);
            a->tab[2] = (b1 == 1 ? 1 : 0);
            h = BASE;
            a->tab[1] = h / b1;
            h = h % b1;
            a->tab[0] = ((dlimb_t)h * BASE) / b1;
            a->sign = x->sign;
            a->exp = 2 - x->exp;
            bd_renorm(a, 2);
        } else {
            step0--;
            goto next;
        }
    } else {
    next:
        __bd_recip(a, x, (prec1 / 2) + 1, step0);

        prec = prec1 + 2;

        /* a = a + a * (1 - x * a) */
        bd_init(&c1);
        bd_init(&t0);
        bd_mul(&t0, x, a, prec);
        t0.sign ^= 1;
        bd_set_si(&c1, 1);
        bd_add(&t0, &c1, &t0, prec);
        bd_mul(&t0, &t0, a, prec);
        bd_add(a, a, &t0, prec1);
        bd_delete(&c1);
        bd_delete(&t0);
    }
}

/* a = 1/x with precision prec1 */
static void bd_recip(bd_t *a, const bd_t *x, limb_t prec1)
{
    return __bd_recip(a, x, prec1, 4);
}

static void __bd_rsqrt(bd_t *a, const bd_t *x, limb_t prec1, int step0)
{
    bd_t c1, t0;
    limb_t prec;

    if (prec1 <= 2) {
        if (step0 == 0) {
            dlimb_t v;
            slimb_t e;
            int k;
            /* initial approximation using MSB position */
            e = x->exp - 1;
            v = x->tab[x->len - 1];
            if (e & 1) {
                e--;
                v *= BASE;
            }
            k = 0;
            while (v != 0) {
                k++;
                v >>= 1;
            }
            bd_set_si(a, BASE >> (k / 2));
            a->exp = -(e / 2);
        } else {
            step0--;
            goto next;
        }
    } else {
    next:
        __bd_rsqrt(a, x, (prec1 / 2) + 1, step0);

        prec = prec1 + 2;

        /* a = a + 0.5 * a * (1 - x * a * a) */
        bd_init(&c1);
        bd_init(&t0);
        bd_set_si(&c1, 1);

        bd_mul(&t0, x, a, prec);
        bd_mul(&t0, &t0, a, prec);
        t0.sign ^= 1;
        bd_add(&t0, &c1, &t0, prec);
        bd_mul(&t0, &t0, a, prec);
        bd_mul_si(&t0, &t0, BASE / 2, prec);
        t0.exp--;
        bd_add(a, a, &t0, prec1);

        bd_delete(&c1);
        bd_delete(&t0);
    }
}

/* a = 1/sqrt(x) with precision prec1 */
static void bd_rsqrt(bd_t *a, const bd_t *x, limb_t prec1)
{
    return __bd_rsqrt(a, x, prec1, 7);
}

static no_inline void bd_op2(bd_t *r, const bd_t *a, const bd_t *b, limb_t prec,
                             bd_op2_func_t *func)
{
    bd_t tmp;
    if (r == a || r == b) {
        bd_init(&tmp);
        func(&tmp, a, b, prec);
        bd_set(r, &tmp);
        bd_delete(&tmp);
    } else {
        func(r, a, b, prec);
    }
}

static void bd_mul(bd_t *r, const bd_t *a, const bd_t *b, limb_t prec)
{
    bd_op2(r, a, b, prec, __bd_mul);
}

static void bd_add(bd_t *r, const bd_t *a, const bd_t *b, limb_t prec)
{
    bd_op2(r, a, b, prec, __bd_add);
}

static void bd_mul_si(bd_t *r, const bd_t *a, int64_t b1, limb_t prec)
{
    bd_t b;
    bd_init(&b);
    bd_set_si(&b, b1);
    bd_mul(r, a, &b, prec);
    bd_delete(&b);
}

/*****************************************************************/


#define CHUD_A 13591409
#define CHUD_B 545140134
#define CHUD_C 640320
/* log10(C/12)*3 */
#define CHUD_DIGITS_PER_TERM 14.18164746272547765551
/* floor(CHUD_DIGITS_PER_TERM * 256) */
#define CHUD_DIGITS_PER_TERM_FIXED8 (int)(CHUD_DIGITS_PER_TERM * 256)

static void chud_bs(bd_t *P, bd_t *Q, bd_t *G, int64_t a, int64_t b, int need_g,
                    limb_t prec)
{
    bd_t T0, T1;
    int64_t c;

    if (a == (b - 1)) {
        
        bd_init(&T0);
        bd_init(&T1);
        bd_set_si(G, 2 * b - 1);
        bd_mul_si(G, G, 6 * b - 1, prec);
        bd_mul_si(G, G, 6 * b - 5, prec);
        bd_set_si(&T0, CHUD_B);
        bd_mul_si(&T0, &T0, b, prec);
        bd_set_si(&T1, CHUD_A);
        bd_add(&T0, &T0, &T1, prec);
        bd_mul(P, G, &T0, prec);
        P->sign = b & 1;

        bd_set_si(Q, b);
        bd_mul_si(Q, Q, b, prec);
        bd_mul_si(Q, Q, b, prec);
        bd_mul_si(Q, Q, (uint64_t)CHUD_C * CHUD_C * CHUD_C / 24, prec);
        bd_delete(&T0);
        bd_delete(&T1);
    } else {
        bd_t P2, Q2, G2;

        bd_init(&P2);
        bd_init(&Q2);
        bd_init(&G2);

        c = (a + b) / 2;
        chud_bs(P, Q, G, a, c, 1, prec);
        chud_bs(&P2, &Q2, &G2, c, b, need_g, prec);
        
        /* Q = Q1 * Q2 */
        /* G = G1 * G2 */
        /* P = P1 * Q2 + P2 * G1 */
        bd_mul(&P2, &P2, G, prec);
        if (!need_g)
            bd_set_si(G, 0); /* just to save memory */
        bd_mul(P, P, &Q2, prec);
        bd_add(P, P, &P2, prec);
        bd_delete(&P2);

        bd_mul(Q, Q, &Q2, prec);
        bd_delete(&Q2);
        if (need_g)
            bd_mul(G, G, &G2, prec);
        bd_delete(&G2);
#if 0
        printf("%d: digits: P=%" PRId64 " Q=%" PRId64 " G=%" PRId64 "\n",
               s->level, 
               P->len * BASE_EXP, Q->len * BASE_EXP, G->len * BASE_EXP);
#endif
    }
}

static void pi_chud(bd_t *Q, int64_t prec)
{
    int64_t n, prec1;
    bd_t P_s, *P = &P_s, G_s, *G = &G_s;

    n = (prec * BASE_EXP * 256 / CHUD_DIGITS_PER_TERM_FIXED8) + 10;
    prec1 = prec + 2;

    bd_init(P);
    bd_init(G);

    //    printf("chud_bs\n");
    chud_bs(P, Q, G, 0, n, 0, prec1);
    
    bd_mul_si(G, Q, CHUD_A, prec1);
    bd_add(P, G, P, prec1);
    
    //    printf("div\n");
    bd_recip(G, P, prec1 + 1);
    bd_set_si(P, CHUD_C / 64); /* save some memory by initializing P here */
    bd_mul(Q, Q, G, prec1);
 
    //    printf("rsqrt\n");
    bd_rsqrt(G, P, prec1);
    bd_mul_si(G, G, (uint64_t)CHUD_C * CHUD_C / (8 * 12), prec1);

    //    printf("final mul\n");
    bd_mul(Q, Q, G, prec);

    bd_delete(P);
    bd_delete(G);
}

static void dump_digits(const bd_t *a, int64_t n_digits)
{
    int i, j, k, k0;
    limb_t pos, lpos;
    char line[100];

    printf("%10s " FMT_LIMB1 ".\n", "POSITION", get_limbz(a, a->len - a->exp));
    for(j = 0; j < 2; j++) {
        for(i = 0; i < 2; i++) {
            pos = i * 50;
            if (j)
                pos += n_digits - 100;
            printf("%10" PRIu64, (uint64_t)(pos + 1));
            lpos = a->len - a->exp - 1 - pos / BASE_EXP;
            for(k = 0; k < (50 + 2 * BASE_EXP - 2) / BASE_EXP; k++) {
                sprintf(line + k * BASE_EXP, FMT_LIMB,
                        get_limbz(a, lpos - k));
            }
            k0 = pos % BASE_EXP;
            for(k = 0; k < 50; k += 10) {
                putchar(' ');
                fwrite(line + k + k0, 1, 10, stdout);
            }
            printf("\n");
        }
        if (n_digits <= 100)
            break;
        if (j == 0)
            printf("%10s\n", "...");
    }
}

int main(int argc, char **argv)
{
    int64_t n_digits, prec;
    bd_t PI;
    const char *output_filename;
    FILE *f;

    if (argc < 2) {
        printf("usage: tinypi n_digits [output_file]\n");
        exit(1);
    }

    n_digits = (int64_t)strtod(argv[1], NULL);
    output_filename = argv[2];
    
    n_digits = (max(n_digits, 100) / 50) * 50;
    /* one more limb is needed for the integer part */
    prec = (n_digits + 2 * BASE_EXP - 1) / BASE_EXP;
    
    bd_static_init();

    bd_init(&PI);

    pi_chud(&PI, prec);

    if (output_filename) {
        f = fopen(output_filename, "wb");
        if (!f) {
            perror(output_filename);
            exit(1);
        }
        bd_print(f, &PI, n_digits);
        fclose(f);
    } else {
        dump_digits(&PI, n_digits);
    }
    
    bd_delete(&PI);

    return 0;
}
