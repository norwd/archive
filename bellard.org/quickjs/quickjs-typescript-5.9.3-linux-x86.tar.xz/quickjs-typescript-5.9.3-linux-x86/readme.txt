Example of compilation of Typescript (https://www.typescriptlang.org/)
to a Linux binary with QuickJS.

Use the typescript executable from './lib/tsc'.

It can be rebuild with the following steps in src/ :

1) Dowload typescript:

   curl -OL https://globalcdn.nuget.org/packages/microsoft.typescript.msbuild.5.9.3.nupkg
   unzip microsoft.typescript.msbuild.5.9.3.nupkg -d tsc
   cp -r tsc/tools/tsc ../lib
   cp tsc/tools/tsc/_tsc.js tsc.js

2) patch it:

   patch -p0 < tsc-5.9.3..patch

3) Compile to binary using build.sh

4) Test it:

   ../lib/tsc declarationsSimple.ts

