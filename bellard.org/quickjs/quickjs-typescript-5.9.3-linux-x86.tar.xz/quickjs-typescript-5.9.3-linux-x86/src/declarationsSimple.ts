// @declaration: true
export const c: number = 1;

export interface A {
    x: number;
}

let expr: { x: number; };

expr = {
    x: 12,
}

export default expr;