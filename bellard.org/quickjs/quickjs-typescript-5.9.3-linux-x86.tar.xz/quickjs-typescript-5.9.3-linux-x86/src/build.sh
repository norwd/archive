#!/bin/sh

~/quickjs/qjsc -S 2097152 -o ../lib/tsc tsc.js
strip ../lib/tsc
