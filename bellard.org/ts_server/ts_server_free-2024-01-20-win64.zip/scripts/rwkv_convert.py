import sys
import torch
import torch.nn.functional as F
import numpy as np
import struct
import math
import io
import json
import argparse
from convert_utils import *

def write_libnc_param_header(f, json_config):
    config = json.dumps(json_config)
    str = config.encode('utf-8')
    f.write(struct.pack("ii", 0x23f4aefb, len(str)))
    f.write(str)
    
def write_libnc_param(f, array, param_name):
    dtype = array.dtype
    print("{:30} {:20} {:10}".format(param_name, str(array.shape), str(dtype)))
    if dtype == torch.float32:
        type_id = 0
    elif dtype == torch.float16:
        type_id = 2
    elif dtype == torch.bfloat16:
        type_id = 1
    else:
        print("unsupported type: " + str(dtype))
        assert(0)

    n_dims = len(array.shape);

    # variable header
    name = param_name.encode('utf-8')
    f.write(struct.pack("iiii", 0x23f4aefa, type_id, n_dims, len(name)))
    for i in range(n_dims):
        f.write(struct.pack("i", array.shape[n_dims - 1 - i]))
    f.write(name);
    # variable data
    if dtype == torch.bfloat16:
        # numpy does not support bfloat16 yet
        v = array.view(torch.int16)
    else:
        v = array
    v.numpy().tofile(f)

param_name_table = { "emb.weight": "wte",
             "blocks.0.ln0.weight": "ln_emb/g", 
             "blocks.0.ln0.bias": "ln_emb/b",
             "ln_out.weight": "ln_f/g",
             "ln_out.bias": "ln_f/b",
             "head.weight": "proj_f/w",
}

def convert_params(model_path, out_filename, n_ctx):

    m = torch.load(model_path, map_location = "cpu")

    d_model = m["emb.weight"].shape[1]
    n_layer = 1
    while "blocks.{:d}.ln1.weight".format(n_layer) in m:
        n_layer += 1
    fp_type = "bf16"

    f = open(out_filename, "wb")

    write_libnc_param_header(f, {"type": "rwkv", "n_layer": n_layer, "d_model": d_model, "n_ctx": n_ctx, "data_type": fp_type });

    for w_name, w in m.items():
        w = torch.squeeze(w)
        if w_name in param_name_table:
            w_name = param_name_table[w_name]
        if len(w.shape) == 2 and w_name != "wte":
            w = torch.transpose(w, 0, 1)
        write_libnc_param(f, w, w_name)
    
    f.close()

parser = argparse.ArgumentParser(description='RWKV to LibNC parameter conversion tool')
parser.add_argument('--n_ctx', type=int, default = 1024)
parser.add_argument('model_filename', type=str)
parser.add_argument('output_filename', type=str)

args = parser.parse_args()

convert_params(args.model_filename, args.output_filename, args.n_ctx)
