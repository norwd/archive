# TextSynth speech to text transcription example
import sys
import argparse
import time
import json
import requests

parser = argparse.ArgumentParser(description='TextSynth transcription example')
parser.add_argument('--url', type=str,
                    help='service URL', default='http://localhost:8080')
parser.add_argument('--model', type=str,
                    help='model', default='whisper_large_v3')
parser.add_argument('--language', type=str, default = "en")
parser.add_argument('--api_key', type=str, default = "")
parser.add_argument('audio_file', type=str, default = "")

args = parser.parse_args()

def main():
    # audio input file
    f = open(args.audio_file, "rb")
    # JSON parameters
    params = { "language": args.language }
    files = { "json": ("json_file", json.dumps(params), "application/json"),
              "file": ("audio_file", f, "application/octet-stream"),  }
    response = requests.post(args.url + "/v1/engines/" + args.model + "/transcript", headers = { "Authorization": "Bearer " + args.api_key }, files = files)
    print("response", response.text)

main()
