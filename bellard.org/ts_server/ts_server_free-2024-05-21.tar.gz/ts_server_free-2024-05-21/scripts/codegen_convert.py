import sys
import torch
import numpy as np
import struct
import math
import json

def get_embedding(num_embeddings, embedding_dim, padding_idx = None):
    """Build sinusoidal embeddings.
    
    This matches the implementation in tensor2tensor, but differs slightly
    from the description in Section 3.5 of "Attention Is All You Need".
    """
    half_dim = embedding_dim // 2
    emb = math.log(10000) / (half_dim - 1)
    emb = torch.exp(torch.arange(half_dim, dtype=torch.float) * -emb)
    emb = torch.arange(num_embeddings, dtype=torch.float).unsqueeze(
        1
    ) * emb.unsqueeze(0)
    emb = torch.cat([torch.sin(emb), torch.cos(emb)], dim=1).view(
        num_embeddings, -1
    )
    if embedding_dim % 2 == 1:
        # zero pad
        emb = torch.cat([emb, torch.zeros(num_embeddings, 1)], dim=1)
    if padding_idx is not None:
        emb[padding_idx, :] = 0
    return emb

def write_libnc_param_header(f, json_config):
    config = json.dumps(json_config)
    str = config.encode('utf-8')
    f.write(struct.pack("ii", 0x23f4aefb, len(str)))
    f.write(str)
    
def write_libnc_param(f, array, param_name):
    print("{:30} {:20} {:10}".format(param_name, str(array.shape), str(array.dtype)))
    dtype_str = str(array.dtype)
    if dtype_str == "float32":
        type_id = 0
    elif dtype_str == "float16":
        type_id = 2
    else:
        print("unsupported type: " + dtype_str)
        assert(0)

    array = array.squeeze()
    n_dims = len(array.shape);

    # variable header
    name = param_name.encode('utf-8')
    f.write(struct.pack("iiii", 0x23f4aefa, type_id, n_dims, len(name)))
    for i in range(n_dims):
        f.write(struct.pack("i", array.shape[n_dims - 1 - i]))
    f.write(name);
    # variable data
    array.tofile(f)

def get_param(model, name):
    return model[name].numpy()
    
def convert_params(in_filename, out_filename):
    model = torch.load(in_filename, map_location=torch.device('cpu'))
    
    f = open(out_filename, "wb")

    n_layer = 1
    while "transformer.h." + str(n_layer) + ".attn.qkv_proj.weight" in model:
        n_layer += 1

    d_model = model["transformer.wte.weight"].shape[1]
    
    write_libnc_param_header(f, {"type": "codegen", "data_type": "f16", "n_layer": n_layer, "d_model": d_model });

    print("{:30} {:20} {:10}".format("NAME", "SHAPE", "TYPE"))

    w = get_param(model, "transformer.wte.weight")
    write_libnc_param(f, w, "wte")

    # permutation for each TPU and Q V K order
    base_permutation = [0, 3, 6, 9, 2, 5, 8, 11, 1, 4, 7, 10]
    local_dim = d_model // 4
    permutation = torch.cat([torch.arange(i*local_dim, (i+1)*local_dim) for i in base_permutation])
    
    for layer_num in range(n_layer):
        prefix = "transformer.h." + str(layer_num) + "."
        out_prefix = "h" + str(layer_num) + "/"
        
        w = get_param(model, prefix + "attn.qkv_proj.weight")
        w = w[permutation,:]
        w = np.transpose(w)
        write_libnc_param(f, w, out_prefix + "attn/c_attn/w")

        write_libnc_param(f, get_param(model, prefix + "ln_1.weight"), out_prefix + "ln_1/g")
        write_libnc_param(f, get_param(model, prefix + "ln_1.bias"), out_prefix + "ln_1/b")
        w = get_param(model, prefix + "attn.out_proj.weight")
        w = np.transpose(w)
        write_libnc_param(f, w, out_prefix + "attn/c_proj/w")

        w = get_param(model, prefix + "mlp.fc_in.weight")
        w = np.transpose(w)
        write_libnc_param(f, w, out_prefix + "mlp/c_fc/w")
        write_libnc_param(f, get_param(model, prefix + "mlp.fc_in.bias"), out_prefix + "mlp/c_fc/b")
        w = get_param(model, prefix + "mlp.fc_out.weight")
        w = np.transpose(w)
        write_libnc_param(f, w, out_prefix + "mlp/c_proj/w")
        write_libnc_param(f, get_param(model, prefix + "mlp.fc_out.bias"), out_prefix + "mlp/c_proj/b")
        
    write_libnc_param(f, get_param(model, "transformer.ln_f.weight"), "ln_f/g")
    write_libnc_param(f, get_param(model, "transformer.ln_f.bias"), "ln_f/b")
    
    w = get_param(model, "lm_head.weight")
    w = np.transpose(w)
    write_libnc_param(f, w, "proj_f/w")
    write_libnc_param(f, get_param(model, "lm_head.bias"), "proj_f/b")
    
    f.close()

if len(sys.argv) != 3:
    print("""usage: convert.py model_file output_file

Convert a Codegen parameter dump to a LibNC one.

model_file is the filename containing the PyTorch parameter dump
output_file is filename of the libNC parameter dump""")
    sys.exit(1)

convert_params(sys.argv[1], sys.argv[2])
