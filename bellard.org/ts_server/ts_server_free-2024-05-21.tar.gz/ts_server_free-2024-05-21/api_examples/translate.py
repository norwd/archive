# TextSynth translation example
import sys
import argparse
import requests
import json
import time

parser = argparse.ArgumentParser(description='TextSynth translation example')
parser.add_argument('--url', type=str, default = "http://localhost:8080", help="server URL")
parser.add_argument('--api_key', type=str, default = "")
parser.add_argument('--model', type=str, default = "m2m100_1_2B", help = "model name")
parser.add_argument('--source_lang', type=str, default = "en", help="source ISO language code")
parser.add_argument('--target_lang', type=str, default = "fr", help="target ISO language code")
parser.add_argument('input_text', type=str, help="input text")

args = parser.parse_args()

def make_request(path, json):
    response = requests.post(args.url + path, headers = { "Authorization": "Bearer " + args.api_key }, json = json)
    return response

def main():
    req = { "text": [ args.input_text ], "source_lang": args.source_lang, "target_lang": args.target_lang }
    
    result = make_request("/v1/engines/" + args.model + "/translate", req);
    if result.status_code != 200:
        print("Request error:", result.text)
        sys.exit(1)

    resp = result.json()
    # only a single translation here
    translation = resp["translations"][0]
    print(translation["text"]);
    
main()
