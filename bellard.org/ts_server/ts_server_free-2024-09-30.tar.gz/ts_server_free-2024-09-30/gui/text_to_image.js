/* Copyright (c) 2019 Fabrice Bellard */
"use strict";
var output_text_active = false;
var cancel_request = false;
var raw_output_text = "";
var output_text = "";
var input_text = "";
var model_params = "";
var http_api_url = "http://localhost:8080";
var req;

var button_el = document.getElementById("generate_button");

function reset_params()
{
    var el;
    
    el = document.getElementById("image_count");
    el.value = "1";

    el = document.getElementById("image_size");
    el.value = "512x512";

    el = document.getElementById("timesteps");
    el.value = "50";

    el = document.getElementById("guidance_scale");
    el.value = "7.5";
}

var example_inputs = [
    "An astronaut riding a horse",
    "Robots celebrating a birthday party",
    "Flying dragon breathing fire",
    "Butterfly with pretty flowers like stained glass",
    "Unicorn galloping with rainbows",
    "Animal in the style of Claude Monet",
    "Animal in the style of Leonardo da Vinci",
    "Classic apartment building on a busy street",
];

function on_select()
{
    var select_el = document.getElementById("examples");
    var input_text_el = document.getElementById("input_text");
    var val = select_el.value | 0;
    var r;
    if (val) {
        input_text_el.value = example_inputs[val - 1];
    }
}

function text_to_image_init()
{
    var el, option, sel, i;

    reset_params();

    el = document.getElementById("input_text");
    el.value = "";

    sel = document.getElementById("examples");
    sel.value = "0";
    for(i = 0; i < example_inputs.length; i++) {
        option = document.createElement("option");
        option.value = (i + 1).toString();
        option.text = example_inputs[i];
        sel.add(option, null);
    }

    update_models("text_to_image");
}

function button_submit()
{
    var input_text_el = document.getElementById("input_text");

    if (output_text_active) {
        cancel_request = true;
        req.abort();
    } else {
        text_to_image_start(input_text_el.value);
    }
}

function set_param_error(e)
{
    var el;
    el = document.getElementById("param_error");
    if (e === "") {
        el.innerHTML = '';
    } else {
        el.innerHTML = '<div class="alert alert-danger">' + e + '</div>';
    }
}

function show_warning(e)
{
    var el;
    el = document.getElementById("param_error");
    el.innerHTML = '<div class="alert alert-warning">' + e + '</div>';
}

function text_to_image_start(input_text)
{
    var req_data, guidance_scale, timesteps, image_count, image_size, model;
    
    if (input_text != "") {

        set_param_error("");

        model = document.getElementById("model").value;
        guidance_scale = +document.getElementById("guidance_scale").value;
        timesteps = document.getElementById("timesteps").value | 0;
        image_count = document.getElementById("image_count").value | 0;
        image_size = document.getElementById("image_size").value.split("x");
        
        req_data = { "prompt": input_text, "timesteps": timesteps, "guidance_scale": guidance_scale, "image_count": image_count, "width": image_size[0] | 0, "height": image_size[1] | 0 };

        req = new XMLHttpRequest();
        req.onreadystatechange = req_on_ready_state_change;
        req.open("POST", http_api_url + "/v1/engines/" + model + "/text_to_image");
        req.setRequestHeader('Content-Type', 'application/json');
        req.send(JSON.stringify(req_data));
        
        button_el.innerHTML = "Stop";
        
        output_text_active = true;
        cancel_request = false;
    }
}

function req_on_ready_state_change(ev)
{
    var tab, i, resp, msg;

    if (req.readyState == 4 && req.status == 200) {
        resp = JSON.parse(req.responseText);
        handle_response(resp);
        text_to_image_end();
    } else if (req.readyState == 4 && !cancel_request) {
        try {
            resp = JSON.parse(req.responseText);
            msg = resp.error;
        } catch(err) {
            msg = "Server error";
        }
        set_param_error(msg);
        text_to_image_end();
    }
}

function handle_response(resp)
{
    var image_count, i, images, base64_data, img_el, img;

    if (resp.error) {
        set_param_error(resp.error);
        return;
    }
    images = resp.images;
    for(i = 0; i < 4; i++) {
        img_el = document.getElementById("img" + i);
        while (img_el.firstChild) {
            img_el.removeChild(img_el.firstChild);
        }

        if (i < images.length) {
            base64_data = images[i].data;
            img = document.createElement("img");
            img.src = "data:image/jpeg;base64," + base64_data;
            img_el.appendChild(img);
        }
    }
}

function text_to_image_end()
{
    button_el.innerHTML = "Generate";
    output_text_active = false;
}
