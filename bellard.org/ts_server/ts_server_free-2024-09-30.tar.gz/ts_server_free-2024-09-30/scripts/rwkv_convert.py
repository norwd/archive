import sys
import torch
import torch.nn.functional as F
import numpy as np
import struct
import math
import io
import json
import argparse
from convert_utils import *

param_name_table = { "emb.weight": "wte",
             "blocks.0.ln0.weight": "ln_emb/g", 
             "blocks.0.ln0.bias": "ln_emb/b",
             "ln_out.weight": "ln_f/g",
             "ln_out.bias": "ln_f/b",
             "head.weight": "proj_f/w",
}

def convert_params(model_path, out_filename, n_ctx, tokenizer_filename):

    m = torch.load(model_path, map_location = "cpu")

    d_model = m["emb.weight"].shape[1]
    n_layer = 1
    while "blocks.{:d}.ln1.weight".format(n_layer) in m:
        n_layer += 1
    fp_type = "bf16"

    f = open(out_filename, "wb")

    write_libnc_param_header(f, {"type": "rwkv", "n_layer": n_layer, "d_model": d_model, "n_ctx": n_ctx, "data_type": fp_type });

    if tokenizer_filename != "":
        write_libnc_tokenizer(f, tokenizer_filename, "tokenizer")
    
    for w_name, w in m.items():
        w = torch.squeeze(w)
        if w_name in param_name_table:
            w_name = param_name_table[w_name]
        if len(w.shape) == 2 and w_name != "wte":
            w = torch.transpose(w, 0, 1)
        write_libnc_param_pt(f, w, w_name)
    
    f.close()

parser = argparse.ArgumentParser(description='RWKV to LibNC parameter conversion tool')
parser.add_argument('--n_ctx', type=int, default = 1024)
parser.add_argument('model_filename', type=str)
parser.add_argument('output_filename', type=str)
parser.add_argument('--tokenizer', type=str, default = "", help = "additional tokenizer file")

args = parser.parse_args()

convert_params(args.model_filename, args.output_filename, args.n_ctx, args.tokenizer)
