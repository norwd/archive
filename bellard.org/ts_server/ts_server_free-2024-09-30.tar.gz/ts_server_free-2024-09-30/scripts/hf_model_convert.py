# convert HF models to the LibNC format
import sys
import torch
import numpy as np
import struct
import math
import io
import json
import os
import argparse
import glob
from convert_utils import *

def concat(params, name, axis = 0):
    return params[name];

def same(params, name):
    return params[name];

# HF Q K weights are permuted for sliced rotary
def permute(a, d_key):
    w = a.shape[1]
    h = a.shape[0]
    return a.view(h // d_key, 2, d_key // 2, w).transpose(1, 2).reshape(h, w)

def permute_bias(a, d_key):
    a = a.view(a.shape[0], 1)
    a = permute(a, d_key)
    return a.view(a.shape[0])

def load_json(filename):
    f = open(filename, "r")
    a = f.read()
    f.close()
    return json.loads(a)


def load_safetensors_model_from_dir(files):
    from safetensors.torch import load_file
    m = {}
    for filename in files:
        print("loading", filename)
        d = load_file(filename, device="cpu")
        for k, v in d.items():
            m[k] = v;
    return m

def load_pytorch_model_from_dir(dir):
    files = glob.glob(dir + "/pytorch_model*.bin")
    if len(files) == 0:
        files = glob.glob(dir + "/model*.safetensors")
        if len(files) == 0:
            print("no python_model*.bin file found");
            sys.exit(1)
        else:
            return load_safetensors_model_from_dir(files)
    m = {}
    for filename in files:
        print("loading", filename)
        d = torch.load(filename, map_location="cpu", weights_only=True)
        for k, v in d.items():
            m[k] = v;
    return m

###############################################
# Llama models

def get_rotary_embed_longrope(hf_config, is_long):
    base = hf_config["rope_theta"]
    dim = hf_config["hidden_size"] // hf_config["num_attention_heads"]
    n_ctx = hf_config["max_position_embeddings"]
    rope_scaling = hf_config["rope_scaling"]
    original_max_position_embeddings = hf_config["original_max_position_embeddings"]
    if is_long:
        ext_factors = rope_scaling["long_factor"]
    else:
        ext_factors = rope_scaling["short_factor"]
    ext_factors = torch.tensor(ext_factors, dtype=torch.float32)
    
    omegas = 1.0 / (ext_factors * base ** (torch.arange(0, dim, 2, dtype=torch.float32) / dim))
    
    scale = n_ctx / original_max_position_embeddings
    if scale <= 1.0:
        scaling_factor = 1.0
    else:
        scaling_factor = math.sqrt(1 + math.log(scale) / math.log(original_max_position_embeddings))

    # build the rope embeddings from omega
    if is_long:
        n_ctx1 = n_ctx
    else:
        n_ctx1 = original_max_position_embeddings
    position_ids = torch.arange(0, n_ctx1, 1, dtype=torch.float32)
    a = position_ids[:, None].expand(-1, dim // 2) * omegas
    emb = torch.cat((a.cos() * scaling_factor, a.sin() * scaling_factor),
                    dim = -1)
    emb = torch.reshape(emb, (-1, 2, dim // 2))
    emb = emb.transpose(1, 2)
    emb = torch.reshape(emb, (-1, dim))
    return emb

# compute the rotary embeddings here. It simplifies the config and avoid precision issues
def get_rotary_embed(hf_config):
    rope_type = None
    if "rope_scaling" in hf_config and hf_config["rope_scaling"] != None:
        rope_scaling = hf_config["rope_scaling"]
        if "type" in rope_scaling:
            rope_type = rope_scaling["type"] # phi3
        else:
            rope_type = rope_scaling["rope_type"]
        if rope_type == "longrope":
            return get_rotary_embed_longrope(hf_config, True), get_rotary_embed_longrope(hf_config, False)

    base = hf_config["rope_theta"]
    dim = hf_config["hidden_size"] // hf_config["num_attention_heads"]
    omegas = 1.0 / (base ** (torch.arange(0, dim, 2, dtype=torch.float32) / dim))
    n_ctx = hf_config["max_position_embeddings"]
    
    if rope_type == "llama3":
        factor = rope_scaling["factor"]
        low_freq_factor = rope_scaling["low_freq_factor"]
        high_freq_factor = rope_scaling["high_freq_factor"]
        old_context_len = rope_scaling["original_max_position_embeddings"]

        low_freq_wavelen = old_context_len / low_freq_factor
        high_freq_wavelen = old_context_len / high_freq_factor
        
        omegas1 = []
        for i in range(dim // 2):
            omega = omegas[i] # float tensor
            wavelen = 2 * math.pi / omega
            if wavelen < high_freq_wavelen:
                omega1 = omega
            elif wavelen > low_freq_wavelen:
                omega1 = omega / factor
            else:
                smooth_factor = (old_context_len / wavelen - low_freq_factor) / (high_freq_factor - low_freq_factor)
                omega1 = (1 - smooth_factor) * omega / factor + smooth_factor * omega
            omegas1.append(omega1)

        omegas = torch.tensor(omegas1, dtype=torch.float32)
    elif rope_type != None:
        print("unsupported rope_type:", rope_type)
        sys.exit(1)
            
    # build the rope embeddings from omega
    position_ids = torch.arange(0, n_ctx, 1, dtype=torch.float32)
    a = position_ids[:, None].expand(-1, dim // 2) * omegas
    emb = torch.cat((a.cos(), a.sin()), dim = -1)
    emb = torch.reshape(emb, (-1, 2, dim // 2))
    emb = emb.transpose(1, 2)
    emb = torch.reshape(emb, (-1, dim))
    return emb, None

def llama_convert_params(model_dir, out_filename, chat_template, hf_config, tokenizer_filename):
    m = load_pytorch_model_from_dir(model_dir)

    hf_model_type = hf_config["model_type"]
    
    rotary_scale = 1.0
    model_type = "llama"
    sliding_window = 0
    n_mlp_experts = 1
    n_mlp_experts_per_tok = 1
    n_ctx = hf_config["max_position_embeddings"]
    rotary_embed = None
    short_rotary_embed = None
    qkv_bias = False
    causal_attn = True
    tied_embed = False
    if hf_model_type == "mistral":
        model_type = "mistral" # only needed if the tokenizer is implicit
    elif hf_model_type == "mixtral":
        model_type = "mistral" # only needed if the tokenizer is implicit
        n_mlp_experts = hf_config["num_local_experts"]
        n_mlp_experts_per_tok = hf_config["num_experts_per_tok"]
    elif "rope_scaling" in hf_config and hf_config["rope_scaling"] != None:
        rotary_embed, short_rotary_embed = get_rotary_embed(hf_config)
    elif "max_sequence_length" in hf_config:
        # rope scaling support
        n_ctx = hf_config["max_sequence_length"]
        rotary_scale = n_ctx / hf_config["max_position_embeddings"]

    # mistral, phi3
    if "sliding_window" in hf_config and hf_config["sliding_window"] != None and hf_config["sliding_window"] < n_ctx:
        sliding_window = hf_config["sliding_window"]

    rotary_base = 10000
    if "rope_theta" in hf_config:
        rotary_base = hf_config["rope_theta"]

    if "tie_word_embeddings" in hf_config:
        tied_embed = hf_config["tie_word_embeddings"]
        
    if n_ctx >= 4096:
        # HF LLAMA2 weights are currently converted to float32 or float16 while they should be bfloat16
        for k in m.keys():
            m[k] = m[k].to(torch.bfloat16)
        data_type = "bf16"
    else:
        data_type = "f16"
        
    prefix0 = "model."
    n_layers = hf_config["num_hidden_layers"]
    d_model = hf_config["hidden_size"]
    d_inner = hf_config["intermediate_size"]
    vocab_size = m[prefix0 + "embed_tokens.weight"].shape[0]

    n_head = hf_config["num_attention_heads"]
    n_head_kv = hf_config["num_key_value_heads"]
    d_key = d_model // n_head
    layer_norm_eps = hf_config["rms_norm_eps"]
    if hf_model_type == "qwen2":
        qkv_bias = True
        # quirk to deduce non causal attention is used
        if "auto_map" in hf_config and \
           "AutoModelForSequenceClassification" in hf_config["auto_map"]:
            causal_attn = False
    
    f = open(out_filename, "wb")

    config = {"type": model_type, "n_layer": n_layers, "d_model": d_model, "d_key": d_key, "n_head": n_head, "n_head_kv": n_head_kv, "d_inner": d_inner, "n_ctx": n_ctx, "vocab_size": vocab_size, "data_type": data_type }
    if sliding_window != 0:
        config["sliding_window"] = sliding_window
    if n_mlp_experts > 1:
        config["n_mlp_experts"] = n_mlp_experts
        config["n_mlp_experts_per_tok"] = n_mlp_experts_per_tok

    if rotary_embed != None:
        config["rotary_embed"] = True
        if short_rotary_embed != None:
            # phi3 128k
            config["short_rotary_embed_len"] = hf_config["original_max_position_embeddings"] 
    else:
        config["rotary_base"] = rotary_base
        if rotary_scale != 1.0:
            config["rotary_scale"] = rotary_scale

    if layer_norm_eps != 1e-5:
        config["layer_norm_eps"] = layer_norm_eps

    if qkv_bias:
        config["qkv_bias"] = True

    if not causal_attn:
        config["causal_attn"] = causal_attn

    if tied_embed:
        config["tied_embed"] = tied_embed
        
    if chat_template != "":
        config["chat_template"] = chat_template
        
    write_libnc_param_header(f, config);

    write_libnc_tokenizer(f, tokenizer_filename, "tokenizer")
    
    w = concat(m, prefix0 + "embed_tokens.weight", 1)
    write_libnc_param_pt(f, w, "wte")

    if rotary_embed != None:
        if data_type == "bf16":
            d_type = torch.bfloat16
        else:
            d_type = torch.float16
        write_libnc_param_pt(f, rotary_embed.to(d_type), "rotary_embed")
        if short_rotary_embed != None:
            write_libnc_param_pt(f, short_rotary_embed.to(d_type), "short_rotary_embed")
            
    for layer_num in range(n_layers):
        prefix = prefix0 + "layers." + str(layer_num) + "."
            
        out_prefix = "h" + str(layer_num) + "/"
        
        write_libnc_param_pt(f, same(m, prefix + "input_layernorm.weight"), out_prefix + "ln_1/g")

        if hf_model_type == "phi3":
            w = concat(m, prefix + "self_attn.qkv_proj.weight", 0)
            w_q, w_k, w_v = torch.split(w, [n_head * d_key, n_head_kv * d_key, n_head_kv * d_key])
        else:
            w_q = concat(m, prefix + "self_attn.q_proj.weight", 0)
            w_k = concat(m, prefix + "self_attn.k_proj.weight", 0)
            w_v = concat(m, prefix + "self_attn.v_proj.weight", 0)

        w_q = permute(w_q, d_key)
        w_k = permute(w_k, d_key)
        w = torch.cat((w_q, w_k, w_v), 0)
        write_libnc_param_pt(f, torch.t(w), out_prefix + "attn/c_attn/w")

        if qkv_bias:
            w_q = concat(m, prefix + "self_attn.q_proj.bias", 0)
            w_k = concat(m, prefix + "self_attn.k_proj.bias", 0)
            w_v = concat(m, prefix + "self_attn.v_proj.bias", 0)
            w_q = permute_bias(w_q, d_key)
            w_k = permute_bias(w_k, d_key)
            w = torch.cat((w_q, w_k, w_v), 0)
            write_libnc_param_pt(f, w, out_prefix + "attn/c_attn/b")

        w = concat(m, prefix + "self_attn.o_proj.weight", 1)
        write_libnc_param_pt(f, torch.t(w), out_prefix + "attn/c_proj/w")

        write_libnc_param_pt(f, same(m, prefix + "post_attention_layernorm.weight"), out_prefix + "ln_2/g")
        if n_mlp_experts > 1:
            w = m[prefix + "block_sparse_moe.gate.weight"]
            write_libnc_param_pt(f, torch.t(w), out_prefix + "mlp_moe_gate/w")
            
            for i in range(n_mlp_experts):
                w1 = m[prefix + "block_sparse_moe.experts.{:d}.w1.weight".format(i)] # gate
                w3 = m[prefix + "block_sparse_moe.experts.{:d}.w3.weight".format(i)] # value
                w = torch.cat((w1, w3), 0)
                write_libnc_param_pt(f, torch.t(w), out_prefix + "mlp{:d}/c_fc/w".format(i))
                
                w = m[prefix + "block_sparse_moe.experts.{:d}.w2.weight".format(i)]
                write_libnc_param_pt(f, torch.t(w), out_prefix + "mlp{:d}/c_proj/w".format(i))
        else:
            if hf_model_type == "phi3":
                w = concat(m, prefix + "mlp.gate_up_proj.weight", 0)
            else:
                w1 = concat(m, prefix + "mlp.gate_proj.weight", 0)
                w3 = concat(m, prefix + "mlp.up_proj.weight", 0)
                w = torch.cat((w1, w3), 0)
                
            write_libnc_param_pt(f, torch.t(w), out_prefix + "mlp/c_fc/w")
        
            w = concat(m, prefix + "mlp.down_proj.weight", 1)
            write_libnc_param_pt(f, torch.t(w), out_prefix + "mlp/c_proj/w")

        # with safetensors the tensors are loaded on demand
        # we remove the reference to the large ones to save memory
        m[prefix + "self_attn.q_proj.weight"] = None
        m[prefix + "self_attn.k_proj.weight"] = None
        m[prefix + "self_attn.v_proj.weight"] = None
        m[prefix + "self_attn.o_proj.weight"] = None
        m[prefix + "mlp.gate_proj.weight"] = None
        m[prefix + "mlp.up_proj.weight"] = None
        m[prefix + "mlp.down_proj.weight"] = None
          
    write_libnc_param_pt(f, same(m, prefix0 + "norm.weight"), "ln_f/g")

    if not tied_embed:
        w = concat(m, "lm_head.weight", 0)
        write_libnc_param_pt(f, torch.t(w), "proj_f/w")
        
    f.close()

###############################################
# T5 models

def convert_layers(f, m, n_layer, is_encoder):
    if is_encoder:
        in_prefix0 = "encoder."
        out_prefix0 = "enc/"
    else:
        in_prefix0 = "decoder."
        out_prefix0 = ""

    w = m[in_prefix0 + "block.0.layer.0.SelfAttention.relative_attention_bias.weight"]
    write_libnc_param_pt(f, w.to(torch.bfloat16), out_prefix0 + "rel_bias")
        
    for layer_num in range(n_layer):
        in_prefix = in_prefix0 + "block.{:d}.".format(layer_num)
        out_prefix = out_prefix0 + "h" + str(layer_num) + "/"

        # self attention layer
        layer_prefix = in_prefix + "layer.0."
        write_libnc_param_pt(f, m[layer_prefix + "layer_norm.weight"].to(torch.bfloat16), out_prefix + "ln_1/g")

        w_q = m[layer_prefix + "SelfAttention.q.weight"];
        w_k = m[layer_prefix + "SelfAttention.k.weight"];
        w_v = m[layer_prefix + "SelfAttention.v.weight"];
        w = torch.cat((w_q, w_k, w_v), 0)
        write_libnc_param_pt(f, torch.transpose(w, 0, 1).to(torch.bfloat16), out_prefix + "attn/c_attn/w")
        
        write_libnc_param_pt(f, torch.transpose(m[layer_prefix + "SelfAttention.o.weight"], 0, 1).to(torch.bfloat16), out_prefix + "attn/c_proj/w")

        # cross attention layer
        if not is_encoder:
            layer_prefix = in_prefix + "layer.1."
            write_libnc_param_pt(f, m[layer_prefix + "layer_norm.weight"].to(torch.bfloat16), out_prefix + "ln_0/g")
            w = m[layer_prefix + "EncDecAttention.q.weight"]
            write_libnc_param_pt(f, torch.transpose(w, 0, 1).to(torch.bfloat16), out_prefix + "cross_attn/q_attn/w")
            
            w_k = m[layer_prefix + "EncDecAttention.k.weight"]
            w_v = m[layer_prefix + "EncDecAttention.v.weight"]
            w = torch.cat((w_k, w_v), 0)
            write_libnc_param_pt(f, torch.transpose(w, 0, 1).to(torch.bfloat16), out_prefix + "cross_attn/kv_attn/w")
            
            write_libnc_param_pt(f, torch.transpose(m[layer_prefix + "EncDecAttention.o.weight"], 0, 1).to(torch.bfloat16), out_prefix + "cross_attn/c_proj/w")
        
        # MLP layer
        if is_encoder:
            layer_prefix = in_prefix + "layer.1."
        else:
            layer_prefix = in_prefix + "layer.2."

        write_libnc_param_pt(f, m[layer_prefix + "layer_norm.weight"].to(torch.bfloat16), out_prefix + "ln_2/g")

        wi_0 = m[layer_prefix + "DenseReluDense.wi_0.weight"];
        wi_1 = m[layer_prefix + "DenseReluDense.wi_1.weight"];
        w = torch.cat((wi_0, wi_1), 0)
        write_libnc_param_pt(f, torch.transpose(w, 0, 1).to(torch.bfloat16), out_prefix + "mlp/c_fc/w")

        w = m[layer_prefix + "DenseReluDense.wo.weight"];
        write_libnc_param_pt(f, torch.transpose(w, 0, 1).to(torch.bfloat16), out_prefix + "mlp/c_proj/w")
        
    write_libnc_param_pt(f, m[in_prefix0 + "final_layer_norm.weight"].to(torch.bfloat16), out_prefix0 + "ln_f/g")

def t5_convert_params(model_dir, out_filename, hf_config, tokenizer_filename):

    m = load_pytorch_model_from_dir(model_dir)
    
    n_layer = 1
    while "encoder.block.{:d}.layer.0.SelfAttention.q.weight".format(n_layer) in m:
        n_layer += 1

    if hf_config["feed_forward_proj"] == "gated-silu":
        model_type = "ul2"
    else:
        model_type = "t5"
        
    if "tie_word_embeddings" in hf_config:
        tied_embed = hf_config["tie_word_embeddings"]
    else:
        tied_embed = True
        
    shape = m["encoder.block.0.layer.0.SelfAttention.q.weight"].shape
    d_model = shape[1]
    n_head = hf_config["num_heads"]
    d_key = shape[0] // n_head
    shape = m["encoder.block.0.layer.1.DenseReluDense.wo.weight"].shape
    d_inner = shape[1]
    n_enc_ctx = 2048 # max number of input tokens
    n_ctx = 512 # max number of output tokens
    if "shared.weight" in m:
        embed = m["shared.weight"]
    else:
        # Note: the encoder and decoder embeddings are identical
        embed = m["encoder.embed_tokens.weight"]
    vocab_size = embed.shape[0]
    fp_type = "bf16"
    
    f = open(out_filename, "wb")

    write_libnc_param_header(f, {"type": model_type, "n_layer": n_layer, "n_encoder_layer": n_layer, "d_model": d_model, "n_head": n_head, "d_key": d_key, "d_inner": d_inner, "n_encoder_ctx": n_enc_ctx, "n_ctx": n_ctx, "vocab_size": vocab_size, "data_type": fp_type });

    write_libnc_tokenizer(f, tokenizer_filename, "tokenizer")
        
    write_libnc_param_pt(f, embed.to(torch.bfloat16), "wte")

    convert_layers(f, m, n_layer, True)

    convert_layers(f, m, n_layer, False)

    if not tied_embed:
        w = m["lm_head.weight"]
        write_libnc_param_pt(f, torch.transpose(w, 0, 1).to(torch.bfloat16), "proj_f/w")
    
    f.close()

###############################################
# bloom model

def load_layer(model_path, layer_num):
    filename = model_path + "/pytorch_model_{:05d}-of-00072.bin".format(layer_num)
    print("loading ", filename)
    d = torch.load(filename, map_location="cpu", weights_only=True)
    return d

def bloom_convert_params(model_path, out_filename, hf_config, tokenizer_filename):
    n_layers = hf_config["n_layer"]
    d_model = hf_config["n_embed"]
    n_head = hf_config["num_attention_heads"]
    d_key = d_model // n_head
    vocab_size = hf_config["vocab_size"]
    
    fp_type = "f16"
    
    # for bloom 170B, we load the files on demand
    multi_file = (n_layers >= 70)
    if multi_file:
        fp_type = "bf16"
    else:
        fp_type = "f16"

    if not multi_file:
        m = load_pytorch_model_from_dir(model_path)
        
    f = open(out_filename, "wb")

    write_libnc_param_header(f, {"type": "bloom", "n_layer": n_layers, "d_model": d_model, "data_type": fp_type, "d_key": d_key, "vocab_size": vocab_size });

    if multi_file:
        m = load_layer(model_path, 1)

    write_libnc_tokenizer(f, tokenizer_filename, "tokenizer")
    
    write_libnc_param_pt(f, m["word_embeddings.weight"], "wte")
    
    write_libnc_param_pt(f, m["word_embeddings_layernorm.weight"], "ln_emb/g")
    write_libnc_param_pt(f, m["word_embeddings_layernorm.bias"], "ln_emb/b")
    
    for layer_num in range(n_layers):
        if multi_file:
            m = load_layer(model_path, layer_num + 2)
        in_prefix = "h." + str(layer_num) + "."
        out_prefix = "h" + str(layer_num) + "/"
        
        write_libnc_param_pt(f, m[in_prefix + "input_layernorm.weight"], out_prefix + "ln_1/g")
        write_libnc_param_pt(f, m[in_prefix + "input_layernorm.bias"], out_prefix + "ln_1/b")

        w = m[in_prefix + "self_attention.query_key_value.weight"];
        # (3*d_model, d_model)
        w = w.reshape(n_head, 3, d_key, d_model)
        w = w.permute(1, 0, 2, 3)
        w = w.reshape(3 * d_model, d_model)
        w = torch.transpose(w, 0, 1)
        write_libnc_param_pt(f, w, out_prefix + "attn/c_attn/w")
        
        w = m[in_prefix + "self_attention.query_key_value.bias"]
        w = w.reshape(n_head, 3, d_key)
        w = w.permute(1, 0, 2)
        w = w.reshape(3 * d_model)
        write_libnc_param_pt(f, w, out_prefix + "attn/c_attn/b")
        
        write_libnc_param_pt(f, torch.transpose(m[in_prefix + "self_attention.dense.weight"], 0, 1), out_prefix + "attn/c_proj/w")
        write_libnc_param_pt(f, m[in_prefix + "self_attention.dense.bias"], out_prefix + "attn/c_proj/b")

        write_libnc_param_pt(f, m[in_prefix + "post_attention_layernorm.weight"], out_prefix + "ln_2/g")
        write_libnc_param_pt(f, m[in_prefix + "post_attention_layernorm.bias"], out_prefix + "ln_2/b")
        write_libnc_param_pt(f, torch.transpose(m[in_prefix + "mlp.dense_h_to_4h.weight"], 0, 1), out_prefix + "mlp/c_fc/w")
        write_libnc_param_pt(f, m[in_prefix + "mlp.dense_h_to_4h.bias"], out_prefix + "mlp/c_fc/b")
        write_libnc_param_pt(f, torch.transpose(m[in_prefix + "mlp.dense_4h_to_h.weight"], 0, 1), out_prefix + "mlp/c_proj/w")
        write_libnc_param_pt(f, m[in_prefix + "mlp.dense_4h_to_h.bias"], out_prefix + "mlp/c_proj/b")

    if multi_file:
        m = load_layer(model_path, 72)
    write_libnc_param_pt(f, m["ln_f.weight"], "ln_f/g")
    write_libnc_param_pt(f, m["ln_f.bias"], "ln_f/b")

    f.close()

###############################################
# OPT model

def get_param(model, name):
    if name in model:
        v = model[name]
    else:
        v = model["model." + name]
    return v.numpy()

def opt_convert_params(model_dir, out_filename, hf_config, tokenizer_filename):

    model = load_pytorch_model_from_dir(model_dir)

    d_model = get_param(model, "decoder.layers.0.self_attn_layer_norm.weight").shape[0]
    n_layer = 1
    while "model.decoder.layers." + str(n_layer) + ".self_attn.q_proj.weight" in model or "decoder.layers." + str(n_layer) + ".self_attn.q_proj.weight" in model:
        n_layer += 1
    n_head = hf_config["num_attention_heads"]
    d_key = d_model // n_head
        
    f = open(out_filename, "wb")

    write_libnc_param_header(f, {"type": "opt", "data_type": "f16", "n_layer": n_layer, "d_model": d_model, "d_key": d_key });

    write_libnc_tokenizer(f, tokenizer_filename, "tokenizer")
    
    w = get_param(model, "decoder.embed_positions.weight")
    w = torch.tensor(w, dtype=torch.float16)
    w = w[2:,:]
    write_libnc_param(f, w.numpy(), "wpe")
    
    w = get_param(model, "decoder.embed_tokens.weight")
    write_libnc_param(f, w, "wte")
    
    # XXX: projections for the 350m model are missing
    
    for layer_num in range(n_layer):
        prefix = "decoder.layers." + str(layer_num) + "."
        out_prefix = "h" + str(layer_num) + "/"
        w_q = get_param(model, prefix + "self_attn.q_proj.weight")
        w_k = get_param(model, prefix + "self_attn.k_proj.weight")
        w_v = get_param(model, prefix + "self_attn.v_proj.weight")
        w = np.concatenate((w_q, w_k, w_v), axis = 0)
        w = np.transpose(w)
        write_libnc_param(f, w, out_prefix + "attn/c_attn/w")

        w_q = get_param(model, prefix + "self_attn.q_proj.bias")
        w_k = get_param(model, prefix + "self_attn.k_proj.bias")
        w_v = get_param(model, prefix + "self_attn.v_proj.bias")
        w = np.concatenate((w_q, w_k, w_v), axis = 0)
        write_libnc_param(f, w, out_prefix + "attn/c_attn/b")

        write_libnc_param(f, get_param(model, prefix + "self_attn_layer_norm.weight"), out_prefix + "ln_1/g")
        write_libnc_param(f, get_param(model, prefix + "self_attn_layer_norm.bias"), out_prefix + "ln_1/b")
        w = get_param(model, prefix + "self_attn.out_proj.weight")
        w = np.transpose(w)
        write_libnc_param(f, w, out_prefix + "attn/c_proj/w")
        write_libnc_param(f, get_param(model, prefix + "self_attn.out_proj.bias"), out_prefix + "attn/c_proj/b")

        write_libnc_param(f, get_param(model, prefix + "final_layer_norm.weight"), out_prefix + "ln_2/g")
        write_libnc_param(f, get_param(model, prefix + "final_layer_norm.bias"), out_prefix + "ln_2/b")
        w = get_param(model, prefix + "fc1.weight")
        w = np.transpose(w)
        write_libnc_param(f, w, out_prefix + "mlp/c_fc/w")
        write_libnc_param(f, get_param(model, prefix + "fc1.bias"), out_prefix + "mlp/c_fc/b")
        w = get_param(model, prefix + "fc2.weight")
        w = np.transpose(w)
        write_libnc_param(f, w, out_prefix + "mlp/c_proj/w")
        write_libnc_param(f, get_param(model, prefix + "fc2.bias"), out_prefix + "mlp/c_proj/b")
        
    write_libnc_param(f, get_param(model, "decoder.final_layer_norm.weight"), "ln_f/g")
    write_libnc_param(f, get_param(model, "decoder.final_layer_norm.bias"), "ln_f/b")
    
    f.close()

###############################################
# falcon model

def falcon_convert_params(model_dir, out_filename, hf_config, tokenizer_filename):
    
    m = load_pytorch_model_from_dir(model_dir)
    prefix0 = "transformer."
    is_falcon_40b = (prefix0 + "h.0.ln_mlp.weight" in m)
    n_layer = 1
    while prefix0 + "h.{:d}.mlp.dense_h_to_4h.weight".format(n_layer) in m:
        n_layer += 1
    d_model = m[prefix0 + "h.0.mlp.dense_h_to_4h.weight"].shape[1]
    d_inner = m[prefix0 + "h.0.mlp.dense_h_to_4h.weight"].shape[0]
    n_symbols = m["lm_head.weight"].shape[0]
    d_key = 64
    assert d_model % d_key == 0
    n_head = d_model // d_key
    n = m[prefix0 + "h.0.self_attention.query_key_value.weight"].shape[0] - d_model
    assert n % (2 * d_key) == 0
    n_head_kv = n // (2 * d_key)
    
    f = open(out_filename, "wb")

    if is_falcon_40b:
        model_type = "falcon2"
    else:
        model_type = "falcon"
        
    write_libnc_param_header(f, {"type": model_type, "n_layer": n_layer, "d_model": d_model, "d_key": d_key, "d_inner": d_inner, "n_head": n_head, "n_head_kv": n_head_kv, "vocab_size": n_symbols, "data_type": "bf16" });

    write_libnc_tokenizer(f, tokenizer_filename, "tokenizer")
    
    w = m[prefix0 + "word_embeddings.weight"]
    write_libnc_param_pt(f, w, "wte")
    
    for layer_num in range(n_layer):
        prefix = prefix0 + "h." + str(layer_num) + "."
            
        out_prefix = "h" + str(layer_num) + "/"

        if is_falcon_40b:
            write_libnc_param_pt(f, m[prefix + "ln_attn.weight"], out_prefix + "ln_1/g")
            write_libnc_param_pt(f, m[prefix + "ln_attn.bias"], out_prefix + "ln_1/b")
            
            write_libnc_param_pt(f, m[prefix + "ln_mlp.weight"], out_prefix + "ln_2/g")
            write_libnc_param_pt(f, m[prefix + "ln_mlp.bias"], out_prefix + "ln_2/b")
        else:
            write_libnc_param_pt(f, m[prefix + "input_layernorm.weight"], out_prefix + "ln_1/g")
            write_libnc_param_pt(f, m[prefix + "input_layernorm.bias"], out_prefix + "ln_1/b")

        w = m[prefix + "self_attention.query_key_value.weight"]

        w = w.reshape(n_head_kv, n_head // n_head_kv + 2, d_key, d_model)
        w_q, w_k, w_v = torch.split(w, [n_head // n_head_kv, 1, 1], 1)
        w_q = w_q.reshape(n_head * d_key, d_model)
        w_k = w_k.reshape(n_head_kv * d_key, d_model)
        w_v = w_v.reshape(n_head_kv * d_key, d_model)

        # permute w_q and w_k but not w_v
        w_q = permute(w_q, d_key)
        w_k = permute(w_k, d_key)
        w = torch.cat((w_q, w_k, w_v), 0)
        write_libnc_param_pt(f, torch.t(w), out_prefix + "attn/c_attn/w")

        w = m[prefix + "self_attention.dense.weight"]
        write_libnc_param_pt(f, torch.t(w), out_prefix + "attn/c_proj/w")

        w = m[prefix + "mlp.dense_h_to_4h.weight"]
        write_libnc_param_pt(f, torch.t(w), out_prefix + "mlp/c_fc/w")
        
        w = m[prefix + "mlp.dense_4h_to_h.weight"]
        write_libnc_param_pt(f, torch.t(w), out_prefix + "mlp/c_proj/w")

    write_libnc_param_pt(f, m[prefix0 + "ln_f.weight"], "ln_f/g")
    write_libnc_param_pt(f, m[prefix0 + "ln_f.bias"], "ln_f/b")

    w = m["lm_head.weight"]
    write_libnc_param_pt(f, torch.t(w), "proj_f/w")
        
    f.close()

###############################################
# GPT neox model

def gpt_neox_convert_params(model_dir, out_filename, hf_config, tokenizer_filename):

    m = load_pytorch_model_from_dir(model_dir)
    prefix0 = "gpt_neox."

    n_layers = 1
    while "gpt_neox.layers.{:d}.input_layernorm.weight".format(n_layers) in m:
        n_layers += 1
    d_model = m["gpt_neox.embed_in.weight"].shape[1]
    n_symbols = m["embed_out.weight"].shape[0]

    # some parameters cannot be inferred from the parameters
    n_ctx = hf_config["max_position_embeddings"]
    n_head = hf_config["num_attention_heads"]
    d_key = d_model // n_head
    rotary_frac = hf_config["rotary_pct"]
    if (not "use_parallel_residual" in hf_config) or hf_config["use_parallel_residual"]:
        parallel_residual = "gptneox"
    else:
        parallel_residual = "none"
        
    f = open(out_filename, "wb")

    write_libnc_param_header(f, {"type": "gptneox", "n_layer": n_layers, "d_model": d_model, "d_key": d_key, "n_ctx": n_ctx, "vocab_size": n_symbols, "rotary_frac": rotary_frac, "parallel_residual": parallel_residual, "data_type": "f16" });

    write_libnc_tokenizer(f, tokenizer_filename, "tokenizer")
    
    w = m[prefix0 + "embed_in.weight"]
    write_libnc_param_pt(f, w, "wte")
    
    for layer_num in range(n_layers):
        prefix = prefix0 + "layers." + str(layer_num) + "."
            
        out_prefix = "h" + str(layer_num) + "/"
        
        write_libnc_param_pt(f, m[prefix + "input_layernorm.weight"], out_prefix + "ln_1/g")
        write_libnc_param_pt(f, m[prefix + "input_layernorm.bias"], out_prefix + "ln_1/b")

        w = torch.t(m[prefix + "attention.query_key_value.weight"]);
        # (d_model, n_head * 3 * d_key)
        w = torch.reshape(w, (d_model, n_head, 3, d_key))
        # (d_model, n_head, 3, d_key) 
        w = torch.permute(w, (0, 2, 1, 3))
        # (d_model, 3, n_head, d_key) 
        w = torch.reshape(w, (d_model, 3 * n_head * d_key))
        write_libnc_param_pt(f, w, out_prefix + "attn/c_attn/w")
        
        w = m[prefix + "attention.query_key_value.bias"]
        w = torch.reshape(w, (n_head, 3, d_key))
        w = torch.permute(w, (1, 0, 2))
        w = torch.reshape(w, (3 * n_head * d_key,))
        write_libnc_param_pt(f, w, out_prefix + "attn/c_attn/b")
        
        write_libnc_param_pt(f, torch.t(m[prefix + "attention.dense.weight"]), out_prefix + "attn/c_proj/w")
        write_libnc_param_pt(f, m[prefix + "attention.dense.bias"], out_prefix + "attn/c_proj/b")

        write_libnc_param_pt(f, m[prefix + "post_attention_layernorm.weight"], out_prefix + "ln_2/g")
        write_libnc_param_pt(f, m[prefix + "post_attention_layernorm.bias"], out_prefix + "ln_2/b")
        write_libnc_param_pt(f, torch.t(m[prefix + "mlp.dense_h_to_4h.weight"]), out_prefix + "mlp/c_fc/w")
        write_libnc_param_pt(f, m[prefix + "mlp.dense_h_to_4h.bias"], out_prefix + "mlp/c_fc/b")
        write_libnc_param_pt(f, torch.t(m[prefix + "mlp.dense_4h_to_h.weight"]), out_prefix + "mlp/c_proj/w")
        write_libnc_param_pt(f, m[prefix + "mlp.dense_4h_to_h.bias"], out_prefix + "mlp/c_proj/b")

    write_libnc_param_pt(f, m[prefix0 + "final_layer_norm.weight"], "ln_f/g")
    write_libnc_param_pt(f, m[prefix0 + "final_layer_norm.bias"], "ln_f/b")

    w = torch.t(m["embed_out.weight"])
    write_libnc_param_pt(f, w, "proj_f/w")
        
    f.close()

###############################################
# MPT model

def mpt_convert_params(model_dir, out_filename, hf_config, tokenizer_filename):
    m = load_pytorch_model_from_dir(model_dir)
    n_layer = 1
    while "transformer.blocks.{:d}.ffn.up_proj.weight".format(n_layer) in m:
        n_layer += 1
    d_model = m["transformer.blocks.0.ffn.up_proj.weight"].shape[1]
    d_inner = m["transformer.blocks.0.ffn.up_proj.weight"].shape[0]
    n_symbols = m["transformer.wte.weight"].shape[0]
    n_head = hf_config["n_heads"]
    assert d_model % n_head == 0
    d_key = d_model // n_head
    n_ctx = hf_config["max_seq_len"]
    
    f = open(out_filename, "wb")

    write_libnc_param_header(f, {"type": "mpt", "n_layer": n_layer, "d_model": d_model, "d_key": d_key, "d_inner": d_inner, "n_head": n_head, "vocab_size": n_symbols, "n_ctx": n_ctx, "data_type": "bf16" });

    write_libnc_tokenizer(f, tokenizer_filename, "tokenizer")
    
    w = m["transformer.wte.weight"]
    write_libnc_param_pt(f, w, "wte")
    
    for layer_num in range(n_layer):
        prefix = "transformer.blocks.{:d}.".format(layer_num)
            
        out_prefix = "h" + str(layer_num) + "/"

        write_libnc_param_pt(f, m[prefix + "norm_1.weight"], out_prefix + "ln_1/g")
            
        write_libnc_param_pt(f, m[prefix + "norm_2.weight"], out_prefix + "ln_2/g")

        w = m[prefix + "attn.Wqkv.weight"]
        write_libnc_param_pt(f, torch.t(w), out_prefix + "attn/c_attn/w")

        w = m[prefix + "attn.out_proj.weight"]
        write_libnc_param_pt(f, torch.t(w), out_prefix + "attn/c_proj/w")

        w = m[prefix + "ffn.up_proj.weight"]
        write_libnc_param_pt(f, torch.t(w), out_prefix + "mlp/c_fc/w")
        
        w = m[prefix + "ffn.down_proj.weight"]
        write_libnc_param_pt(f, torch.t(w), out_prefix + "mlp/c_proj/w")

    write_libnc_param_pt(f, m["transformer.norm_f.weight"], "ln_f/g")

    f.close()

###############################################
# main

def convert_params(model_dir, out_filename, chat_template, tokenizer):
    hf_config = load_json(model_dir + "/config.json")
    
    hf_model_type = hf_config["model_type"]

    if hf_model_type == "llama" or hf_model_type == "mistral" or hf_model_type == "mixtral" or hf_model_type == "phi3" or hf_model_type == "qwen2":
        llama_convert_params(model_dir, out_filename, chat_template, hf_config, tokenizer)
    elif hf_model_type == "t5":
        t5_convert_params(model_dir, out_filename, hf_config, tokenizer)
    elif hf_model_type == "bloom":
        bloom_convert_params(model_dir, out_filename, hf_config, tokenizer)
    elif hf_model_type == "opt":
        opt_convert_params(model_dir, out_filename, hf_config, tokenizer)
    elif hf_model_type == "RefinedWebModel":
        falcon_convert_params(model_dir, out_filename, hf_config, tokenizer)
    elif hf_model_type == "gpt_neox":
        gpt_neox_convert_params(model_dir, out_filename, hf_config, tokenizer)
    elif hf_model_type == "mpt":
        mpt_convert_params(model_dir, out_filename, hf_config, tokenizer)
    else:
        print("unsupported model type:", hf_model_type)
        sys.exit(1)
        
parser = argparse.ArgumentParser(description='LLAMA HF to LibNC parameter conversion tool')
parser.add_argument('model_dir', type=str, help = "directory containing the HF 'config.json' and pytorch checkpoints")
parser.add_argument('output_filename', type=str, help = "name of the output file for the LibNC model")
parser.add_argument('--chat_template', type=str, default = "", help = "optional chat template (e.g. vicuna or llama2)")
parser.add_argument('--tokenizer', type=str, default = "", help = "additional tokenizer file")

args = parser.parse_args()

convert_params(args.model_dir, args.output_filename, args.chat_template, args.tokenizer)
