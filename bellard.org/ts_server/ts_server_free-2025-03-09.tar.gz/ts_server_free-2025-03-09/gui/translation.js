/* Copyright (c) 2019 Fabrice Bellard */
"use strict";
var output_text_active = false;
var cancel_request = false;
var raw_output_text = "";
var output_text = "";
var input_text = "";
var model_params = "";
var http_api_url = "http://localhost:8080";
var req;
var cur_response_len;

var button_el = document.getElementById("translate_button");

function html_escape(s)
{
    var i, r, c;
    r = "";
    for(i = 0; i < s.length; i++) {
        c = s[i];
        switch(c) {
        case "<":
            r += "&lt;";
            break;
        case ">":
            r += "&gt;";
            break;
        case "&":
            r += "&amp;";
            break;
        case "\"":
            r += "&quot;";
            break;
        default:
            r += c;
            break;
        }
    }
    return r;
}

function reset_params()
{
    var el;
    
    el = document.getElementById("topk");
    el.value = "40";

    el = document.getElementById("topp");
    el.value = "0.9";

    el = document.getElementById("temperature");
    el.value = "1.0";

    el = document.getElementById("max_tokens");
    el.value = "200";

    el = document.getElementById("stop");
    el.value = "";
}

function on_select(lang)
{
    var select_el = document.getElementById("select_" + lang);
    var input_text_el = document.getElementById("input_text");
    var val = select_el.value | 0;
    var r;
    if (val) {
        r = example_inputs[lang][val - 1];
        input_text_el.value = r.prompt;
        reset_params();
        if ("top_k" in r) {
            document.getElementById("topk").value = r.top_k;
        }
        if ("stop" in r) {
            document.getElementById("stop").value = r.stop;
        }
    }
}

function on_model_select()
{
    update_lang_select()
}

function translate_init()
{
    var el;

    el = document.getElementById("input_text");
    el.value = "";

    update_models("translation");
}

function button_swap()
{
    var input_text_el = document.getElementById("input_text");
    var output_text_el = document.getElementById("output_text");
    var source_el = document.getElementById("source_lang");
    var target_el = document.getElementById("target_lang");
    var tmp;
    
    tmp = input_text_el.value;
    input_text_el.value = output_text_el.value;
    output_text_el.value = tmp;

    tmp = source_el.value;
    if (tmp == "auto")
        tmp = "en";
    source_el.value = target_el.value;
    target_el.value = tmp;
}

function button_submit()
{
    var input_text_el = document.getElementById("input_text");

    if (output_text_active) {
        cancel_request = true;
        req.abort();
    } else {
        translate_start(input_text_el.value);
    }
}

function set_param_error(e)
{
    var el;
    el = document.getElementById("param_error");
    if (e === "") {
        el.innerHTML = '';
    } else {
        el.innerHTML = '<div class="alert alert-danger">' + e + '</div>';
    }
}

function show_warning(e)
{
    var el;
    el = document.getElementById("param_error");
    el.innerHTML = '<div class="alert alert-warning">' + e + '</div>';
}

function translate_start(input_text)
{
    var model, req_data, source_lang, target_lang;
    
    if (input_text != "") {

        set_param_error("");

        model = document.getElementById("model").value;
        source_lang = document.getElementById("source_lang").value;
        target_lang = document.getElementById("target_lang").value;
        
        req_data = { text: input_text, source_lang: source_lang, target_lang: target_lang };
        cur_response_len = 0;

        req = new XMLHttpRequest();
        req.onreadystatechange = req_on_ready_state_change;
        req.open("POST", http_api_url + "/v1/engines/" + model + "/translate");
        req.setRequestHeader('Content-Type', 'application/json');
        req.send(JSON.stringify(req_data));
        
        button_el.innerHTML = "Stop";
        
        output_text_active = true;
        cancel_request = false;
    }
}

function req_on_ready_state_change(ev)
{
    var tab, i, resp, msg;

    if (req.readyState == 4 && req.status == 200) {
        resp = JSON.parse(req.responseText);
        handle_response(resp);
        translate_end();
    } else if (req.readyState == 4 && !cancel_request) {
        try {
            resp = JSON.parse(req.responseText);
            msg = resp.error;
        } catch(err) {
            msg = "Server error";
        }
        set_param_error(msg);
        translate_end();
    }
}

function handle_response(resp)
{
    var output_el = document.getElementById("output_text");
    output_el.value = resp.translations[0].text;
}

function translate_end()
{
    button_el.innerHTML = "Translate";
    output_text_active = false;
}
