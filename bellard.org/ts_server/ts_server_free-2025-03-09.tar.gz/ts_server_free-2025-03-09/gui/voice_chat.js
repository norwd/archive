/* Copyright (c) 2024-2025 Fabrice Bellard */
"use strict";

var page_type; /* "voice_chat", "stt" */
var audioContext, audio_worklet;
var audioSource = null;
var websocket = null;

var raw_output_text = "";
var last_turn = -1; /* -1 = none, 0 = user, 1 = bot */
var output_text_el = null;
var got_audio_done = false;
var cur_messages = [];

var voice_list = ["Will","Eric","Laura","Alisa","Patrick","Rose","Jerry","Jordan","Lauren","Jenna","Karen","Rick","Bill","James","Yann","Emily","Anna","Jon","Brenda","Barbara"];

/* XXX: use an array */
var transcript_languages = {
    "en": "English",
    "zh": "Chinese",
    "de": "German",
    "es": "Spanish",
    "ru": "Russian",
    "ko": "Korean",
    "fr": "French",
    "ja": "Japanese",
    "pt": "Portuguese",
    "tr": "Turkish",
    "pl": "Polish",
    "ca": "Catalan",
    "nl": "Dutch",
    "ar": "Arabic",
    "sv": "Swedish",
    "it": "Italian",
    "id": "Indonesian",
    "hi": "Hindi",
    "fi": "Finnish",
    "vi": "Vietnamese",
    "he": "Hebrew",
    "uk": "Ukrainian",
    "el": "Greek",
    "ms": "Malay",
    "cs": "Czech",
    "ro": "Romanian",
    "da": "Danish",
    "hu": "Hungarian",
    "ta": "Tamil",
    "no": "Norwegian",
    "th": "Thai",
    "ur": "Urdu",
    "hr": "Croatian",
    "bg": "Bulgarian",
    "lt": "Lithuanian",
    "la": "Latin",
    "mi": "Maori",
    "ml": "Malayalam",
    "cy": "Welsh",
    "sk": "Slovak",
    "te": "Telugu",
    "fa": "Persian",
    "lv": "Latvian",
    "bn": "Bengali",
    "sr": "Serbian",
    "az": "Azerbaijani",
    "sl": "Slovenian",
    "kn": "Kannada",
    "et": "Estonian",
    "mk": "Macedonian",
    "br": "Breton",
    "eu": "Basque",
    "is": "Icelandic",
    "hy": "Armenian",
    "ne": "Nepali",
    "mn": "Mongolian",
    "bs": "Bosnian",
    "kk": "Kazakh",
    "sq": "Albanian",
    "sw": "Swahili",
    "gl": "Galician",
    "mr": "Marathi",
    "pa": "Punjabi",
    "si": "Sinhala",
    "km": "Khmer",
    "sn": "Shona",
    "yo": "Yoruba",
    "so": "Somali",
    "af": "Afrikaans",
    "oc": "Occitan",
    "ka": "Georgian",
    "be": "Belarusian",
    "tg": "Tajik",
    "sd": "Sindhi",
    "gu": "Gujarati",
    "am": "Amharic",
    "yi": "Yiddish",
    "lo": "Lao",
    "uz": "Uzbek",
    "fo": "Faroese",
    "ht": "Haitian creole",
    "ps": "Pashto",
    "tk": "Turkmen",
    "nn": "Nynorsk",
    "mt": "Maltese",
    "sa": "Sanskrit",
    "lb": "Luxembourgish",
    "my": "Myanmar",
    "bo": "Tibetan",
    "tl": "Tagalog",
    "mg": "Malagasy",
    "as": "Assamese",
    "tt": "Tatar",
    "haw": "Hawaiian",
    "ln": "Lingala",
    "ha": "Hausa",
    "ba": "Bashkir",
    "jw": "Javanese",
    "su": "Sundanese",
    "yue": "Cantonese",
};

var start_stop_button_el = document.getElementById("start_stop_button");
var reset_button_el = document.getElementById("reset_button");
var message_list_el = document.getElementById("message_list");
var model_el = document.getElementById("model");
var voice_enable_el = document.getElementById("voice_enable");
var voice_el = document.getElementById("voice");
var language_el = document.getElementById("language");
var expert_params_el = document.getElementById("expert_params");
var expert_el = document.getElementById("expert");
var topk_el = document.getElementById("topk");
var topp_el = document.getElementById("topp");
var max_tokens_el = document.getElementById("max_tokens");
var vad_start_delay_el = document.getElementById("vad_start_delay");
var vad_stop_delay_el = document.getElementById("vad_stop_delay");
var instructions_el = document.getElementById("instructions");
var param_error_el = document.getElementById("param_error");
var record_icon_el = document.getElementById("record_icon");

function show_state(str)
{
    console.log("state:", str);
}

function display_speech_state(enabled)
{
    record_icon_el.style.visibility = enabled ? "visible" : "hidden";
}

function html_escape(s)
{
    s = s.replaceAll('&', '&amp').replaceAll('<', '&lt').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
    /* nicer markdown programs:
       ```
       program
       ```
       ->
       <pre>
       program
       </pre>
     */
    s = s.replaceAll(/\n```([^`]*)(\n```|$)/g, "<pre>$1</pre>");
    return s;
}

/* only trim the "space" character */
function trim_spaces(str)
{
    var l, i, j;
    l = str.length;
    i = 0;
    while (i < l && str[i] == ' ')
        i++;
    j = l;
    while (j > i && str[j - 1] == ' ')
        j--;
    return str.slice(i, j);
}

function set_param_error(e)
{
    if (e === "") {
        param_error_el.innerHTML = '';
    } else {
        param_error_el.innerHTML = '<div class="alert alert-danger">' + e + '</div>';
    }
}

/* role is "user" or "bot" */
function display_message(msg, role)
{
    var div_el;

    div_el = document.createElement("div");
    div_el.className = "message " + role;
    div_el.innerHTML = html_escape(msg);

    message_list_el.appendChild(div_el);
    div_el.scrollIntoView(false);
    return div_el;
}

function output_text_update()
{
    output_text_el.innerHTML = html_escape(raw_output_text);
    output_text_el.scrollIntoView(false);
}

function disable_parameters(disabled)
{
    if (page_type == "voice_chat") {
        model_el.disabled = disabled;
        voice_enable_el.disabled = disabled;
        voice_el.disabled = disabled;
        topk_el.disabled = disabled;
        topp_el.disabled = disabled;
        max_tokens_el.disabled = disabled;
        instructions_el.disabled = disabled;
    }
    language_el.disabled = disabled;
    vad_start_delay_el.disabled = disabled;
    vad_stop_delay_el.disabled = disabled;
}

function websocket_onopen()
{
    var ws = this;
    var msg;
    
    switch(page_type) {
    case "voice_chat":
        /* ensuite that there is no pending user message in the history */
        if ((cur_messages.length % 2) != 0)
            cur_messages.pop();
        msg = { type: "session.update",
                session: {
                    "language": language_el.value,
                    "voice_enable": voice_enable_el.checked,
                    "voice": voice_el.value,
                    "instructions": instructions_el.value,
                    "top_k": +topk_el.value,
                    "top_p": +topp_el.value,
                    "max_tokens": +max_tokens_el.value,
                    "messages": cur_messages,
                }
              };
        break;
    case "stt":
    default:
        msg = { type: "session.update",
                session: {
                    "language": language_el.value,
                },
              };
        break;
    }

    ws.send(JSON.stringify(msg));
    
    show_state("connected");
}

function websocket_onclose(event)
{
    console.log("WebSocket disconnected. Code: ", event.code, "Reason", event.reason);
    if (event.code == 4000) {
        /* captcha required */
        captcha_start();
    } else {
        /* otherwise: stop */
        if (event.code == 3000) {
            set_param_error("authorization error");
        } else if (event.code == 4001) {
            set_param_error("quota reached for free access");
        }
        
        if (audioSource)
            audioSource.disconnect();
        audioSource = null;
        websocket = null;

        disable_parameters(false);
        display_speech_state(false);
        start_stop_button.innerHTML = "Start";
        show_state("stopped");
    }
}

function websocket_onerror(error)
{
    console.log("websocket error:", error);
    /* we don't want to display errors about closed websockets */
    if (this == websocket )
        set_param_error("WebSocket error");
}

function websocket_onmessage(event)
{
    if (event.data instanceof ArrayBuffer) {
        /* flush the current audio output in case the
         * previous response is still being played back
         * but interrupted */
        if (got_audio_done) {
            got_audio_done = false;
            if (audio_worklet) {
                audio_worklet.port.postMessage({ event_type: 4 });
            }
        }
        if (audio_worklet) {
            audio_worklet.port.postMessage({ event_type: 3, buffer: new Uint8Array(event.data)});
        }
    } else {
        // Handle JSON messages
//        console.log("msg=" + event.data);
        var msg = JSON.parse(event.data);
        switch(msg.type) {
        case "transcript.delta":
            if (last_turn != 0) {
                last_turn = 0;
                output_text_el = display_message("", "user");
                raw_output_text = ""
            }
            raw_output_text += msg.delta;
            output_text_update();
            break;
        case "transcript.done":
            if (page_type == "stt") {
                last_turn = -1; /* next transcript delta will show
                                   a new message */
            } else {
                cur_messages.push(raw_output_text);
            }
            break;
        case "response.text.delta":
            if (last_turn != 1) {
                last_turn = 1;
                output_text_el = display_message("", "bot");
                raw_output_text = ""
            }
            raw_output_text += msg.delta;
            output_text_update();
            break;
        case "response.text.done":
            cur_messages.push(raw_output_text);
            break;
        case "response.audio.done":
            got_audio_done = true;
            break;
        default:
            console.log("unexpected message" + event.data);
            break;
        }
    }
}

function websocket_open()
{
    var url, ws;
    
    switch(page_type) {
    case "voice_chat":
        url = ws_api_url + "/v1/realtime_chat?model=" + model_el.value;
        break;
    case "stt":
        url = ws_api_url + "/v1/realtime_transcript";
        break;
    }
    ws = new WebSocket(url);
    ws.binaryType = "arraybuffer";

    ws.onopen = websocket_onopen;

    ws.onclose = websocket_onclose;
    
    ws.onerror = websocket_onerror;

    ws.onmessage = websocket_onmessage;

    websocket = ws;
}

function stop_recording()
{
    if (audioSource)
        audioSource.disconnect();
    audioSource = null;
    
    if (websocket) {
        websocket.close();
        websocket = null;
    }
    disable_parameters(false);
    display_speech_state(false);
    
    start_stop_button.innerHTML = "Start";
    show_state("stopped");
}

function button_start_stop()
{
    if (audioSource) {
        stop_recording();
    } else {
        set_param_error("");

        navigator.mediaDevices.getUserMedia({ audio: {
            channelCount: 1,
            echoCancellation: true,
            autoGainControl: true,
            noiseSuppression: true,
            sampleRate: 16000
        } }).then(record_start1);
    }
}

function record_start1(stream)
{
    audioContext = new AudioContext();
    audioSource = audioContext.createMediaStreamSource(stream);
    audioContext.audioWorklet.addModule("voice_chat_worklet.js").then(record_start2);
}

function record_start2()
{
    if (!websocket) {
        websocket_open();
    }

    audio_worklet = new AudioWorkletNode(audioContext, "voice_chat_worklet", {
        processorOptions: {
            vad_start_delay: vad_start_delay_el.value | 0,
            vad_stop_delay: vad_stop_delay_el.value | 0,
        }
    });
    
    audio_worklet.port.onmessage = (ev) => {
        var msg = ev.data;
        var event_type = msg.event_type;
        //        console.log("msg", msg.event_type);
        switch(event_type) {
        case 0:
            display_speech_state(true);
            break;
        case 1:
            display_speech_state(false);
            websocket.send(JSON.stringify({ "type": "input_audio_buffer.commit" }));
            break;
        case 2:
            websocket.send(msg.buffer);
            break;
        }
    };
    
    audioSource.connect(audio_worklet).connect(audioContext.destination);
    
    disable_parameters(true);
    start_stop_button.innerHTML = "Stop";
    show_state("running");
}

function captcha_solved()
{
    websocket_open();
}

function button_reset()
{
    stop_recording();

    cur_messages = [];
    while (message_list_el.firstChild) {
        message_list_el.removeChild(message_list_el.lastChild);
    }
    set_param_error("");
    show_state("disconnected");
}

function expert_change()
{
    if (expert_el.checked)
        expert_params_el.style.display = "block";
    else
        expert_params_el.style.display = "none";
}

function init_voices()
{
    var i, select_html, v;

    select_html = "";
    for(i = 0; i < voice_list.length; i++) {
        v = voice_list[i];
        select_html += '<option value="' + v + '">' + v + '</option>';
    }
    voice_el.innerHTML = select_html;
}

function init_languages()
{
    var i, select_html, v, langs, k;
    langs = Object.keys(transcript_languages);
    select_html = "";
    for(i = 0; i < langs.length; i++) {
        k = langs[i];
        v = transcript_languages[k]
        select_html += '<option value="' + k + '">' + v + '</option>';
    }
    language_el.innerHTML = select_html;
}

function init()
{
    if (topk_el)
        page_type = "voice_chat";
    else
        page_type = "stt";

    show_state("disconnected");

    start_stop_button_el.addEventListener('click', button_start_stop);

    reset_button_el.addEventListener('click', button_reset);

    expert_el.addEventListener("change", expert_change);
    
    if (page_type == "voice_chat") {
        update_models("chat");
        init_voices();
        topk_el.value = "40";
        topp_el.value = "0.9";
        max_tokens_el.value = "500";
        expert_el.checked = false;
        voice_enable_el.checked = true;
        instructions_el.value = "You are a helpful, respectful and honest assistant. Always answer as helpfully as possible, while being safe. Your answers should not include any harmful, unethical, racist, sexist, toxic, dangerous, or illegal content. Please ensure that your responses are socially unbiased and positive in nature. If a question does not make any sense, or is not factually coherent, explain why instead of answering something not correct. If you don't know the answer to a question, please don't share false information. In any case, try to give concise answers because your answers are translated to speech.";
    } else {
        init_languages();
    }
    vad_start_delay_el.value = "500"; /* ms */
    vad_stop_delay_el.value = "500"; /* ms */
}

window.onload = init;

