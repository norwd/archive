/* Copyright (c) 2024-2025 Fabrice Bellard */
import Module from './opus.js';

var opus_enc_init = Module.cwrap("opus_enc_init", null, [ "number", "number", "number", "number", "number", "number", "number" ]);
var opus_enc_process = Module.cwrap("opus_enc_process", null, ["number", "number"]);

var opus_dec_init = Module.cwrap("opus_dec_init", null, [ "number" ]);
var opus_dec_queue = Module.cwrap("opus_dec_queue", null, [ "number", "number" ]);
var opus_dec_flush = Module.cwrap("opus_dec_flush", null, [ ]);
var opus_dec_process = Module.cwrap("opus_dec_process", "number", [ "number" ]);

class Processor extends AudioWorkletProcessor {
    constructor(options) {
        var opt;
        super();
        opt = options.processorOptions;

        opus_enc_init(sampleRate, 16000, 20, 48000, 3,
                      opt.vad_start_delay, opt.vad_stop_delay, 100);
        opus_dec_init(sampleRate);

        /* called by opus_enc_process() */
        Module["opusCallback"] = (event_type, buf) => {
            this.port.postMessage(
                { event_type: event_type, buffer: buf });
        }
        this.port.onmessage = (ev) => {
            var msg = ev.data;
            switch(msg.event_type) {
            case 3: /* audio data */
                var buf = msg.buffer;
                var buf_len = buf.length;
                var buf_addr = Module._malloc(buf_len | 0);
                //            console.log("msg event_type=", msg.event_type);
                Module.HEAPU8.set(buf, buf_addr);
                opus_dec_queue(buf_addr | 0, buf_len | 0);
                break;
            case 4: /* audio flush */
                opus_dec_flush();
                break;
            }
        }
    }
    process(inputs, outputs, parameters) {
        var input0 = inputs[0];
        if (input0.length < 1)
            return true; /* no more input, happens when closing */
        var buf = input0[0];
        var buf_len = buf.length;
        var out_buf = outputs[0][0];
        var out_buf_len = out_buf.length;

        //        console.log("process:", buf_len, out_buf_len);

        /* send input to encoder */
        var buf_addr = Module._malloc((buf_len * 4) | 0);
        Module.HEAPF32.set(buf, buf_addr >> 2);
        opus_enc_process(buf_addr, buf_len);
        Module._free(buf_addr);

        /* get output from decoder */
        var out_buf_addr = opus_dec_process(out_buf_len);
        out_buf.set(Module.HEAPF32.subarray(out_buf_addr >> 2, (out_buf_addr >> 2) + out_buf_len));
        Module._free(out_buf_addr);
        
        return true;
    }
}

registerProcessor("voice_chat_worklet", Processor);
