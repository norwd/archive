/* Copyright (c) 2024 Fabrice Bellard */
"use strict";
var tts_active_state = 0; /* 0 = inactive, 1 = request in progress, 
                             2 = playback in progress */
var cancel_request = false;
var raw_output_text = "";
var output_text = "";
var input_text = "";
var model_params = "";
var http_api_url = "http://localhost:8080";
var req;
var audioCtx, audioSource;

var voice_list = ["Will","Eric","Laura","Alisa","Patrick","Rose","Jerry","Jordan","Lauren","Jenna","Karen","Rick","Bill","James","Yann","Emily","Anna","Jon","Brenda","Barbara"];

var button_el = document.getElementById("start_button");
var input_text_el = document.getElementById("input_text");
var model_el = document.getElementById("model");
var voice_el = document.getElementById("voice");
var param_error_el = document.getElementById("param_error");
var seed_el = document.getElementById("seed");
var select_example_el = document.getElementById("select_example");

function html_escape(s)
{
    var i, r, c;
    r = "";
    for(i = 0; i < s.length; i++) {
        c = s[i];
        switch(c) {
        case "<":
            r += "&lt;";
            break;
        case ">":
            r += "&gt;";
            break;
        case "&":
            r += "&amp;";
            break;
        case "\"":
            r += "&quot;";
            break;
        default:
            r += c;
            break;
        }
    }
    return r;
}

function start_button()
{
    if (tts_active_state != 0) {
        if (tts_active_state == 1) {
            cancel_request = true;
            req.abort();
        } else {
            play_abort();
        }
    } else {
        tts_start();
    }
}

function set_param_error(e)
{
    if (e === "") {
        param_error_el.innerHTML = '';
    } else {
        param_error_el.innerHTML = '<div class="alert alert-danger">' + e + '</div>';
    }
}

function show_warning(e)
{
    var el;
    el = document.getElementById("param_error");
    el.innerHTML = '<div class="alert alert-warning">' + e + '</div>';
}

function tts_start()
{
    var req_data, source_lang, target_lang, input_text;

    input_text = input_text_el.value;
    if (input_text != "") {

        set_param_error("");

        req_data = { input: input_text, voice: voice_el.value, seed: seed_el.value | 0 };

        req = new XMLHttpRequest();
        req.onreadystatechange = req_on_ready_state_change;
        req.open("POST", http_api_url + "/v1/engines/" + model_el.value + "/speech");
        req.setRequestHeader('Content-Type', 'application/json');
        req.responseType = "arraybuffer";
        req.send(JSON.stringify(req_data));
        
        button_el.innerHTML = "Stop";
        
        tts_active_state = 1;
        cancel_request = false;
        audioCtx = new AudioContext();
    }
}

function play_end_cb()
{
    tts_end();
    audioSource = null;
}

function play_audio_cb(buffer)
{
    var source = audioCtx.createBufferSource();
    source.buffer = buffer;
    source.connect(audioCtx.destination);
    source.onended = play_end_cb;
    source.start();
    audioSource = source;
}

function play_audio(audio_data)
{
    audioCtx.decodeAudioData(audio_data, play_audio_cb);
}

function play_abort()
{
    audioSource.stop();
}

function req_on_ready_state_change(ev)
{
    var tab, i, resp, msg;

    if (req.readyState == 4 && req.status == 200) {
        play_audio(req.response);
        tts_active_state = 2;
    } else if (req.readyState == 4) {
        if (!cancel_request) {
            try {
                resp = JSON.parse(req.responseText);
                msg = resp.error;
            } catch(err) {
                msg = "Server error";
            }
            set_param_error(msg);
        }
        tts_end();
    }
}

function tts_end()
{
    button_el.innerHTML = "Start";
    tts_active_state = 0;
}

function init_voices()
{
    var i, select_html, v;

    select_html = "";
    for(i = 0; i < voice_list.length; i++) {
        v = voice_list[i];
        select_html += '<option value="' + v + '">' + v + '</option>';
    }
    voice_el.innerHTML = select_html;
}

function select_example_change()
{
    if (select_example_el.value != "") 
        input_text_el.value = select_example_el.value;
}

function tts_init()
{
    input_text_el.value = "";
    update_models("text_to_speech");
    seed_el.value = "0";
    
    button_el.addEventListener('click', start_button);
    init_voices();

    select_example_el.value = "";
    select_example_el.addEventListener('change', select_example_change);
}

window.onload = tts_init;
