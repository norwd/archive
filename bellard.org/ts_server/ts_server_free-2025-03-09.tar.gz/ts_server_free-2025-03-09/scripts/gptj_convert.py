import sys
import numpy as np
import jax
import jax.numpy as jnp
import struct
import math
import io
import json

def write_libnc_param_header(f, json_config):
    config = json.dumps(json_config)
    str = config.encode('utf-8')
    f.write(struct.pack("ii", 0x23f4aefb, len(str)))
    f.write(str)
    
def write_libnc_param(f, array, param_name):
    print("{:30} {:20} {:10}".format(param_name, str(array.shape), str(array.dtype)))
    dtype_str = str(array.dtype)
    if dtype_str == "float32":
        type_id = 0
    elif dtype_str == "float16":
        type_id = 2
    elif dtype_str == "bfloat16":
        type_id = 1
    else:
        print("unsupported type: " + dtype_str)
        assert(0)

    array = array.squeeze()
    n_dims = len(array.shape);

    # variable header
    name = param_name.encode('utf-8')
    f.write(struct.pack("iiii", 0x23f4aefa, type_id, n_dims, len(name)))
    for i in range(n_dims):
        f.write(struct.pack("i", array.shape[n_dims - 1 - i]))
    f.write(name);
    # variable data
    array.tofile(f)

def concat_param(models, name, axis = 0):
    tab = []
    for i in range(len(models)):
        w = models[i][name].numpy()
        tab.append(w)
    return np.concatenate(tab, axis = axis)



def load_npz(fname):
    with open(fname, "rb") as f:
        buf = f.read()
        return np.load(io.BytesIO(buf))

def load_shard(shard_path):
    out = []
    for piece_num in range(16):
        fname = shard_path + "/" + str(piece_num) + ".npz"
        print("loading", fname)
        dict = load_npz(fname)
        for name in dict:
            arr = dict[name]
            if arr.dtype == np.dtype("V2"):
                arr.dtype = jnp.bfloat16
            out.append(arr)
    return out

def concat_param(params, param_index, axis = 0):
    tab = []
    for i in range(len(params)):
        tab.append(params[i][param_index])
    return np.concatenate(tab, axis = axis)

def same_param(params, param_index):
    return params[0][param_index]

def convert_params(model_path, out_filename):
    params = []
    for shard_num in range(8):
        shard = load_shard(model_path + "/shard_" + str(shard_num))
#        for arr in shard:
#            print("  ", arr.shape, arr.dtype)
        params.append(shard)
    n_layers = 28
    d_model = 4096
    
    f = open(out_filename, "wb")

    write_libnc_param_header(f, {"type": "gptj", "data_type": "bf16", "n_layer": n_layers, "d_model": d_model });
    
    # embedding bias
    wte_bias = same_param(params, 0) * 8
    w = concat_param(params, 1, 0) + wte_bias
    write_libnc_param(f, w, "wte")

    # the layers are stored in alphabetical order
    layer_names = sorted(map(str, range(n_layers)))
    
    for layer_num in range(n_layers):
        out_prefix = "h" + layer_names[layer_num] + "/"
        w_q = concat_param(params, 10 * layer_num + 2, 1)
        w_v = concat_param(params, 10 * layer_num + 3, 1)
        w_k = concat_param(params, 10 * layer_num + 4, 1)
        w = np.concatenate((w_q, w_k, w_v), axis = 1)
        write_libnc_param(f, w, out_prefix + "attn/c_attn/w")
        
        w = concat_param(params, 10 * layer_num + 5, 0)
        write_libnc_param(f, w, out_prefix + "attn/c_proj/w")

        w = concat_param(params, 10 * layer_num + 6, 0)
        write_libnc_param(f, w, out_prefix + "mlp/c_fc/b")
        
        w = concat_param(params, 10 * layer_num + 7, 1)
        write_libnc_param(f, w, out_prefix + "mlp/c_fc/w")

        w = same_param(params, 10 * layer_num + 8) * 8
        write_libnc_param(f, w, out_prefix + "mlp/c_proj/b")

        w = concat_param(params, 10 * layer_num + 9, 0)
        write_libnc_param(f, w, out_prefix + "mlp/c_proj/w")

        w = same_param(params, 10 * layer_num + 10)
        write_libnc_param(f, w, out_prefix + "ln_1/b")
        
        w = same_param(params, 10 * layer_num + 11)
        write_libnc_param(f, w, out_prefix + "ln_1/g")

    w = concat_param(params, 10 * 28 + 2)
    write_libnc_param(f, w, "proj_f/b")
    
    w = concat_param(params, 10 * 28 + 3, 1)
    write_libnc_param(f, w, "proj_f/w")

    w = same_param(params, 10 * 28 + 4)
    write_libnc_param(f, w, "ln_f/b")
    
    w = same_param(params, 10 * 28 + 5)
    write_libnc_param(f, w, "ln_f/g")

    f.close()

            
if len(sys.argv) != 3:
    print("""usage: convert.py model_dir output_file

Convert a GPT-J-6B parameter dump to a LibNC one.

model_dir is the filename containing the JAX parameter dump
output_file is filename of the libNC parameter dump""")
    sys.exit(1)

convert_params(sys.argv[1], sys.argv[2])
