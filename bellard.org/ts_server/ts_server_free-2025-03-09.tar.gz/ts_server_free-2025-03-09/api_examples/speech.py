# TextSynth text to speech example
import sys
import argparse
import requests
import json
import time
import base64

parser = argparse.ArgumentParser(description='TextSynth text to speech example')
parser.add_argument('--url', type=str, default = "http://localhost:8080", help="server URL")
parser.add_argument('--api_key', type=str, default = "")
parser.add_argument('-f', type=str, default = "", help = "input text from file")
parser.add_argument('-o', type=str, default = "/tmp/out.mp3", help="output audio file")
parser.add_argument('--voice', '-V', type=str, default = "Laura", help = "select the voice")
parser.add_argument('text', type=str, nargs='?', help="input text")
parser.add_argument('--seed', type=int, default = None, help="seed (0 = random)")
parser.add_argument('--model', type=str, default = "parler_tts", help = "model name")

args = parser.parse_args()

def make_request(path, json):
    response = requests.post(args.url + path, headers = { "Authorization": "Bearer " + args.api_key }, json = json)
    return response

def main():
    if args.f != "":
        if args.text != None:
            print("the input text must be provided either with -f or as first argument");
            sys.exit(1)
        f = open(args.f, "r")
        input_text = f.read()
        f.close()
    elif args.text != None:
        input_text = args.text
    else:
        parser.print_help()
        sys.exit(1)
    
    req = { "input": input_text, "voice": args.voice }

    if args.seed != None:
        req["seed"] = args.seed
    
    result = make_request("/v1/engines/" + args.model + "/speech", req);
    if result.status_code != 200:
        print("Request error:", result.text)
        sys.exit(1)
        
    f = open(args.o, "wb")
    f.write(result.content)
    f.close()
    
main()
