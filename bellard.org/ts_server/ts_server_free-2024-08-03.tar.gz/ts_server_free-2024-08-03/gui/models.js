/* Copyright (c) 2023 Fabrice Bellard */
"use strict";
var models_req, model_list;

function get_model(short_name)
{
    var i, model;
    for(i = 0; i < model_list.length; i++) {
        model = model_list[i];
        if (model.short_name == short_name)
            return model;
    }
    return null
}

function lang_cmp(a, b)
{
    return a.lang > b.lang;
}

function update_lang_select()
{
    var el, lang_select, model, languages, i, e;

    model = get_model(document.getElementById("model").value)
    if (model == null)
        return;
    languages = model.languages;

    languages = languages.sort(lang_cmp)
    
    lang_select = "";
    for(i = 0; i < languages.length; i++) {
        e = languages[i];
        lang_select += '<option value="' + e.code + '">' + e.lang + '</option>';
    }
    
    el = document.getElementById("source_lang");
    el.innerHTML = '<option value="auto">Auto-detect</option>' + lang_select;
    el.value = "auto";

    el = document.getElementById("target_lang");
    el.innerHTML = lang_select;
    el.value = "fr";
}

function update_models(model_type) {
    var resp, i, models, model, selected, select_html, el;

    if (model_type == "chat")
        model_type = "completion";
    select_html = "";
    
    models_req = new XMLHttpRequest();
    models_req.open('GET', http_api_url + "/v1/engines");
    models_req.onload = function() {
        if (models_req.status == 200) {
            try {
                resp = JSON.parse(models_req.responseText);
                models = resp.models;
                model_list = models;
                for(i = 0; i < models.length; i++) {
                    model = models[i];
                    selected = false;
                    if (model_type in model)
                        selected = model[model_type];
                    if (selected) {
                        select_html += '<option value="' + model.id + '">' + model.short_name + '</option>';
                    }
                }
                el = document.getElementById("model");
                el.innerHTML = select_html;
                if (model_type == "translation")
                    update_lang_select();
            } catch(err) {
            }
        }
    };
    models_req.send();
}

