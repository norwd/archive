import math
import torch
import numpy as np
import sys
import json
import struct

def get_embedding(num_embeddings, embedding_dim, padding_idx = None):
    """Build sinusoidal embeddings.
    
    This matches the implementation in tensor2tensor, but differs slightly
    from the description in Section 3.5 of "Attention Is All You Need".
    """
    half_dim = embedding_dim // 2
    emb = math.log(10000) / (half_dim - 1)
    emb = torch.exp(torch.arange(half_dim, dtype=torch.float) * -emb)
    emb = torch.arange(num_embeddings, dtype=torch.float).unsqueeze(
        1
    ) * emb.unsqueeze(0)
    emb = torch.cat([torch.sin(emb), torch.cos(emb)], dim=1).view(
        num_embeddings, -1
    )
    if embedding_dim % 2 == 1:
        # zero pad
        emb = torch.cat([emb, torch.zeros(num_embeddings, 1)], dim=1)
    if padding_idx is not None:
        emb[padding_idx, :] = 0
    return emb

def write_libnc_param_header(f, json_config):
    config = json.dumps(json_config)
    str = config.encode('utf-8')
    f.write(struct.pack("ii", 0x23f4aefb, len(str)))
    f.write(str)

# write numpy parameter
def write_libnc_param(f, array, param_name):
    print("{:30} {:20} {:10}".format(param_name, str(array.shape), str(array.dtype)))
    dtype_str = str(array.dtype)
    if dtype_str == "float32":
        type_id = 0
    elif dtype_str == "float16":
        type_id = 2
    elif dtype_str == "bfloat16":
        type_id = 1
    elif dtype_str == "uint8":
        type_id = 6
    else:
        print("unsupported type: " + dtype_str)
        assert(0)

    n_dims = len(array.shape);

    # variable header
    name = param_name.encode('utf-8')
    f.write(struct.pack("iiii", 0x23f4aefa, type_id, n_dims, len(name)))
    for i in range(n_dims):
        f.write(struct.pack("i", array.shape[n_dims - 1 - i]))
    f.write(name);
    # variable data
    array.tofile(f)

# same for pytorch    
def write_libnc_param_pt(f, array, param_name):
    dtype = array.dtype
    print("{:30} {:20} {:10}".format(param_name, str(array.shape), str(dtype)))
    if dtype == torch.float32:
        type_id = 0
    elif dtype == torch.float16:
        type_id = 2
    elif dtype == torch.bfloat16:
        type_id = 1
    else:
        print("unsupported type: " + str(dtype))
        assert(0)

    n_dims = len(array.shape);

    # variable header
    name = param_name.encode('utf-8')
    f.write(struct.pack("iiii", 0x23f4aefa, type_id, n_dims, len(name)))
    for i in range(n_dims):
        f.write(struct.pack("i", array.shape[n_dims - 1 - i]))
    f.write(name);
    # variable data
    if dtype == torch.bfloat16:
        # numpy does not support bfloat16 yet
        v = array.view(torch.int16)
    else:
        v = array
    v.numpy().tofile(f)

def write_libnc_tokenizer(f, filename, param_name):
    g = open(filename, "rb")
    data = g.read()
    g.close()
    data = np.frombuffer(data, dtype=np.uint8)
    write_libnc_param(f, data, param_name)
    
def load_pytorch_model(path):
    p = path.find("-of-")
    if p < 0:
        return torch.load(path, map_location="cpu")
    n_files = int(path[p + 4 : p + 4 + 5])
    assert n_files >= 1
    m = {}
    for file_index in range(n_files):
        filename = path[0:p - 5] + "{:05d}-of-{:05d}".format(file_index + 1, n_files) + path[p + 4 + 5:]
        print("filename=", filename)
        d = torch.load(filename, map_location="cpu")
        for k, v in d.items():
            m[k] = v;
    return m
