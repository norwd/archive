/* Copyright (c) 2019 Fabrice Bellard */
"use strict";
var output_text_active = false;
var cancel_request = false;
var raw_output_text = "";
var output_text = "";
var input_text = "";
var model_params = "";
var http_api_url = "http://localhost:8080";
var req;
var cur_response_len;

var button_el = document.getElementById("submit_button");
var more_button_el = document.getElementById("more_button");

function html_escape(s)
{
    var i, r, c;
    r = "";
    for(i = 0; i < s.length; i++) {
        c = s[i];
        switch(c) {
        case "<":
            r += "&lt;";
            break;
        case ">":
            r += "&gt;";
            break;
        case "&":
            r += "&amp;";
            break;
        case "\"":
            r += "&quot;";
            break;
        default:
            r += c;
            break;
        }
    }
    return r;
}

/* just handle '\n' */
function string_escape(s)
{
    var i, r, c;
    r = "";
    for(i = 0; i < s.length; i++) {
        c = s[i];
        if (c === '\\') {
            i++;
            c = s[i];
            if (c == 'n')
                r += '\n';
            else
                r += c;
        } else {
            r += c;
        }
    }
    return r;
}

/* only trim the "space" character */
function trim_spaces(str)
{
    var l, i, j;
    l = str.length;
    i = 0;
    while (i < l && str[i] == ' ')
        i++;
    j = l;
    while (j > i && str[j - 1] == ' ')
        j--;
    return str.slice(i, j);
}

var example_inputs = {
    "en": [
        { prompt: "In a shocking finding, scientist discovered a herd of unicorns living in a remote, previously unexplored valley, in the Andes Mountains. Even more surprising to the researchers was the fact that the unicorns spoke perfect English." },
        { prompt: "My name is John. I am 34 year old.\n\nQ: What is my name ?\nA:", top_k: 1, stop: "\\nQ" },
        { prompt: "int main(int argc, char **argv) {" },
        { prompt: "Making an omelette is simple!\n\n1." },
        { prompt: "The Linux kernel is" },
        { prompt: "Game of Thrones is" },
        { prompt: "<html>" },
        { prompt: "The election to the European Parliament" },
        { prompt: "The United States Air Force facility commonly known as Area 51 is a highly classified remote detachment" },
    ],
    "fr": [
        { prompt: "Je recherche du travail en tant que développeur web après avoir terminé mes études d'informatique. Voici ma lettre de motivation pour une grande agence parisienne.\n\n\nMadame, monsieur,\n\n" },
        { prompt: "Je dois écrire un article sur le fromage en France. Voici des idées à développer dans un article:" },
        { prompt: "Q : Qui est Batman ?\nR : Batman est un personnage de bande dessinée fictif.\n\nQ : Qu'est-ce qu'un atome ?\nR : Un atome est une minuscule particule qui compose tout.\n\nQ : Qu'est-ce qui orbite autour de la Terre ?\nR : La lune orbite autour de la Terre.\n\nQ : Qu'est-ce qu'une étoile ?\nR :", top_k: 1, stop: "\\nQ" },
    ]
};
    
function reset_params()
{
    var el;
    
    el = document.getElementById("topk");
    el.value = "40";

    el = document.getElementById("topp");
    el.value = "0.9";

    el = document.getElementById("temperature");
    el.value = "1.0";

    el = document.getElementById("max_tokens");
    el.value = "200";

    el = document.getElementById("stop");
    el.value = "";
}

function on_select(lang)
{
    var select_el = document.getElementById("select_" + lang);
    var input_text_el = document.getElementById("input_text");
    var val = select_el.value | 0;
    var r;
    if (val) {
        r = example_inputs[lang][val - 1];
        input_text_el.value = r.prompt;
        reset_params();
        if ("top_k" in r) {
            document.getElementById("topk").value = r.top_k;
        }
        if ("stop" in r) {
            document.getElementById("stop").value = r.stop;
        }
    }
}

function on_model_select()
{
    var model = document.getElementById("model").value;
    var lang;
    if (model == "boris_6B")
        lang = "fr";
    else
        lang = "en";
    if (lang == "fr") {
        document.getElementById("select_fr").style.display = "inline";
        document.getElementById("select_en").style.display = "none";
    } else {
        document.getElementById("select_fr").style.display = "none";
        document.getElementById("select_en").style.display = "inline";
    }
}

function output_text_update()
{
    var gtext_el = document.getElementById("gtext");
    gtext_el.innerHTML = output_text;
}

function complete_init()
{
    var el;
    el = document.getElementById("input_text");
    el.value = "";

    el = document.getElementById("select_en");
    el.value = "0";

    el = document.getElementById("select_fr");
    el.value = "0";

    update_models("completion");

    reset_params();
}

function button_submit()
{
    var input_text_el = document.getElementById("input_text");

    if (output_text_active) {
        cancel_request = true;
        req.abort();
    } else {
        complete_start(input_text_el.value, false);
    }
}

function button_more()
{
    complete_start(raw_output_text, true);
}

function set_param_error(e)
{
    var el;
    el = document.getElementById("param_error");
    if (e === "") {
        el.innerHTML = '';
    } else {
        el.innerHTML = '<div class="alert alert-danger">' + e + '</div>';
    }
}

function show_warning(e)
{
    var el;
    el = document.getElementById("param_error");
    el.innerHTML = '<div class="alert alert-warning">' + e + '</div>';
}

function complete_start(str, more_output)
{
    var gtext_header_el = document.getElementById("gtext_header");
    var model, req_data, top_p, temperature, top_k, max_tokens, stop, stream;
    
    input_text = trim_spaces(str);
    if (input_text != "") {

        set_param_error("");

        model = document.getElementById("model").value;

        top_k = document.getElementById("topk").value | 0;
        if (top_k < 1 || top_k > 1000) {
            set_param_error("top-k must be between 1 and 1000");
            return;
        }

        top_p = +document.getElementById("topp").value;
        if (top_p <= 0 || top_p > 1) {
            set_param_error("top-p must be between 0 and 1");
            return;
        }

        temperature = +document.getElementById("temperature").value;
        if (temperature <= 0.1 || temperature > 10) {
            set_param_error("temperature must be between 0.1 and 10");
            return;
        }

        stream = true;
        stop = document.getElementById("stop").value;

        if (stop !== "") {
            stop = string_escape(stop);
        } else {
            stop = null;
        }
        
        max_tokens = +document.getElementById("max_tokens").value;
        
        req_data = { prompt: input_text, temperature: temperature,
                     top_k: top_k, top_p: top_p, max_tokens: max_tokens,
                     stream: stream, stop: stop };
        cur_response_len = 0;

        req = new XMLHttpRequest();
        req.onreadystatechange = req_on_ready_state_change;
        req.open("POST", http_api_url + "/v1/engines/" + model + "/completions");
        req.setRequestHeader('Content-Type', 'application/json');
        req.send(JSON.stringify(req_data));
        
        gtext_header_el.style.display = "block";
        more_button_el.style.display = "none";
        
        button_el.innerHTML = "Stop";
        
        if (!more_output) {
            raw_output_text = input_text;
            output_text = "<b>" + html_escape(input_text) + "</b>";
        }
        output_text_update();
        output_text_active = true;
        cancel_request = false;
    }
}

function req_on_ready_state_change(ev)
{
    var tab, i, resp, msg;

    if ((req.readyState == 3 || req.readyState == 4) &&
        req.status == 200) {
        /* the responses are followed by '\n\n' */
        tab = req.responseText.split("\n\n");
        for(i = cur_response_len; i < tab.length - 1; i++) {
            resp = JSON.parse(tab[i]);
            handle_response(resp);
            if (i == 0 && resp.truncated_prompt) {
                show_warning("Warning: the start of your input was truncated because it is too long");
            }
        }
        cur_response_len = tab.length - 1;
    } else if (req.readyState == 4 && !cancel_request) {
        try {
            resp = JSON.parse(req.responseText);
            msg = resp.error;
        } catch(err) {
            msg = "Server error";
        }
        set_param_error(msg);
    }
    
    if (req.readyState == 4) {
        complete_end();
    }
}

function handle_response(resp)
{
    raw_output_text += resp.text;
    output_text += html_escape(resp.text);
    output_text_update();
}

function complete_end()
{
    button_el.innerHTML = "Generate another";
    more_button_el.style.display = "inline";
    output_text_active = false;
}
