/* Copyright (c) 2023 Fabrice Bellard */
"use strict";
var output_text_active = false;
var cancel_request = false;
var raw_output_text = "";
var allow_more_button = false;
var output_text_el = null;
var req;
var cur_response_len;
var cur_messages = [];
var submit_button_el = document.getElementById("submit_button");
var regen_button_el = document.getElementById("regen_button");
var more_button_el = document.getElementById("more_button");
var clear_history_button_el = document.getElementById("clear_history_button");
var message_list_el = document.getElementById("message_list");
var input_text_el = document.getElementById("input_text");
var max_tokens_el = document.getElementById("max_tokens");
var http_api_url = "http://localhost:8080";

function html_escape(s)
{
    s = s.replaceAll('&', '&amp').replaceAll('<', '&lt').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
    /* nicer markdown programs:
       ```
       program
       ```
       ->
       <pre>
       program
       </pre>
     */
    s = s.replaceAll(/\n```([^`]*)(\n```|$)/g, "<pre>$1</pre>");
    return s;
}

/* only trim the "space" character */
function trim_spaces(str)
{
    var l, i, j;
    l = str.length;
    i = 0;
    while (i < l && str[i] == ' ')
        i++;
    j = l;
    while (j > i && str[j - 1] == ' ')
        j--;
    return str.slice(i, j);
}

function reset_params()
{
    var el;
    
    el = document.getElementById("topk");
    el.value = "40";

    el = document.getElementById("topp");
    el.value = "0.9";

    el = document.getElementById("temperature");
    el.value = "1.0";

    max_tokens_el.value = "200";
}

/* role is "user" or "bot" */
function display_message(msg, role)
{
    var div_el;

    div_el = document.createElement("div");
    div_el.className = "message " + role;
    div_el.innerHTML = html_escape(msg);

    message_list_el.appendChild(div_el);
    div_el.scrollIntoView(false);
    return div_el;
}

function output_text_update()
{
    output_text_el.innerHTML = html_escape(raw_output_text);
    output_text_el.scrollIntoView(false);
}

function chat_init()
{
    var el;
    el = document.getElementById("input_text");
    el.value = "";

    update_models("chat");
    
    reset_params();
}

function button_submit()
{
    if (output_text_active) {
        cancel_request = true;
        req.abort();
    } else {
        complete_start(input_text_el.value, false);
        input_text_el.value = "";
    }
}

function button_regen()
{
    if (cur_messages.length >= 2) {
        cur_messages.pop();
        message_list_el.lastChild.innerHTML = "";
        raw_output_text = ""
        complete_start_internal();
    }
}

function button_more()
{
    complete_start("", true);
}

function clear_history()
{
    cur_messages = []
    output_text_el = null
    raw_output_text = ""
    while (message_list_el.firstChild) {
        message_list_el.removeChild(message_list_el.lastChild);
    }
    regen_button_el.style.display = "none";
    more_button_el.style.display = "none";
}

function set_param_error(e)
{
    var el;
    el = document.getElementById("param_error");
    if (e === "") {
        el.innerHTML = '';
    } else {
        el.innerHTML = '<div class="alert alert-danger">' + e + '</div>';
    }
}

function show_warning(e)
{
    var el;
    el = document.getElementById("param_error");
    el.innerHTML = '<div class="alert alert-warning">' + e + '</div>';
}

function complete_start(str, more_output)
{
    var input_text;
    if (!more_output) {
        input_text = trim_spaces(str);
        if (input_text == "")
            return;
        cur_messages.push(input_text);
        display_message(input_text, "user");
        output_text_el = display_message("", "bot");
        raw_output_text = ""
    }

    complete_start_internal();
}

function complete_start_internal()
{
    var model, req_data, top_p, temperature, top_k, max_tokens, stop, stream;
    
    set_param_error("");
    
    model = document.getElementById("model").value;
    
    top_k = document.getElementById("topk").value | 0;
    if (top_k < 1 || top_k > 1000) {
        set_param_error("top-k must be between 1 and 1000");
        return;
    }
    
    top_p = +document.getElementById("topp").value;
    if (top_p <= 0 || top_p > 1) {
        set_param_error("top-p must be between 0 and 1");
        return;
    }
    
    temperature = +document.getElementById("temperature").value;
    if (temperature <= 0.1 || temperature > 10) {
        set_param_error("temperature must be between 0.1 and 10");
        return;
    }
    
    stream = true;
    
    max_tokens = +max_tokens_el.value;
    
    req_data = { messages: cur_messages, temperature: temperature,
                 top_k: top_k, top_p: top_p, max_tokens: max_tokens,
                 stream: stream, stop: stop };
    cur_response_len = 0;
    
    req = new XMLHttpRequest();
    req.onreadystatechange = req_on_ready_state_change;
    req.open("POST", http_api_url + "/v1/engines/" + model + "/chat");
    req.setRequestHeader('Content-Type', 'application/json');
    req.send(JSON.stringify(req_data));
    
    more_button_el.style.display = "none";
    regen_button_el.style.display = "none";
    clear_history_button_el.style.display = "none";
    
    submit_button_el.innerHTML = "Stop";
    
    output_text_update();
    output_text_active = true;
    cancel_request = false;
}

function req_on_ready_state_change(ev)
{
    var tab, i, resp, msg;

    if ((req.readyState == 3 || req.readyState == 4) &&
        req.status == 200) {
        /* the responses are followed by '\n\n' */
        tab = req.responseText.split("\n\n");
        for(i = cur_response_len; i < tab.length - 1; i++) {
            resp = JSON.parse(tab[i]);
            if ("output_tokens" in resp) {
                /* allow the "more" button if the maximum number of
                   tokens was reached */
                allow_more_button = (resp["output_tokens"] >= +max_tokens_el.value);
            }
            if (resp.error) {
                set_param_error("Server error (" + resp.error + ")");
            } else {
                handle_response(resp);
                if (i == 0 && resp.truncated_prompt) {
                    show_warning("Warning: the start of your input was truncated because it is too long");
                }
            }
        }
        cur_response_len = tab.length - 1;
    } else if (req.readyState == 4 && !cancel_request) {
        try {
            resp = JSON.parse(req.responseText);
            msg = resp.error;
        } catch(err) {
            msg = "Server error";
        }
        set_param_error(msg);
    }
    
    if (req.readyState == 4) {
        complete_end();
    }
}

function handle_response(resp)
{
    raw_output_text += resp.text;
    output_text_update();
}

function complete_end()
{
    if ((cur_messages.length % 2) == 1) {
        /* normal case: add the reply */
        cur_messages.push(raw_output_text);
    } else {
        /* "more" case: extend the last reply */
        cur_messages[cur_messages.length - 1] == raw_output_text;
    }
    submit_button_el.innerHTML = "Send";
    if (allow_more_button)
        more_button_el.style.display = "inline";
    regen_button_el.style.display = "inline";
    clear_history_button_el.style.display = "inline";
    output_text_active = false;
}

