import sys
import torch
import numpy as np
import struct
import math
import json
from convert_utils import *

def get_param(model, name):
    return model[name].numpy()
    
def convert_params(in_filename, out_filename):
    dict = torch.load(in_filename, map_location=torch.device('cpu'))
    model = dict["model"]
    cfg = dict["cfg"]
    max_target_positions = cfg["model"]["max_target_positions"]
    decoder_embed_dim = cfg["model"]["decoder_embed_dim"]
    decoder_layers = cfg["model"]["decoder_layers"]
    
    f = open(out_filename, "wb")

    write_libnc_param_header(f, {"type": "fairseq_gpt", "data_type": "f16", "n_layer": decoder_layers, "d_model": decoder_embed_dim });

    print("{:30} {:20} {:10}".format("NAME", "SHAPE", "TYPE"))

    # sinusoidal embeddings
    # from fairseq/utils.py make_positions(), the first position is 2 assuming padding_idx = 1.
    w = get_embedding(max_target_positions + 2, decoder_embed_dim)
    w = w.to(torch.float16)
    w = w[2:,:]
    write_libnc_param(f, w.numpy(), "wpe")
    
    w = get_param(model, "decoder.embed_tokens.weight")
    write_libnc_param(f, w, "wte")
    
    for layer_num in range(decoder_layers):
        prefix = "decoder.layers." + str(layer_num) + "."
        out_prefix = "h" + str(layer_num) + "/"
        w_q = get_param(model, prefix + "self_attn.q_proj.weight")
        w_k = get_param(model, prefix + "self_attn.k_proj.weight")
        w_v = get_param(model, prefix + "self_attn.v_proj.weight")
        w = np.concatenate((w_q, w_k, w_v), axis = 0)
        w = np.transpose(w)
        write_libnc_param(f, w, out_prefix + "attn/c_attn/w")

        w_q = get_param(model, prefix + "self_attn.q_proj.bias")
        w_k = get_param(model, prefix + "self_attn.k_proj.bias")
        w_v = get_param(model, prefix + "self_attn.v_proj.bias")
        w = np.concatenate((w_q, w_k, w_v), axis = 0)
        write_libnc_param(f, w, out_prefix + "attn/c_attn/b")

        write_libnc_param(f, get_param(model, prefix + "self_attn_layer_norm.weight"), out_prefix + "ln_1/g")
        write_libnc_param(f, get_param(model, prefix + "self_attn_layer_norm.bias"), out_prefix + "ln_1/b")
        w = get_param(model, prefix + "self_attn.out_proj.weight")
        w = np.transpose(w)
        write_libnc_param(f, w, out_prefix + "attn/c_proj/w")
        write_libnc_param(f, get_param(model, prefix + "self_attn.out_proj.bias"), out_prefix + "attn/c_proj/b")

        write_libnc_param(f, get_param(model, prefix + "final_layer_norm.weight"), out_prefix + "ln_2/g")
        write_libnc_param(f, get_param(model, prefix + "final_layer_norm.bias"), out_prefix + "ln_2/b")
        w = get_param(model, prefix + "fc1.weight")
        w = np.transpose(w)
        write_libnc_param(f, w, out_prefix + "mlp/c_fc/w")
        write_libnc_param(f, get_param(model, prefix + "fc1.bias"), out_prefix + "mlp/c_fc/b")
        w = get_param(model, prefix + "fc2.weight")
        w = np.transpose(w)
        write_libnc_param(f, w, out_prefix + "mlp/c_proj/w")
        write_libnc_param(f, get_param(model, prefix + "fc2.bias"), out_prefix + "mlp/c_proj/b")
        
    write_libnc_param(f, get_param(model, "decoder.layer_norm.weight"), "ln_f/g")
    write_libnc_param(f, get_param(model, "decoder.layer_norm.bias"), "ln_f/b")
    
    w = get_param(model, "decoder.output_projection.weight")
    w = np.transpose(w)
    write_libnc_param(f, w, "proj_f/w")
    
    f.close()

if len(sys.argv) != 3:
    print("""usage: convert.py model_file output_file

Convert a fairseq parameter dump to a LibNC one.

model_dir is the filename containing the PyTorch parameter dump
output_file is filename of the libNC parameter dump""")
    sys.exit(1)

convert_params(sys.argv[1], sys.argv[2])
