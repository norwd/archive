# TextSynth text completion example
import sys
import argparse
import requests
import json
import time

parser = argparse.ArgumentParser(description='TextSynth text completion example')
parser.add_argument('--url', type=str, default = "http://localhost:8080", help="server URL")
parser.add_argument('--api_key', type=str, default = "")
parser.add_argument('--model', type=str, default = "gpt2_117M", help = "model name")
parser.add_argument('prompt', type=str, help="image generation prompt")

args = parser.parse_args()

def make_request(path, json):
    response = requests.post(args.url + path, headers = { "Authorization": "Bearer " + args.api_key }, json = json)
    return response

def main():
    req = { "prompt": args.prompt }
        
    result = make_request("/v1/engines/" + args.model + "/completions", req);
    if result.status_code != 200:
        print("Request error:", result.text)
        sys.exit(1)

    resp = result.json()
    print(args.prompt + resp["text"])
    
main()
