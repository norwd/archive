import sys
import torch
import torch.nn.functional as F
import numpy as np
import struct
import math
import io
import json
import base64
from convert_utils import *

LANGUAGES = {
    "en": "English",
    "zh": "Chinese",
    "de": "German",
    "es": "Spanish",
    "ru": "Russian",
    "ko": "Korean",
    "fr": "French",
    "ja": "Japanese",
    "pt": "Portuguese",
    "tr": "Turkish",
    "pl": "Polish",
    "ca": "Catalan",
    "nl": "Dutch",
    "ar": "Arabic",
    "sv": "Swedish",
    "it": "Italian",
    "id": "Indonesian",
    "hi": "Hindi",
    "fi": "Finnish",
    "vi": "Vietnamese",
    "he": "Hebrew",
    "uk": "Ukrainian",
    "el": "Greek",
    "ms": "Malay",
    "cs": "Czech",
    "ro": "Romanian",
    "da": "Danish",
    "hu": "Hungarian",
    "ta": "Tamil",
    "no": "Norwegian",
    "th": "Thai",
    "ur": "Urdu",
    "hr": "Croatian",
    "bg": "Bulgarian",
    "lt": "Lithuanian",
    "la": "Latin",
    "mi": "Maori",
    "ml": "Malayalam",
    "cy": "Welsh",
    "sk": "Slovak",
    "te": "Telugu",
    "fa": "Persian",
    "lv": "Latvian",
    "bn": "Bengali",
    "sr": "Serbian",
    "az": "Azerbaijani",
    "sl": "Slovenian",
    "kn": "Kannada",
    "et": "Estonian",
    "mk": "Macedonian",
    "br": "Breton",
    "eu": "Basque",
    "is": "Icelandic",
    "hy": "Armenian",
    "ne": "Nepali",
    "mn": "Mongolian",
    "bs": "Bosnian",
    "kk": "Kazakh",
    "sq": "Albanian",
    "sw": "Swahili",
    "gl": "Galician",
    "mr": "Marathi",
    "pa": "Punjabi",
    "si": "Sinhala",
    "km": "Khmer",
    "sn": "Shona",
    "yo": "Yoruba",
    "so": "Somali",
    "af": "Afrikaans",
    "oc": "Occitan",
    "ka": "Georgian",
    "be": "Belarusian",
    "tg": "Tajik",
    "sd": "Sindhi",
    "gu": "Gujarati",
    "am": "Amharic",
    "yi": "Yiddish",
    "lo": "Lao",
    "uz": "Uzbek",
    "fo": "Faroese",
    "ht": "Haitian creole",
    "ps": "Pashto",
    "tk": "Turkmen",
    "nn": "Nynorsk",
    "mt": "Maltese",
    "sa": "Sanskrit",
    "lb": "Luxembourgish",
    "my": "Myanmar",
    "bo": "Tibetan",
    "tl": "Tagalog",
    "mg": "Malagasy",
    "as": "Assamese",
    "tt": "Tatar",
    "haw": "Hawaiian",
    "ln": "Lingala",
    "ha": "Hausa",
    "ba": "Bashkir",
    "jw": "Javanese",
    "su": "Sundanese",
    "yue": "Cantonese",
}

# convert the tiktoken tokenizer
def convert_tokenizer(in_filename, out_filename, num_languages):
    with open(in_filename, "rb") as f:
         contents = f.read()
    tokens = []
    for line in contents.splitlines():
        if line:
            token, rank = line.split()
            token = base64.b64decode(token)
            rank = int(rank)
            assert rank == len(tokens)
            if len(token) == 0:
                token = "<|endoftext1|>".encode("utf-8")
            tokens.append(token)

    langs = list(LANGUAGES.keys())[:num_languages]
    lang_pos = len(tokens) + 2
    
    specials = [
        "<|endoftext|>",
        "<|startoftranscript|>",
        *[f"<|{lang}|>" for lang in langs],
        "<|translate|>",
        "<|transcribe|>",
        "<|startoflm|>",
        "<|startofprev|>",
        "<|nospeech|>",
        "<|notimestamps|>",
        *[f"<|{i * 0.02:.2f}|>" for i in range(1501)],
    ]
    for token in specials:
        tokens.append(bytearray(token, "utf-8"))
        
    fo = open(out_filename, "wb");

    json_config = {"type": "whisper"}

    languages = []
    for lang in langs:
        script = "" # XXX
        languages.append([lang_pos, lang, script, LANGUAGES[lang]])
        lang_pos += 1
    json_config["languages"] = languages
        
    fo.write(bytearray(json.dumps(json_config) + "\n", "utf-8"))
    
    for token in tokens:
        for c in token:
            if c == 10:
                fo.write(bytearray([ord("\\"), ord("n")]))
            elif c == 92:
                fo.write(bytearray([ord("\\"), ord("\\")]))
            elif c == 9:
                fo.write(bytearray([ord("\\"), ord("t")]))
            else:
                fo.write(bytearray([c]))

        fo.write(bytearray("\t 0\n", "utf-8"))

    fo.close()
    
                
def convert_layers(f, m, n_layer, is_encoder):
    if is_encoder:
        in_prefix0 = "encoder."
        out_prefix0 = "enc/"
    else:
        in_prefix0 = "decoder."
        out_prefix0 = ""

    if is_encoder:
        # (K, C, W) -> (K, W, C)
        write_libnc_param_pt(f, torch.permute(m[in_prefix0 + "conv1.weight"], (0, 2, 1)), "conv1/w")
        write_libnc_param_pt(f, m[in_prefix0 + "conv1.bias"], "conv1/b")

        # (K, C, W) -> (K, W, C)
        write_libnc_param_pt(f, torch.permute(m[in_prefix0 + "conv2.weight"], (0, 2, 1)), "conv2/w")
        write_libnc_param_pt(f, m[in_prefix0 + "conv2.bias"], "conv2/b")

        
    else:
        write_libnc_param_pt(f, m[in_prefix0 + "token_embedding.weight"], out_prefix0 + "wte")

    w = m[in_prefix0 + "positional_embedding"]
    write_libnc_param_pt(f, w, out_prefix0 + "wpe")
        
    for layer_num in range(n_layer):
        in_prefix = in_prefix0 + "blocks.{:d}.".format(layer_num)
        out_prefix = out_prefix0 + "h" + str(layer_num) + "/"

        # self attention layer
        write_libnc_param_pt(f, m[in_prefix + "attn_ln.weight"], out_prefix + "ln_1/g")
        write_libnc_param_pt(f, m[in_prefix + "attn_ln.bias"], out_prefix + "ln_1/b")

        w_q = m[in_prefix + "attn.query.weight"];
        w_k = m[in_prefix + "attn.key.weight"];
        w_v = m[in_prefix + "attn.value.weight"];
        w = torch.cat((w_q, w_k, w_v), 0)
        write_libnc_param_pt(f, torch.transpose(w, 0, 1), out_prefix + "attn/c_attn/w")

        b_q = m[in_prefix + "attn.query.bias"];
        b_k = torch.zeros(w_k.shape[1], dtype = torch.float16)
        b_v = m[in_prefix + "attn.value.bias"];
        w = torch.cat((b_q, b_k, b_v), 0)
        write_libnc_param_pt(f, w, out_prefix + "attn/c_attn/b")
        
        write_libnc_param_pt(f, torch.transpose(m[in_prefix + "attn.out.weight"], 0, 1), out_prefix + "attn/c_proj/w")
        write_libnc_param_pt(f, m[in_prefix + "attn.out.bias"], out_prefix + "attn/c_proj/b")

        # cross attention layer
        if not is_encoder:
            write_libnc_param_pt(f, m[in_prefix + "cross_attn_ln.weight"], out_prefix + "ln_0/g")
            write_libnc_param_pt(f, m[in_prefix + "cross_attn_ln.bias"], out_prefix + "ln_0/b")
            w = m[in_prefix + "cross_attn.query.weight"]
            write_libnc_param_pt(f, torch.transpose(w, 0, 1), out_prefix + "cross_attn/q_attn/w")
            w = m[in_prefix + "cross_attn.query.bias"]
            write_libnc_param_pt(f, w, out_prefix + "cross_attn/q_attn/b")
            
            w_k = m[in_prefix + "cross_attn.key.weight"]
            w_v = m[in_prefix + "cross_attn.value.weight"]
            w = torch.cat((w_k, w_v), 0)
            write_libnc_param_pt(f, torch.transpose(w, 0, 1), out_prefix + "cross_attn/kv_attn/w")

            b_k = torch.zeros(w_k.shape[1], dtype = torch.float16)
            b_v = m[in_prefix + "cross_attn.value.bias"]
            w = torch.cat((b_k, b_v), 0)
            write_libnc_param_pt(f, w, out_prefix + "cross_attn/kv_attn/b")
            
            write_libnc_param_pt(f, torch.transpose(m[in_prefix + "cross_attn.out.weight"], 0, 1), out_prefix + "cross_attn/c_proj/w")
            write_libnc_param_pt(f, m[in_prefix + "cross_attn.out.bias"], out_prefix + "cross_attn/c_proj/b")
        
        # MLP layer
        write_libnc_param_pt(f, m[in_prefix + "mlp_ln.weight"], out_prefix + "ln_2/g")
        write_libnc_param_pt(f, m[in_prefix + "mlp_ln.bias"], out_prefix + "ln_2/b")

        write_libnc_param_pt(f, torch.transpose(m[in_prefix + "mlp.0.weight"], 0, 1), out_prefix + "mlp/c_fc/w")
        write_libnc_param_pt(f, m[in_prefix + "mlp.0.bias"], out_prefix + "mlp/c_fc/b")

        write_libnc_param_pt(f, torch.transpose(m[in_prefix + "mlp.2.weight"], 0, 1), out_prefix + "mlp/c_proj/w")
        write_libnc_param_pt(f, m[in_prefix + "mlp.2.bias"], out_prefix + "mlp/c_proj/b")
        
    if is_encoder:
        write_libnc_param_pt(f, m[in_prefix0 + "ln_post.weight"], out_prefix0 + "ln_f/g")
        write_libnc_param_pt(f, m[in_prefix0 + "ln_post.bias"], out_prefix0 + "ln_f/b")
    else:
        write_libnc_param_pt(f, m[in_prefix0 + "ln.weight"], out_prefix0 + "ln_f/g")
        write_libnc_param_pt(f, m[in_prefix0 + "ln.bias"], out_prefix0 + "ln_f/b")

def convert_params(model_path, mel_filter_path, tokenizer_path, out_filename):

    d = torch.load(model_path)
    dims = d["dims"]
    n_vocab = dims["n_vocab"]
    m = d["model_state_dict"]
    n_mels = dims["n_mels"]
    n_layer = dims["n_audio_layer"]
    d_model = dims["n_audio_state"]
    n_head = dims["n_audio_head"]
    d_key = 64 # check
    fp_type = "f16"
    
    f = open(out_filename, "wb")

    write_libnc_param_header(f, {"type": "whisper", "n_layer": n_layer, "n_encoder_layer": n_layer, "d_model": d_model, "n_head": n_head, "d_key": d_key, "vocab_size": n_vocab, "n_mels" : n_mels, "data_type": fp_type });

    is_multilingual = n_vocab >= 51865
    num_languages = n_vocab - 51765 - int(is_multilingual)
    convert_tokenizer(tokenizer_path, "/tmp/whisper_vocab.txt", num_languages)
    
    write_libnc_tokenizer(f, "/tmp/whisper_vocab.txt", "tokenizer")
    
    mels = np.load(mel_filter_path, allow_pickle=False)
    w = mels[f"mel_{n_mels}"]
    write_libnc_param(f, np.transpose(w), "mel_filters")
    
    convert_layers(f, m, n_layer, True)

    convert_layers(f, m, n_layer, False)

    f.close()

            
if len(sys.argv) != 5:
    print("""usage: convert.py model_path mel_filter_path tokenizer_path output_file

Convert a Whisper parameter dump to a LibNC one.

model_dir is the filename containing the parameter dump
output_file is filename of the libNC parameter dump""")
    sys.exit(1)

convert_params(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4])
