/* See LICENSE file for copyright and license details. */
int
main(void)
{
	return 1;
}
