/* See LICENSE file for copyright and license details. */

#define ENV_SUPATH	"/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
#define ENV_PATH	"/usr/local/bin:/usr/bin:/bin:/usr/local/games:/usr/games"
