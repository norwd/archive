/* See LICENSE file for copyright and license details. */

/* tile.c */
void setmwfact(const char *arg);	/* sets master width factor */
void tile(void);			/* arranges all windows tiled */
void zoom(const char *arg);		/* zooms the focused client to master area, arg is ignored */
