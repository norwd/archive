/*
 * (C)opyright MMVI Anselm R. Garbe <garbeam at gmail dot com>
 * See LICENSE file for license details.
 */

#define FONT			"-*-terminus-medium-*-*-*-12-*-*-*-*-*-iso10646-*"
#define BGCOLOR			"#0d121d"
#define FGCOLOR			"#eeeeee"
#define BORDERCOLOR		"#3f484d"
