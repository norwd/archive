#include <u.h>
#include <libc.h>

int
exitcode(char *s)
{
	return 1;
}

