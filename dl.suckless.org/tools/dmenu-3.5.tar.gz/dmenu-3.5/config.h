/* See LICENSE file for copyright and license details. */

/* appearance */
#define FONT			"-*-terminus-medium-r-normal-*-14-*-*-*-*-*-*-*"
#define NORMBGCOLOR             "#cccccc"
#define NORMFGCOLOR             "#000000"
#define SELBGCOLOR              "#0066ff"
#define SELFGCOLOR              "#ffffff"
/* next macro defines the space between menu items */
#define SPACE			30 /* px */
