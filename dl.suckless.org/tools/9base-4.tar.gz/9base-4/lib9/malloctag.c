#include <lib9.h>

void
setmalloctag(void *v, ulong t)
{
	USED(v);
	USED(t);
}

void
setrealloctag(void *v, ulong t)
{
	USED(v);
	USED(t);
}
