#include <lib9.h>

int
main(int argc, char **argv)
{
	werrstr("hello world");
	print("%r\n");
}
