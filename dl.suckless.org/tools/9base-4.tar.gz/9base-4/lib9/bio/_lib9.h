#include <fmt.h>
#include <fcntl.h>
#include	<string.h>
#include	<unistd.h>
#include <stdlib.h>

#define OREAD O_RDONLY
#define OWRITE O_WRONLY

#include <utf.h>

#define nil ((void*)0)
