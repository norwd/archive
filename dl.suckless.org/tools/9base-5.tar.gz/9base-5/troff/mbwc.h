#define mblen p9mblen
#define mbtowc p9mbtowc
#define mbstowcs p9mbstowcs
#define wctomb p9wctomb
#define wcstombs p9wcstombs
