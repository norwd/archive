'''\"	TMAC.M @(#)tmacs.src	1.7
.if n .so #9/tmac/mmn
.if t .so #9/tmac/mmt
