/*
 * (C)opyright MMVI Anselm R. Garbe <garbeam at gmail dot com>
 * See LICENSE file for license details.
 */

#define FONT			"-*-terminus-medium-*-*-*-13-*-*-*-*-*-iso10646-*"
#define BGCOLOR			"#0a2c2d"
#define FGCOLOR			"#ddeeee"
#define BORDERCOLOR		"#176164"
