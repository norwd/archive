/*
 * (C)opyright MMVI Anselm R. Garbe <garbeam at gmail dot com>
 * See LICENSE file for license details.
 */

#define FONT			"-*-terminus-medium-*-*-*-12-*-*-*-*-*-iso10646-*"
#define SELBGCOLOR		"#333366"
#define SELFGCOLOR		"#eeeeee"
#define NORMBGCOLOR		"#333333"
#define NORMFGCOLOR		"#dddddd"
#define STDIN_TIMEOUT		3 /* seconds */
