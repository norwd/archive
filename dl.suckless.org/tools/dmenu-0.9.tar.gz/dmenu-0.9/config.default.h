/*
 * (C)opyright MMVI Anselm R. Garbe <garbeam at gmail dot com>
 * See LICENSE file for license details.
 */

#define FONT			"fixed"
#define SELBGCOLOR		"#666699"
#define SELFGCOLOR		"#eeeeee"
#define NORMBGCOLOR		"#333366"
#define NORMFGCOLOR		"#cccccc"
#define STDIN_TIMEOUT		3 /* seconds */
