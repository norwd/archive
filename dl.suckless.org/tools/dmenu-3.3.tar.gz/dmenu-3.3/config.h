/* See LICENSE file for copyright and license details. */

/* appearance */
#define FONT			"-*-terminus-medium-r-*-*-12-*-*-*-*-*-iso10646-*"
#define NORMBGCOLOR		"#000"
#define NORMFGCOLOR		"#ccc"
#define SELBGCOLOR		"#00f"
#define SELFGCOLOR		"#fff"
/* next macro defines the space between menu items */
#define SPACE			30 /* px */
