/* $Id: screen.c,v 1.40 2001/03/13 16:22:38 zarq Exp $

   Copyright (c) 2001 Ivo Timmermans <irt@cistron.nl>
   All rights reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:

   1. Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

   3. Neither the name of the author, the name of the program, nor the
      names of its contributors may be used to endorse or promote
      products derived from this software without specific prior
      written permission.

   THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
   AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
   TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
   USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
   ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
   OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
   OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
   SUCH DAMAGE.
*/

#include <assert.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <termios.h>

#include "events.h"
#include "screen.h"
#include "ui.h"
#include "util.h"

/* Maximum (numerical) parameters to an escape sequence */
#define NPAR 16

/* Dimensions of the visible screen in characters */
int screen_rows = -1;
int screen_cols = -1;

/* Start and end rows of the scrolling region  */
int scroll_region_start = 1;
int scroll_region_end = DEFAULT_NR_ROWS;
int scroll_in_region = 0;


text_row_t *text_screen;
text_row_t *saved_screen;

int screen_rows;
int screen_cols;

text_letter_t text_attrs;

int curr_row = 1;
int curr_col = 1;

text_row_t *buffer_create(int rows, int cols)
{
  int i;
  text_row_t *tr;
  
  tr = calloc(rows, sizeof(text_row_t));
  if(!tr)
    {
      fprintf(stderr, "Could not allocate %dx%d bytes\n",
	      rows, sizeof(text_row_t));
      exit(1);
    }
  for(i = 0; i < rows; i++)
    {
      tr[i].line = calloc(cols, sizeof(text_letter_t));
      assert(tr[i].line);
    }

  return tr;
}

/* Cursor movement functions */
int cursor_move_up(int n)
{
  curr_row -= n;
  if(curr_row < 1)
    curr_row = 0;
  return curr_row;
}

int cursor_move_down(int n)
{
  curr_row += n;
  if(curr_row > screen_rows)
    curr_row = screen_rows;
  return curr_row;
}

int cursor_move_left(int n)
{
  curr_col -= n;
  if(curr_col < 1)
    curr_col = 1;
  return curr_col;
}

int cursor_move_right(int n)
{
  curr_col += n;
  if(curr_col > screen_cols)
    curr_col = screen_cols;
  return curr_col;
}

int cursor_move_col(int n)
{
  curr_col = n;
  if(curr_col < 1)
    curr_col = 1;
  if(curr_col > screen_cols)
    curr_col = screen_cols;
  return curr_col;
}

int cursor_move_row(int n)
{
  curr_row = n;
  if(curr_row < 1)
    curr_row = 1;
  if(curr_row > screen_rows)
    curr_row = screen_rows;
  return curr_row;
}

void cursor_goto(int x, int y)
{
  curr_col = x;
  curr_row = y;
  if(curr_col < 1)
    curr_col = 1;
  if(curr_col > screen_cols)
    curr_col = screen_cols;
  if(curr_row < 1)
    curr_row = 1;
  if(curr_row > screen_rows)
    curr_row = screen_rows;
}

void cursor_rego(void)
{
  cursor_goto(curr_col, curr_row);
}

void delete_rows(text_row_t *screen, int start, int n)
{
  int i;

  for(i = 0; i < n; i++)
    free(screen[start + i - 1].line);
}

void add_rows(text_row_t *screen, int pos, int n)
{
  int i, j;

  text_attrs.letter = ' ';
  for(i = 0; i < n; i++)
    {
      screen[pos + i - 1].line = calloc(screen_cols, sizeof(text_letter_t));
      assert(screen[pos + i - 1].line);
      for(j = 0; j < screen_cols; j++)
	screen[pos + i - 1].line[j] = text_attrs;
      screen[pos + i - 1].needs_update = 1;
    }
}


int init_vt_buffer(void)
{
  text_screen = buffer_create(screen_rows, screen_cols);

  curr_col = curr_row = 1;
  scroll_region_start = 1;
  scroll_region_end = screen_rows;

  return 0;
}

void buffer_destroy(text_row_t *screen)
{
  int i;
  
  for(i = 0; i < screen_rows; i++)
    free(screen[i].line);

  free(screen);
}

void save_current_screen(void)
{
  saved_screen = text_screen;
  text_screen = buffer_create(screen_rows, screen_cols);
}

void restore_saved_screen(void)
{
  int i;
  
  buffer_destroy(text_screen);
  text_screen = saved_screen;
  for(i = 0; i < screen_rows; i++)
    text_screen[i].needs_update = 1;
}

/* Resize the buffer pointed to by s to rows x cols.  s may point to a
   different location on return, due to the way realloc works.  */
void _buffer_resize(text_row_t **s, int rows, int cols) { int i;

  if(rows < screen_rows)
    {
      delete_rows(*s, 1, screen_rows - rows);
      moverows(*s, screen_rows - rows + 1, 1, rows);
    }
  *s = realloc(*s, rows * sizeof(text_row_t));
  assert(*s);
  if(rows > screen_rows)
    {
      add_rows(*s, screen_rows + 1, rows - screen_rows);
    }

  if(cols != screen_cols)
    {
      for(i = 0; i < rows; i++)
	{
	  int j;
	  
	  (*s)[i].line = realloc((*s)[i].line, cols * sizeof(text_letter_t));
	  assert((*s)[i].line);
	  for(j = screen_cols; j < cols; j++)
	    *(int*)(&((*s)[i]).line[j]) = 0;
	  (*s)[i].needs_update = 1;
	}
    }
}

void buffer_resize(int rows, int cols)
{
  if(using_alternate_screen)
    _buffer_resize(&saved_screen, rows, cols);
  _buffer_resize(&text_screen, rows, cols);
}

void clear_area(int x1, int y1, int x2, int y2)
{
  int i, j;
  win_clear_region((x1 - 1) * font_width, (y1 - 1) * font_height,
		   x2 * font_width, y2 * font_height,
		   GET_BG_COLOR(text_attrs));
  for(i = y1; i <= y2; i++)
    for(j = x1; j <= x2; j++)
      {
	text_screen[i-1].line[j-1] = text_attrs;
	text_screen[i-1].line[j-1].letter = ' ';
      }
}

void clear_row(text_row_t *r)
{
  memset(r->line, '\0', screen_cols * sizeof(text_letter_t));
}

void moverows(text_row_t *screen, int from, int to, int n)
{
  memmove(&(screen[to-1]), &(screen[from-1]), n * sizeof(text_row_t));
}

void scroll_up(int rows)
{
  if(scroll_in_region)
    {
      /* Only scroll region */
      region_scroll_up(scroll_region_start, scroll_region_end, rows);
      delete_rows(text_screen, scroll_region_start, rows);
      moverows(text_screen, rows + scroll_region_start, scroll_region_start, scroll_region_end - scroll_region_start - rows + 1);
      add_rows(text_screen, scroll_region_end - rows + 1, rows);
    }
  else
    {
      /* Scroll entire buffer */
      window_scroll_up(rows);
      delete_rows(text_screen, 1, rows);
      moverows(text_screen, rows + 1, 1, screen_rows - rows);
      add_rows(text_screen, screen_rows - rows + 1, rows);
    }
}

void scroll_down(int rows)
{
  if(scroll_in_region)
    {
      /* Only scroll region */
      region_scroll_down(scroll_region_start, scroll_region_end, rows);
      delete_rows(text_screen, scroll_region_end - rows + 1, rows);
      moverows(text_screen, scroll_region_start, scroll_region_start + rows, scroll_region_end - scroll_region_start - rows + 1);
      add_rows(text_screen, scroll_region_start, rows);
    }
  else
    {
      /* Scroll entire buffer */
      window_scroll_down(rows);
      delete_rows(text_screen, screen_rows - rows + 1, rows);
      moverows(text_screen, 1, rows + 1, screen_rows - rows);
      add_rows(text_screen, 1, rows);
    }
}

void insert_lines(int lines)
{
  int a,b;
  
  /* Fake region scroll */
  a = scroll_region_start;
  b = scroll_in_region;
  scroll_region_start = curr_row;
  scroll_in_region = 1;
  scroll_down(lines);
  scroll_region_start = a;
  scroll_in_region = b;
}

void delete_lines(int lines)
{
  int a,b;
  
  /* Fake region scroll */
  a = scroll_region_start;
  b = scroll_in_region;
  scroll_region_start = curr_row;
  scroll_in_region = 1;
  scroll_up(lines);
  scroll_region_start = a;
  scroll_in_region = b;
}

void set_buffer_fg_color(int c)
{
  text_attrs.fg = c;
}

void set_buffer_bg_color(int c)
{
  text_attrs.bg = c;
}

void set_buffer_attrs(int bold)
{
  text_attrs.bold = bold ? 1 : 0;
}

void set_buffer_reverse(int rev)
{
  text_attrs.rev = rev ? 1 : 0;
}

struct winsize *get_font_dim()
{
  static struct winsize w;
  w.ws_row = screen_rows;
  w.ws_col = screen_cols;
  w.ws_xpixel = w.ws_ypixel = 0;
  return &w;
}

void write_buffer(unsigned char c)
{
  text_attrs.letter = c;
  text_screen[curr_row-1].line[curr_col-1] = text_attrs;
  text_screen[curr_row-1].needs_update = 1;
}

/* Handle an xterm escape sequence. */
void xterm_seq(int op)
{
  unsigned char *buf;
  int len;
  int buflen;
  unsigned char c;

  buf = malloc(buflen = 20);
  c = cmdgetc();
  for(len = 0; c != '\007'; len++)
    {
      if(len > buflen + 1)
	{
	  buflen <<= 1;
	  buf = realloc(buf, buflen);
	  assert(buf);
	}
      buf[len] = c;
      c = cmdgetc();
    }
  buf[len] = 0;

  switch(op)
    {
    case 0: /* set window and icon title */
    case 1: /* set icon title */
    case 2: /* set window title */
      win_set_window_title(buf);
      break;
    }
}

/* If the current cursor position is beyond the right margin, wrap the
   cursor and scroll if needed.  */
void wrap_line(void)
{
  while(curr_col > screen_cols)
    {
      curr_col -= screen_cols;
      if(!wraparound_mode)
	curr_row++;
      if(curr_row > scroll_region_end)
	{
	  scroll_up(curr_row - scroll_region_end);
	  curr_row = scroll_region_end;
	}
    }
}

void dispatch_escape(void)
{
  int len;
  int pos;
  int args[NPAR];
  int narg = 0;
  int digit;
  int rows, cols;
  int i;
  int questionmark;
  unsigned char c;

  for(pos = 0; pos < NPAR; pos++)
    args[pos] = 0;

  c = cmdgetc();
  switch(c)
    {
    case '[': /* CSI */
      digit = 0;
      questionmark = 0;
      c = cmdgetc();
      while(isdigit(c) || c == ';' || c == '?')
	{
	  if(c == ';')
	    {
	      args[narg] = 0;
	      digit = 0;
	    }
	  else
	    {
	      if(c == '?')
		questionmark = 1;
	      else
		{
		  if(!digit)
		    narg++;
		  digit = 1;
		  args[narg-1] *= 10;
		  args[narg-1] += c - '0';
		}
	    }
	  c = cmdgetc();
	}

      switch(c)
	{
	case 'A':
	  cursor_move_up(narg ? args[0] : 1);
	  break;
	case 'B':
	  cursor_move_down(narg ? args[0] : 1);
	  break;
	case 'C':
	  cursor_move_right(narg ? args[0] : 1);
	  break;
	case 'D':
	  cursor_move_left(narg ? args[0] : 1);
	  break;
	case 'G':
	  cursor_move_col(narg ? args[0] : 1);
	  break;
	case 'H':
	  cursor_goto(args[1] ? args[1] : 1, args[0] ? args[0] : 1);
	  break;
	case 'J':
	  if(narg)
	    {
	      if(args[0] == 1)
		{
		  /* erase from start to cursor */
		  clear_area(1, 1,
			     screen_cols, curr_row);
		}
	      if(args[0] == 2)
		{
		  /* erase whole display */
		  clear_area(1, 1,
			     screen_cols, screen_rows);
		}
	    }
	  else
	    {
	      /* erase from cursor to end of display */
	      clear_area(1, curr_row,
			 screen_cols, screen_rows);
	    }
	  break;
	case 'K':
	  if(narg)
	    {
	      if(args[0] == 1)
		{
		  /* erase from start of line to cursor */
		  clear_area(1, curr_row, curr_col, curr_row);
		}
	      if(args[0] == 2)
		{
		  /* erase whole line */
		  clear_area(1, curr_row, screen_cols, curr_row);
		}
	    }
	  else
	    {
	      /* erase from cursor to end of line */
	      clear_area(curr_col, curr_row, screen_cols, curr_row);
	    }
	  break;
	case 'L': /* Insert lines */
	  insert_lines(narg ? args[0] : 1);
	  break;
	case 'M': /* Delete lines */
	  delete_lines(narg ? args[0] : 1);
	  break;
	case 'd': /* line position absolute */
	  cursor_move_row(narg ? args[0] : 1);
	  break;
	case 'P': /* clear # of characters */
	  clear_area(curr_col, curr_row, curr_col + args[0], curr_row);
	  break;
	case 'h': /* set mode */
	  switch(args[0])
	    {
	    case 1:
	      if(questionmark)
		/* DEC CKM mode */
		decckm_mode = 1;
	      break;
	    case 4:
	      if(!questionmark)
		/* insert mode */
		insert_mode = 1;
	      break;
	    case 7:
	      if(questionmark)
		wraparound_mode = 1;
	      break;
	    case 25:
	      if(questionmark)
		cursor_visible = 1;
	      break;
	    case 47:
	      if(questionmark)
		{
		  using_alternate_screen = 1;
		  save_current_screen();
		}
	      break;
	    default:
	      fprintf(stderr, "Unsupported ESC [%s h mode %d\n",
		      questionmark?" ?":"",
		      args[0]);
	      break;
	    }
	  break;
	case 'l': /* reset mode */
	  switch(args[0])
	    {
	    case 1:
	      if(questionmark)
		/* DEC CKM mode */
		decckm_mode = 0;
	      break;
	    case 4: /* insert mode */
	      insert_mode = 0;
	      break;
	    case 7:
	      if(questionmark)
		wraparound_mode = 0;
	      break;
	    case 25:
	      if(questionmark)
		cursor_visible = 0;
	      break;
	    case 47:
	      if(questionmark)
		{
		  using_alternate_screen = 0;
		  restore_saved_screen();
		}
	      break;
	    default:
	      fprintf(stderr, "Unsupported ESC [%s l mode %d\n",
		      questionmark?" ?":"",
		      args[0]);
	      break;
	    }
	  break;
	case 'm':
	  /* reset attrs */
	  if(!narg)
	    {
	      set_buffer_attrs(0);
	      set_buffer_fg_color(7);
	      set_buffer_reverse(0);
	      set_buffer_bg_color(0);
	    }
	  for(i = 0; i < narg; i++)
	    {
	      if(args[i] == 0)
		{
		  set_buffer_attrs(0);
		  set_buffer_fg_color(7);
		}
	      else if(args[i] == 1)
		set_buffer_attrs(1);
	      else if(args[i] == 7)
		set_buffer_reverse(1);
	      else if(args[i] == 27)
		set_buffer_reverse(0);
	      else if(args[i] >= 30 && args[i] <= 37)
		set_buffer_fg_color(args[i] - 30);
	      else if(args[i] >= 40 && args[i] <= 47)
		set_buffer_bg_color(args[i] - 40);
	      else if(args[i] == 39)
		set_buffer_fg_color(7);
	      else if(args[i] == 49)
		set_buffer_bg_color(0);
	      else
		fprintf(stderr, "Unsupported mode %d\n",
			args[i]);
	    }
	  break;
	case 'n':
	  /* status report */
	  {
	    char buf[20];
	    
	    switch(args[0])
	      {
	      case 6:
		/* cursor position */
		snprintf(buf, sizeof(buf), "\033[%d;%dR",
			 curr_row, curr_col);
		cmd_write(buf, strlen(buf));
		break;
	      default:
		fprintf(stderr, "Unknown status request id %d\n",
			args[0]);
	      }
	  }
	  break;
	case 'r': /* set scrolling region */
	  scroll_region_start = args[0] ? args[0] : 1;
	  scroll_region_end = args[1] ? args[1] : screen_rows;
	  if(!narg)
	    /* Reset scroll region */
	    scroll_in_region = 0;
	  else if(args[0] == 1 && args[1] == screen_rows)
	    scroll_in_region = 0;
	  else
	    scroll_in_region = 1;
	  break;
	case '[': /* echoed function key */
	  cmdgetc();
	  break;
	default:
	  fprintf(stderr, "Unsupported CSI sequence ESC [");
	  if(questionmark)
	    fprintf(stderr, " ?");
	  for(i = 0; i < narg; i++)
	    fprintf(stderr, " %d", args[i]);
	  fprintf(stderr, " %c\n", c);
	}
      break;
    case ']': /* xterm sequence */

      digit = 0;
      c = cmdgetc();
      while(isdigit(c))
	{
	  if(!digit)
	    narg++;
	  digit = 1;
	  args[narg-1] *= 10;
	  args[narg-1] += c - '0';
	  c = cmdgetc();
	}
      if(c != ';' || !narg)
	{
	  fprintf(stderr, "Invalid xterm sequence\n");
	  break;
	}

      xterm_seq(args[0]);
      break;
    case '7': /* save cursor position */
      saved_cursor_x = curr_col;
      saved_cursor_y = curr_row;
      break;
    case '8': /* restore cursor position */
      curr_col = saved_cursor_x;
      curr_row = saved_cursor_y;
      break;
    case '=': /* set application keypad mode */
      application_keypad_mode = 1;
      break;
    case '>': /* set numeric keypad mode */
      application_keypad_mode = 0;
      break;
    case 'M': /* reverse linefeed */
      curr_row--;
      if(curr_row < scroll_region_start)
	{
	  curr_row = scroll_region_start;
	  scroll_down(1);
	}
      break;
    default:
      fprintf(stderr, "Unsupported ESC sequence ESC %c\n", c);
      break;
    }
}

void main_loop()
{
  unsigned char c;

  for(;;)
    {
      switch((c = cmdgetc()))
	{
	case '\007': /* Bell */
	  bell();
	  break;
	case '\010': /* backspace */
	  curr_col--;
	  if(curr_col < 1)
	    curr_col = 1;
	  break;
	case '\011': /* tab */
	  curr_col = ((curr_col) | 7) + 2;
	  if(curr_col > screen_cols)
	    {
	      curr_col = 8;
	      if(!wraparound_mode)
		curr_row++;
	      if(curr_row > scroll_region_end)
		{
		  scroll_up(curr_row - scroll_region_end);
		  curr_row = scroll_region_end;
		}
	    }
	  break;
	case '\033': /* escape */
	  /* handle esc codes */
	  dispatch_escape();
	  break;
	case '\n': /* newline */
	  if(!application_keypad_mode)
	    /* return carriage */
	    curr_col = 1;
	  
	  curr_row++;
	  if(curr_row > scroll_region_end)
	    {
	      scroll_up(curr_row - scroll_region_end);
	      curr_row = scroll_region_end;
	    }
	  break;
	case '\r': /* carriage return */
	  curr_col = 1;
	  break;
	default:
	  wrap_line();
	  if(c >= ' ')
	    {
	      write_buffer(c);
	      curr_col++;
	    }
	  break;
	}
    }
}

