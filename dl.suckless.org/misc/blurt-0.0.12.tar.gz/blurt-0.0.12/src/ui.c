/* $Id: ui.c,v 1.22 2001/03/13 16:24:31 zarq Exp $

   Copyright (c) 2001 Ivo Timmermans <irt@cistron.nl>
   All rights reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:

   1. Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

   3. Neither the name of the author, the name of the program, nor the
      names of its contributors may be used to endorse or promote
      products derived from this software without specific prior
      written permission.

   THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
   AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
   TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
   USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
   ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
   OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
   OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
   SUCH DAMAGE.
*/

#include <assert.h>
#include <ctype.h>
#include <stdio.h>

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/cursorfont.h>

#include "process.h"
#include "screen.h"
#include "events.h"
#include "ui.h"
#include "util.h"

Display *Xdisplay;
Window MainWindow;
XFontStruct *Xfont;
XFontStruct *Xboldfont;
GC Xgc;
Colormap Xcolmap;
Cursor Xcursor;

XColor colors[9];
XColor bgcolors[8];
XColor cursor_color;
int Xdepth;
Visual *Xvisual;
int Xscreen;

int window_width;
int window_height;

int font_height = -1;
int font_width = -1;

int init_display(void)
{
  Xdisplay = XOpenDisplay(NULL);
  if(!Xdisplay)
    {
      fprintf(stderr, "Couldn't open display\n");
      return -1;
    }

  Xscreen = DefaultScreen(Xdisplay);

  Xdepth = DefaultDepth(Xdisplay, Xscreen);
  Xcolmap = DefaultColormap(Xdisplay, Xscreen);
  Xvisual = DefaultVisual(Xdisplay, Xscreen);

  /*
  if (Xdepth != 24)
    {
      XVisualInfo     vinfo;
      
      if (XMatchVisualInfo(Xdisplay, Xscreen, 24, TrueColor, &vinfo))
	{
	  Xdepth = 24;
	  Xvisual = vinfo.visual;
	  Xcolmap = XCreateColormap(Xdisplay, RootWindow(Xdisplay, Xscreen),
				    Xvisual, AllocNone);
        }
    }
  */

  if(!(Xcursor = XCreateFontCursor(Xdisplay, XC_xterm)))
    {
      fprintf(stderr, "Couldn't create cursor\n");
      return -1;
    }
  
  return 0;
}

int init_window(void)
{
  char *args[] = { NULL };
  
  XSizeHints sh;
  XWMHints wh;
  XClassHint ch;

  MainWindow = XCreateSimpleWindow(Xdisplay, DefaultRootWindow(Xdisplay), 0, 0, 
				   window_width, window_height,
				   0, DEFAULT_BACKGROUND_COLOR.pixel, DEFAULT_BACKGROUND_COLOR.pixel);

  XSelectInput(Xdisplay, MainWindow, StructureNotifyMask);
  XMapWindow(Xdisplay, MainWindow);

  /* Wait for the window to be mapped */
  wait_for_specific_event(MapNotify);

  Xgc = XCreateGC(Xdisplay, MainWindow, 0, NULL);
  XSetForeground(Xdisplay, Xgc, DEFAULT_FOREGROUND_COLOR.pixel);
  XSetBackground(Xdisplay, Xgc, DEFAULT_BACKGROUND_COLOR.pixel);

  XDefineCursor(Xdisplay, MainWindow, Xcursor);

  sh.x = sh.y = 0;
  sh.width = window_width;
  sh.height = window_height;
  sh.width_inc = font_width;
  sh.height_inc = font_height;
  sh.flags = PPosition | PSize | PResizeInc;

  wh.input = 1;
  wh.flags = InputHint;

  ch.res_name = "blurt";
  ch.res_class = "blurt";

  XSetWMProperties(Xdisplay, MainWindow, NULL, NULL, &args[0], 0, &sh, &wh, &ch);
  XStoreName(Xdisplay, MainWindow, "blurt");

  XSync(Xdisplay, 0);
  
  set_text_attrs(-1, 0);
  XSetFont(Xdisplay, Xgc, Xfont->fid);

  return 0;
}

int init_font()
{
  Xfont = XLoadQueryFont(Xdisplay, DEFAULT_FONT);
  if(!Xfont)
    {
      fprintf(stderr, "Couldn't open font `%s'\n",
	      DEFAULT_FONT);
      return -1;
    }

  Xboldfont = XLoadQueryFont(Xdisplay, DEFAULT_BOLD_FONT);
  if(!Xfont)
    {
      fprintf(stderr, "Couldn't open font `%s'\n",
	      DEFAULT_FONT);
      return -1;
    }

  if(font_height == -1 || font_width == -1)
    {
      font_height = Xfont->ascent + Xfont->descent;
      font_width = Xfont->max_bounds.width;
    }

  screen_rows = screen_rows == -1 ? DEFAULT_NR_ROWS : screen_rows;
  screen_cols = screen_cols == -1 ? DEFAULT_NR_COLS : screen_cols;
  window_width = screen_cols * font_width;
  window_height = screen_rows * font_height;

  return 0;
}

void wait_for_specific_event(int event_type)
{
  XEvent e;
  
  for(;;)
    {
      XNextEvent(Xdisplay, &e);
      if(e.type == event_type)
	break;
    }
}

int find_color(XColor *Xc, char *def)
{
  if((XParseColor(Xdisplay, Xcolmap, def, Xc)))
    if(!(XAllocColor(Xdisplay, Xcolmap, Xc)))
      return -1;
  return 0;
}

int init_colors(void)
{
  int color;

  char *color_values[9] = {
      "black",
      "red",
      "green",
      "yellow",
      "blue",
      "magenta",
      "#00d0d0",
      "#d0d0d0",
      "#404040"
  };

  char *bgcolor_values[8] = {
    "black",
    "#d00000",
    "#00d000",
    "#d0d000",
    "#0000d0",
    "#d000d0",
    "#00d0d0",
    "#d0d0d0"
  };

  for(color = 0; color < 9; color++)
    if(find_color(&(colors[color]), color_values[color]))
      fprintf(stderr, "Couldn't allocate color %d (%s)\n",
	      color, color_values[color]);
  
  for(color = 0; color < 8; color++)
    if(find_color(&(bgcolors[color]), bgcolor_values[color]))
      fprintf(stderr, "Couldn't allocate bgcolor %d (%s)\n",
	      color, bgcolor_values[color]);
  
  if(find_color(&(cursor_color), "lightgreen"))
    fprintf(stderr, "Couldn't allocate cursor color (%s)\n",
	    "lightgreen");
  
  return 0;
}

void win_clear_region(int x1, int y1, int x2, int y2, int color)
{
  XSetBackground(Xdisplay, Xgc, color);
  XClearArea(Xdisplay, MainWindow, x1, y1, x2 - x1, y2 - y1, 0);
}

/* Draws the string in s (l bytes long) to the screen.  row and col
   are with offset 0. */
void win_draw_string(int row, int col, char *s, int l)
{
  XDrawImageString(Xdisplay, MainWindow, Xgc,
		   col * font_width, row * font_height + Xfont->ascent,
		   s, l);
}

void win_set_window_title(char *title)
{
  XStoreName(Xdisplay, MainWindow, title);
}

void window_scroll_up(int lines)
{
  XCopyArea(Xdisplay, MainWindow, MainWindow, Xgc,
	    0, lines * font_height,
	    window_width, (screen_rows - lines + 1) * font_height,
	    0, 0);
  win_clear_region(0, (screen_rows - lines) * font_height,
	       window_width, screen_rows * font_height,
	       GET_BG_COLOR(text_attrs));
}

void region_scroll_up(int start, int end, int lines)
{
  XCopyArea(Xdisplay, MainWindow, MainWindow, Xgc,
	    0, (start - 1 + lines) * font_height,
	    window_width, (end - start + 2 - lines) * font_height,
	    0, (start - 1) * font_height);
  win_clear_region(0, (end - lines) * font_height,
	       window_width, end * font_height,
	       GET_BG_COLOR(text_attrs));
}

void window_scroll_down(int lines)
{
  XCopyArea(Xdisplay, MainWindow, MainWindow, Xgc,
	    0, 0,
	    window_width, (screen_rows - lines + 1) * font_height,
	    0, lines * font_height);
  win_clear_region(0, 0,
	       window_width, (lines) * font_height,
	       GET_BG_COLOR(text_attrs));
}

void region_scroll_down(int start, int end, int lines)
{
  XCopyArea(Xdisplay, MainWindow, MainWindow, Xgc,
	    0, (start - 1) * font_height,
	    window_width, (end - start + 2 - lines) * font_height,
	    0, (start - 1 + lines) * font_height);
  win_clear_region(0, (start - 1) * font_height,
	       window_width, (start + lines - 1) * font_height,
	       GET_BG_COLOR(text_attrs));
}

void set_text_attrs(text_letter_t l)
{
  int fg, bg;

  if(l.rev ^ l.sel)
    fg = l.bg, bg = l.fg;
  else
    fg = l.fg, bg = l.bg;

  if(l.bold && fg == 0)
    XSetForeground(Xdisplay, Xgc, colors[8].pixel);
  else
    XSetForeground(Xdisplay, Xgc, colors[fg].pixel);
  if(l.bold)
    XSetFont(Xdisplay, Xgc, Xboldfont->fid);
  else
    XSetFont(Xdisplay, Xgc, Xfont->fid);
  XSetBackground(Xdisplay, Xgc, bgcolors[bg].pixel);
}

int exit_display(void)
{
  XCloseDisplay(Xdisplay);
  return 0;
}

int get_x_filedes(void)
{
  return XConnectionNumber(Xdisplay);
}

/* Max number of characters to be drawn at once */
#define MAXRUNLENGTH 100

void redraw_screen(void)
{
  int i, j;
  int a;
  int sl, start;
  unsigned char buf[MAXRUNLENGTH];

  a = 0;
  set_text_attrs(text_screen[0].line[0]);
  for(i = 0; i < screen_rows; i++)
    {
      if(!text_screen[i].needs_update)
	continue;
/*       win_clear_region(0, i * font_height, window_width-1, (i + 1) * font_height - 1); */
      sl = 0; start = 0;
      for(j = 0; j <= screen_cols; j++)
	{
	  if(j == screen_cols)
	    {
	      if(sl > 0)
		win_draw_string(i, start, &buf[0], sl);
	      break;
	    }
	  if(a != ((*(int*)&(text_screen[i].line[j])) & ~0xff) || sl >= sizeof(buf))
	    {
	      if(sl > 0)
		win_draw_string(i, start, &buf[0], sl);
	      set_text_attrs(text_screen[i].line[j]);
	      a = (*(int*)&(text_screen[i].line[j])) & ~0xff;
	      start = j;
	      sl = 0;
	    }
	  buf[sl] = text_screen[i].line[j].letter;
	  sl++;
	}
      text_screen[i].needs_update = 0;
    }
  XFlush(Xdisplay);
}

void force_redraw_screen(void)
{
  int i;
  for(i = 0; i < screen_rows; i++)
    text_screen[i].needs_update = 1;
  redraw_screen();
}

void bell(void)
{
  XBell(Xdisplay, 0);
}

void redraw_region(int x1, int y1, int x2, int y2)
{
  int i, j;
  int a;
  int sl, start;
  unsigned char buf[MAXRUNLENGTH];

/*  win_clear_region((x1 - 1) * font_width, (y1 - 1) * font_height, x2 * font_width, y2 * font_height); */
  a = (*(int*)&(text_screen[y1-1].line[x1-1])) & ~0xff;
  set_text_attrs(text_screen[y1-1].line[x1-1]);
  for(i = y1 - 1; i < y2; i++)
    {
      sl = 0; start = x1 - 1;
      for(j = x1 - 1; j <= x2; j++)
	{
	  if(j == x2)
	    {
	      if(sl > 0)
		win_draw_string(i, start, &buf[0], sl);
	      break;
	    }
	  if(a != ((*(int*)&(text_screen[i].line[j])) & ~0xff) || sl >= sizeof(buf))
	    {
	      if(sl > 0)
		win_draw_string(i, start, &buf[0], sl);
	      set_text_attrs(text_screen[i].line[j]);
	      a = (*(int*)&(text_screen[i].line[j])) & ~0xff;
	      start = j;
	      sl = 0;
	    }
	  buf[sl] = text_screen[i].line[j].letter;
	  sl++;
	}
      text_screen[i].needs_update = 0;
    }
  XFlush(Xdisplay);
}

extern int curr_row, curr_col;
static int cursor_row, cursor_col;
static int cursor_is_visible = 0;

void show_cursor(void)
{
  if(cursor_is_visible)
    return;
  if(!cursor_visible)
    return;

  cursor_row = curr_row;
  cursor_col = curr_col;
  if(curr_col > screen_cols)
    cursor_col = screen_cols;
  
  if(text_screen[cursor_row-1].line[cursor_col-1].bold)
    XSetFont(Xdisplay, Xgc, Xboldfont->fid);
  else
    XSetFont(Xdisplay, Xgc, Xfont->fid);

  win_clear_region((cursor_col - 1) * font_width, (cursor_row - 1) * font_height,
	       cursor_col * font_width, cursor_row * font_height,
	       cursor_color.pixel);

  XSetForeground(Xdisplay, Xgc, colors[0].pixel);
  XSetBackground(Xdisplay, Xgc, cursor_color.pixel);

  win_draw_string(cursor_row - 1, cursor_col - 1, &(text_screen[cursor_row - 1].line[cursor_col - 1]), 1);
  XFlush(Xdisplay);
  cursor_is_visible = 1;
}

void hide_cursor(void)
{
  if(!cursor_is_visible)
    return;
  if(cursor_row <= screen_rows && cursor_col <= screen_cols)
    {
      set_text_attrs(text_screen[cursor_row-1].line[cursor_col-1]);
      win_clear_region((cursor_col - 1) * font_width, (cursor_row - 1) * font_height,
		       cursor_col * font_width, cursor_row * font_height,
		       GET_BG_COLOR(text_screen[cursor_row-1].line[cursor_col-1]));
      win_draw_string(cursor_row - 1, cursor_col - 1, &(text_screen[cursor_row - 1].line[cursor_col - 1]), 1);
      XFlush(Xdisplay);
    }
  cursor_is_visible = 0;
}
