/* $Id: process.c,v 1.16 2001/03/13 16:22:04 zarq Exp $

   Copyright (c) 2001 Ivo Timmermans <irt@cistron.nl>
   All rights reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:

   1. Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

   3. Neither the name of the author, the name of the program, nor the
      names of its contributors may be used to endorse or promote
      products derived from this software without specific prior
      written permission.

   THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
   AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
   TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
   USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
   ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
   OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
   OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
   SUCH DAMAGE.
*/

#include <assert.h>
#include <fcntl.h>
#include <pwd.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#include "screen.h"
#include "util.h"

static unsigned char output_buf[512];
static unsigned int startptr = 0; /* index into output_buf to where data starts */
static unsigned int endptr = 0;   /* index into output_buf to where data ends */

pid_t pid;

static int cmd_fd = -1;
static int slave;

char *ptydev, *ttydev;

void sigchld_handler(int a)
{
  int status = 0;
  
  if(waitpid(pid, &status, 0) < 0)
    {
      fprintf(stderr, "Waiting for pid %hd failed: %m\n",
	      pid);
      exit(1);
    }
  
  if(WIFEXITED(status))		/* Child exited by itself */
    {
      if(WEXITSTATUS(status))
	exit(WEXITSTATUS(status));
    }
  else if(WIFSIGNALED(status))	/* Child was killed by a signal */
    exit(1);
  else				/* Something strange happened */
    exit(1);

  exit(0);
}

struct passwd *find_user(void)
{
  uid_t uid;
  struct passwd *pw;

  if((uid = getuid()) == -1)
    {
      fprintf(stderr, "Couldn't find current uid: %m\n");
      exit(2);
    }

  if((pw = getpwuid(uid)) == NULL)
    {
      fprintf(stderr, "Couldn't find password entry for user %d: %m\n",
	      uid);
      exit(2);
    }

  return pw;
}

int get_pty(void)
{
  extern char *ptsname();
  int fd;

  if((fd = getpt()) >= 0)
    {
      if(grantpt(fd) == 0 && unlockpt(fd) == 0)
	{
	  ptydev = ptsname(fd);
	  if((slave = open(ptydev, O_RDWR | O_NOCTTY)) < 0)
	    {
	      fprintf(stderr, "Error opening slave pty: %m\n");
	      return -1;
	    }
	  fcntl(fd, F_SETFL, O_NDELAY);
	  return fd;
	}
      close(fd);
    }
  fprintf(stderr, "Can't open a pseudo-tty\n");
  return -1;
}

int resize_app(void)
{
  if(ioctl(cmd_fd, TIOCSWINSZ, get_font_dim()) < 0)
    {
      fprintf(stderr, "Couldn't set window size: %m\n");
      return -1;
    }

  return 0;
}

int get_tty(void)
{
  int i;
  
  for(i = 0; i < 100 ; i++)
    if(i != slave)
      close(i);

  cmd_fd = slave;

  setsid(); /* create a new process group */

  dup2(cmd_fd, 0);
  dup2(cmd_fd, 1);
  dup2(cmd_fd, 2);

  if(ioctl(cmd_fd, TIOCSCTTY, NULL) < 0)
    {
      fprintf(stderr, "Couldn't set controlling terminal: %m\n");
      return -1;
    }

  if(ioctl(cmd_fd, TIOCSWINSZ, get_font_dim()) < 0)
    {
      fprintf(stderr, "Couldn't set window size: %m\n");
      return -1;
    }


  return 0;
}

int execute_command(int argc, const char **argv)
{
  char **args;
  int master;
  struct passwd *pw;

  pw = find_user();

  if((cmd_fd = get_pty()) < 0)
    return -1;

  if((pid = fork()) < 0)
    {
      fprintf(stderr, "Couldn't fork: %m\n");
      return -1;
    }

  if(!pid)
    {
      /* child */
      get_tty();

      putenv("TERM=blurt");
      chdir(pw->pw_dir);

      args = calloc(3, sizeof(char*));
      args[0] = malloc(strlen(pw->pw_shell) + 1);
      strcpy(args[0], pw->pw_shell);
      args[1] = "-i";
      args[2] = NULL;

      execvp(pw->pw_shell, args);

      /* shouldn't be here */
      fprintf(stderr, "Error executing %s: %m\n", pw->pw_shell);
      exit(1);
    }

  /* parent */
  close(slave);
  signal(SIGCHLD, sigchld_handler);

  return 0;
}

#define TIMEOUT_USEC 10000
void wait_for_input(void)
{
  int len;
  fd_set fset;
  struct timeval tv;
  int r;
  int X_fd;
  int need_redraw = 0;

  X_fd = get_x_filedes();

  hide_cursor();
  redraw_screen();
  
  for(;;)
    {
      FD_ZERO(&fset);
      if(cmd_fd >= 0)
	FD_SET(cmd_fd, &fset);
      FD_SET(X_fd, &fset);

      tv.tv_usec = TIMEOUT_USEC;
      tv.tv_sec = 0;

      r = select(FD_SETSIZE, &fset, NULL, NULL, &tv);

      if(r < 0)
	{
	  /* error */
	  fprintf(stderr, "select: %m\n");
	  exit(1);
	}

      if(!r)
	{
	  /* timeout */
	  if(need_redraw)
	    {
	      hide_cursor();
	      redraw_screen();
	      need_redraw = 0;
	    }
	  show_cursor();
	  continue;
	}

      if(FD_ISSET(cmd_fd, &fset))
	{
	  /* Input from the command */
	  hide_cursor();
	  return;
	}

      if(FD_ISSET(X_fd, &fset))
	{
	  hide_cursor();
	  handle_x_events();
	  need_redraw = 1;
	}
    }
}

void fill_buffer(int fd)
{
  int len;

  wait_for_input();
  len = read(fd, &output_buf[0], sizeof(output_buf));
  if(len < 0)
    {
      fprintf(stderr, "Error reading from command: %m\n");
      exit(1);
    }
  if(len == 0)
    {
      fprintf(stderr, "No more data! exiting.\n");
      exit(1);
    }
  endptr = len;
  startptr = 0;
}

unsigned char cmdgetc()
{
  unsigned char r;
  static int bla = 0;

  if(startptr >= endptr) /* there is no more data available */
    fill_buffer(cmd_fd);

  r = output_buf[startptr];

#if 0
  /* For debugging purposes :)  Produces quite a lot of output. */
  fprintf(stderr, " %02x %c ", r, isprint(r)?r:'.');
  bla++;
  if(bla % 10 == 0)
    fprintf(stderr, "\n");
#endif
  
  startptr++;
  return r;
}

int cmd_write(const char *buf, int len)
{
  if(write(cmd_fd, buf, len) < 0)
    {
      fprintf(stderr, "Error writing to process: %m\n");
      exit(2);
    }

  return 0;
}

