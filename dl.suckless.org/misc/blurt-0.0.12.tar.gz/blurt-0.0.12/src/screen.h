/* $Id: screen.h,v 1.17 2001/03/13 16:23:00 zarq Exp $

   Copyright (c) 2001 Ivo Timmermans <irt@cistron.nl>
   All rights reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:

   1. Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

   3. Neither the name of the author, the name of the program, nor the
      names of its contributors may be used to endorse or promote
      products derived from this software without specific prior
      written permission.

   THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
   AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
   TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
   USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
   ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
   OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
   OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
   SUCH DAMAGE.
*/

#ifndef __BLURT_SCREEN_H__
#define __BLURT_SCREEN_H__

/*
#define DEFAULT_FONT "fixed"
#define DEFAULT_BOLD_FONT "fixed"
*/

#define DEFAULT_FONT "lucidasanstypewriter-12"
#define DEFAULT_BOLD_FONT "lucidasanstypewriter-bold-12"

#define DEFAULT_NR_ROWS 24
#define DEFAULT_NR_COLS 80

extern int screen_cols;
extern int screen_rows;

extern int scroll_region_start;
extern int scroll_region_end ;
extern int scroll_in_region;

typedef struct text_letter_t {
#ifndef BIGENDIAN
  unsigned letter: 8;
  unsigned fg: 3;
  unsigned bg: 3;
  unsigned bold: 1;
  unsigned rev: 1;
  unsigned sel: 1;
  int padding: 15;
#else
  int padding: 15;
  unsigned sel: 1;
  unsigned rev: 1;
  unsigned bold: 1;
  unsigned fg: 3;
  unsigned bg: 3;
  unsigned letter: 8;
#endif /* BIGENDIAN */
} text_letter_t;

typedef struct text_row_t {
  text_letter_t *line;
  int needs_update;
} text_row_t;

extern text_row_t *text_screen;

extern text_letter_t text_attrs;

extern int init_screen(void);
extern int init_window(void);
extern void wait_for_specific_event(int);
extern struct winsize *get_font_dim(void);
extern void buffer_resize(int,int);
extern void cursor_rego(void);
extern void redraw_screen(void);
extern void redraw_region(int,int,int,int);

#endif
