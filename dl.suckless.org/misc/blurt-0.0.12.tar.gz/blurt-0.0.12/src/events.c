/* $Id: events.c,v 1.19 2001/03/14 01:09:31 zarq Exp $

   Copyright (c) 2001 Ivo Timmermans <irt@cistron.nl>
   All rights reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:

   1. Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

   3. Neither the name of the author, the name of the program, nor the
      names of its contributors may be used to endorse or promote
      products derived from this software without specific prior
      written permission.

   THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
   AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
   TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
   USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
   ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
   OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
   OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
   SUCH DAMAGE.
*/

#include <assert.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <termios.h>

#include <X11/Xatom.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/cursorfont.h>
#include <X11/keysym.h>
#include <X11/Xmd.h>

#include "process.h"
#include "screen.h"
#include "ui.h"
#include "util.h"

#include "keys.h"

#define REFRESH_NO        0
#define REFRESH_FULL      1
#define REFRESH_PARTIALLY 2

#define KEYSEQLEN 10

#define ModMetaMask Mod4Mask

#define Atom32 CARD32

int refresh_type = 0;

int saved_cursor_x, saved_cursor_y;

int application_keypad_mode = 0;
int insert_mode = 0;
int decckm_mode = 0;
int wraparound_mode = 0;
int cursor_visible = 1;
int using_alternate_screen = 0;

char           *eventnames[] = {    /* mason - this matches my system */
  "",
  "",
  "KeyPress",
  "KeyRelease",
  "ButtonPress",
  "ButtonRelease",
  "MotionNotify",
  "EnterNotify",
  "LeaveNotify",
  "FocusIn",
  "FocusOut",
  "KeymapNotify",
  "Expose",
  "GraphicsExpose",
  "NoExpose",
  "VisibilityNotify",
  "CreateNotify",
  "DestroyNotify",
  "UnmapNotify",
  "MapNotify",
  "MapRequest",
  "ReparentNotify",
  "ConfigureNotify",
  "ConfigureRequest",
  "GravityNotify",
  "ResizeRequest",
  "CirculateNotify",
  "CirculateRequest",
  "PropertyNotify",
  "SelectionClear",
  "SelectionRequest",
  "SelectionNotify",
  "ColormapNotify",
  "ClientMessage",
  "MappingNotify"
};

void handle_keypress(XEvent *xev)
{
  char kbuf[KEYSEQLEN];
  KeySym keysym;
  static XComposeStatus compose = {NULL, 0};
  int len;
  int meta;
  int shift;

  meta = xev->xkey.state & ModMetaMask;
  shift = xev->xkey.state & ShiftMask;
  len = XLookupString(&(xev->xkey), &kbuf[0], sizeof(kbuf), &keysym, &compose);
  if(len > 0)
    {
      kbuf[KEYSEQLEN-1] = 0;
      if(meta && len == 1)
	cmd_write("\033", 1);
      cmd_write(kbuf, len);
      return;
    }
  if(keysym >= XK_Shift_L && keysym <= XK_Hyper_R)
    /* modifiers, these are handled by XLookupString */
    return;
	  
  switch(keysym)
    {
    case XK_Up:
    case XK_Down:
    case XK_Left:
    case XK_Right:
      kbuf[0] = '\033';
      if(decckm_mode)
	kbuf[1] = 'O';
      else
	kbuf[1] = '[';
      kbuf[2] = "DACB"[keysym - XK_Left];
      cmd_write(kbuf, 3);
      break;
    case XK_Delete:
      cmd_write(DELETE_KEY, sizeof(DELETE_KEY)-1);
      break;
    case XK_Home:
      cmd_write(HOME_KEY, sizeof(HOME_KEY)-1);
      break;
    case XK_End:
      cmd_write(END_KEY, sizeof(END_KEY)-1);
      break;
    case XK_Prior:
      cmd_write(PREV_KEY, sizeof(PREV_KEY)-1);
      break;
    case XK_Next:
      cmd_write(NEXT_KEY, sizeof(NEXT_KEY)-1);
      break;
    case XK_Insert:
      if(shift)
	selection_paste(CurrentTime);
      break;
    default:
      fprintf(stderr, "Unhandled special key: %d\n",
	      (int)keysym);
      break;
    }
}

void handle_resize(XEvent *xev)
{
  int new_cols, new_rows;

  new_cols = xev->xconfigure.width / font_width;
  new_rows = xev->xconfigure.height / font_height;
  if(new_cols != screen_cols || new_rows != screen_rows)
    {
      buffer_resize(new_rows, new_cols);

      screen_cols = new_cols;
      screen_rows = new_rows;
      scroll_region_start = 1;
      scroll_region_end = screen_rows;
      window_width = xev->xconfigure.width;
      window_height = xev->xconfigure.height;

      /* make sure the cursor is within the window */
      cursor_rego();

      /* Finally: pass the info to the application */
      resize_app();

      /* and redraw */
      force_redraw_screen();
    }
}

static int selection_start_col, selection_start_row, selection_end_col, selection_end_row;
static int selection_mode = 0;

static unsigned char *selection_text = NULL;

#define SELECT_NONE 0
#define SELECT_LETTER 1
#define SELECT_WORD 2
#define SELECT_LINE 3

void selection_reset(void)
{
  int i, j;
  
  selection_mode = SELECT_NONE;
  for(i = 0; i < screen_rows; i++)
    {
      for(j = 0; j < screen_cols; j++)
	text_screen[i].line[j].sel = 0;
      text_screen[i].needs_update = 1;
    }

  if(selection_text)
    {
      free(selection_text);
      selection_text = NULL;
    }
}

void selection_start(int row, int col, Time tm)
{
  fprintf(stderr, "Selection started, row=%d, col=%d\n", row, col);
  selection_start_col = col, selection_start_row = row;
  selection_end_col = col, selection_end_row = row;
  selection_mode = SELECT_LETTER;
}

void selection_select_word(int row, int col, Time tm)
{
  int i, len;

  if(selection_text)
    free(selection_text);
  selection_text = malloc(screen_cols+1);
  assert(selection_text);
  fprintf(stderr, "Select word on %d,%d\n", col, row);
  i = col - 1;
  while(i >= 0 && isalnum(text_screen[row-1].line[i].letter))
    i--;
  i++;
  len = 0;
  while((i < screen_cols) && isalnum(text_screen[row-1].line[i].letter))
    {
      selection_text[len++] = text_screen[row-1].line[i].letter;
      text_screen[row-1].line[i].sel = 1;
      i++;
    }
  fprintf(stderr, "len=%d\n", len);
  text_screen[row-1].needs_update = 1;
  XStoreBuffer(Xdisplay, selection_text, len, XA_CUT_BUFFER0);
  XSetSelectionOwner(Xdisplay, XA_PRIMARY, MainWindow, tm);
}

void selection_select_line(int row, int col, Time tm)
{
  int i;

  if(selection_text)
    free(selection_text);
  selection_text = malloc(screen_cols+1);
  assert(selection_text);
  fprintf(stderr, "select line %d\n", row);
  for(i = 0; i < screen_cols; i++)
    {
      selection_text[i] = text_screen[row-1].line[i].letter;
      text_screen[row-1].line[i].sel = 1;
    }
  while(selection_text[i] == ' ') i--;
  text_screen[row-1].needs_update=1;
  XStoreBuffer(Xdisplay, selection_text, screen_cols, XA_CUT_BUFFER0);
  XSetSelectionOwner(Xdisplay, XA_PRIMARY, MainWindow, tm);
}

void selection_paste(Time tm)
{
  int nbytes;
  char *text;

  XConvertSelection(Xdisplay, XA_PRIMARY, XA_CUT_BUFFER0, None, MainWindow, tm);
  text = XFetchBytes(Xdisplay, &nbytes);
  cmd_write(text, nbytes);
}

void handle_buttonpress(XEvent *xev)
{
  static int lastclick_time = 0;
  static int times_clicked = 0;
  int click_col, click_row;
  int button;

  click_col = xev->xbutton.x / font_width + 1;
  click_row = xev->xbutton.y / font_height + 1;
  click_col = click_col > screen_cols ? screen_cols : (click_col < 1 ? 1 : click_col);
  click_row = click_row > screen_rows ? screen_rows : (click_row < 1 ? 1 : click_row);
  button = xev->xbutton.button;
  fprintf(stderr, "Mouse button %d pressed on (%d,%d)\n", button, click_col, click_row);

  switch(button)
    {
    case 1:
      if(xev->xbutton.time <= lastclick_time + 600 &&
	 xev->xbutton.time > lastclick_time)
	  times_clicked = (times_clicked) % 3 + 1;
      else
	times_clicked = 0;
      
      switch(times_clicked)
	{
	case SELECT_NONE:
	case SELECT_LETTER:
	  selection_reset();
	  selection_start(click_row, click_col, xev->xbutton.time);
	  times_clicked = 1;
	  break;
	case SELECT_WORD:
	  selection_select_word(click_row, click_col, xev->xbutton.time);
	  break;
	case SELECT_LINE:
	  selection_select_line(click_row, click_col, xev->xbutton.time);
	  break;
	}
      lastclick_time = xev->xbutton.time;
      break;
    case 2: /* middle button */
      selection_paste(xev->xbutton.time);
      break;
    case 3: /* right button */
      break;
    }
}

void handle_motionnotify(XEvent *xev)
{
  int unused;
  while(XCheckTypedWindowEvent(Xdisplay, MainWindow, MotionNotify, xev));
  XQueryPointer(Xdisplay, MainWindow, &unused, &unused,
		&unused, &unused, &(xev->xbutton.x), &(xev->xbutton.y), &unused);
}

void selection_copy(XEvent *xev)
{
  XEvent ev;
  XSelectionRequestEvent *rq = (XSelectionRequestEvent*)xev;
  Atom32          target_list[4];
  Atom            target;
  static Atom     xa_targets = None;
  static Atom     xa_compound_text = None;
  static Atom     xa_text = None;
  XTextProperty   ct;
  XICCEncodingStyle style;
  char           *cl[4];

  if(!selection_text)
    return;
  
  ev.xselection.type = SelectionNotify;
  ev.xselection.property = None;
  ev.xselection.display = rq->display;
  ev.xselection.requestor = rq->requestor;
  ev.xselection.selection = rq->selection;
  ev.xselection.target = rq->target;
  ev.xselection.time = rq->time;

  if (rq->target == None)
    {
      target_list[0] = (Atom32) xa_targets;
      target_list[1] = (Atom32) XA_STRING;
      target_list[2] = (Atom32) xa_text;
      target_list[3] = (Atom32) xa_compound_text;
      XChangeProperty(Xdisplay, rq->requestor, rq->property, rq->target,
		      (8 * sizeof(target_list[0])), PropModeReplace,
		      (unsigned char *)target_list,
		      (sizeof(target_list) / sizeof(target_list[0])));
      ev.xselection.property = rq->property;
    }
  else if (rq->target == XA_STRING
	   || rq->target == xa_compound_text
	   || rq->target == xa_text)
    {
      if (rq->target == XA_STRING)
	{
	  style = XStringStyle;
	  target = XA_STRING;
	}
      else
	{
	  target = xa_compound_text;
	  style = (rq->target == xa_compound_text) ? XCompoundTextStyle
	    : XStdICCTextStyle;
	}
      cl[0] = selection_text;
      XmbTextListToTextProperty(Xdisplay, cl, 1, style, &ct);
      XChangeProperty(Xdisplay, rq->requestor, rq->property,
		      target, 8, PropModeReplace,
		      ct.value, ct.nitems);
      ev.xselection.property = rq->property;
    }
  XSendEvent(Xdisplay, rq->requestor, False, 0, &ev);
}

int handle_x_events(void)
{
  XEvent xev;

  /* Input from the X server */
  while (XPending(Xdisplay))
    {
      /* process pending X events */
      XNextEvent(Xdisplay, &xev);

      switch(xev.type)
	{
	case ButtonPress:
	  handle_buttonpress(&xev);
	  break;
	case MotionNotify:
	  handle_motionnotify(&xev);
	  break;
	case KeyPress:
	  handle_keypress(&xev);
	  break;
	case ConfigureNotify:
	  handle_resize(&xev);
	  break;
	case SelectionNotify:
	  /* Ignore this? */
	  break;
	case GraphicsExpose:
	case Expose:
	  /* Part of the window needs a redraw */
	  switch(refresh_type)
	    {
	    case REFRESH_FULL:
	      force_redraw_screen();
	      break;
	    case REFRESH_PARTIALLY:
	      {
		int a,b,c,d;
		a = xev.xexpose.x / font_width + 1;
		b = xev.xexpose.y / font_height + 1;
		c = (xev.xexpose.x + xev.xexpose.width) / font_width + 1;
		d = (xev.xexpose.y + xev.xexpose.height) / font_height + 1;
		a = a > screen_cols ? screen_cols : a;
		b = b > screen_rows ? screen_rows : b;
		c = c > screen_cols ? screen_cols : c;
		d = d > screen_rows ? screen_rows : d;
		redraw_region(a,b,c,d);
	      }
	      break;
	    default:
	      /* No refreshing needs to be done */
	    }
	  break;
	case VisibilityNotify:
	  /* Some part of the screen has to be redrawn */
	  switch(xev.xvisibility.state)
	    {
	    case VisibilityUnobscured:
	      refresh_type = REFRESH_FULL;
	      break;
	    case VisibilityPartiallyObscured:
	      refresh_type = REFRESH_PARTIALLY;
	      break;
	    default:
	      refresh_type = REFRESH_NO;
	      break;
	    }
	  break;
	case MapNotify:
	case UnmapNotify:
	case FocusIn:
	case FocusOut:
	case NoExpose:
	  /* Silently unhandled for now */
	  break;
	case SelectionClear:
	  selection_reset();
	  free(selection_text);
	  selection_text = NULL;
	  break;
	case SelectionRequest:
	  fprintf(stderr, "SelectionRequest\n");
	  selection_copy(&xev);
	  break;
	default:
	  fprintf(stderr, "Got unhandled X event %d (%s)\n", xev.type, eventnames[xev.type]);
	}
    }

  return 0;
}

int set_x_event_mask(void)
{
  XSelectInput(Xdisplay, MainWindow, KeyPressMask | ButtonPressMask
	       | FocusChangeMask | VisibilityChangeMask
	       | StructureNotifyMask | ExposureMask
	       | Button1MotionMask | Button3MotionMask);
  return 0;
}

