/* $Id: ui.h,v 1.4 2001/03/11 20:07:45 zarq Exp $

   Copyright (c) 2001 Ivo Timmermans <irt@cistron.nl>
   All rights reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:

   1. Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

   3. Neither the name of the author, the name of the program, nor the
      names of its contributors may be used to endorse or promote
      products derived from this software without specific prior
      written permission.

   THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
   AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
   TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
   USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
   ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
   OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
   OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
   SUCH DAMAGE.
*/

#ifndef __BLURT__UI_H__
#define __BLURT__UI_H__

#include <X11/Xlib.h>

extern XColor colors[9];
extern XColor bgcolors[8];
#define DEFAULT_BACKGROUND_COLOR colors[0]
#define DEFAULT_FOREGROUND_COLOR colors[7]
extern XColor cursor_color;

extern Display *Xdisplay;
extern Window MainWindow;
extern XFontStruct *Xfont;
extern XFontStruct *Xboldfont;
extern GC Xgc;
extern Colormap Xcolmap;
extern Cursor Xcursor;

extern XColor colors[9];
extern XColor cursor_color;
extern int Xdepth;
extern Visual *Xvisual;
extern int Xscreen;

extern int window_width;
extern int window_height;

extern int font_height;
extern int font_width;

extern void force_redraw_screen(void);

extern void win_set_window_title(char *);
#define win_set_icon_title win_set_window_title

#endif
