# TODO

* suckless adblocking
* integrate the WebKitWebInspector API
* make scrollbars a switch and allow them to be disabled
* replace webkit with something sane
* add video player options
	* play in plugin
	* play in video player
	* call command with URI (quvi + cclive)

