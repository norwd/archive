ENCODING="utf8" \
TYPE="sentence" \
REALTYPE="sentence" \
	$SH man/template/next_break.sh
