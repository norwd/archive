ENCODING="utf8" \
TYPE="character" \
REALTYPE="grapheme cluster" \
	$SH man/template/next_break.sh
