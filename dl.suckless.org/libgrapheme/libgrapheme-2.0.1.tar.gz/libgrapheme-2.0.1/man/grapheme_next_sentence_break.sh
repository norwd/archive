ENCODING="codepoint" \
TYPE="sentence" \
REALTYPE="sentence" \
	$SH man/template/next_break.sh
