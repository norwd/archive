ENCODING="codepoint" \
CASE="lowercase" \
	$SH man/template/is_case.sh
