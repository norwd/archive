ENCODING="utf8" \
CASE="lowercase" \
	$SH man/template/to_case.sh
