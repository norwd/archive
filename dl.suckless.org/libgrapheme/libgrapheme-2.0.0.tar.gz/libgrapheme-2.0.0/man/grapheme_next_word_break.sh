ENCODING="codepoint" \
TYPE="word" \
REALTYPE="word" \
	$SH man/template/next_break.sh
