ENCODING="utf8" \
CASE="titlecase" \
	$SH man/template/to_case.sh
