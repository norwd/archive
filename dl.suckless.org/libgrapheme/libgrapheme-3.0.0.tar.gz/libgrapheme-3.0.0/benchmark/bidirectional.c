/* See LICENSE file for copyright and license details. */
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../gen/bidirectional-test.h"
#include "../grapheme.h"
#include "util.h"

#define NUM_ITERATIONS 100000

int
main(int argc, char *argv[])
{
	(void)argc;
	(void)argv;

	return 0;
}
