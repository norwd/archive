ENCODING="utf8" \
TYPE="word" \
REALTYPE="word" \
	$SH man/template/next_break.sh
