ENCODING="codepoint" \
CASE="titlecase" \
	$SH man/template/is_case.sh
