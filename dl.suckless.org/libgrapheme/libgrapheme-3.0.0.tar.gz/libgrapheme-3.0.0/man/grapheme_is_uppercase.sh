ENCODING="codepoint" \
CASE="uppercase" \
	$SH man/template/is_case.sh
