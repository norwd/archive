ENCODING="utf8" \
TYPE="line" \
REALTYPE="possible line" \
	$SH man/template/next_break.sh
