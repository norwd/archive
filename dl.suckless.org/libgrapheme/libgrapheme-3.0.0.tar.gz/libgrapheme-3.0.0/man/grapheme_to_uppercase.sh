ENCODING="codepoint" \
CASE="uppercase" \
	$SH man/template/to_case.sh
