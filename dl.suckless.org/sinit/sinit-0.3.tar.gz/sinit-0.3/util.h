/* See LICENSE file for copyright and license details. */

#define LEN(x) (sizeof (x) / sizeof *(x))

void enprintf(int, const char *, ...);
void eprintf(const char *, ...);
void weprintf(const char *, ...);
