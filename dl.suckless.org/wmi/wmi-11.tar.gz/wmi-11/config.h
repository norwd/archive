#pragma once
//#define DEBUG
//#define DIAMOND
//#define SLOT_SUPPORT
//#define XFT_SUPPORT
