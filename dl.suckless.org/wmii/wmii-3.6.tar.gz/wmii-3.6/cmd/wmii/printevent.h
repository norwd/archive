void printevent(XEvent*);
