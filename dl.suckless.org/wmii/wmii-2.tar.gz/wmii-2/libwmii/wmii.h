/*
 * (C)opyright MMIV-MMV Anselm R. Garbe <garbeam at gmail dot com>
 * See LICENSE file for license details.
 */

/** \addtogroup libwmii 
 * common functions for wmii parts & modules
 * @{ */

#include "ixp.h"
#include "blitz.h"

#define STRLEN1(X) strlen(X) + 1

/* ixputil.c */
File *wmii_create_ixpfile(IXPServer * s, char *key, char *val);
void wmii_get_ixppath(File * f, char *path, size_t size);
void wmii_move_ixpfile(File * f, File * to_parent);
IXPServer *wmii_setup_server(char *sockfile, size_t socklen,
                             char *binname);

/** @} */
