/* See LICENSE file for copyright and license details. */
int mkpath(const char *path, mode_t mode);
