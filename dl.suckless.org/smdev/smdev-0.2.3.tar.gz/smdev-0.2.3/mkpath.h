/* See LICENSE file for copyright and license details. */
int mkpath(const char *, mode_t);
